<?php /** Piano di cura (Cartella per problemi) · @var array $doc @var array $paziente @var array $medico @var array $problemi @var bool $auto_print */ ?>
<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8"><title>Piano di cura · <?= e($paziente['nome_completo']) ?></title><?php include DRF_ROOT . '/docs/templates/_stile.php'; ?>
<style>.prob{border:1px solid #E4E6F0;border-radius:10px;padding:12px 14px;margin:0 0 10px}.prob b{font-size:14px}.prob .meta{color:#5C6174;font-size:11.5px;margin:2px 0 6px}.prob .p{white-space:pre-wrap}.prob .old{color:#5C6174;font-size:12px;margin-top:6px;border-top:1px dashed #E4E6F0;padding-top:6px}</style></head>
<body>
<div class="toolbar"><button class="ghost" onclick="window.close()">Chiudi</button><button onclick="window.print()">Stampa / salva PDF</button></div>
<div class="foglio">
  <header>
    <div class="medico"><b><?= e($medico['nome_completo']) ?></b><div><?= e($medico['specializzazione']) ?> · <?= e($medico['studio']) ?><br><?= e($medico['indirizzo']) ?> · <?= e($medico['telefono']) ?></div></div>
    <div class="destinatario"><b><?= e($paziente['nome_completo']) ?></b><?php if (!empty($paziente['cf'])): ?><span class="mono">CF <?= e($paziente['cf']) ?></span><?php endif; ?></div>
  </header>
  <div class="doc-riga"><b>Piano di cura</b> aggiornato al <?= data_it($doc['data']) ?><?= $paziente['eta'] !== null ? ' · paziente di ' . $paziente['eta'] . ' anni' : '' ?></div>
  <?php if (!$problemi): ?><p>Nessun problema attivo.</p><?php endif; ?>
  <?php foreach ($problemi as $i => $p): ?>
    <div class="prob"><b><?= $i + 1 ?>. <?= e($p['titolo']) ?></b>
      <div class="meta">aperto il <?= data_it($p['aperto_il']) ?><?= $p['ultima_il'] ? ' · ultima valutazione ' . data_it($p['ultima_il']) : '' ?></div>
      <?php if ($p['ultimo_piano']): ?><div class="p"><?= nl2br(e($p['ultimo_piano'])) ?></div><?php else: ?><div class="p" style="color:#9AA0B3">Piano non ancora definito</div><?php endif; ?>
      <?php $prec = array_slice($p['note'], 1); if ($prec): ?><div class="old"><?php foreach ($prec as $n): ?><div><b><?= data_it($n['data']) ?></b> · <?= e($n['p']) ?></div><?php endforeach; ?></div><?php endif; ?>
    </div>
  <?php endforeach; ?>
  <div class="firma"><div><b><?= e($medico['nome']) ?></b></div></div>
  <footer><?= e($medico['studio']) ?> · P.IVA <?= e($medico['piva']) ?></footer>
</div>
<?php if ($auto_print): ?><script>window.print()</script><?php endif; ?>
</body></html>
