<?php
/**
 * BACHECA PERSONALE (codice: bacheca) — il menu sull'avatar. Esempio guida per menu.voci.
 * Le voci STATICHE si dichiarano qui (arrivano al client in DRF.config.menu); quelle DINAMICHE (con i numeri del giorno)
 * le aggiunge js/bacheca.js con il filtro JS omonimo, che riceve la lista già pronta e la trasforma.
 * Le note personali sono PER UTENTE: chiave impostazione bacheca_note_<id utente> (prefisso del codice: nessuna capability).
 */
Hooks::add('menu.voci', function (array $v) {
    $v[] = ['label' => 'Il mio profilo', 'fi' => 'user', 'fa' => 'fa-solid fa-user', 'modulo' => 'impostazioni'];
    $v[] = ['label' => 'Scorciatoie da tastiera', 'fi' => 'keyboard', 'fa' => 'fa-regular fa-keyboard', 'comando' => 'bacheca:scorciatoie'];
    return $v;
});
