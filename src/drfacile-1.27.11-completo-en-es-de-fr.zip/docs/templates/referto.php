<?php /** @var array $doc @var array $paziente @var array $medico @var bool $auto_print */ ?>
<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8"><title><?= e($doc['tipo']) ?> · <?= e($paziente['nome_completo']) ?></title><?php include __DIR__ . '/_stile.php'; ?></head>
<body>
<div class="toolbar"><button class="ghost" onclick="window.close()">Chiudi</button><button onclick="window.print()">Stampa / salva PDF</button></div>
<div class="foglio">
  <?php $destra = '<div class="destinatario">' . (($tipo ?? '') === 'fattura' ? '<span class="dest-eyebrow">Spett.le</span>' : '') . '<b>' . e($paziente['nome_completo']) . '</b>'
  . (!empty($paziente['indirizzo']) ? '<span>' . e($paziente['indirizzo']) . '</span>' : '')
  . (($riga2 = trim(implode(' ', array_filter([$paziente['cap'] ?? '', $paziente['citta'] ?? '', !empty($paziente['provincia']) ? '(' . $paziente['provincia'] . ')' : ''])))) !== '' ? '<span>' . e($riga2) . '</span>' : '')
  . (!empty($paziente['cf']) ? '<span class="mono">CF ' . e($paziente['cf']) . '</span>' : '') . '</div>'; include __DIR__ . '/_testata.php'; ?>
  <div class="doc-riga"><b><?= e($doc['tipo']) ?></b> del <?= data_it($doc['data']) ?> · n. <?= (int) $doc['id'] ?><?= $paziente['eta'] !== null ? ' · paziente di ' . $paziente['eta'] . ' anni (' . data_it($paziente['nascita']) . ')' : '' ?></div>
  <?php foreach ($doc['sezioni'] as $titolo => $testo): ?>
    <h2><?= e($titolo) ?></h2><?= str_contains((string) $testo, '<') ? '<div class="rich-out">' . rich_txt($testo) . '</div>' : '<p>' . nl2br(e($testo)) . '</p>' ?>
  <?php endforeach; ?>
  <div class="firma"><div>
    <?php if ($doc['stato'] === 'bozza'): ?><span class="badge">Bozza, non ancora firmato</span>
    <?php else: ?><b><?= e($medico['nome']) ?></b>Firmato digitalmente il <?= date('d/m/Y H:i', strtotime($doc['firmato_il'] ?? $doc['data'])) ?><?php endif; ?>
  </div></div>
  <?php ob_start(); ?><?= e($medico['studio']) ?> · P.IVA <?= e($medico['piva']) ?> · Ordine <?= e($medico['ordine']) ?><?php $piede_extra = '<div class="riga-studio">' . trim(ob_get_clean()) . '</div>'; include __DIR__ . '/_piede.php'; ?>
</div>
<?php if ($auto_print): ?><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),300))</script><?php endif; ?>
</body></html>
