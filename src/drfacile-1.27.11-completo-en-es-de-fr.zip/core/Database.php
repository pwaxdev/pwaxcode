<?php
/**
 * Wrapper PDO minimale. Supporta SQLite (default) e MySQL.
 * Tutte le query passano da prepared statement.
 * Due livelli: il database BASE di config.php (init) e, nel SaaS, il database DEDICATO dello studio (tenant):
 * le tabelle comuni si raggiungono sempre con Database::comune('tabella').
 */
final class Database
{
    private static ?PDO $pdo = null;
    private static string $driver = 'sqlite';
    private static string $common = '';   // database delle tabelle condivise: vuoto = stesso database (MySQL: nome del db; SQLite: alias dell'ATTACH)
    private static array $base = [];      // la configurazione di config.php (il database "base": comune + studio predefinito)
    private static ?int $tenant = null;   // id dello studio se è attivo un database dedicato (Database::tenant)

    /** Connessione al database BASE di config.php: tabelle comuni + studio predefinito (installazioni monostudio e legacy) */
    public static function init(array $cfg): void
    {
        self::$base = $cfg;
        self::$tenant = null;
        self::connetti($cfg, false);
    }

    /**
     * SaaS: passa al database DEDICATO di uno studio (core/Tenant.php), tenendo raggiungibili le tabelli comuni del base.
     *   MySQL  → nuova connessione al db dello studio; il comune resta `dbcomune`.tabella (db.common, o il db del base)
     *   SQLite → apre il file dello studio e fa ATTACH del file base come `comune`
     * $cfg ha la stessa forma di config db: ['driver' => 'sqlite', 'sqlite' => 'percorso'] oppure ['driver' => 'mysql', 'mysql' => ['dsn', 'user', 'pass']]
     * (percorsi SQLite relativi = relativi a DRF_ROOT; user/pass MySQL assenti = quelli del base).
     */
    public static function tenant(int $studioId, array $cfg): void
    {
        $cfg['driver'] = $cfg['driver'] ?? self::$base['driver'] ?? 'sqlite';
        if ($cfg['driver'] === 'mysql') {
            $cfg['mysql'] = ($cfg['mysql'] ?? []) + (self::$base['mysql'] ?? []);
            $cfg['common'] = self::$base['common'] ?: self::nomeDb((string) (self::$base['mysql']['dsn'] ?? ''));
            if ($cfg['common'] === '') throw new RuntimeException('Tenant MySQL: impossibile determinare il database comune');
        } else {
            if (!str_starts_with((string) $cfg['sqlite'], '/')) $cfg['sqlite'] = DRF_ROOT . '/' . ltrim((string) $cfg['sqlite'], '/');
        }
        self::connetti($cfg, true);
        self::$tenant = $studioId;
    }

    /** Id dello studio con database dedicato attivo (null = database base) */
    public static function tenantId(): ?int { return self::$tenant; }
    public static function configBase(): array { return self::$base; }

    private static function nomeDb(string $dsn): string { return preg_match('/dbname=([^;]+)/', $dsn, $m) ? $m[1] : ''; }

    private static function connetti(array $cfg, bool $dedicato): void
    {
        self::$driver = $cfg['driver'] ?? 'sqlite';
        self::$common = self::$driver === 'mysql' ? trim((string) ($cfg['common'] ?? '')) : '';
        if (self::$driver === 'mysql') {
            $m = $cfg['mysql'];
            $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4, sql_mode = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION'"];
            try {
                self::$pdo = new PDO($m['dsn'], $m['user'], $m['pass'], $opt);
            } catch (PDOException $e) {
                // 1049 = database inesistente: lo creiamo (serve il privilegio CREATE) e ci riconnettiamo
                if (!str_contains($e->getMessage(), '1049') || !preg_match('/dbname=([^;]+)/', $m['dsn'], $mm)) throw $e;
                $tmp = new PDO(preg_replace('/dbname=[^;]+;?/', '', $m['dsn']), $m['user'], $m['pass'], $opt);
                $tmp->exec('CREATE DATABASE IF NOT EXISTS `' . str_replace('`', '', $mm[1]) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                self::$pdo = new PDO($m['dsn'], $m['user'], $m['pass'], $opt);
            }
            if (self::$common !== '') self::$pdo->exec('CREATE DATABASE IF NOT EXISTS `' . self::$common . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        } else {
            $path = $cfg['sqlite'];
            if (!is_dir(dirname($path))) mkdir(dirname($path), 0775, true);
            self::$pdo = new PDO('sqlite:' . $path, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
            self::$pdo->exec('PRAGMA foreign_keys = ON');
            self::$pdo->exec('PRAGMA journal_mode = WAL');
            if ($dedicato) {   // le tabelle comuni (studi, utenti, store_moduli, comuni…) restano nel file base
                self::$pdo->exec("ATTACH DATABASE '" . str_replace("'", "''", (string) self::$base['sqlite']) . "' AS comune");
                self::$common = 'comune';
            }
        }
    }

    public static function pdo(): PDO { return self::$pdo; }
    public static function driver(): string { return self::$driver; }

    /** Nome qualificato di una tabella condivisa fra tutti gli ambienti (es. comuni, aifa, icd) */
    public static function comune(string $table): string
    {
        return self::$common !== '' ? '`' . self::$common . '`.' . $table : $table;
    }
    public static function commonDb(): string { return self::$common; }

    /** Concatenazione portabile: SQLite usa ||, MySQL CONCAT() */
    public static function concat(string ...$parts): string
    {
        return self::$driver === 'mysql' ? 'CONCAT(' . implode(', ', $parts) . ')' : implode(' || ', $parts);
    }

    public static function run(string $sql, array $params = []): PDOStatement
    {
        $st = self::$pdo->prepare($sql);
        $st->execute($params);
        return $st;
    }

    public static function all(string $sql, array $params = []): array { return self::run($sql, $params)->fetchAll(); }
    public static function one(string $sql, array $params = []): ?array { $r = self::run($sql, $params)->fetch(); return $r === false ? null : $r; }
    public static function value(string $sql, array $params = []): mixed { $v = self::run($sql, $params)->fetchColumn(); return $v === false ? null : $v; }

    public static function insert(string $table, array $data): int
    {
        Capabilities::tabella($table, true);
        $cols = array_keys($data);
        $sql = sprintf('INSERT INTO %s (%s) VALUES (%s)', $table, implode(',', $cols), implode(',', array_map(fn($c) => ':' . $c, $cols)));
        self::run($sql, $data);
        return (int) self::$pdo->lastInsertId();
    }

    public static function update(string $table, array $data, string $where, array $params = []): int
    {
        Capabilities::tabella($table, true);
        $set = implode(', ', array_map(fn($c) => "$c = :set_$c", array_keys($data)));
        $bind = $params;
        foreach ($data as $c => $v) $bind["set_$c"] = $v;
        return self::run("UPDATE $table SET $set WHERE $where", $bind)->rowCount();
    }

    public static function delete(string $table, string $where, array $params = []): int
    {
        Capabilities::tabella($table, true);
        return self::run("DELETE FROM $table WHERE $where", $params)->rowCount();
    }

    public static function tableExists(string $table): bool
    {
        try {
            if (self::$driver === 'mysql') {
                if (str_contains($table, '.')) { [$db, $t] = explode('.', str_replace('`', '', $table), 2); return (bool) self::value('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = ?', [$db, $t]); }
                return (bool) self::value('SHOW TABLES LIKE ?', [$table]);
            }
            if (str_contains($table, '.')) { [$db, $t] = explode('.', str_replace('`', '', $table), 2); return (bool) self::value("SELECT name FROM `$db`.sqlite_master WHERE type='table' AND name = ?", [$t]); }
            return (bool) self::value("SELECT name FROM sqlite_master WHERE type='table' AND name = ?", [$table]);
        } catch (Throwable) { return false; }
    }

    /** Colonne di una tabella con il tipo dichiarato: [nome => tipo] (es. 'varchar(255)', 'text', 'int') */
    public static function colonneTipi(string $table): array
    {
        $out = [];
        if (self::$driver === 'mysql') { foreach (self::all("SHOW COLUMNS FROM `$table`") as $c) $out[$c['Field']] = strtolower($c['Type']); }
        else { foreach (self::all("PRAGMA table_info($table)") as $c) $out[$c['name']] = strtolower($c['type']); }
        return $out;
    }

    /** Elenco delle colonne di una tabella */
    public static function colonne(string $table): array
    {
        if (self::$driver === 'mysql') return array_column(self::all("SHOW COLUMNS FROM `$table`"), 'Field');
        return array_column(self::all("PRAGMA table_info($table)"), 'name');
    }

    public static function transaction(callable $fn): mixed
    {
        self::$pdo->beginTransaction();
        try { $r = $fn(); self::$pdo->commit(); return $r; }
        catch (Throwable $e) { self::$pdo->rollBack(); throw $e; }
    }
}
