<?php
/**
 * PROVISIONING SaaS: crea e amministra gli STUDI (tenant) dal backend (il portale DRFacile, dopo la
 * registrazione o il pagamento, chiama questo script — o esegue le stesse operazioni).
 *
 *   php strumenti/studio.php                                        → elenco degli studi
 *   php strumenti/studio.php crea "Studio Rossi" --sqlite=data/studi/rossi.sqlite \
 *        --utente=rossi --password=segreta123 --cognome=Rossi [--nome=Mario] [--email=…] [--scadenza=+365 | AAAA-MM-GG, default +30] [--periodo=mensile]
 *   php strumenti/studio.php crea "Studio Rossi" --mysql=drfacile_rossi [--mysql-user=… --mysql-pass=…] --utente=… --password=… --cognome=…
 *   php strumenti/studio.php crea "Studio Rossi" --utente=… --password=… --cognome=…   → SENZA database dedicato: usa il base (solo monostudio)
 *   php strumenti/studio.php database 3 --sqlite=data/studi/rossi.sqlite              → assegna/cambia il database di uno studio già esistente
 *   php strumenti/studio.php utente 3 --utente=segre --password=… --cognome=… [--ruolo=segreteria] [--admin]
 *   php strumenti/studio.php disattiva 3 | attiva 3                                   → sospende/riattiva l'accesso di tutti gli utenti dello studio
 *   php strumenti/studio.php acquisto 3 sms --metodo=bonifico --note="bonifico del 3/9"  → attiva un pacchetto/servizio dello Store senza carta
 *   php strumenti/studio.php sms 3 +500 | 0                                          → credito SMS: aggiunge o imposta (il portale lo chiama dopo l'acquisto del pacchetto)
 *   php strumenti/studio.php quota 3 +5120 | 10240 | 0                                → spazio dell'archivio in MB: aggiunge, imposta, illimitato (il portale lo chiama dopo l'acquisto)
 *
 * Il database dedicato viene creato subito con lo schema completo (senza dati dimostrativi).
 * Un percorso SQLite relativo è relativo alla cartella di DRFacile. Per MySQL, user/pass assenti = quelli di config.php
 * (il database viene creato se l'utente ha il privilegio CREATE).
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
require __DIR__ . '/../core/bootstrap.php';

$args = array_slice($argv, 1); $opt = []; $pos = [];
foreach ($args as $a) {
    if (preg_match('/^--([a-z-]+)(?:=(.*))?$/', $a, $m)) $opt[$m[1]] = $m[2] ?? true;
    else $pos[] = $a;
}
$cmd = $pos[0] ?? 'elenco';
$S = Database::comune('studi'); $U = Database::comune('utenti');

$elenco = function () use ($S, $U): void {
    echo "Studi:\n";
    foreach (Database::all("SELECT * FROM $S ORDER BY id") as $s) {
        $n = (int) Database::value("SELECT COUNT(*) FROM $U WHERE studio_id = ? AND attivo = 1", [$s['id']]);
        $db = Tenant::configDb($s);
        $dbTxt = !$db ? 'database base' : ($db['driver'] === 'sqlite' ? 'sqlite ' . $db['sqlite'] : 'mysql ' . preg_replace('/.*dbname=([^;]+).*/', '$1', $db['mysql']['dsn']));
        printf("  %3d  %-28s %-8s %d utenti · scadenza %s (%s) · %s\n", $s['id'], $s['nome'], $s['attivo'] ? 'attivo' : 'SOSPESO', $n, $s['abbonamento_scadenza'] ?: '—', $s['abbonamento_periodo'] ?: 'mensile', $dbTxt);
    }
};

$configDa = function (array $opt): ?array {
    if (!empty($opt['sqlite'])) return ['driver' => 'sqlite', 'sqlite' => (string) $opt['sqlite']];
    if (!empty($opt['mysql'])) {
        $base = Database::configBase()['mysql'] ?? [];
        $dsn = preg_replace('/dbname=[^;]+/', 'dbname=' . preg_replace('/[^a-zA-Z0-9_]/', '', (string) $opt['mysql']), (string) ($base['dsn'] ?? 'mysql:host=127.0.0.1;dbname=x;charset=utf8mb4'));
        $m = ['dsn' => $dsn];
        if (!empty($opt['mysql-user'])) $m['user'] = (string) $opt['mysql-user'];
        if (isset($opt['mysql-pass'])) $m['pass'] = (string) $opt['mysql-pass'];
        return ['driver' => 'mysql', 'mysql' => $m];
    }
    return null;
};

/** Crea un utente nello studio (in comune) */
$creaUtente = function (int $sid, array $opt, bool $admin) use ($U): int {
    foreach (['utente', 'password', 'cognome'] as $k) if (empty($opt[$k])) exit("Manca --$k\n");
    $username = strtolower(trim((string) $opt['utente']));
    if (!preg_match('/^[a-z0-9._-]{3,60}$/', $username)) exit("Nome utente non valido: $username\n");
    if (strlen((string) $opt['password']) < 8) exit("La password deve avere almeno 8 caratteri\n");
    if (Database::value("SELECT id FROM $U WHERE username = ?", [$username])) exit("Nome utente già in uso: $username\n");
    $ruolo = (string) ($opt['ruolo'] ?? 'medico');
    Database::run("INSERT INTO $U (studio_id, username, password_hash, nome, cognome, sesso, ruolo, email, telefono, attivo, creato_il, admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)",
        [$sid, $username, password_hash((string) $opt['password'], PASSWORD_DEFAULT), (string) ($opt['nome'] ?? ''), (string) $opt['cognome'], ($opt['sesso'] ?? 'F') === 'M' ? 'M' : 'F', $ruolo, (string) ($opt['email'] ?? ''), (string) ($opt['telefono'] ?? ''), date('Y-m-d H:i:s'), $admin ? 1 : 0]);
    return (int) Database::pdo()->lastInsertId();
};

/** Attiva il database dello studio e lo installa (schema completo, niente demo) */
$installa = function (int $sid, array $cfg) use ($S): void {
    Database::run("UPDATE $S SET `database` = ? WHERE id = ?", [json_encode($cfg, JSON_UNESCAPED_SLASHES), $sid]);
    Config::override('app.demo', false);
    Tenant::attiva($sid);
    if (!Database::tableExists('pazienti')) Installer::run(); else Installer::aggiorna();
    $nome = (string) Database::value("SELECT nome FROM $S WHERE id = ?", [$sid]);
    if ($nome && Impostazione::get('studio_nome') === '') Impostazione::set('studio_nome', $nome);
    echo "  database dello studio pronto (" . Database::driver() . ")\n";
};

switch ($cmd) {
    case 'elenco':
        $elenco(); break;

    case 'crea':
        $nome = trim((string) ($pos[1] ?? ''));
        if ($nome === '') exit("Uso: crea \"Nome studio\" [--sqlite=… | --mysql=…] --utente=… --password=… --cognome=…\n");
        $scad = date('Y-m-d', strtotime('+30 days'));   // senza --scadenza: 30 giorni di prova
        if (!empty($opt['scadenza'])) $scad = preg_match('/^\+(\d+)$/', (string) $opt['scadenza'], $m) ? date('Y-m-d', strtotime("+{$m[1]} days")) : (string) $opt['scadenza'];
        $periodo = (string) ($opt['periodo'] ?? 'mensile');
        if (!in_array($periodo, ['mensile', 'bimestrale', 'semestrale', 'annuale'], true)) exit("Periodo non valido: $periodo\n");
        $cfg = $configDa($opt);
        if (!$cfg && Database::value("SELECT COUNT(*) FROM $S")) echo "  ATTENZIONE: nessun database dedicato (--sqlite/--mysql): lo studio condividerà i dati del database base con gli studi che già lo usano.\n";
        Database::run("INSERT INTO $S (nome, citta, abbonamento_scadenza, abbonamento_periodo, attivo, creato_il) VALUES (?, ?, ?, ?, 1, ?)", [$nome, (string) ($opt['citta'] ?? ''), $scad, $periodo, date('Y-m-d H:i:s')]);
        $sid = (int) Database::pdo()->lastInsertId();
        echo "Studio $sid creato: $nome\n";
        $uid = $creaUtente($sid, $opt, true);
        echo "  amministratore $uid: {$opt['utente']}\n";
        if ($cfg) $installa($sid, $cfg);
        break;

    case 'database':
        $sid = (int) ($pos[1] ?? 0);
        if (!$sid || !Utente::studio($sid)) exit("Studio inesistente\n");
        $cfg = $configDa($opt) ?? exit("Indica --sqlite=… oppure --mysql=…\n");
        $installa($sid, $cfg);
        break;

    case 'utente':
        $sid = (int) ($pos[1] ?? 0);
        if (!$sid || !Utente::studio($sid)) exit("Studio inesistente\n");
        $uid = $creaUtente($sid, $opt, !empty($opt['admin']));
        echo "Utente $uid creato nello studio $sid\n";
        break;

    case 'attiva': case 'disattiva':
        $sid = (int) ($pos[1] ?? 0);
        if (!$sid || !Utente::studio($sid)) exit("Studio inesistente\n");
        Database::run("UPDATE $S SET attivo = ? WHERE id = ?", [$cmd === 'attiva' ? 1 : 0, $sid]);
        echo "Studio $sid " . ($cmd === 'attiva' ? 'attivo' : 'sospeso') . "\n";
        break;

    case 'acquisto':
        $sid = (int) ($pos[1] ?? 0); $codice = (string) ($pos[2] ?? '');
        if (!$sid || !Utente::studio($sid)) exit("Studio inesistente\n");
        if ($codice === '') exit("Indica il codice dell'articolo dello Store (es. sms, spazio, sms_500, senza_marchio)\n");
        $_SESSION['drf_user'] = ['utente_id' => 0, 'studio_id' => $sid, 'username' => 'cli']; Tenant::attiva($sid);
        if (!Database::tableExists('estensioni')) Estensioni::tabelle();
        Config::override('sistema.amministratore', true);
        $o = Pagamenti::manuale($codice, (string) ($opt['metodo'] ?? 'bonifico'), (string) ($opt['note'] ?? ''));
        echo "Ordine {$o['id']}: {$o['nome']} → {$o['stato']} ({$o['metodo']})\n";
        break;

    case 'sms':
        $sid = (int) ($pos[1] ?? 0); $v = (string) ($pos[2] ?? '');
        if (!$sid || !Utente::studio($sid)) exit("Studio inesistente\n");
        if (!preg_match('/^\+?\d+$/', $v)) exit("Indica gli SMS: +500 (aggiunge) oppure un numero (imposta)\n");
        $att = (int) Database::value("SELECT COALESCE(sms_credito, 0) FROM $S WHERE id = ?", [$sid]);
        $nuovo = str_starts_with($v, '+') ? $att + (int) substr($v, 1) : (int) $v;
        Database::run("UPDATE $S SET sms_credito = ? WHERE id = ?", [$nuovo, $sid]);
        echo "Studio $sid: credito SMS $nuovo (prima $att)\n";
        break;

    case 'quota':
        $sid = (int) ($pos[1] ?? 0); $v = (string) ($pos[2] ?? '');
        if (!$sid || !Utente::studio($sid)) exit("Studio inesistente\n");
        if ($v === '' || !preg_match('/^\+?\d+$/', $v)) exit("Indica i MB: +5120 (aggiunge), 10240 (imposta), 0 (illimitata)\n");
        $att = Database::value("SELECT quota_mb FROM $S WHERE id = ?", [$sid]);
        $att = $att === null || $att === '' ? (int) Config::get('archivio.quota_mb', 2048) : (int) $att;
        $nuova = str_starts_with($v, '+') ? $att + (int) substr($v, 1) : (int) $v;
        Database::run("UPDATE $S SET quota_mb = ? WHERE id = ?", [$nuova, $sid]);
        echo "Studio $sid: quota " . ($nuova ? $nuova . ' MB' : 'illimitata') . " (prima " . ($att ?: 'illimitata') . ")\n";
        break;

    default:
        exit("Comando sconosciuto: $cmd\n");
}
