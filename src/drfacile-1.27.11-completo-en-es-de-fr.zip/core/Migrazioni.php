<?php
/**
 * MIGRAZIONI delle estensioni: le tabelle e le colonne di un'estensione nascono e cambiano con file numerati in
 * estensioni/<codice>/migrations/, eseguiti UNA volta ciascuno, in ordine, nel database dello studio (tabella
 * `estensioni_migrazioni`). Girano da sole all'installazione, alla riattivazione e a ogni aggiornamento
 * (hook di ciclo di vita), oppure con `DRF_STUDIO=… php strumenti/estensione.php migra <codice>`.
 *
 *   migrations/001_tabelle.php
 *     <?php return function () {
 *         Migrazioni::tabella('ext_dieta_piani', "
 *             id INTEGER PRIMARY KEY AUTOINCREMENT,
 *             paziente_id INTEGER NOT NULL,
 *             kcal INTEGER, note TEXT, creato_il VARCHAR(19)");
 *         Migrazioni::indice('ext_dieta_piani', 'paziente_id');
 *     };
 *   migrations/002_colonna_pasti.php
 *     <?php return function () { Migrazioni::colonna('ext_dieta_piani', 'pasti', 'INTEGER DEFAULT 3'); };
 *
 * Lo schema si scrive in dialetto SQLite (come core/schema.sql): su MySQL viene adattato da solo.
 * Un file può anche ritornare una stringa SQL o un array di stringhe. Le tabelle devono chiamarsi ext_<codice>_…
 * Richiede la capability `database.tabelle`.
 */
final class Migrazioni
{
    public static function tabelle(): void
    {
        $id = Database::driver() === 'mysql' ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
        Database::run("CREATE TABLE IF NOT EXISTS estensioni_migrazioni (id $id, codice VARCHAR(40) NOT NULL, nome VARCHAR(120) NOT NULL, eseguita_il VARCHAR(19))");
    }

    /** I file di migrazione dell'estensione, in ordine: [nome => percorso] */
    public static function disponibili(string $codice): array
    {
        $out = [];
        foreach (glob(Store::dir($codice) . '/migrations/*.php') ?: [] as $f) $out[basename($f, '.php')] = $f;
        ksort($out, SORT_NATURAL);
        return $out;
    }

    public static function eseguite(string $codice): array
    {
        try { return array_column(Database::all('SELECT nome FROM estensioni_migrazioni WHERE codice = ? ORDER BY id', [$codice]), 'nome'); }
        catch (Throwable $e) { return []; }
    }

    /** Esegue le migrazioni non ancora eseguite. Ritorna i nomi eseguiti. */
    public static function esegui(string $codice): array
    {
        $da = array_diff_key(self::disponibili($codice), array_flip(self::eseguite($codice)));
        if (!$da) return [];
        self::tabelle();
        $fatte = [];
        foreach ($da as $nome => $file) {
            OutputGuard::run("migrazione $codice/$nome", fn() => Capabilities::come($codice, function () use ($codice, $nome, $file) {
                Capabilities::richiedi('database.tabelle');
                $m = require $file;
                if (is_callable($m)) $m();
                else foreach ((array) $m as $sql) Database::pdo()->exec(self::adatta((string) $sql));
                Database::insert('estensioni_migrazioni', ['codice' => $codice, 'nome' => $nome, 'eseguita_il' => date('Y-m-d H:i:s')]);
            }));
            $fatte[] = $nome;
            error_log("Migrazione $codice/$nome eseguita");
        }
        return $fatte;
    }

    /* ------------------------------------------------------------------ aiuti per scrivere le migrazioni (portabili SQLite/MySQL) */

    /** CREATE TABLE IF NOT EXISTS con le colonne in dialetto SQLite; la tabella deve iniziare con ext_ */
    public static function tabella(string $nome, string $colonne): void
    {
        self::controllaNome($nome);
        Database::pdo()->exec(self::adatta("CREATE TABLE IF NOT EXISTS $nome (\n" . trim($colonne) . "\n);"));
    }

    /** Aggiunge una colonna se manca */
    public static function colonna(string $tabella, string $colonna, string $tipo): void
    {
        self::controllaNome($tabella);
        if (in_array($colonna, Database::colonne($tabella), true)) return;
        Database::pdo()->exec(self::adatta("ALTER TABLE $tabella ADD COLUMN $colonna $tipo"));
    }

    /** Indice (idempotente) */
    public static function indice(string $tabella, string $colonne, ?string $nome = null): void
    {
        self::controllaNome($tabella);
        $nome = $nome ?: 'idx_' . $tabella . '_' . preg_replace('/[^a-z0-9]+/i', '_', $colonne);
        try { Database::pdo()->exec("CREATE INDEX $nome ON $tabella($colonne)"); } catch (Throwable $e) { /* esiste già */ }
    }

    /** Adatta un'istruzione scritta in dialetto SQLite al driver corrente */
    public static function adatta(string $sql): string
    {
        return Database::driver() === 'mysql' ? Installer::perMysql($sql) : $sql;
    }

    private static function controllaNome(string $t): void
    {
        if (!preg_match('/^ext_[a-z0-9_]+$/', $t)) throw new RuntimeException("Tabella non ammessa per un'estensione: $t (usa ext_<codice>_…)");
    }
}
