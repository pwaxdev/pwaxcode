/* Ricerca globale (⌘K): comandi (nuova prenotazione, vai a…, scrivania, tema…) + pazienti, appuntamenti, referti, fatture.
   I moduli possono aggiungere comandi: DRF.search.comando({ label, fi, fa, kw: 'parole chiave', run }) */
DRF.search = (function ($) {
  'use strict';
  const ICONS = { paziente: ['user', 'fa-solid fa-user'], appuntamento: ['calendar', 'fa-regular fa-calendar'], referto: ['document', 'fa-regular fa-file-lines'], fattura: ['receipt', 'fa-solid fa-file-invoice'] };
  const GROUP = { paziente: DRF.__('Pazienti'), appuntamento: DRF.__('Appuntamenti'), referto: DRF.__('Referti'), fattura: DRF.__('Fatture'), cmd: DRF.__('Comandi') };
  let results = [], hl = -1, seq = 0;
  const comandi = [];

  const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  /** corrispondenza "sfumata": tutte le lettere della ricerca compaiono in ordine */
  function fuzzy(q, t) { q = norm(q); t = norm(t); if (t.includes(q)) return 2; let i = 0; for (const c of t) if (c === q[i]) i++; return i === q.length ? 1 : 0; }

  function open(r) {
    if (r.tipo === 'cmd') { r.run(); }
    else if (r.tipo === 'paziente') DRF.nav.go('pazienti', { select: r.id });
    else if (r.tipo === 'appuntamento') DRF.nav.go('agenda', { date: r.data, select: r.id });
    else if (r.tipo === 'referto') DRF.nav.go('referti', { select: r.id });
    else if (r.tipo === 'fattura') DRF.nav.go('fatture', { select: r.id });
    $('#searchInput').val('').trigger('blur'); close();
  }
  function close() { $('#searchResults').removeClass('open'); hl = -1; }
  function render() {
    const $r = $('#searchResults'); let last = null, html = '';
    results.forEach((o, i) => { if (o.tipo !== last) { last = o.tipo; html += `<div class="sr-group">${GROUP[o.tipo] || o.tipo}</div>`; } const [fi, fa] = o.tipo === 'cmd' ? [o.fi, o.fa] : ICONS[o.tipo]; html += `<div class="sr ${o.tipo === 'cmd' ? 'cmd' : ''}" data-i="${i}">${DRF.icons.html(fi, fa)}<div><b>${DRF.esc(o.titolo)}</b><span>${DRF.esc(o.sotto || '')}</span></div>${o.kbd ? `<kbd>${DRF.esc(o.kbd)}</kbd>` : ''}</div>`; });
    $r.html(html || `<div class="sr-empty">${DRF.__('Nessun risultato per “')}${DRF.esc($('#searchInput').val())}”</div>`);
    DRF.icons.apply($r[0]); $r.addClass('open'); hl = results.length ? 0 : -1; paint();
  }
  function paint() { $('#searchResults .sr').removeClass('hl').eq(hl).addClass('hl'); }
  function cerca(q) {
    const mine = ++seq;
    const cmds = comandi.map(c => ({ c, s: Math.max(fuzzy(q, c.label), fuzzy(q, c.kw || '')) })).filter(x => x.s).sort((a, b) => b.s - a.s).slice(0, 5).map(x => Object.assign({ tipo: 'cmd', titolo: x.c.label, sotto: x.c.desc || DRF.__('Comando') }, x.c));
    if (q.length < 2) { results = cmds; render(); return; }
    DRF.api.get('search', 'q', { q }).then(r => { if (mine !== seq) return; results = cmds.concat(r); render(); });
  }
  const run = DRF.util.debounce(cerca, 150);

  return {
    init() {
      const $in = $('#searchInput');
      $('#search').on('click', e => { if (!$(e.target).closest('.search-results').length) $in.trigger('focus'); });
      $in.on('input focus', () => { const q = $in.val().trim(); if (!q) { seq++; return close(); } run(q); });
      $in.on('keydown', e => {
        if (!$('#searchResults').hasClass('open')) return;
        if (e.key === 'ArrowDown') { hl = Math.min(hl + 1, results.length - 1); e.preventDefault(); }
        else if (e.key === 'ArrowUp') { hl = Math.max(hl - 1, 0); e.preventDefault(); }
        else if (e.key === 'Enter') { if (results[hl]) open(results[hl]); return; }
        else return;
        paint();
      });
      $in.on('blur', () => setTimeout(close, 150));
      $('#searchResults').on('mousedown', '.sr', function (e) { e.preventDefault(); open(results[+this.dataset.i]); });
      // comandi di sistema
      const S = DRF.search;
      DRF.modules().forEach((m, i) => S.comando({ label: `${DRF.__('Vai a')} ${m.title || m.key}`, fi: 'arrow-small-right', fa: 'fa-solid fa-arrow-right', kw: 'apri modulo ' + m.key, kbd: String((i + 1) % 10), run: () => DRF.nav.go(m.key) }));
      S.comando({ label: DRF.__('Nuova prenotazione'), fi: 'calendar-plus', fa: 'fa-regular fa-calendar-plus', kw: 'appuntamento agenda prenota', run: () => DRF.module('agenda').prenota() });
      S.comando({ label: DRF.__('Nuovo paziente'), fi: 'user-add', fa: 'fa-solid fa-user-plus', kw: 'anagrafica crea', run: () => DRF.module('pazienti').nuovo() });
      S.comando({ label: DRF.__('Nuova fattura'), fi: 'receipt', fa: 'fa-solid fa-file-invoice', kw: 'emetti fatturazione', run: () => DRF.module('fatture').nuova() });
      S.comando({ label: DRF.__('Nuovo post-it'), fi: 'note-sticky', fa: 'fa-regular fa-note-sticky', kw: 'nota appunto', run: () => DRF.postit.nuovo() });
      DRF.hooks.run('search.comandi', { comando: S.comando });   // le estensioni registrano i loro comandi (⌘K)
      S.comando({ label: DRF.__('Apri la Scrivania'), fi: 'apps', fa: 'fa-solid fa-table-cells-large', kw: 'desk moduli calcolatrice', run: () => DRF.desk.open() });
      S.comando({ label: DRF.__('Centro notifiche'), fi: 'bell', fa: 'fa-regular fa-bell', kw: 'avvisi', run: () => DRF.notify.centro() });
      S.comando({ label: DRF.__('Cambia tema (chiaro / scuro)'), fi: 'moon', fa: 'fa-regular fa-moon', kw: 'dark light notte', run: () => $('#themeBtn').trigger('click') });
      S.comando({ label: DRF.__('Scorciatoie da tastiera'), fi: 'keyboard', fa: 'fa-regular fa-keyboard', kw: 'tasti aiuto help', kbd: '?', run: () => DRF.app.scorciatoie() });
    },
    comando(c) { comandi.push(c); },
    close
  };
})(jQuery);
