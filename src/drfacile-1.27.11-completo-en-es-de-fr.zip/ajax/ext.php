<?php
/**
 * ROUTER AJAX DELLE ESTENSIONI: ajax/ext.php?ext=<codice>&action=<azione>
 * Un'estensione installata da pacchetto non può mettere file in ajax/: dichiara le sue azioni in
 * estensioni/<codice>/ajax.php, che ritorna [ 'azioni' => [...closure...], 'permessi' => ... ] (o solo l'array delle azioni).
 * Qui si verifica che l'estensione sia attiva e si passa tutto ad Api::run (autenticazione, CSRF, permessi, JSON).
 * Lato client: DRF.api.ext('consigli', 'config') / DRF.api.ext('consigli', 'salva', {…}).
 */
require __DIR__ . '/../core/bootstrap.php';
$codice = preg_replace('/[^a-z0-9_]/', '', strtolower((string) ($_GET['ext'] ?? '')));
if ($codice === '' || !Estensioni::attiva($codice)) { http_response_code(403); header('Content-Type: application/json'); echo json_encode(['ok' => false, 'error' => 'Estensione non attiva']); exit; }
$file = Store::dir($codice) . '/ajax.php';
if (!is_file($file)) { http_response_code(404); header('Content-Type: application/json'); echo json_encode(['ok' => false, 'error' => "L'estensione $codice non ha un endpoint AJAX"]); exit; }
$def = Capabilities::come($codice, fn() => require $file);
if (!is_array($def)) { http_response_code(500); exit; }
$azioni = isset($def['azioni']) && is_array($def['azioni']) ? $def['azioni'] : $def;
Capabilities::come($codice, fn() => Api::run($azioni, $def['permessi'] ?? null));   // le azioni girano a nome dell'estensione: capability verificate
