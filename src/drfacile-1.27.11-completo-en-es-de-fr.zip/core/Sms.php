<?php
/**
 * SMS: servizio a consumo dello studio. Il cliente attiva il servizio dallo Store (pacchetto `sms`, abbonamento) e compra
 * pacchetti di messaggi (`sms_500`, `sms_2000`: il portale chiama `php strumenti/studio.php sms <id> +500`).
 * Il credito vive nel database comune (studi.sms_credito); l'invio passa da Comunicazioni::invia('sms', …) con il driver
 * `clickatell` (config comunicazioni.sms.clickatell: api_key, mittente) e scala un messaggio per ogni invio riuscito.
 */
final class Sms
{
    public static function attivo(): bool { return Estensioni::attiva('sms'); }

    public static function credito(): int
    {
        $sid = Auth::studioId();
        if (!$sid) return 0;
        try { return (int) Database::value('SELECT sms_credito FROM ' . Database::comune('studi') . ' WHERE id = ?', [$sid]); } catch (Throwable $e) { return 0; }
    }

    public static function scala(int $n = 1): void
    {
        $sid = Auth::studioId();
        if ($sid) Database::run('UPDATE ' . Database::comune('studi') . ' SET sms_credito = CASE WHEN COALESCE(sms_credito, 0) >= ? THEN sms_credito - ? ELSE 0 END WHERE id = ?', [$n, $n, $sid]);
    }

    /** Pronto a spedire davvero? (servizio attivo, credito, chiave del provider) */
    public static function pronto(): array
    {
        $cfg = (array) (Config::get('comunicazioni.sms') ?? []);
        $driver = $cfg['driver'] ?? 'log';
        $chiave = trim((string) ($cfg['clickatell']['api_key'] ?? ''));
        $problemi = [];
        if (!self::attivo()) $problemi[] = 'Servizio SMS non attivo: attivalo dallo Store';
        elseif (self::credito() <= 0) $problemi[] = 'Credito SMS esaurito: acquista un pacchetto dallo Store';
        if ($driver === 'clickatell' && $chiave === '') $problemi[] = 'Manca la chiave Clickatell in config.php (comunicazioni.sms.clickatell.api_key)';
        return ['driver' => $driver, 'attivo' => self::attivo(), 'credito' => self::credito(), 'problemi' => $problemi, 'pronto' => !$problemi && $driver !== 'log'];
    }

    /** Invio tramite Clickatell (REST, chiave API). Ritorna l'id del messaggio del provider. */
    public static function clickatell(string $a, string $testo, array $cfg): string
    {
        $chiave = trim((string) ($cfg['api_key'] ?? ''));
        if ($chiave === '') throw new ApiException(__('Chiave Clickatell mancante'));
        $num = preg_replace('/[^0-9+]/', '', $a);
        if ($num === '' ) throw new ApiException(__('Numero non valido'));
        if (!str_starts_with($num, '+') && !str_starts_with($num, '00')) $num = '+39' . ltrim($num, '0');   // numeri italiani senza prefisso
        $num = ltrim(str_replace('+', '', str_starts_with($num, '00') ? substr($num, 2) : $num), '0');
        $body = ['content' => $testo, 'to' => [$num]];
        if (!empty($cfg['mittente'])) $body['from'] = (string) $cfg['mittente'];
        $risposta = self::http('https://platform.clickatell.com/messages', json_encode($body), ['Authorization: ' . $chiave, 'Content-Type: application/json', 'Accept: application/json']);
        $j = json_decode($risposta, true);
        $m = $j['messages'][0] ?? null;
        if (!$m || empty($m['accepted'])) throw new ApiException('Clickatell: ' . ($m['error'] ?? $j['error']['description'] ?? 'messaggio rifiutato'));
        return (string) ($m['apiMessageId'] ?? '');
    }

    private static function http(string $url, string $body, array $headers): string
    {
        if (function_exists('curl_init')) {
            $c = curl_init($url);
            curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_HTTPHEADER => $headers, CURLOPT_TIMEOUT => 20]);
            $r = curl_exec($c); $err = curl_error($c); curl_close($c);
            if ($r === false) throw new ApiException("Clickatell non raggiungibile: $err");
            return (string) $r;
        }
        $r = @file_get_contents($url, false, stream_context_create(['http' => ['method' => 'POST', 'header' => implode("\r\n", $headers), 'content' => $body, 'timeout' => 20, 'ignore_errors' => true]]));
        if ($r === false) throw new ApiException(__('Clickatell non raggiungibile'));
        return (string) $r;
    }
}
