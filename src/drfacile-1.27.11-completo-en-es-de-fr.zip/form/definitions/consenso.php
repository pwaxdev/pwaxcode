<?php
return [
    'title' => __('Nuovo consenso'), 'title_edit' => __('Modifica consenso'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Registra'),
    'table' => 'consensi',
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'consensi'],
        ['name' => 'paziente_id', 'label' => __('Paziente'), 'type' => 'select', 'required' => true, 'empty' => __('Seleziona…'), 'options' => fn() => Paziente::optionsMap()],
        ['name' => 'tipo', 'label' => __('Tipo di consenso'), 'type' => 'select', 'required' => true, 'options' => ['Privacy' => __('Trattamento dati (privacy)'), 'Consenso informato' => __('Consenso informato alla prestazione'), 'FSE' => __('Fascicolo sanitario elettronico'), 'Marketing' => __('Comunicazioni promozionali')]],
        ['name' => 'data', 'label' => __('Data'), 'type' => 'date', 'required' => true, 'default' => date('Y-m-d'), 'row' => 1],
        ['name' => 'scadenza', 'label' => __('Scadenza'), 'type' => 'date', 'row' => 1],
        ['name' => 'firmato', 'label' => __('Firmato dal paziente'), 'type' => 'switch', 'default' => 1],
        ['name' => 'note', 'label' => __('Note'), 'type' => 'text'],
    ],
];
