/* ==========================================================================
   DRFacile · nucleo: namespace, registro dei moduli, avvio
   ========================================================================== */
window.DRF = (function ($) {
  'use strict';
  const modules = {}, order = [];

  const D = {
    config: {},
    state: { current: null },

    /** Ogni file in assets/js registra il proprio modulo: DRF.register('agenda', {...}) */
    register(key, def) { def.key = key; modules[key] = def; order.push(key); return def; },
    module(key) {
      if (modules[key]) return modules[key];
      // modulo non caricato perché il ruolo non lo vede (cfg.moduli_assenti): un segnaposto che avvisa invece di rompere
      if ((D.config.moduli_assenti || []).indexOf(key) >= 0) return new Proxy({ key }, { get: (t, p) => p in t ? t[p] : (() => { if (DRF.ui && DRF.ui.toast) DRF.ui.toast(DRF.__('Funzione non disponibile per il tuo ruolo'), 'warn'); }) });
      return undefined;
    },
    modules() { return order.map(k => modules[k]); },
    keys() { return order.slice(); },
    current() { return modules[D.state.current]; },

    /** Bus di eventi fra moduli: DRF.on('paziente:selezionato', p => …); DRF.emit('paziente:selezionato', p) */
    on(evt, fn) { (D._ev[evt] = D._ev[evt] || []).push(fn); return D; },
    off(evt, fn) { D._ev[evt] = (D._ev[evt] || []).filter(f => f !== fn); return D; },
    emit(evt, data) { (D._ev[evt] || []).forEach(f => { try { f(data); } catch (e) { console.error(evt, e); } }); (D._ev['*'] || []).forEach(f => { try { f(evt, data); } catch (e) { /* ignora */ } }); return D; },
    _ev: {},

    /** Permessi dell'utente collegato (core/permessi.php, calcolati dal server): DRF.can('fatture.emetti') → true/false.
        Serve SOLO per nascondere pulsanti e voci: il controllo vero lo fa il server su ogni chiamata. */
    can(p) { return !p || ((D.config.utente || {}).permessi || []).indexOf(p) >= 0; },

    /** Traduzioni (gettext, cataloghi in DRF.config.i18n generati dai .mo): DRF.__('Salva'), DRF.__('Ultima mestruazione', 'ginecologia'),
        DRF._n('%d paziente', '%d pazienti', n), DRF._p('medical', 'Visita'). DRF.t = DRF.__ . In italiano i cataloghi sono vuoti: torna la stringa. */
    i18n: {
      cat(d) { return ((D.config.i18n || {})[d || 'drfacile']) || null; },
      regola(d) { const c = D.i18n.cat(d); if (!c || !c.regola) return n => (n !== 1 ? 1 : 0); if (!c._fn) { try { c._fn = new Function('n', 'return Number(' + c.regola.replace(/[^n0-9\s()<>=!&|?:%+\-*\/]/g, '') + ');'); } catch (e) { c._fn = n => (n !== 1 ? 1 : 0); } } return c._fn; },
    },
    __(s, d) { const c = D.i18n.cat(d); const t = c && c.msg && c.msg[s]; return typeof t === 'string' && t !== '' ? t : (Array.isArray(t) && t[0] ? t[0] : s); },
    _p(ctx, s, d) { const c = D.i18n.cat(d); const t = c && c.msg && c.msg[ctx + '\u0004' + s]; return typeof t === 'string' && t !== '' ? t : (Array.isArray(t) && t[0] ? t[0] : s); },
    _n(sing, plur, n, d) { const c = D.i18n.cat(d); const t = c && c.msg && c.msg[sing]; let out = n === 1 ? sing : plur; if (Array.isArray(t)) { const i = Math.min(D.i18n.regola(d)(n), t.length - 1); if (t[i]) out = t[i]; } return out.replace(/%d/g, n); },
    t(s, d) { return D.__(s, d); },

    /** Documenti: si aprono SOLO con un link firmato chiesto al server (documenti/link): DRF.doc.apri('referto', 12), DRF.doc.file('referto/2026/x.pdf').
        La finestra si apre subito (così il browser non la blocca) e riceve l'URL quando arriva. opts: { stampa, html, scarica } */
    doc: {
      _apri(richiesta, opts) {
        const w = window.open('', '_blank'); if (w) w.document.write('<p style="font-family:sans-serif;padding:30px;color:#888">' + DRF.__('Apro il documento…') + '</p>');
        return DRF.api.post('documenti', 'link', richiesta).then(r => {
          let url = r.url; Object.keys(opts || {}).forEach(k => { if (opts[k]) url += '&' + k + '=1'; });
          if (w) w.location.href = url; else window.open(url, '_blank');
          return url;
        }).catch(() => { if (w) w.close(); });
      },
      apri(tipo, id, opts) { return D.doc._apri({ tipo, id }, opts); },
      /** Finestra di invio email: destinatario modificabile (proposto dall'anagrafica), modello, oggetto e testo ritoccabili.
          DRF.doc.invia({ tipo, id }) per un documento generato; DRF.doc.invia({ file, paziente_id, documento }) per un file. Promise con l'esito. */
      invia(r) {
        const per = r.per || (r.file ? 'file' : (['referto', 'fattura', 'ricetta'].includes(r.tipo) ? r.tipo : 'documento'));
        return DRF.api.get('documenti', 'modelli', { per, tipo: r.tipo || '', id: r.id || 0, paziente_id: r.paziente_id || 0, documento: r.documento || '' }).then(d => new Promise(res => {
          const mod = d.modelli || [], m0 = mod[0] || { oggetto: '', testo: '' };
          DRF.ui.modal({ title: DRF.__('Invia via email'), size: 'lg', ok: DRF.__('Invia'), cancel: DRF.__('Annulla'), html: `
            <div class="field"><label>${DRF.__('Destinatario')}</label><input class="input" id="invEmail" type="email" value="${DRF.esc(r.email || d.email || '')}" placeholder="indirizzo@esempio.it" autocomplete="off">
              <span class="small ${d.email ? 'muted' : ''}" style="display:block;margin-top:4px;${d.email ? '' : 'color:var(--amber-ink)'}">${d.email ? DRF.__('Indirizzo dell\'anagrafica: puoi cambiarlo (un familiare, il commercialista…)') : (d.paziente ? d.paziente + ' ' + DRF.__('non ha un\'email in anagrafica: scrivi l\'indirizzo a cui inviare') : DRF.__('Scrivi l\'indirizzo a cui inviare'))}</span></div>
            ${mod.length ? `<div class="field"><label>${DRF.__('Modello')}</label><select class="select" id="invModello">${mod.map((m, i) => `<option value="${DRF.esc(m.codice)}" ${i === 0 ? 'selected' : ''}>${DRF.esc(m.descrizione)}${m.per_tipo === 'generico' ? ' (' + DRF.__('generico') + ')' : ''}</option>`).join('')}</select></div>` : ''}
            <div class="field"><label>${DRF.__('Oggetto')}</label><input class="input" id="invOggetto" value="${DRF.esc(m0.oggetto)}"></div>
            <div class="field"><label>${DRF.__('Testo')}</label><textarea class="input inv-testo" id="invTesto" rows="8">${DRF.esc(m0.testo)}</textarea><span class="small muted" style="display:block;margin-top:4px">${DRF.__('Il documento va in allegato (PDF).')}${d.driver === 'log' ? ' <b>' + DRF.__('Modalità prova') + '</b>: ' + DRF.__('l\'email viene solo registrata (driver log in config).') : ''}</span></div>`,
            onOpen($b) { $b.on('change', '#invModello', function () { const m = mod.find(x => x.codice === this.value); if (m) { $b.find('#invOggetto').val(m.oggetto); $b.find('#invTesto').val(m.testo); } }); setTimeout(() => $b.find('#invEmail').trigger('focus'), 80); },
            onOk($b) {
              const email = $b.find('#invEmail').val().trim();
              if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) { DRF.ui.toast(DRF.__('Scrivi un indirizzo email valido'), 'error'); return false; }
              $('#modalOk').prop('disabled', true).text(DRF.__('Invio…'));
              DRF.api.post('documenti', 'invia', { email, tipo: r.tipo || '', id: r.id || 0, file: r.file || '', paziente_id: r.paziente_id || 0, modello: $b.find('#invModello').val() || '', oggetto: $b.find('#invOggetto').val(), testo: $b.find('#invTesto').val() })
                .then(x => { DRF.ui.toast(x.messaggio, 'success'); DRF.ui.closeModal(); res(x); }).catch(() => { $('#modalOk').prop('disabled', false).text(DRF.__('Invia')); });
              return false;
            } }).then(ok => { if (!ok) res(null); });
        }));
      },
      file(rel, opts) { return D.doc._apri({ file: rel }, opts); },
    },

    /** Scorciatoie da tastiera delle estensioni: DRF.tasti.add('ctrl+shift+d', () => …, 'Apri il piano dieta') */
    tasti: {
      _reg: [],
      add(combo, run, label) { D.tasti._reg.push({ combo: String(combo).toLowerCase().replace(/\s+/g, ''), run, label }); return D; },
      lista() { return D.tasti._reg.slice(); },
      gestisci(e) {
        if (!e || typeof e.key !== 'string' || !D.tasti._reg.length) return false;
        const k = e.key.length === 1 ? e.key.toLowerCase() : e.key.toLowerCase();
        const combo = [e.ctrlKey || e.metaKey ? 'ctrl' : '', e.altKey ? 'alt' : '', e.shiftKey ? 'shift' : '', k].filter(Boolean).join('+');
        const t = D.tasti._reg.find(x => x.combo === combo); if (!t) return false;
        e.preventDefault(); try { t.run(e); } catch (err) { console.error('Scorciatoia ' + combo, err); } return true;
      },
    },

    /** Escape HTML per tutto ciò che viene inserito via innerHTML */
    esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); },

    /** Avvio: chiamato dal layout con la configurazione generata da PHP */
    boot(cfg) {
      D.config = cfg || {};
      $(function () {
        DRF.icons.apply();
        DRF.ui.init();
        DRF.form.init();
        DRF.nav.init();
        DRF.search.init();
        DRF.app.init();
        D.modules().forEach(m => { if (m.init) m.init(); });
        DRF.nav.go(cfg.start || order[0], { instant: true });
        $(window).on('load', DRF.icons.detect);
      });
    }
  };
  return D;
})(jQuery);
