<?php
/** Post-it: appunti liberi incollati su una sezione (modulo) e, se presente, su un record (es. un paziente) */
final class Postit extends Model
{
    protected static string $table = 'postit';
    protected static array $fillable = ['ident', 'sezione', 'record_id', 'testo', 'posx', 'posy', 'width', 'height', 'rotation', 'fontsize', 'back', 'color', 'bold', 'zindex'];

    public static function delContesto(string $sezione, int $record): array
    {
        return self::all('sezione = ? AND record_id = ?', [$sezione, $record], 'zindex, id');
    }

    /** Conteggio per ogni record di una sezione (per i segnalini negli elenchi) */
    public static function conteggi(string $sezione): array
    {
        $out = [];
        foreach (Database::all('SELECT record_id, COUNT(*) n FROM postit WHERE sezione = ? GROUP BY record_id', [$sezione]) as $r) $out[(int) $r['record_id']] = (int) $r['n'];
        return $out;
    }

    public static function salva(array $in): array
    {
        Api::require($in, ['ident', 'sezione'], ['ident' => 'Identificativo', 'sezione' => 'Sezione']);
        $ident = preg_replace('/[^a-z0-9_-]/i', '', (string) $in['ident']);
        $esistente = Database::one('SELECT id FROM postit WHERE ident = ?', [$ident]);
        $data = ['id' => $esistente ? (int) $esistente['id'] : 0, 'ident' => $ident, 'sezione' => preg_replace('/[^a-z0-9_]/i', '', (string) $in['sezione']), 'record_id' => (int) ($in['record_id'] ?? 0),
            'testo' => (string) ($in['testo'] ?? ''), 'posx' => (int) ($in['posx'] ?? 40), 'posy' => (int) ($in['posy'] ?? 40), 'width' => max(140, (int) ($in['width'] ?? 220)), 'height' => max(90, (int) ($in['height'] ?? 190)),
            'rotation' => max(-20, min(20, (int) ($in['rotation'] ?? 0))), 'fontsize' => max(12, min(40, (int) ($in['fontsize'] ?? 20))),
            'back' => preg_match('/^#[0-9a-f]{6}$/i', $in['back'] ?? '') ? $in['back'] : '#FFF4A3', 'color' => preg_match('/^#[0-9a-f]{6}$/i', $in['color'] ?? '') ? $in['color'] : '#1F2233',
            'bold' => (int) !empty($in['bold']), 'zindex' => max(1, (int) ($in['zindex'] ?? 1))];
        $id = self::save($data);
        return self::find($id);
    }
}
