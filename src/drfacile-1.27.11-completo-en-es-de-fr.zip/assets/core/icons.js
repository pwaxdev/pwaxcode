/* Icone: Flaticon UIcons con fallback automatico, icona per icona, a Font Awesome (locale).
   Ogni icona è <i class="ico" data-fi="calendar" data-fa="fa-regular fa-calendar"></i>. */
DRF.icons = (function ($) {
  'use strict';
  let mode = 'fi';
  const cache = {};
  let probe = null;

  const hasGlyph = el => { const c = getComputedStyle(el, '::before').content; return !!c && c !== 'none' && c !== 'normal' && c !== '""'; };
  const exists = cls => {
    if (cls in cache) return cache[cls];
    if (!probe) { probe = document.createElement('i'); probe.style.cssText = 'position:absolute;left:-9999px;top:0;opacity:0;pointer-events:none'; document.body.appendChild(probe); }
    probe.className = cls; return (cache[cls] = hasGlyph(probe));
  };
  const set = (el, cls) => {
    const keep = [...el.classList].filter(c => !/^(fi|fi-.*|fa|fa-.*|fas|far|fab)$/.test(c));
    el.className = [...keep, ...cls.split(' ')].join(' ');
  };

  return {
    html(fi, fa, cls) { return `<i class="ico ${cls || ''}" data-fi="${fi}" data-fa="${fa}"></i>`; },
    apply(root) {
      $(root || document).find('i.ico[data-fi]').addBack('i.ico[data-fi]').each(function () {
        const fi = this.dataset.fi, fa = this.dataset.fa, solid = !!this.closest('.is-active');
        if (mode === 'fi') {
          if (solid && exists(`fi fi-sr-${fi}`)) return set(this, `fi fi-sr-${fi}`);
          if (exists(`fi fi-rr-${fi}`)) return set(this, `fi fi-rr-${fi}`);
        }
        set(this, fa);
      });
    },
    async detect() {
      for (const k in cache) delete cache[k];
      let ok = exists('fi fi-rr-calendar');
      if (ok) { try { await document.fonts.ready; ok = document.fonts.check('16px "uicons-regular-rounded"'); } catch (e) { /* ignora */ } }
      mode = ok ? 'fi' : 'fa';
      DRF.icons.apply();
    }
  };
})(jQuery);
