<?php
/**
 * GESTIONE DOCUMENTALE (codice: documentale). Tutti i documenti di un paziente: cartelle di sistema (riempite dal programma
 * tramite l'evento documento.archiviato), cartelle libere, upload nell'archivio dello studio (Spazio: quota), anteprime.
 * Tabelle: ext_documentale_cartelle, ext_documentale_file (l'INDICE: i file veri stanno in Spazio::base()).
 */
final class Documentale
{
    public const C = 'ext_documentale_cartelle';
    public const F = 'ext_documentale_file';
    public const SISTEMA = ['referti' => 'Referti', 'fatture' => 'Fatture', 'ricette' => 'Ricette', 'esami' => 'Esami', 'documenti' => 'Documenti'];
    public const TIPO_CARTELLA = ['referto' => 'referti', 'fattura' => 'fatture', 'ricetta' => 'ricette', 'documento' => 'documenti', 'esame' => 'esami'];
    public const MIME = ['pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'heic' => 'image/heic',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'doc' => 'application/msword', 'odt' => 'application/vnd.oasis.opendocument.text',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'csv' => 'text/csv', 'txt' => 'text/plain', 'rtf' => 'application/rtf', 'html' => 'text/html', 'zip' => 'application/zip', 'dcm' => 'application/dicom'];

    /** Le cartelle di sistema del paziente (create al primo accesso) */
    public static function sistema(int $pid): array
    {
        $out = [];
        foreach (self::SISTEMA as $k => $nome) {
            $id = Database::value('SELECT id FROM ' . self::C . ' WHERE paziente_id = ? AND sistema = ?', [$pid, $k]);
            if (!$id) $id = Database::insert(self::C, ['paziente_id' => $pid, 'parent_id' => null, 'nome' => $nome, 'sistema' => $k, 'creato_il' => date('Y-m-d H:i:s')]);
            $out[$k] = (int) $id;
        }
        return $out;
    }

    /** Importa nell'indice i documenti già generati dal programma per il paziente (referti con file, fatture e documenti dall'archivio) */
    public static function importa(int $pid): void
    {
        $sys = self::sistema($pid);
        $p = Paziente::find($pid); if (!$p) return;
        $slug = preg_replace('/[^a-z0-9]+/i', '-', mb_strtolower($p['nome_completo']));
        $base = Spazio::base();
        $noti = array_column(Database::all('SELECT percorso FROM ' . self::F . ' WHERE paziente_id = ?', [$pid]), 'percorso');
        $aggiungi = function (string $rel, string $cartella, string $origine, ?string $rifT, ?int $rifId) use (&$noti, $pid, $sys, $base) {
            if (in_array($rel, $noti, true) || !is_file("$base/$rel")) return;
            $noti[] = $rel;
            Database::insert(self::F, ['paziente_id' => $pid, 'cartella_id' => $sys[$cartella], 'nome' => basename($rel), 'mime' => self::MIME[strtolower(pathinfo($rel, PATHINFO_EXTENSION))] ?? 'application/octet-stream',
                'dimensione' => filesize("$base/$rel"), 'percorso' => $rel, 'origine' => $origine, 'rif_tabella' => $rifT, 'rif_id' => $rifId, 'utente_id' => null, 'creato_il' => date('Y-m-d H:i:s', filemtime("$base/$rel"))]);
        };
        foreach (Database::all("SELECT id, file FROM referti WHERE paziente_id = ? AND file IS NOT NULL AND file <> ''", [$pid]) as $r) $aggiungi($r['file'], 'referti', 'referto', 'referti', (int) $r['id']);
        foreach (Database::all('SELECT id FROM fatture WHERE paziente_id = ?', [$pid]) as $f) foreach (glob("$base/fattura/*/" . sprintf('fattura-%05d-', $f['id']) . '*.*') ?: [] as $file) $aggiungi(substr($file, strlen($base) + 1), 'fatture', 'fattura', 'fatture', (int) $f['id']);
        foreach (glob("$base/documento/*/documento-*-$slug.*") ?: [] as $file) $aggiungi(substr($file, strlen($base) + 1), 'documenti', 'documento', null, null);
        foreach (glob("$base/ricetta/*/ricetta-*-$slug.*") ?: [] as $file) $aggiungi(substr($file, strlen($base) + 1), 'ricette', 'ricetta', null, null);
    }

    /** L'albero: cartelle (con conteggio) e file, tutto del paziente */
    public static function albero(int $pid): array
    {
        self::importa($pid);
        $cartelle = Database::all('SELECT c.*, (SELECT COUNT(*) FROM ' . self::F . ' f WHERE f.cartella_id = c.id) n FROM ' . self::C . ' c WHERE c.paziente_id = ? ORDER BY c.sistema IS NULL, c.nome', [$pid]);
        $file = Database::all('SELECT f.*, u.nome unome, u.cognome ucognome FROM ' . self::F . ' f LEFT JOIN ' . Database::comune('utenti') . ' u ON u.id = f.utente_id WHERE f.paziente_id = ? ORDER BY f.creato_il DESC', [$pid]);
        foreach ($file as &$f) { $f['protetto'] = $f['origine'] !== 'upload'; $f['da'] = trim(($f['unome'] ?? '') . ' ' . ($f['ucognome'] ?? '')); unset($f['unome'], $f['ucognome']); $f['anteprima'] = self::anteprima((string) $f['mime'], (string) $f['nome']); }
        return ['cartelle' => $cartelle, 'file' => $file, 'spazio' => Spazio::stato()];
    }

    public static function anteprima(string $mime, string $nome): string
    {
        $ext = strtolower(pathinfo($nome, PATHINFO_EXTENSION));
        if ($mime === 'application/pdf') return 'pdf';
        if (str_starts_with($mime, 'image/') && $ext !== 'heic') return 'immagine';
        if ($ext === 'docx') return 'word';
        if (in_array($ext, ['txt', 'csv', 'html'], true)) return 'testo';
        return 'nessuna';
    }

    /** Upload: nell'archivio dello studio, in documentale/<paziente>/<anno>/, con controllo di estensione, dimensione e quota */
    public static function carica(int $pid, int $cartellaId, array $file): array
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new ApiException('Caricamento non riuscito (codice ' . $file['error'] . ')');
        $nome = trim(preg_replace('/[\\\\\/:*?"<>|]+/', '-', (string) $file['name']));
        $ext = strtolower(pathinfo($nome, PATHINFO_EXTENSION));
        $ammesse = array_filter(array_map('trim', explode(',', Impostazione::get('documentale_estensioni') ?: implode(',', array_keys(self::MIME)))));
        if ($ext === '' || !in_array($ext, $ammesse, true)) throw new ApiException("Tipo di file non ammesso (.$ext). Ammessi: " . implode(', ', $ammesse));
        $max = (int) (Impostazione::get('documentale_max_mb') ?: 25);
        if ((int) $file['size'] > $max * 1048576) throw new ApiException("File troppo grande: massimo $max MB");
        if (!Database::value('SELECT id FROM ' . self::C . ' WHERE id = ? AND paziente_id = ?', [$cartellaId, $pid])) throw new ApiException('Cartella non valida');
        $rel = "documentale/$pid/" . date('Y') . '/' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
        Spazio::scrivi($rel, (string) file_get_contents($file['tmp_name']));
        $id = Database::insert(self::F, ['paziente_id' => $pid, 'cartella_id' => $cartellaId, 'nome' => mb_substr($nome, 0, 200), 'mime' => self::MIME[$ext] ?? 'application/octet-stream', 'dimensione' => (int) $file['size'],
            'percorso' => $rel, 'origine' => 'upload', 'utente_id' => (int) (Auth::utente()['id'] ?? 0) ?: null, 'creato_il' => date('Y-m-d H:i:s')]);
        Attivita::registra('documento.caricato', 'documenti', $id, $nome);
        return ['id' => $id];
    }

    public static function file(int $id, int $pid): array
    {
        return Database::one('SELECT * FROM ' . self::F . ' WHERE id = ? AND paziente_id = ?', [$id, $pid]) ?? throw new ApiException('File non trovato', 404);
    }
}

/* --- il programma genera un documento → finisce nella cartella di sistema giusta */
Hooks::add('documento.archiviato', function (string $tipo, int $id, string $rel, int $pid = 0) {
    if (!$pid) return;
    $sys = Documentale::sistema($pid);
    $cart = Documentale::TIPO_CARTELLA[$tipo] ?? 'documenti';
    if (Database::value('SELECT id FROM ' . Documentale::F . ' WHERE percorso = ?', [$rel])) return;
    $base = Spazio::base();
    Database::insert(Documentale::F, ['paziente_id' => $pid, 'cartella_id' => $sys[$cart], 'nome' => basename($rel), 'mime' => Documentale::MIME[strtolower(pathinfo($rel, PATHINFO_EXTENSION))] ?? 'application/octet-stream',
        'dimensione' => is_file("$base/$rel") ? filesize("$base/$rel") : 0, 'percorso' => $rel, 'origine' => $tipo, 'rif_tabella' => in_array($tipo, ['referto', 'fattura', 'ricetta'], true) ? $tipo . (str_ends_with($tipo, 'a') ? '' : 'i') : null, 'rif_id' => $id, 'utente_id' => (int) (Auth::utente()['id'] ?? 0) ?: null, 'creato_il' => date('Y-m-d H:i:s')]);
});
/* --- paziente eliminato → via i suoi file caricati e l'indice */
Hooks::add('paziente.eliminato', function (int $pid) {
    foreach (Database::all('SELECT percorso FROM ' . Documentale::F . " WHERE paziente_id = ? AND origine = 'upload'", [$pid]) as $f) Spazio::elimina($f['percorso']);
    Database::delete(Documentale::F, 'paziente_id = ?', [$pid]); Database::delete(Documentale::C, 'paziente_id = ?', [$pid]);
});
Hooks::add('api.dopo', function ($out, string $sez, string $az) {   // il conteggio dei documenti arriva con la scheda del paziente
    if ($sez === 'pazienti' && $az === 'get' && is_array($out) && !empty($out['paziente']['id'])) $out['documentale_n'] = (int) Database::value('SELECT COUNT(*) FROM ' . Documentale::F . ' WHERE paziente_id = ?', [(int) $out['paziente']['id']]);
    return $out;
});
Hooks::add('backup.contenuto', fn(array $t) => [...$t, Documentale::C, Documentale::F]);
Hooks::add('impostazioni.pannelli', function (array $p) {
    $p['documentale'] = ['titolo' => 'Gestione documentale', 'fi' => 'folder-open', 'fa' => 'fa-regular fa-folder-open',
        'html' => '<div class="grid2"><div class="field"><label>Dimensione massima di un file (MB)</label><input class="input" name="documentale_max_mb" inputmode="numeric" placeholder="25"></div>
            <div class="field"><label>Estensioni ammesse <span class="small muted">(separate da virgola)</span></label><input class="input" name="documentale_estensioni" placeholder="' . e(implode(',', array_keys(Documentale::MIME))) . '"></div></div>',
        'chiavi' => ['documentale_max_mb', 'documentale_estensioni'], 'salva' => 'Salva'];
    return $p;
});
