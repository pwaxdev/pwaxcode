<?php
/** Timeline clinica del paziente */
final class Storico
{
    public static function aggiungi(int $pazienteId, string $data, string $tipo, ?string $descrizione, ?string $rifTabella = null, ?int $rifId = null): int
    {
        return Database::insert('storico', ['paziente_id' => $pazienteId, 'data' => $data, 'tipo' => $tipo, 'descrizione' => $descrizione, 'rif_tabella' => $rifTabella, 'rif_id' => $rifId, 'creato_il' => date('Y-m-d H:i:s')]);
    }

    public static function diPaziente(int $pazienteId, int $limit = 30): array
    {
        return Database::all('SELECT * FROM storico WHERE paziente_id = ? ORDER BY data DESC, id DESC LIMIT ' . $limit, [$pazienteId]);
    }
}
