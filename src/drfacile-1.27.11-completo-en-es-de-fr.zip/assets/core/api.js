/* Chiamate AJAX verso ajax/<sezione>.php?action=<azione>
   GET per letture, POST (JSON + token CSRF) per scritture. Ritorna una promise jQuery con i soli `data`. */
DRF.api = (function ($) {
  'use strict';
  function call(section, action, data, method) {
    method = method || (data ? 'POST' : 'GET');
    const base = section.includes('?') ? `ajax/${section}&action=` : `ajax/${section}.php?action=`;   // sezione core, oppure ext.php?ext=… (estensioni)
    const opts = { url: base + encodeURIComponent(action), method, dataType: 'json', headers: { 'X-CSRF-Token': DRF.config.csrf || '' } };
    if (method === 'GET') opts.data = data || {};
    else if (typeof FormData !== 'undefined' && data instanceof FormData) { opts.processData = false; opts.contentType = false; opts.data = data; }   // upload di file (multipart): i campi in $_POST, i file in $_FILES
    else { opts.contentType = 'application/json'; opts.data = JSON.stringify(data || {}); }
    return $.ajax(opts).then(
      r => { if (r && r.ok) return r.data; DRF.ui.toast((r && r.error) || DRF.__('Errore imprevisto'), 'error'); return $.Deferred().reject(r).promise(); },
      xhr => {
        if (xhr.status === 401) { location.href = 'login.php'; return; }
        if (xhr.status === 419) { DRF.ui.toast(DRF.__('Sessione da rinnovare: ricarico la pagina…'), 'warn'); setTimeout(() => location.reload(), 1200); return; }
        let msg = DRF.__('Errore di comunicazione con il server');
        try { const j = JSON.parse(xhr.responseText); if (j && j.error) msg = j.error; }
        catch (e) {
          // Un parsererror con HTTP 200 significa quasi sempre che PHP ha aggiunto output estraneo
          // (warning, BOM, echo) prima/dopo il JSON. Il server dalla 1.27.10 lo sopprime; se ricapita,
          // lasciamo in console la risposta reale invece di nasconderla dietro il messaggio generico.
          if (window.console && console.error) console.error('[DRFacile] Risposta API non JSON', { status: xhr.status, statusText: xhr.statusText, responseText: xhr.responseText });
        }
        DRF.ui.toast(msg, 'error');
        return $.Deferred().reject(xhr).promise();
      }
    );
  }
  /** Endpoint di un'ESTENSIONE (estensioni/<codice>/ajax.php via ajax/ext.php): GET senza dati, POST con dati */
  function ext(codice, action, data, method) {
    method = method || (data ? 'POST' : 'GET');
    return call(`ext.php?ext=${encodeURIComponent(codice)}`, action, data, method);
  }
  return { call, get: (s, a, d) => call(s, a, d, 'GET'), post: (s, a, d) => call(s, a, d || {}, 'POST'), ext };
})(jQuery);
