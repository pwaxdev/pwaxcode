<?php /* Stile condiviso dei documenti stampabili (incluso inline così l'archivio resta autonomo). Parametrico: $stampa = Documenti::stampa() */
$tst = $stampa ?? Documenti::stampa(); $tstAcc = $tst['colore']; $tstMm = fn($v) => number_format((float) $v, 1, '.', '') . 'mm'; ?>
<style>
  @page{size:<?= e($tst['formato']) ?> <?= e($tst['orientamento']) ?>;margin:<?= $tstMm($tst['m_sup']) ?> <?= $tstMm($tst['m_des']) ?> <?= $tstMm($tst['m_inf']) ?> <?= $tstMm($tst['m_sin']) ?>}
  *{box-sizing:border-box}
  body{font-family:<?= $tst['font'] ?>;color:#1F2233;margin:0;background:#EEF0F4;font-size:<?= (int) $tst['corpo'] ?>px;line-height:1.6}
  .foglio{background:#fff;max-width:<?= $tst['formato'] === 'A5' ? '560px' : '800px' ?>;margin:24px auto;padding:<?= $tstMm($tst['m_sup']) ?> <?= $tstMm($tst['m_des']) ?> <?= $tstMm($tst['m_inf']) ?> <?= $tstMm($tst['m_sin']) ?>;box-shadow:0 10px 30px -12px rgba(0,0,0,.25);border-radius:10px;min-height:<?= $tst['formato'] === 'A5' ? '790px' : '1100px' ?>;position:relative}
  header{padding-bottom:14px;margin-bottom:20px}
  header.bordo{border-bottom:2px solid <?= $tstAcc ?>}
  header .riga{display:flex;justify-content:space-between;align-items:flex-start;gap:20px}
  header .logo.centro{text-align:center;margin-bottom:10px}
  header .logo-inl{display:block;margin-bottom:8px;max-width:80mm}
  header .destra .logo-inl{margin-left:auto}
  header .medico b{font-size:16px;display:block}
  header .medico div{color:#5C6174;font-size:12px}
  @media print{body{background:#fff}.foglio{box-shadow:none;margin:0;max-width:none;padding:0;min-height:0}.toolbar{display:none}footer{position:fixed;bottom:0;left:0;right:0}.pagine .n:before{content:counter(page)}.pagine .t:before{content:counter(pages)}}
  header .doc{text-align:right;font-size:12px;color:#5C6174}
  header .doc b{display:block;font-size:14px;color:#1F2233}
  header .destinatario{text-align:right;font-size:12.5px;line-height:1.55;color:#3A3F52;max-width:46%}
  header .destinatario .dest-eyebrow{display:block;font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:#9AA0B3;margin-bottom:2px}
  header .destinatario b{display:block;font-size:14px;color:#1F2233}
  header .destinatario span{display:block}
  .doc-riga{font-size:12.5px;color:#5C6174;margin:0 0 16px;padding:8px 12px;background:#F6F7FA;border-radius:8px}
  .doc-riga b{color:#1F2233}
  footer .riga-studio{font-size:11.5px;color:#5C6174;font-weight:600;margin-bottom:4px}
  h1{font-size:20px;margin:0 0 4px}
  h2{font-size:11px;text-transform:uppercase;letter-spacing:.09em;color:#9AA0B3;margin:20px 0 4px}
  .paz{color:#5C6174;font-size:12px}
  .mono{font-family:Menlo,Consolas,monospace;letter-spacing:.03em}
  p{margin:0;white-space:pre-line}
  table{width:100%;border-collapse:collapse;margin-top:16px}
  th{text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.07em;color:#9AA0B3;padding:8px 6px;border-bottom:1px solid #ECEDF2}
  td{padding:9px 6px;border-bottom:1px solid #ECEDF2;vertical-align:top}
  td.n,th.n{text-align:right;white-space:nowrap}
  .small{font-size:11px}
  .rich-out{font-size:13px;line-height:1.7}
  .rich-out mark{background:#FBEB9B;border-radius:3px;padding:0 2px}
  .rich-out ul,.rich-out ol{margin:4px 0 8px;padding-left:20px}
  .rich-out h3{font-size:13px;margin:8px 0 4px}
  .tot td{border:0;font-weight:700}
  .tot.grande td{font-size:16px;border-top:2px solid #6B6FE6;padding-top:12px}
  .firma{margin-top:36px;display:flex;justify-content:flex-end}
  .firma div{text-align:center;font-size:11px;color:#9AA0B3}
  .firma b{display:block;font-family:"Segoe Script","Brush Script MT",cursive;font-size:24px;color:#6B6FE6;font-weight:400}
  .badge{display:inline-block;background:#FDF2DC;color:#B7811B;font-weight:700;font-size:11px;padding:4px 9px;border-radius:999px}
  .nre{font-family:Menlo,Consolas,monospace;font-size:20px;letter-spacing:.12em;background:#F5F6F9;padding:10px 14px;border-radius:8px;display:inline-block;margin-top:8px}
  .barra{margin-top:10px;font-size:11px;color:#9AA0B3}
  footer{margin-top:30px;padding-top:12px;border-top:1px solid #ECEDF2;font-size:10.5px;color:#9AA0B3}
  footer .piede-riga{width:100%;border-collapse:collapse;margin:0}
  footer .piede-riga td{border:0;padding:0;font-size:10.5px;color:#9AA0B3}
  footer .piede-riga td.pagine{text-align:right;white-space:nowrap}
  footer .pagine-num{visibility:hidden}   /* nel PDF la numerazione la scrive il canvas (Pagina X di Y); a video il browser non sa contare */
  .tot.grande td{border-top-color:<?= $tstAcc ?>}
  .firma b{color:<?= $tstAcc ?>}
  .toolbar{max-width:800px;margin:20px auto 0;display:flex;gap:8px;justify-content:flex-end}
  .toolbar button{border:0;background:#6B6FE6;color:#fff;font:inherit;font-weight:700;padding:10px 16px;border-radius:10px;cursor:pointer}
  .toolbar button.ghost{background:#fff;color:#1F2233}
  @media print{body{background:#fff}.foglio{box-shadow:none;margin:0;max-width:none;padding:0}.toolbar{display:none}}
</style>
<?php unset($tst, $tstAcc, $tstMm); ?>