<?php
/** Procedura demo: genera i promemoria (SMS / email) per gli appuntamenti di una data */
final class Promemoria extends Procedura
{
    public function label(): string { return 'Promemoria appuntamenti'; }
    public function descrizione(): string { return 'Prepara il testo dei promemoria per i pazienti con appuntamento nella data scelta.'; }
    public function pulsante(): string { return 'Genera promemoria'; }

    public function campi(): array
    {
        return [
            ['name' => 'data', 'label' => __('Data degli appuntamenti'), 'type' => 'date', 'default' => date('Y-m-d', strtotime('+1 day')), 'row' => 1],
            ['name' => 'canale', 'label' => 'Canale', 'type' => 'seg', 'options' => ['sms' => 'SMS', 'email' => 'Email'], 'default' => 'sms', 'row' => 1],
            ['name' => 'testo', 'label' => 'Testo (segnaposto: {nome}, {data}, {ora}, {studio}, {telefono})', 'type' => 'textarea', 'default' => "Gentile {nome}, le ricordiamo l'appuntamento di {data} alle ore {ora} presso {studio}. Per disdire: {telefono}."],
        ];
    }

    public function esegui(array $in): array
    {
        $data = preg_match('/^\d{4}-\d{2}-\d{2}$/', $in['data'] ?? '') ? $in['data'] : date('Y-m-d', strtotime('+1 day'));
        $canale = ($in['canale'] ?? 'sms') === 'email' ? 'email' : 'sms';
        $m = Impostazione::profilo();
        $righe = [];
        foreach (Appuntamento::delGiorno($data) as $a) {
            $p = Paziente::find((int) $a['paziente_id']);
            $recapito = $canale === 'email' ? ($p['email'] ?? '') : ($p['cellulare'] ?: ($p['telefono'] ?? ''));
            $testo = strtr((string) ($in['testo'] ?? ''), ['{nome}' => $p['nome_completo'], '{data}' => data_it($data), '{ora}' => $a['ora'], '{studio}' => $m['studio'], '{telefono}' => $m['telefono']]);
            $righe[] = [
                'ora' => '<b class="num">' . e($a['ora']) . '</b>',
                'paziente' => '<b>' . e($p['nome_completo']) . '</b><div class="small muted">' . e($a['tipo_label']) . '</div>',
                'recapito' => $recapito ? '<span class="mono">' . e($recapito) . '</span>' : '<span class="badge amber">manca ' . ($canale === 'email' ? 'email' : 'telefono') . '</span>',
                'testo' => '<div class="small" style="max-width:420px">' . e($testo) . '</div>',
                'azione' => '<button class="btn ghost sm" type="button" data-copia="' . e($testo) . '">Copia</button>',
            ];
        }
        $n = count($righe);
        return [
            'titolo' => "$n " . ($n === 1 ? 'promemoria' : 'promemoria') . ' per ' . data_lunga($data),
            'html' => $this->tabella(['ora' => 'Ora', 'paziente' => 'Paziente', 'recapito' => $canale === 'email' ? 'Email' : 'Telefono', 'testo' => 'Messaggio', 'azione' => ''], $righe)
                . '<p class="small muted" style="margin-top:10px">Qui si collega l\'invio reale (gateway SMS o email): la procedura restituisce già testo e recapito per ogni paziente.</p>',
        ];
    }
}
