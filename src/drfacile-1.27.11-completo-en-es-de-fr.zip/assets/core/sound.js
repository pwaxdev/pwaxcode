/* Suoni di sistema (assets/sounds). Disattivabili dalle preferenze. */
DRF.sound = (function () {
  'use strict';
  const cache = {};
  return {
    enabled() { return !!(DRF.config.pref && DRF.config.pref.suoni); },
    play(name) {
      if (!this.enabled()) return;
      try {
        if (!cache[name]) { cache[name] = new Audio(`assets/sounds/${name}.wav`); cache[name].volume = name === 'click' ? 0.25 : 0.5; }
        cache[name].currentTime = 0;
        const p = cache[name].play(); if (p && p.catch) p.catch(() => {});
      } catch (e) { /* audio non disponibile */ }
    }
  };
})();
