<?php
return [
    'title' => __('Nuovo tipo di appuntamento'), 'title_edit' => __('Modifica tipo di appuntamento'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Aggiungi'),
    'table' => 'tipi_appuntamento',
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'tipi_appuntamento'],
        ['name' => 'codice', 'label' => __('Codice'), 'type' => 'text', 'required' => true, 'placeholder' => __('es. visita'), 'attrs' => ['maxlength' => 20], 'row' => 1],
        ['name' => 'nome', 'label' => __('Nome'), 'type' => 'text', 'required' => true, 'row' => 1],
        ['name' => 'colore', 'label' => __('Colore'), 'type' => 'color', 'default' => '#6B6FE6', 'row' => 2],
        ['name' => 'durata', 'label' => __('Durata proposta (min)'), 'type' => 'text', 'mask' => 'numero', 'default' => 30, 'row' => 2],
        ['name' => 'attivo', 'label' => __('Attivo'), 'type' => 'switch', 'default' => 1],
    ],
];
