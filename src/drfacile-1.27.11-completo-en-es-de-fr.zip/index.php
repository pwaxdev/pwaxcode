<?php
/** DRFacile · entry point dell'applicazione */
require __DIR__ . '/core/bootstrap.php';
Auth::requirePage();

// moduli della costa: quelli del core + quelli aggiunti dalle estensioni (hook moduli.elenco: key, label, fi, fa, permesso, vista, css[], js[], dopo)
$modules = Hooks::filter('moduli.elenco', require DRF_ROOT . '/core/modules.php');
$modules = array_values(array_filter($modules, fn($m) => !empty($m['key']) && preg_match('/^[a-z][a-z0-9_]*$/', $m['key']) && Auth::can($m['permesso'] ?? null)));   // solo i moduli permessi al ruolo
$medico  = Impostazione::profilo();
$tema    = Impostazione::get('pref_tema', 'light');
$abbonamento = Auth::abbonamento();
$utente = Auth::utente();
$estAssets = Estensioni::assets();
$jsConfig = [
    'app'    => Config::get('app.name'), 'versione' => Config::get('app.version'),
    'csrf'   => Auth::csrf(), 'start' => $modules[0]['key'] ?? 'agenda',
    'medico' => $medico,
    'utente' => ['id' => (int) $utente['id'], 'nome_completo' => $utente['nome_completo'], 'iniziali' => $utente['iniziali'], 'avatar' => $utente['avatar'], 'ruolo' => $utente['ruolo'], 'admin' => Auth::admin(), 'permessi' => Auth::permessi()],
    'agenda' => Config::get('agenda'), 'fattura' => Config::get('fattura'),
    'pref'   => ['tema' => $tema, 'suoni' => Impostazione::get('pref_suoni', '1') === '1', 'durata' => Impostazione::get('pref_durata', '30'), 'prezzi_visita' => Impostazione::get('pref_prezzi_visita', '1') !== '0'],
    'moduli' => array_column($modules, 'key'),
    'moduli_assenti' => array_values(array_diff(array_column(Hooks::filter('moduli.elenco', require DRF_ROOT . '/core/modules.php'), 'key'), array_column($modules, 'key'))),   // negati dal ruolo
    'postit' => ['font_size' => (int) Config::get('postit.font_size', 14)],
    'locale' => I18n::locale(), 'i18n' => I18n::cataloghiPagina(),   // cataloghi gettext per DRF.__ (vuoti in italiano)
    // novità della versione (docs/novita.json): mostrate una volta per utente, alla prima apertura dopo l'aggiornamento
    'novita' => (function () use ($utente) {
        $tutte = json_decode((string) @file_get_contents(DRF_ROOT . '/docs/novita.json'), true) ?: [];
        $viste = Impostazione::get('novita_viste_' . (int) ($utente['id'] ?? 0));
        $chiavi = array_filter(array_keys($tutte), fn($v) => version_compare($v, Installer::VERSIONE, '<=') && ($viste === '' || version_compare($v, $viste, '>')));
        if (!$chiavi) return null;
        usort($chiavi, 'version_compare'); $v = end($chiavi);
        return ['versione' => $v] + $tutte[$v];
    })(),   // dimensione iniziale del testo dei post-it (config)
    'menu' => Hooks::filter('menu.voci', []),   // voci aggiunte dalle estensioni al menu dell'utente (label, fi, fa, modulo|url|comando, permesso)
    'scorciatoie' => Hooks::filter('scorciatoie', []),   // scorciatoie dichiarate lato server (tasti → comando), mostrate nell'aiuto
    'estensioni' => array_values(array_filter(array_column(Estensioni::catalogo(), 'codice'), fn($c) => Estensioni::attiva($c))),
];
include DRF_ROOT . '/views/layout.php';
