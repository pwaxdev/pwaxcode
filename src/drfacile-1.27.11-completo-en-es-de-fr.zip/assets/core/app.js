/* Comportamenti globali: tema, avatar, notifiche, uscita */
DRF.app = (function ($) {
  'use strict';
  $(document).on('click', '[data-doc]', function (e) { e.preventDefault(); const o = {}; (this.dataset.opts || '').split(',').filter(Boolean).forEach(k => o[k] = 1); if (this.dataset.file) DRF.doc.file(this.dataset.file, o); else DRF.doc.apri(this.dataset.doc, +this.dataset.id, o); });
  return {
    init() {
      if (DRF.config.novita) setTimeout(() => DRF.novita.mostra(DRF.config.novita), 900);   // novità della versione, una volta per utente
  const q = new URLSearchParams(location.search);
      if (q.get('acquisto')) { setTimeout(() => { const e = q.get('acquisto'); if (e === 'ok') { DRF.ui.toast(DRF.__('Acquisto completato: ') + (q.get('codice') || ''), 'success'); DRF.desk.open(); DRF.desk.apri('negozio'); } else if (e === 'annullato') DRF.ui.toast(DRF.__('Pagamento annullato')); else DRF.ui.toast(DRF.__('Pagamento non confermato: ') + (q.get('msg') || ''), 'error'); history.replaceState(null, '', location.pathname); }, 600); }

      DRF.ui.setTheme((DRF.config.pref && DRF.config.pref.tema) || 'light', false);
      $('#themeBtn').on('click', () => DRF.ui.setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark', true));
      DRF.desk.init();   // l'avatar apre la Scrivania
      $('#logoutBtn').on('click', () => DRF.ui.confirm(DRF.__('Uscire da DRFacile?'), DRF.__('La sessione verrà chiusa.'), DRF.__('Esci')).then(ok => { if (ok) DRF.api.post('auth', 'logout').then(r => location.href = r.redirect || 'login.php'); }));
      DRF.notify.init();
      DRF.postit.init();
      DRF.app.statoVisita();
      $(document).on('keydown', e => { if (e.key === '?' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && !document.activeElement.isContentEditable && !$('#sheet').hasClass('open')) DRF.app.scorciatoie(); });
    },
    /** Scorciatoie da tastiera (tasto ?) */
    scorciatoie() {
      const mods = DRF.modules().slice(0, 10).map((m, i) => `<div><span>${DRF.esc(m.title || m.key)}</span><kbd>${(i + 1) % 10}</kbd></div>`).join('');
      DRF.ui.modal({ title: DRF.__('Scorciatoie da tastiera'), size: 'lg', ok: false, cancel: DRF.__('Chiudi'), html: `<div class="keys">${mods}<div><span>${DRF.__('Modulo precedente / successivo')}</span><kbd>↑ ↓</kbd></div><div><span>${DRF.__('Ricerca e comandi')}</span><kbd>⌘K / Ctrl+K</kbd></div><div><span>${DRF.__('Chiudi calendario, tendina, messaggio, pannello, scrivania')}</span><kbd>Esc</kbd></div><div><span>${DRF.__('Agenda: modifica l\'appuntamento selezionato')}</span><kbd>E</kbd></div><div><span>${DRF.__('Agenda: elimina l\'appuntamento selezionato')}</span><kbd>Canc</kbd></div><div><span>${DRF.__('Menu contestuale su appuntamenti, post-it, dock')}</span><kbd>${DRF.__('tasto destro')}</kbd></div><div><span>${DRF.__('Calcolatrice: tastiera numerica')}</span><kbd>0-9 + − × ÷ % Invio</kbd></div><div><span>${DRF.__('Questa finestra')}</span><kbd>?</kbd></div>${DRF.tasti.lista().map(t => `<div><span>${DRF.esc(t.label || t.combo)}</span><kbd>${DRF.esc(t.combo.replace(/\+/g, ' + ').replace(/ctrl/, '⌘/Ctrl'))}</kbd></div>`).join('')}${(DRF.config.scorciatoie || []).map(t => `<div><span>${DRF.esc(t.label || '')}</span><kbd>${DRF.esc(t.tasti || '')}</kbd></div>`).join('')}</div>` });
    },
    /** Pallino verde sull'icona Visita quando c'è una visita in corso */
    statoVisita() { if (!DRF.modules().some(m => m.key === 'visita')) return; DRF.api.get('visita', 'stato').then(r => DRF.nav.setDot('visita', r.aperta, r.paziente ? DRF.__('Visita in corso: ') + r.paziente : '')); },
    aggiornaBadge() { DRF.notify.refresh(); },
  };
})(jQuery);
