/* Modulo Scrivania: Oggi. Appuntamenti della giornata dall'API dell'agenda. */
DRF.desk.register('oggi', {
  init($win) {
    const load = () => DRF.api.get('agenda', 'giorno', { data: DRF.util.todayIso() }).then(d => {
      const nm = DRF.util.nowMin();
      $win.find('.oggi-n').text(`${DRF._n('%d appuntamento', '%d appuntamenti', d.appuntamenti.length)}`);
      $win.find('.oggi-list').html(d.appuntamenti.map(a => { const done = a.stato === 'completato' || DRF.util.mins(a.ora) + +a.durata < nm; const c = (d.tipi[a.tipo] || {}).colore || 'var(--accent)';
        return `<div class="oggi-it ${done ? 'done' : ''}" data-id="${a.id}" style="--c:${c}"><span class="ora">${a.ora}</span><div class="who"><b>${DRF.esc(a.paziente)}</b><span>${DRF.esc(a.tipo_label)}${a.note ? ' · ' + DRF.esc(a.note) : ''}</span></div>${done ? '' : `<button class="icon-btn" type="button" data-visita="${a.paziente_id}" data-app="${a.id}" title="${DRF.__('Inizia visita')}">${DRF.icons.html('play', 'fa-solid fa-play')}</button>`}</div>`; }).join('') || '<div class="empty">' + DRF.__('Nessun appuntamento oggi.') + '</div>');
      DRF.icons.apply($win[0]);
    });
    $win.on('click', '.oggi-it', function (e) { if ($(e.target).closest('[data-visita]').length) return; DRF.desk.close(); DRF.nav.go('agenda', { date: DRF.util.todayIso(), select: +this.dataset.id }); })
      .on('click', '[data-visita]', function () { DRF.desk.close(); DRF.module('visita').avvia(+this.dataset.visita, +this.dataset.app); });
    $win.data('load', load); load();
  },
  open($win) { const l = $win.data('load'); if (l) l(); }
});
