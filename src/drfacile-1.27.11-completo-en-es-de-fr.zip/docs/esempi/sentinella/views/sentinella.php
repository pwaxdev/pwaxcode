<div class="sent stagger">
  <div class="sent-top">
    <div class="kpis three" id="sentKpi"></div>
    <div class="row" style="gap:8px"><div class="seg" id="sentFiltro"><button class="on" data-t="">Tutte</button><button data-t="assente">Non visti</button><button data-t="controllo">Controlli</button><button data-t="fattura">Fatture</button><button data-t="anagrafica">Anagrafiche</button></div></div>
  </div>
  <div class="card"><h3><i class="ico" data-fi="eye" data-fa="fa-regular fa-eye"></i>Segnalazioni aperte</h3><div id="sentLista"></div></div>
</div>
