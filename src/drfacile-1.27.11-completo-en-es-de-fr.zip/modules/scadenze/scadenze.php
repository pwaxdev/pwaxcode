<?php
/** Modulo Scrivania: scadenzario (prossimi 30 giorni) */
if (!function_exists('module_scadenze_render')) {
    function module_scadenze_render(array $ctx): string
    {
        return '<div class="scad"><div class="scad-list"><div class="muted small" style="padding:14px">' . __('Caricamento…') . '</div></div></div>';
    }
}
