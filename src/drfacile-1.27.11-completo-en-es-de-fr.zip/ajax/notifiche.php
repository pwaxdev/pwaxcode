<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'recenti'     => fn(array $in) => ['notifiche' => Notifica::recenti(Api::int($in, 'n', 8)), 'non_lette' => Notifica::nonLette()],
    'tutte'       => fn() => ['notifiche' => Notifica::tutte(), 'non_lette' => Notifica::nonLette()],
    'aggiungi'    => function (array $in) { Api::require($in, ['titolo'], ['titolo' => 'Titolo']); $id = Notifica::aggiungi(Api::str($in, 'tipo', 'info'), Api::str($in, 'titolo'), Api::str($in, 'testo'), is_array($in['link'] ?? null) ? $in['link'] : null); return ['id' => $id, 'non_lette' => Notifica::nonLette()]; },
    'letta'       => function (array $in) { Notifica::segna(Api::int($in, 'id'), !isset($in['letta']) || (bool) $in['letta']); return ['non_lette' => Notifica::nonLette()]; },
    'tutte_lette' => fn() => ['aggiornate' => Notifica::segnaTutte(), 'non_lette' => 0],
    'elimina'     => fn(array $in) => ['eliminata' => Notifica::delete(Api::int($in, 'id')), 'non_lette' => Notifica::nonLette()],
    'elimina_lette' => fn() => ['eliminate' => Notifica::eliminaLette(), 'non_lette' => Notifica::nonLette()],
    'elimina_tutte' => fn() => ['eliminate' => Notifica::eliminaTutte(), 'non_lette' => 0],
]);
