<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'elenco' => fn() => Archivio::elenco(),
    'list'   => function (array $in) { $d = Archivio::def(Api::str($in, 'archivio')); return ['archivio' => ['nome' => $d['nome'], 'label' => $d['label'], 'desc' => $d['desc'], 'form' => $d['form'], 'columns' => $d['columns']], 'righe' => Archivio::righe($d['nome'])]; },
    'save'   => function (array $in) { $nome = Api::str($in, 'archivio'); $id = Archivio::salva($nome, $in); return ['id' => $id, 'archivio' => $nome, 'messaggio' => empty($in['id']) ? __('Voce aggiunta') : __('Voce aggiornata')]; },
    'delete' => fn(array $in) => ['eliminato' => Archivio::elimina(Api::str($in, 'archivio'), Api::int($in, 'id')), 'messaggio' => __('Voce eliminata')],
], ['*' => 'archivi.leggi', 'save' => 'archivi.modifica', 'delete' => 'archivi.modifica']);
