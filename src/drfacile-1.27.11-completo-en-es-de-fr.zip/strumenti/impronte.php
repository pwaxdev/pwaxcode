<?php
/**
 * IMPRONTE del pacchetto: rigenera docs/impronte.json (md5 abbreviato di ogni file distribuito),
 * il file che diagnosi.php e strumenti/diagnosi.php usano per capire se un aggiornamento è stato applicato
 * per intero o se qualche file è stato modificato a mano sul server.
 *
 *   php strumenti/impronte.php            → riscrive docs/impronte.json
 *   php strumenti/impronte.php verifica   → confronta i file con le impronte salvate (exit 1 se ci sono differenze)
 *
 * Da lanciare SEMPRE come ultimo passo prima di creare lo ZIP di distribuzione.
 * Restano fuori: dati e file generati (data/, temp/, docs/archivio, docs/backup), config/config.php, .gitkeep.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
$root = dirname(__DIR__);
$out = "$root/docs/impronte.json";
$escludi = ['data/', 'temp/', 'docs/archivio/', 'docs/backup/', 'config/config.php', 'docs/impronte.json'];

$file = [];
$it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS));
foreach ($it as $f) {
    $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($root) + 1));
    if (basename($rel) === '.gitkeep' || str_starts_with($rel, '.git/')) continue;
    foreach ($escludi as $e) if ($rel === $e || str_starts_with($rel, $e)) continue 2;
    $file[$rel] = substr(md5_file($f->getPathname()), 0, 10);
}
ksort($file, SORT_STRING);

if (($argv[1] ?? '') === 'verifica') {
    $attese = is_file($out) ? (json_decode((string) file_get_contents($out), true) ?: []) : [];
    $diff = [];
    foreach ($attese as $rel => $h) if (($file[$rel] ?? 'MANCANTE') !== $h) $diff[$rel] = $file[$rel] ?? 'MANCANTE';
    foreach ($file as $rel => $h) if (!isset($attese[$rel])) $diff[$rel] = 'NUOVO';
    if (!$diff) { echo "Impronte coerenti: " . count($file) . " file\n"; exit(0); }
    echo count($diff) . " differenze:\n"; foreach ($diff as $rel => $h) echo "  $rel ($h)\n";
    exit(1);
}
file_put_contents($out, json_encode($file, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n");
echo "docs/impronte.json: " . count($file) . " file\n";
