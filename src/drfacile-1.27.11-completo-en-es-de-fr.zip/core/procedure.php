<?php
/**
 * Voci del modulo Procedure. Ogni voce apre un ARCHIVIO (CRUD standard su una tabella, definito in core/archivi.php)
 * oppure una PROCEDURA (classe in core/procedure/<Nome>.php che estende Procedura: campi di input + esecuzione).
 *
 *   'tipo' => 'archivio',  'archivio'  => 'consensi'        → DataTable + form come nel modulo Archivi
 *   'tipo' => 'procedura', 'procedura' => 'Promemoria'      → form dei parametri + pulsante Esegui + risultato
 *   'tipo' => 'vista',     'vista'     => 'controlli'       → pagina libera: views/procedure/<vista>.php + DRF.procedure.viste.<vista>($root) in assets/js/procedure.js
 *   'tipo' => 'vuoto'                                       → segnaposto
 *   'permesso' => 'procedure.esegui'                         → chi può vederla (core/permessi.php); assente = tutti
 */
$voci = [
    'voce1' => ['label' => __('Voce 1'), 'desc' => __('Archivio demo: registro dei consensi informati'), 'fi' => 'document-signed', 'fa' => 'fa-solid fa-file-signature', 'tipo' => 'archivio', 'archivio' => 'consensi', 'permesso' => 'procedure.esegui'],
    'voce2' => ['label' => __('Voce 2'), 'desc' => __('Procedura demo: promemoria degli appuntamenti'), 'fi' => 'paper-plane', 'fa' => 'fa-regular fa-paper-plane', 'tipo' => 'procedura', 'procedura' => 'Promemoria', 'permesso' => 'procedure.esegui'],
    'voce3' => ['label' => __('Voce 3'), 'desc' => __('Pagina demo: i controlli di DRFacile (modali, messaggi, toast, pannelli, campi…) con il codice per usarli'), 'fi' => 'magic-wand', 'fa' => 'fa-solid fa-wand-magic-sparkles', 'tipo' => 'vista', 'vista' => 'controlli', 'permesso' => 'procedure.esegui'],
    'voce4' => ['label' => __('Voce 4'), 'desc' => 'Pagina demo: l\'editor di testo DRF.rich (formattazione, campi {segnaposto}, moduli) con esempi dal vivo e codice', 'fi' => 'text', 'fa' => 'fa-solid fa-pen-fancy', 'tipo' => 'vista', 'vista' => 'editor', 'permesso' => 'procedure.esegui'],
];

// le estensioni del Negozio aggiungono le loro voci
if (class_exists('Estensioni') && Estensioni::attiva('commercialista')) {
    $voci['contabilita'] = ['label' => __('Contabilità'), 'desc' => __('Esportazione delle fatture per il commercialista: XML in formato elettronico (uno per fattura) e riepilogo CSV, in un archivio ZIP'), 'fi' => 'calculator', 'fa' => 'fa-solid fa-calculator', 'tipo' => 'vista', 'vista' => 'contabilita', 'permesso' => 'contabilita.leggi'];
}
if (class_exists('Hooks')) $voci = Hooks::filter('procedure.voci', $voci);   // hook per le estensioni
// ogni voce può dichiarare 'permesso' (core/permessi.php): chi non ce l'ha non la vede e non può aprirla
if (class_exists('Auth') && PHP_SAPI !== 'cli') $voci = array_filter($voci, fn($v) => Auth::can($v['permesso'] ?? null));
return $voci;
