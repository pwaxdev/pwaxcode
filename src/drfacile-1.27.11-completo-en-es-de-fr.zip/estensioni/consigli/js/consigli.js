/* Estensione "Consigli di fine visita": card nel pannello visita con testo predefinito e frasi rapide
   (dalle Impostazioni dello studio, pannello aggiunto dall'estensione). Il testo viaggia con la visita
   in dati.consigli e alla chiusura diventa la sezione "Consigli" del referto (hook PHP referto.sezioni). */
(function ($) {
  'use strict';
  let cfg = null;
  const config = () => cfg ? $.Deferred().resolve(cfg).promise() : DRF.api.ext('consigli', 'config').then(c => (cfg = c));

  DRF.hooks.add('visita.pannello', function (ctx) {
    const $anam = ctx.$root.find('#vNote').closest('.vcard, .card, .field').first();
    if (!$anam.length) return;
    let $box = $anam.find('.consigli-box');
    if (!$box.length) {
      $box = $(`<div class="consigli-box">
          <b>${DRF.icons.html('comment-heart', 'fa-regular fa-comment-dots')} ${DRF.__('Consigli per il paziente', 'consigli')}</b>
          <div class="consigli-chips"></div>
          <textarea class="input" rows="2" placeholder="${DRF.__('Consigli di fine visita: finiscono nel referto', 'consigli')}"></textarea>
        </div>`).appendTo($anam);
      $box.on('input', 'textarea', function () { if (ctx.visita) ctx.setDati('consigli', { testo: this.value }); });
      $box.on('click', '.chip', function () {
        const $t = $box.find('textarea'), cur = $t.val().trim();
        $t.val((cur ? cur + ' ' : '') + this.dataset.frase).trigger('input');
      });
      DRF.icons.apply($box[0]);
    }
    const salvato = ctx.getDati('consigli');
    $box.find('textarea').prop('disabled', !ctx.visita);
    config().then(c => {
      $box.find('.consigli-chips').html(c.frasi.map(f => `<button type="button" class="chip" data-frase="${DRF.esc(f)}">${DRF.esc(f)}</button>`).join(''));
      // testo salvato con la visita; altrimenti, con "sempre nel referto" acceso, il predefinito già pronto
      $box.find('textarea').val(salvato && salvato.testo != null ? salvato.testo : (ctx.visita && c.auto ? c.testo : ''));
    });
  });

  // in Impostazioni: contatore delle frasi rapide e invalidazione della cache alla modifica
  DRF.hooks.add('impostazioni.pronto', function (ctx) {
    const $card = ctx.pannello('consigli'); if (!$card.length) return;
    const $fr = $card.find('[name=consigli_frasi]'), $lab = $fr.closest('.field').find('label');
    const conta = () => { const n = $fr.val().split('\n').filter(s => s.trim()).length; $lab.find('.consigli-n').remove(); $lab.append(` <span class="consigli-n small muted">${n} ${DRF.util.plural(n, 'frase', 'frasi')}</span>`); };
    $fr.off('input.consigli').on('input.consigli', conta); conta();
    $card.find('[data-save]').off('click.consigli').on('click.consigli', () => { cfg = null; });
  });
})(jQuery);
