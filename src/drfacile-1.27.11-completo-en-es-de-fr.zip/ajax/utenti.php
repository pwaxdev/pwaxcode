<?php
/** Gestione degli utenti dello studio (tabella comune). Più utenti per studio: medici e segreteria. */
require __DIR__ . '/../core/bootstrap.php';
$studioId = fn() => Auth::studioId() ?: throw new ApiException(__('Sessione senza studio: esci e accedi di nuovo'));
Api::run([
    'me' => function () { $u = Auth::utente() ?? []; return ['utente' => ['nome' => $u['nome'] ?? '', 'cognome' => $u['cognome'] ?? '', 'email' => $u['email'] ?? '', 'telefono' => $u['telefono'] ?? '', 'username' => $u['username'] ?? '', 'ruolo' => $u['ruolo'] ?? '']]; },
    'salva_me' => function (array $in) {
        $u = Auth::utente(); $id = (int) ($u['id'] ?? 0);
        if (!$id) throw new ApiException(__('Account legacy: i dati si cambiano da Impostazioni → Profilo'));
        $riga = Utente::trova($id) ?? throw new ApiException(__('Utente non trovato'));
        if (!password_verify((string) ($in['password_attuale'] ?? ''), (string) $riga['password_hash'])) throw new ApiException(__('Password attuale non corretta'));
        $dati = ['nome' => trim(Api::str($in, 'nome')), 'cognome' => trim(Api::str($in, 'cognome')), 'email' => trim(Api::str($in, 'email')), 'telefono' => trim(Api::str($in, 'telefono'))];
        if ($dati['cognome'] === '') throw new ApiException(__('Il cognome è obbligatorio'));
        if ($dati['email'] !== '' && !filter_var($dati['email'], FILTER_VALIDATE_EMAIL)) throw new ApiException(__('Email non valida'));
        $pwd = (string) ($in['password'] ?? '');
        if ($pwd !== '') { if (strlen($pwd) < 8) throw new ApiException(__('La nuova password deve avere almeno 8 caratteri')); $dati['password_hash'] = password_hash($pwd, PASSWORD_DEFAULT); }
        Database::update(Database::comune('utenti'), $dati, 'id = :id', ['id' => $id]);
        Attivita::registra('utente.profilo', 'utenti', $id, 'Dati personali aggiornati' . ($pwd !== '' ? ' (password cambiata)' : ''));
        return ['messaggio' => 'Dati salvati' . ($pwd !== '' ? ': la nuova password vale dal prossimo accesso' : '')];
    },
    'lista' => fn() => ['utenti' => Utente::delloStudio($studioId()), 'io' => (int) (Auth::utente()['id'] ?? 0), 'ruoli' => Utente::ruoli()],
    'salva' => function (array $in) use ($studioId) {
        $id = Utente::salva($in, $studioId());
        Attivita::registra(empty($in['id']) ? 'utente.creato' : 'utente.modificato', 'impostazioni', $id, (string) ($in['username'] ?? ''));
        return ['id' => $id, 'messaggio' => empty($in['id']) ? 'Utente creato' : 'Utente aggiornato'];
    },
    'stato' => function (array $in) use ($studioId) {
        $id = Api::int($in, 'id');
        if ($id === (int) (Auth::utente()['id'] ?? 0)) throw new ApiException(__('Non puoi disattivare il tuo stesso account'));
        $attivi = (int) Database::value('SELECT COUNT(*) FROM ' . Database::comune('utenti') . ' WHERE studio_id = ? AND attivo = 1', [$studioId()]);
        $u = Utente::trova($id) ?? throw new ApiException(__('Utente non trovato'));
        if ((int) $u['attivo'] === 1 && $attivi <= 1) throw new ApiException(__('Deve restare almeno un utente attivo'));
        Database::run('UPDATE ' . Database::comune('utenti') . ' SET attivo = ? WHERE id = ? AND studio_id = ?', [(int) !$u['attivo'], $id, $studioId()]);
        return ['attivo' => (int) !$u['attivo']];
    },
], ['*' => 'utenti.gestisci', 'me' => null, 'salva_me' => null]);
