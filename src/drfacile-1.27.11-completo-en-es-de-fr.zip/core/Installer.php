<?php
/**
 * Installazione (prima esecuzione) e aggiornamento automatico dello schema:
 * le tabelle e le colonne presenti in schema.sql ma assenti nel database vengono aggiunte senza perdere dati.
 */
final class Installer
{
    /** Versione dello schema: quando cambia, al primo avvio viene eseguito aggiorna() */
    /** Versione dell'applicazione: viaggia con il codice (config.php non viene mai toccato dagli aggiornamenti) */
    public const VERSIONE = '1.27.11';
    public const SCHEMA = '1.19.0';
    /** Versione delle tabelle COMUNI (Utente::tabelle, Estensioni::tabelle): quando cambia, il bootstrap le riallinea in ogni sessione */
    public const SCHEMA_COMUNE = '1.7';

    public static function run(): void
    {
        foreach (self::istruzioni() as $stmt) Database::pdo()->exec($stmt);
        self::tabelleComuni();
        Seed::impostazioni();
        Seed::archivi();
        if (Config::get('app.demo')) Seed::demo();
    }

    /** Tabelle condivise (core/schema-comune.sql): create nel database comune se configurato, altrimenti in quello locale */
    public static function tabelleComuni(): void
    {
        $sql = preg_replace('/--[^\n]*/', '', file_get_contents(DRF_ROOT . '/core/schema-comune.sql'));
        preg_match_all('/CREATE TABLE (\w+) \((.*?)\n\);/s', $sql, $tabelle, PREG_SET_ORDER);
        foreach ($tabelle as $t) {
            $q = Database::comune($t[1]);
            if (Database::tableExists($q)) continue;
            $create = str_replace("CREATE TABLE {$t[1]} ", "CREATE TABLE $q ", $t[0]);
            preg_match_all('/CREATE INDEX (\w+) ON ' . $t[1] . '\(([^)]+)\);/', $sql, $idx, PREG_SET_ORDER);
            foreach (self::istruzioni($create) as $stmt) Database::pdo()->exec($stmt);
            foreach ($idx as $i) Database::pdo()->exec("CREATE INDEX {$i[1]} ON $q({$i[2]})");
            Seed::comuni();
        }
    }

    /** Allinea un database esistente allo schema corrente (chiamato a ogni bootstrap, costo trascurabile) */
    public static function aggiorna(): void
    {
        $schema = self::schema();
        preg_match_all('/CREATE TABLE (\w+) \((.*?)\n\);/s', $schema, $tabelle, PREG_SET_ORDER);
        $nuove = false;
        foreach ($tabelle as $t) {
            $nome = $t[1];
            if (!Database::tableExists($nome)) {
                foreach (self::istruzioni("$t[0];") as $stmt) Database::pdo()->exec($stmt);
                $nuove = true;
                continue;
            }
            $tipi = Database::colonneTipi($nome); $presenti = array_keys($tipi);
            foreach (preg_split('/,\n/', trim($t[2])) as $riga) {
                foreach (explode(',', $riga) as $def) {           // gestisce anche più colonne sulla stessa riga
                    $def = trim($def);
                    if ($def === '' || !preg_match('/^(\w+) ([A-Z]+(?:\(\d+(?:,\d+)?\))?)/', $def, $m) || in_array(strtoupper($m[1]), ['PRIMARY', 'FOREIGN', 'UNIQUE'], true)) continue;
                    $tipo = Database::driver() === 'mysql' ? str_replace(['INTEGER', 'REAL'], ['INT', 'DECIMAL(10,2)'], $m[2]) : $m[2];
                    if (!in_array($m[1], $presenti, true)) { Database::pdo()->exec("ALTER TABLE $nome ADD COLUMN {$m[1]} $tipo"); continue; }
                    // MySQL: colonne di testo lungo create come VARCHAR(255) da una versione precedente → TEXT (nessuna perdita di dati)
                    if (Database::driver() === 'mysql' && strtoupper($m[2]) === 'TEXT' && !str_contains($tipi[$m[1]], 'text')) Database::pdo()->exec("ALTER TABLE $nome MODIFY {$m[1]} TEXT");
                    // MySQL: VARCHAR più corti dello schema attuale → allargati
                    if (Database::driver() === 'mysql' && preg_match('/^VARCHAR\((\d+)\)$/i', $m[2], $v) && preg_match('/^varchar\((\d+)\)$/', $tipi[$m[1]], $a) && (int) $a[1] < (int) $v[1]) Database::pdo()->exec("ALTER TABLE $nome MODIFY {$m[1]} VARCHAR({$v[1]})");
                }
            }
        }
        // Anche gli indici possono mancare dopo una prima installazione interrotta.
        // CREATE INDEX non ha una forma portabile IF NOT EXISTS fra SQLite e MySQL/MariaDB:
        // proviamo a crearli e ignoriamo soltanto il caso in cui esistano già.
        preg_match_all('/CREATE INDEX (\w+) ON (\w+)\(([^)]+)\);/', $schema, $indici, PREG_SET_ORDER);
        foreach ($indici as $i) {
            try { Database::pdo()->exec("CREATE INDEX {$i[1]} ON {$i[2]}({$i[3]})"); }
            catch (Throwable $e) { /* indice già presente */ }
        }
        self::tabelleComuni();
        Seed::impostazioni();
        Seed::archivi();
        Seed::messaggi();   // modelli di messaggio predefiniti, se la tabella è nuova
        Impostazione::set('schema_versione', self::SCHEMA);
    }

    private static function schema(): string
    {
        return preg_replace('/--[^\n]*/', '', file_get_contents(DRF_ROOT . '/core/schema.sql'));
    }

    /** Istruzioni SQL pronte per il driver corrente */
    private static function istruzioni(?string $sql = null): array
    {
        $sql = $sql ?? self::schema();
        if (Database::driver() === 'mysql') $sql = self::perMysql($sql);
        return array_values(array_filter(array_map('trim', explode(';', $sql))));
    }

    /** Adatta lo schema SQLite a MySQL/MariaDB */
    public static function perMysql(string $sql): string
    {
        $sql = str_replace('INTEGER PRIMARY KEY AUTOINCREMENT', 'INT AUTO_INCREMENT PRIMARY KEY', $sql);
        $sql = preg_replace('/\bINTEGER\b/', 'INT', $sql);
        $sql = preg_replace('/\bREAL\b/', 'DECIMAL(10,2)', $sql);
        $sql = preg_replace_callback('/REFERENCES (\w+)\((\w+)\) ON DELETE (CASCADE|RESTRICT)/', fn($m) => "/*FK:{$m[1]}:{$m[2]}:{$m[3]}*/", $sql);
        $sql = preg_replace_callback('/CREATE TABLE (\w+) \((.*?)\n\);/s', function ($m) {
            $body = $m[2]; $fk = [];
            $body = preg_replace_callback('/(\w+) INT NOT NULL \/\*FK:(\w+):(\w+):(\w+)\*\//', function ($c) use (&$fk) { $fk[] = "FOREIGN KEY ({$c[1]}) REFERENCES {$c[2]}({$c[3]}) ON DELETE {$c[4]}"; return "{$c[1]} INT NOT NULL"; }, $body);
            if ($fk) $body .= ",\n  " . implode(",\n  ", $fk);
            return "CREATE TABLE {$m[1]} ({$body}\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        }, $sql);
        return $sql;
    }

    /** Svuota il database dello studio e reinstalla (pulsante "Ripristina dati demo").
     *  Le tabelle vengono ricavate da schema.sql: niente liste manuali che possono dimenticare
     *  una tabella aggiunta in futuro (come era successo con `messaggi`).
     */
    public static function reset(): void
    {
        preg_match_all('/CREATE TABLE (\w+) \(/', self::schema(), $m);
        $tabelle = array_values(array_unique($m[1] ?? []));
        if (!$tabelle) throw new RuntimeException('Invalid DRFacile schema: no tables found');

        $pdo = Database::pdo();
        $mysql = Database::driver() === 'mysql';
        if ($mysql) $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        else $pdo->exec('PRAGMA foreign_keys = OFF');

        try {
            // Ordine inverso: prima le tabelle figlie, poi quelle principali. Con i vincoli
            // disattivati non è strettamente necessario, ma rende il reset più robusto.
            foreach (array_reverse($tabelle) as $t) {
                $pdo->exec('DROP TABLE IF EXISTS `' . str_replace('`', '', $t) . '`');
            }
        } finally {
            if ($mysql) $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
            else $pdo->exec('PRAGMA foreign_keys = ON');
        }

        self::run();
    }
}
