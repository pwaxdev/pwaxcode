<?php
return [
    'title' => __('Nuova aliquota IVA'), 'title_edit' => __('Modifica aliquota IVA'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Salva aliquota'),
    'table' => 'iva',
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'iva'],
        ['name' => 'nome', 'label' => __('Nome'), 'type' => 'text', 'required' => true, 'placeholder' => __('Es. Esente art. 10, IVA 22%')],
        ['name' => 'aliquota', 'label' => __('Percentuale'), 'type' => 'text', 'mask' => 'decimale', 'default' => 0, 'row' => 1],
        ['name' => 'predefinita', 'label' => __('Predefinita'), 'type' => 'switch', 'default' => 0, 'row' => 1, 'help' => __('Proposta per le nuove prestazioni e le righe libere')],
        ['name' => 'nota', 'label' => __('Dicitura in fattura'), 'type' => 'text', 'placeholder' => __('Es. Operazione esente IVA art. 10 n. 18 DPR 633/72')],
        ['name' => 'attiva', 'label' => __('Attiva'), 'type' => 'switch', 'default' => 1],
    ],
];
