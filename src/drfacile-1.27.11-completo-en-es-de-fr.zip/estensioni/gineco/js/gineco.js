/* Estensione "Visita ginecologica" 1.3 — sostituzione completa e ACCURATA della visita.
   Stessa grammatica del programma (stepper, select2, inputmask, flatpickr, switch) e i blocchi
   vivi del core ADOTTATI nel percorso: Prestazioni eseguite (→ fatturazione), Parametri vitali
   con peso e altezza (→ sezione del referto), Storico visite del paziente.
   Dati specialistici in visite.dati['gineco'], conclusione → diagnosi, referto da estensione.php. */
(function ($) {
  'use strict';
  const CAMPI = ['motivo', 'menarca', 'um', 'ciclo', 'g', 'p', 'a', 'contraccezione',
    'gravidanza', 'fumo', 'alcol', 'diabete', 'familiarita',
    'esterni', 'speculum', 'collo', 'annessi',
    'pap_data', 'pap_esito', 'tamponi', 'eco', 'seno',
    'conclusione', 'indicazioni', 'controllo'];
  const PASSI = [
    { k: 'anamnesi', label: 'Anamnesi' },
    { k: 'esame', label: 'Esame ginecologico' },
    { k: 'accertamenti', label: 'Accertamenti' },
    { k: 'conclusioni', label: 'Conclusioni' },
  ];
  const I = (fi, fa) => DRF.icons.html(fi, fa);
  const sel = (chiave, opzioni) => `<select class="select" data-gin="${chiave}"><option value=""></option>${opzioni.map(o => `<option>${o}</option>`).join('')}</select>`;
  const sw = (chiave, label) => `<div class="pref pref-sm"><div><b>${label}</b></div><button class="switch" type="button" data-switch="gin_${chiave}"></button><input type="hidden" name="gin_${chiave}" value="0" data-gin="${chiave}"></div>`;
  let tab = 0, ultimaVisita = null;

  DRF.hooks.add('visita.pannello', function (ctx) {
    let $ext = ctx.$root.find('.visita-ext');
    if (!$ext.find('.gin-visita').length) {
      $ext = ctx.sostituisci($(`
        <div class="gin-visita">
          <div class="stepper" id="ginStepper">
            ${PASSI.map((p, i) => `<button class="step ${i === 0 ? 'on' : ''}" data-gtab="${p.k}" type="button"><i class="n">${i + 1}</i>${p.label}</button>`).join('')}
          </div>

          <div class="gtab" data-gtab="anamnesi">
            <div class="gin-slot-vitali"></div>
            <div class="card">
              <h3><i class="ico" data-fi="venus" data-fa="fa-solid fa-venus"></i>Anamnesi ginecologica</h3>
              <div class="field"><label>Motivo della visita</label><input class="input" data-gin="motivo" placeholder="Es. controllo annuale, dismenorrea, perdite…"></div>
              <div class="grid2">
                <div class="field"><label>Ultima mestruazione</label><input class="input" type="date" data-gin="um"></div>
                <div class="field"><label>Ciclo</label>${sel('ciclo', ['Regolare', 'Irregolare', 'Amenorrea', 'Menopausa'])}</div>
                <div class="field"><label>Contraccezione</label>${sel('contraccezione', ['Nessuna', 'Estroprogestinico', 'IUD', 'Preservativo', 'Altro'])}</div>
                <div class="field"><label>Menarca · G · P · A</label><div class="gin-num"><input class="input" data-mask="intero" data-min="5" data-max="25" maxlength="2" placeholder="anni" data-gin="menarca"><input class="input" data-mask="intero" data-min="0" data-max="20" maxlength="2" placeholder="G" data-gin="g"><input class="input" data-mask="intero" data-min="0" data-max="20" maxlength="2" placeholder="P" data-gin="p"><input class="input" data-mask="intero" data-min="0" data-max="20" maxlength="2" placeholder="A" data-gin="a"></div></div>
              </div>
              <div class="gin-switch-riga">
                ${sw('gravidanza', 'Gravidanza in corso')}${sw('fumo', 'Fumatrice')}${sw('alcol', 'Consumo di alcol')}${sw('diabete', 'Diabete')}
              </div>
              <div class="field"><label>Familiarità oncologica (mammella, ovaio, utero)</label><input class="input" data-gin="familiarita" placeholder="Es. madre: ca. mammario a 62 anni"></div>
            </div>
          </div>

          <div class="gtab" data-gtab="esame" hidden>
            <div class="card">
              <h3><i class="ico" data-fi="stethoscope" data-fa="fa-solid fa-stethoscope"></i>Esame ginecologico</h3>
              <div class="grid2">
                <div class="field"><label>Genitali esterni</label><input class="input" data-gin="esterni" placeholder="Es. nella norma"></div>
                <div class="field"><label>Esame con speculum</label><input class="input" data-gin="speculum" placeholder="Es. vagina normotrofica, secrezioni fisiologiche"></div>
                <div class="field"><label>Collo uterino</label><input class="input" data-gin="collo" placeholder="Es. regolare, no sanguinamenti"></div>
                <div class="field"><label>Utero e annessi</label><input class="input" data-gin="annessi" placeholder="Es. utero in AVF, annessi liberi"></div>
              </div>
              <div class="field"><label>Esame del seno</label><input class="input" data-gin="seno" placeholder="Es. nulla da rilevare bilateralmente"></div>
            </div>
          </div>

          <div class="gtab" data-gtab="accertamenti" hidden>
            <div class="card">
              <h3><i class="ico" data-fi="microscope" data-fa="fa-solid fa-microscope"></i>Accertamenti</h3>
              <div class="grid2">
                <div class="field"><label>Pap test · data</label><input class="input" type="date" data-gin="pap_data"></div>
                <div class="field"><label>Pap test · esito</label><input class="input" data-gin="pap_esito" placeholder="Es. negativo per lesioni intraepiteliali"></div>
                <div class="field"><label>Tamponi</label><input class="input" data-gin="tamponi" placeholder="Es. tampone vaginale: negativo"></div>
                <div class="field"><label>Ecografia transvaginale</label><input class="input" data-gin="eco" placeholder="Es. endometrio 6 mm, ovaie regolari"></div>
              </div>
            </div>
          </div>

          <div class="gtab" data-gtab="conclusioni" hidden>
            <div class="card">
              <h3><i class="ico" data-fi="check" data-fa="fa-solid fa-clipboard-check"></i>Conclusioni</h3>
              <div class="gin-slot-prestazioni"></div>
              <div class="field"><label>Conclusione diagnostica</label><input class="input" data-gin="conclusione" placeholder="Diventa la diagnosi della visita, es. Quadro ginecologico nella norma"></div>
              <div class="field"><label>Indicazioni e follow-up</label><textarea class="textarea" data-gin="indicazioni" placeholder="Terapia, esami da eseguire…"></textarea></div>
              <div class="field" style="max-width:220px"><label>Prossimo controllo</label><input class="input" type="date" data-gin="controllo"></div>
            </div>
            <div class="gin-slot-storico"></div>
          </div>

          <div class="row" style="justify-content:space-between;margin-top:14px">
            <button class="btn ghost" type="button" id="ginPrev">${I('angle-left', 'fa-solid fa-chevron-left')}Indietro</button>
            <button class="btn primary" type="button" id="ginNext">Avanti${I('angle-right', 'fa-solid fa-chevron-right')}</button>
          </div>
        </div>`));
      DRF.ui.wire($ext[0]);   // select2, inputmask, flatpickr, switch di casa

      // i blocchi VIVI del core, adottati al posto giusto: continuano a fare il loro mestiere
      $ext.find('.gin-slot-vitali').append(ctx.adotta('#vitals'));                       // parametri con peso e altezza → referto
      $ext.find('.gin-slot-prestazioni').append(ctx.adotta('#vPrest').closest('.field'));// prestazioni eseguite → fatturazione
      $ext.find('.gin-slot-storico').append(ctx.adotta('#vStorico').closest('.card'));   // visite precedenti
      DRF.icons.apply($ext[0]);

      const vai = i => {
        tab = Math.max(0, Math.min(PASSI.length - 1, i));
        $ext.find('#ginStepper .step').each((j, s) => { s.classList.toggle('on', j === tab); s.classList.toggle('done', j < tab); });
        $ext.find('.gtab').each(function () { this.hidden = this.dataset.gtab !== PASSI[tab].k; });
        $ext.find('#ginPrev').prop('disabled', tab === 0);
        $ext.find('#ginNext').html(tab === PASSI.length - 1 ? `${I('check', 'fa-solid fa-check')}Chiudi visita e genera referto` : `Avanti${I('angle-right', 'fa-solid fa-chevron-right')}`);
        DRF.icons.apply($ext.find('#ginNext')[0]);
      };
      $ext.on('click', '#ginStepper .step', function () { vai($(this).index()); });
      $ext.on('click', '#ginPrev', () => vai(tab - 1));
      $ext.on('click', '#ginNext', () => {
        if (tab === PASSI.length - 1) { $ext.data('salva')(); ctx.chiudi(); }   // flush dello stato, poi la chiusura del core
        else vai(tab + 1);
      });
      $ext.data('vai', vai);
      $ext.data('salva', () => {
        const v = {}; CAMPI.forEach(k => { const x = DRF.ui.val($ext.find(`[data-gin="${k}"]`)); if (x && x !== '0') v[k] = x; });
        ctx.setDati('gineco', v);
        ctx.setDiagnosi(v.conclusione ? [v.conclusione] : []);
      });
      $ext.on('input change', '[data-gin]', () => $ext.data('salva')());   // stato in RAM sempre fresco; il debounce verso il server lo fa già l'autosave del core
    }
    // ripristino valori + stato: i blocchi adottati li gestisce già il core
    const dati = ctx.getDati('gineco') || {};
    CAMPI.forEach(k => {
      try {
        const $c = $ext.find(`[data-gin="${k}"]`);
        const eSwitch = ($c.attr('name') || '').indexOf('gin_') === 0;   // NON type=hidden: flatpickr lo usa per le date!
        DRF.ui.setVal($c, dati[k] || (eSwitch ? '0' : ''));
        if (eSwitch) $c.prev('.switch').toggleClass('on', dati[k] === '1');
      } catch (e) { console.error('gineco: ripristino campo ' + k, e); }
    });
    const idOra = ctx.visita ? ctx.visita.id : null;
    if (idOra !== ultimaVisita) { ultimaVisita = idOra; tab = 0; ($ext.data('vai') || $.noop)(0); }   // visita nuova o chiusa: dal primo passo
    $ext.find('[data-gin], .gin-visita .switch').not('[name^="gin_"]').prop('disabled', !ctx.visita);
    $ext.find('.gin-visita .switch').prop('disabled', !ctx.visita);
    $ext.find('select.select[data-gin]').prop('disabled', !ctx.visita).trigger('change.select2');
    $ext.find('.gin-visita').toggleClass('gin-off', !ctx.visita);
  });
})(jQuery);
