<?php /** PROVA DI STAMPA (Impostazioni → Stampa): un referto finto con i dati di esempio · @var array $doc @var array $paziente @var array $medico @var array $stampa @var bool $auto_print */ $tipo = 'referto'; ?>
<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8"><title>Prova di stampa</title><?php include __DIR__ . '/_stile.php'; ?></head>
<body>
<div class="toolbar"><button class="ghost" onclick="window.close()">Chiudi</button><button onclick="window.print()">Stampa / salva PDF</button></div>
<div class="foglio">
  <?php $destra = '<div class="destinatario"><b>' . e($paziente['nome_completo']) . '</b><span>' . e($paziente['indirizzo']) . '</span><span>' . e($paziente['cap'] . ' ' . $paziente['citta'] . ' (' . $paziente['provincia'] . ')') . '</span><span class="mono">CF ' . e($paziente['cf']) . '</span></div>'; include __DIR__ . '/_testata.php'; ?>
  <div class="doc-riga"><b>Prova di stampa</b> del <?= data_it($doc['data']) ?> · formato <?= e($stampa['formato']) ?> <?= $stampa['orientamento'] === 'landscape' ? 'orizzontale' : 'verticale' ?> · margini <?= (int) $stampa['m_sup'] ?>/<?= (int) $stampa['m_des'] ?>/<?= (int) $stampa['m_inf'] ?>/<?= (int) $stampa['m_sin'] ?> mm</div>
  <h2>Anamnesi</h2><p>Paziente in buone condizioni generali. Riferisce cefalea occasionale da circa due settimane, prevalentemente serale, senza nausea né fotofobia. Nega traumi recenti. In terapia con ramipril 5 mg per ipertensione arteriosa, ben tollerato.</p>
  <h2>Esame obiettivo</h2><p>PA 128/82 mmHg, FC 72 bpm ritmico, SpO₂ 98%. Cuore: toni validi, pause libere. Torace: murmure vescicolare normotrasmesso. Addome trattabile, non dolente.</p>
  <h2>Conclusioni</h2><p>Cefalea tensiva. Si consiglia igiene del sonno e controllo fra 30 giorni; in caso di peggioramento rivalutazione anticipata.</p>
  <table><thead><tr><th>Esempio di tabella</th><th class="n">Valore</th></tr></thead><tbody><tr><td>Glicemia</td><td class="n">92 mg/dl</td></tr><tr><td>Colesterolo totale</td><td class="n">184 mg/dl</td></tr></tbody></table>
  <div class="firma"><div><b><?= e($medico['nome']) ?></b>Firmato digitalmente il <?= date('d/m/Y H:i') ?></div></div>
  <?php ob_start(); ?><?= e($medico['studio']) ?><?= $medico['piva'] ? ' · P.IVA ' . e($medico['piva']) : '' ?><?= $medico['ordine'] ? ' · Ordine ' . e($medico['ordine']) : '' ?><?php $piede_extra = '<div class="riga-studio">' . trim(ob_get_clean()) . '</div>'; include __DIR__ . '/_piede.php'; ?>
</div>
<?php if ($auto_print): ?><script>window.print()</script><?php endif; ?>
</body></html>
