<div class="split stagger">
  <div>
    <div class="toolbar">
      <div class="search"><i class="ico" data-fi="search" data-fa="fa-solid fa-magnifying-glass"></i><input id="patSearch" placeholder="<?= __('Cerca per nome, codice fiscale, telefono…') ?>" autocomplete="off"></div>
      <div class="chips" id="patFilters"><button class="chip on" data-f="tutti"><?= __('Tutti') ?></button><button class="chip" data-f="recenti"><?= __('Visti di recente') ?></button><button class="chip" data-f="allergie"><?= __('Con allergie') ?></button></div>
    </div>
    <div class="plist" id="plist"></div>
  </div>
  <div class="card detail" id="pdetail"></div>
</div>
