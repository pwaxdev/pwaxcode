<?php
/**
 * COMANDI DA RIGA DI COMANDO delle estensioni (hook cli.comandi): manutenzioni, ricalcoli, importazioni, sincronizzazioni.
 *
 *   php strumenti/drf.php                                → elenco dei comandi disponibili
 *   DRF_STUDIO=3 php strumenti/drf.php dieta:ricalcola --anno=2026 --verbose
 *
 * Un'estensione registra i suoi comandi in estensione.php:
 *   Hooks::add('cli.comandi', function (array $c) {
 *       $c['dieta:ricalcola'] = ['descrizione' => 'Ricalcola i piani dell\'anno', 'fn' => function (array $arg, array $opt) {
 *           echo "anno " . ($opt['anno'] ?? date('Y')) . "\n"; return 0;   // exit code
 *       }];
 *       return $c;
 *   });
 * $arg = argomenti posizionali, $opt = opzioni --nome=valore (o --flag = true). Lo studio si sceglie con DRF_STUDIO=ID.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
require __DIR__ . '/../core/bootstrap.php';

$comandi = Hooks::filter('cli.comandi', []);
$nome = $argv[1] ?? null;
if ($nome === null || $nome === 'elenco' || !isset($comandi[$nome])) {
    if ($nome !== null && $nome !== 'elenco') echo "Comando sconosciuto: $nome\n\n";
    echo "Comandi disponibili (studio " . (getenv('DRF_STUDIO') ?: 'base') . "):\n";
    if (!$comandi) echo "  (nessuno: le estensioni attive non registrano comandi cli.comandi)\n";
    foreach ($comandi as $k => $c) printf("  %-28s %s\n", $k, $c['descrizione'] ?? '');
    exit($nome === null || $nome === 'elenco' ? 0 : 1);
}
$arg = []; $opt = [];
foreach (array_slice($argv, 2) as $a) {
    if (preg_match('/^--([a-z0-9_-]+)(?:=(.*))?$/i', $a, $m)) $opt[$m[1]] = $m[2] ?? true;
    else $arg[] = $a;
}
$fn = $comandi[$nome]['fn'] ?? null;
if (!is_callable($fn)) exit("Il comando $nome non ha una funzione eseguibile\n");
$code = $fn($arg, $opt);
exit(is_int($code) ? $code : 0);
