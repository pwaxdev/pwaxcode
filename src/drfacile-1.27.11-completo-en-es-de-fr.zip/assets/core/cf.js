/* Codice fiscale: calcolo, verifica e decodifica (stessa logica di core/CodiceFiscale.php) */
DRF.cf = (function () {
  'use strict';
  const MESI = 'ABCDEHLMPRST';
  const DISP = { 0: 1, 1: 0, 2: 5, 3: 7, 4: 9, 5: 13, 6: 15, 7: 17, 8: 19, 9: 21, A: 1, B: 0, C: 5, D: 7, E: 9, F: 13, G: 15, H: 17, I: 19, J: 21, K: 2, L: 4, M: 18, N: 20, O: 11, P: 3, Q: 6, R: 8, S: 12, T: 14, U: 16, V: 10, W: 22, X: 25, Y: 24, Z: 23 };
  const OMO = { L: '0', M: '1', N: '2', P: '3', Q: '4', R: '5', S: '6', T: '7', U: '8', V: '9' };
  const pulisci = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/[^A-Z]/g, '');
  const cons = s => s.replace(/[AEIOU]/g, ''), voc = s => s.replace(/[^AEIOU]/g, '');
  const controllo = cf15 => { let s = 0; for (let i = 0; i < 15; i++) { const c = cf15[i]; s += i % 2 === 0 ? DISP[c] : (/\d/.test(c) ? +c : c.charCodeAt(0) - 65); } return String.fromCharCode(65 + s % 26); };
  return {
    calcola(cognome, nome, nascita, sesso, cod) {
      if (!nascita || !cod || String(cod).length !== 4) return '';
      const d = new Date(nascita + 'T00:00:00'); if (isNaN(d)) return '';
      const cg = pulisci(cognome), nm = pulisci(nome);
      let cn = cons(nm); if (cn.length >= 4) cn = cn[0] + cn[2] + cn[3];
      const parte = (cons(cg) + voc(cg) + 'XXX').slice(0, 3) + (cn + voc(nm) + 'XXX').slice(0, 3) + String(d.getFullYear()).slice(2) + MESI[d.getMonth()] + String(d.getDate() + (String(sesso).toUpperCase() === 'F' ? 40 : 0)).padStart(2, '0') + String(cod).toUpperCase();
      return parte + controllo(parte);
    },
    valida(cf) {
      cf = String(cf || '').toUpperCase().trim();
      if (!/^[A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]$/.test(cf)) return false;
      return controllo(cf.slice(0, 15)) === cf[15];
    },
    decodifica(cf) {
      cf = String(cf || '').toUpperCase().trim(); if (!this.valida(cf)) return null;
      const num = s => [...s].map(c => /\d/.test(c) ? c : OMO[c]).join('');
      const aa = +num(cf.slice(6, 8)), mese = MESI.indexOf(cf[8]) + 1; let gg = +num(cf.slice(9, 11));
      const sesso = gg > 40 ? 'F' : 'M'; if (gg > 40) gg -= 40;
      const yy = new Date().getFullYear() % 100; let anno = aa + (yy >= aa ? 2000 : 1900); if (anno > new Date().getFullYear()) anno -= 100;
      return { nascita: `${anno}-${String(mese).padStart(2, '0')}-${String(gg).padStart(2, '0')}`, sesso, cod: cf[11] + num(cf.slice(12, 15)) };
    }
  };
})();
