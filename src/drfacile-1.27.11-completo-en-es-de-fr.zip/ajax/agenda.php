<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    // Vista giornaliera + conteggi settimana + prossimo appuntamento di oggi
    'giorno' => function (array $in) {
        $data = preg_match('/^\d{4}-\d{2}-\d{2}$/', $in['data'] ?? '') ? $in['data'] : oggi();
        return ['data' => $data, 'appuntamenti' => Appuntamento::delGiorno($data), 'settimana' => Appuntamento::contaSettimana($data), 'prossimo' => Appuntamento::prossimo(), 'n_oggi' => Appuntamento::contaGiorno(oggi()), 'tipi' => Appuntamento::tipi()];
    },
    // Vista mensile
    'mese' => function (array $in) {
        $data = preg_match('/^\d{4}-\d{2}/', $in['data'] ?? '') ? $in['data'] : oggi();
        $anno = (int) substr($data, 0, 4); $mese = (int) substr($data, 5, 2);
        return ['anno' => $anno, 'mese' => $mese, 'label' => ucfirst(mese_it($mese)) . " $anno", 'giorni' => Appuntamento::delMese($anno, $mese), 'prossimo' => Appuntamento::prossimo(), 'n_oggi' => Appuntamento::contaGiorno(oggi()), 'tipi' => Appuntamento::tipi()];
    },
    'get'    => fn(array $in) => Appuntamento::find(Api::int($in, 'id')) ?? throw new ApiException(__('Appuntamento non trovato'), 404),
    'save'   => function (array $in) { $r = Appuntamento::salvaDaForm($in); Hooks::run('appuntamento.salvato', (int) ($r['id'] ?? 0), $r); return $r; },
    'stato'  => function (array $in) { $a = Appuntamento::find(Api::int($in, 'id')) ?? throw new ApiException(__('Appuntamento non trovato'), 404); Appuntamento::save(['id' => $a['id'], 'stato' => in_array($in['stato'] ?? '', ['prenotato', 'completato', 'annullato', 'assente']) ? $in['stato'] : 'prenotato']); return ['id' => $a['id']]; },
    'delete' => fn(array $in) => ['eliminato' => Appuntamento::delete(Api::int($in, 'id'))],
], ['*' => 'agenda.leggi', 'save' => 'agenda.modifica', 'stato' => 'agenda.modifica', 'delete' => 'agenda.modifica']);
