/* Componenti di interfaccia: toast, sheet (pannello laterale), dialog di conferma, wiring di seg/switch/select2, DataTables, tema */
DRF.ui = (function ($) {
  'use strict';
  const ICON = { success: ['check', 'fa-solid fa-check'], error: ['exclamation', 'fa-solid fa-triangle-exclamation'], warn: ['exclamation', 'fa-solid fa-triangle-exclamation'], info: ['info', 'fa-solid fa-circle-info'] };
  let onOk = null, dialogResolve = null, modalResolve = null, maskReady = false;
  /** Alias Inputmask (stessi di Igea) + varianti per i parametri clinici */
  function initMasks() {
    if (maskReady || !window.Inputmask) return; maskReady = true;
    const base = { radixPoint: ',', groupSeparator: '.', alias: 'numeric', placeholder: '0', autoGroup: true, digitsOptional: false, clearMaskOnLostFocus: false, unmaskAsNumber: true, rightAlign: false };
    Inputmask.extendAliases({
      euros: Object.assign({}, base, { prefix: '€ ', digits: 2 }),
      numero: Object.assign({}, base, { prefix: '', digits: 0 }),
      decimale: Object.assign({}, base, { prefix: '', digits: 2 }),
      sconto: Object.assign({}, base, { prefix: '', suffix: '%', digits: 0 }),
      intero: Object.assign({}, base, { prefix: '', digits: 0, placeholder: '', clearMaskOnLostFocus: true, autoGroup: false }),
      decimale1: Object.assign({}, base, { prefix: '', digits: 1, digitsOptional: true, placeholder: '', clearMaskOnLostFocus: true, autoGroup: false }),
      cap: { mask: '99999', placeholder: '' },
    });
  }
  const DT_IT = { emptyTable: DRF.__('Nessun dato disponibile'), info: DRF.__('Da _START_ a _END_ di _TOTAL_'), infoEmpty: DRF.__('Nessun elemento'), infoFiltered: DRF.__('(filtrati da _MAX_ totali)'), lengthMenu: DRF.__('Mostra _MENU_'), loadingRecords: DRF.__('Caricamento…'), processing: DRF.__('Elaborazione…'), search: DRF.__('Cerca'), zeroRecords: DRF.__('Nessun risultato'), paginate: { first: '«', last: '»', next: '›', previous: '‹' }, aria: { orderable: DRF.__('Ordina'), orderableReverse: DRF.__('Ordina al contrario') } };

  const UI = {
    init() {
      $('#sheetClose, #sheetCancel, #backdrop').on('click', UI.closeSheet);
      $('#sheetOk').on('click', () => { if (onOk && onOk() === false) return; });
      $('#sheetBody').on('submit', e => { e.preventDefault(); $('#sheetOk').trigger('click'); });
      $('#dialog').on('click', '[data-dlg]', function () { UI._dialogDone(this.dataset.dlg); });
      $('#modalClose, #modalCancel').on('click', () => UI._modalDone(false));
      $('#modalOk').on('click', () => UI._modalDone(true));
      $(document).on('keydown', e => {
        if (e.key !== 'Escape') return;
        // prima chiudo calendari e tendine aperte, poi (al prossimo Esc) dialog e pannello
        let chiuso = false;
        $('input').each(function () { if (this._flatpickr && this._flatpickr.isOpen) { this._flatpickr.close(); chiuso = true; } });
        if ($('.select2-container--open').length) { $('select.select2-hidden-accessible').select2('close'); chiuso = true; }
        if (chiuso) return;
        if ($('#dialog').hasClass('open')) UI._dialogDone('esc'); else if ($('#modal').hasClass('open')) UI._modalDone(false); else UI.closeSheet();
      });
      UI.wire(document);
      UI.tooltips();
    },

    /** Tooltip coerente con quelli della rail per tutti gli elementi che usano title="…".
        Il title viene rimosso al primo utilizzo per evitare il fumetto nativo del browser. */
    tooltips() {
      if ($('#drfTooltip').length) return;
      const $tip = $('<div class="drf-tooltip" id="drfTooltip" role="tooltip" aria-hidden="true"></div>').appendTo('body');
      let timer = null, current = null;
      const hide = () => { clearTimeout(timer); current = null; $tip.removeClass('show').attr('aria-hidden', 'true'); };
      const show = el => {
        clearTimeout(timer);
        const $el = $(el); let txt = $el.attr('title') || $el.attr('data-drf-title');
        if (!txt) return;
        if ($el.attr('title')) {
          $el.attr('data-drf-title', txt).removeAttr('title');
          if (!$el.attr('aria-label') && !$el.text().trim()) $el.attr('aria-label', txt);
        }
        current = el;
        timer = setTimeout(() => {
          if (current !== el || !document.documentElement.contains(el)) return;
          $tip.text(txt).attr('aria-hidden', 'false').removeClass('show').css({ left: 0, top: 0 });
          const r = el.getBoundingClientRect(), tw = $tip.outerWidth(), th = $tip.outerHeight(), gap = 10, pad = 8;
          let pos = r.left < 100 ? 'right' : 'top';
          let left = pos === 'right' ? r.right + gap : r.left + r.width / 2 - tw / 2;
          let top = pos === 'right' ? r.top + r.height / 2 - th / 2 : r.top - th - gap;
          if (pos === 'top' && top < pad) { pos = 'bottom'; top = r.bottom + gap; }
          if (pos === 'right' && left + tw > innerWidth - pad) { pos = 'left'; left = r.left - tw - gap; }
          left = Math.max(pad, Math.min(left, innerWidth - tw - pad));
          top = Math.max(pad, Math.min(top, innerHeight - th - pad));
          $tip.attr('data-pos', pos).css({ left: Math.round(left), top: Math.round(top) });
          requestAnimationFrame(() => $tip.addClass('show'));
        }, 180);
      };
      $(document)
        .on('mouseenter.drfTip focusin.drfTip', '[title], [data-drf-title]', function () { show(this); })
        .on('mouseleave.drfTip focusout.drfTip mousedown.drfTip', '[title], [data-drf-title]', hide);
      $(window).on('scroll.drfTip resize.drfTip', hide);
    },

    /** Notifica in basso a destra. kind: success | error | warn | info, oppure {fi, fa}. opts.undo = funzione → pulsante "Annulla" (8 s) */
    toast(msg, kind = 'success', opts) {
      const [fi, fa] = typeof kind === 'object' ? [kind.fi, kind.fa] : (ICON[kind] || ICON.success);
      const cls = typeof kind === 'string' ? kind : 'success';
      const $t = $(`<div class="toast ${cls}">${DRF.icons.html(fi, fa)}<span>${DRF.esc(msg)}</span>${opts && opts.undo ? '<button type="button" class="toast-undo">' + DRF.__('Annulla') + '</button><i class="toast-bar"></i>' : ''}</div>`).appendTo('#toasts');
      DRF.icons.apply($t[0]);
      DRF.sound.play(cls === 'error' ? 'error' : cls === 'success' ? 'success' : 'notify');
      const via = () => { $t.addClass('out'); setTimeout(() => $t.remove(), 320); };
      const ms = opts && opts.undo ? 8000 : cls === 'error' ? 4500 : 3200;
      const timer = setTimeout(via, ms);
      if (opts && opts.undo) { $t.find('.toast-bar').css('animation-duration', ms + 'ms'); $t.find('.toast-undo').on('click', () => { clearTimeout(timer); via(); opts.undo(); }); }
      return $t;
    },

    /** Barra dei passi: steps($el, { steps: [{ label, desc?, fi, fa }], current: 0 }) → { set(i), error(i, msg), done(), get() }
        Stati: fatti (verde), corrente (in corso), da fare; error(i) marca il passo in rosso. */
    steps($el, o) {
      const st = { cur: o.current || 0, err: null };
      const render = () => {
        $el.addClass('steps').html(o.steps.map((s, i) => { const stato = st.err === i ? 'err' : i < st.cur ? 'done' : i === st.cur ? 'cur' : 'todo';
          return `<div class="step-it ${stato}"><div class="step-dot">${stato === 'done' ? DRF.icons.html('check', 'fa-solid fa-check') : stato === 'err' ? DRF.icons.html('cross-small', 'fa-solid fa-xmark') : (s.fi ? DRF.icons.html(s.fi, s.fa) : `<b>${i + 1}</b>`)}</div><div class="step-txt"><b>${DRF.esc(s.label)}</b>${s.desc ? `<span>${DRF.esc(s.desc)}</span>` : ''}${st.err === i && st.errMsg ? `<span class="step-err">${DRF.esc(st.errMsg)}</span>` : ''}</div></div>`; }).join('<div class="step-line"></div>'));
        $el.find('.step-line').each((i, l) => l.classList.toggle('done', i < st.cur));
        DRF.icons.apply($el[0]);
      };
      render();
      return { set(i) { st.cur = Math.max(0, i); st.err = null; render(); }, error(i, msg) { st.err = i; st.errMsg = msg || ''; st.cur = i; render(); }, done() { st.cur = o.steps.length; st.err = null; render(); }, get: () => st.cur };
    },

    /** Linea del tempo: timeline($el, items, { compatta: false, anni: true })
        item: { data:'2026-06-29', tipo:'Visita', titolo, testo, fi, fa, colore, run } — cliccabile se run è definita. */
    timeline($el, items, o) {
      o = o || {}; const compatta = !!o.compatta;
      const lista = (items || []).slice().sort((a, b) => String(b.data || '').localeCompare(String(a.data || '')));
      let html = '', anno = null;
      lista.forEach((it, i) => {
        const y = String(it.data || '').slice(0, 4);
        if (o.anni !== false && y && y !== anno) { anno = y; html += `<div class="tl-year"><span>${y}</span></div>`; }
        const col = it.colore || 'var(--accent)';
        html += `<div class="tl-it ${compatta ? 'r' : (i % 2 ? 'r' : 'l')} ${it.run ? 'click' : ''}" data-i="${i}" style="--c:${col}"><span class="tl-dot">${it.fi ? DRF.icons.html(it.fi, it.fa) : ''}</span><div class="tl-card"><div class="tl-head"><span class="tl-tipo">${DRF.esc(it.tipo || '')}</span><span class="tl-data">${it.data ? DRF.util.fmtIso(it.data) : ''}${it.ora ? ' · ' + DRF.esc(it.ora) : ''}</span></div><b>${DRF.esc(it.titolo || '')}</b>${it.testo ? `<span>${DRF.esc(it.testo)}</span>` : ''}</div></div>`;
      });
      $el.addClass('timeline ' + (compatta ? 'compatta' : 'alterna')).html(html || '<div class="empty">' + DRF.__('Nessun evento.') + '</div>');
      DRF.icons.apply($el[0]);
      $el.off('click.tl').on('click.tl', '.tl-it.click', function () { const it = lista[+this.dataset.i]; if (it && it.run) it.run(it); });
      return $el;
    },

    /** Apre il pannello laterale. onOk può restituire false per tenerlo aperto. */
    openSheet(title, html, ok, okLabel) {
      $('#sheetTitle').text(title); $('#sheetBody').html(html); $('#sheetOk').text(okLabel || DRF.__('Salva')).prop('disabled', false);
      onOk = ok || null;
      DRF.icons.apply($('#sheetBody')[0]); UI.wire($('#sheetBody')[0]);
      $('#sheet').addClass('open'); $('#backdrop').addClass('open');
      setTimeout(() => $('#sheetBody').find('input:not([type=hidden]),select,textarea').first().trigger('focus'), 380);
    },
    closeSheet() { $('#sheet').removeClass('open'); $('#backdrop').removeClass('open'); onOk = null; setTimeout(() => $('#sheet').removeClass('wide nofoot'), 500); },   // nofoot: pannello senza pulsanti Annulla/Salva (es. gestione documentale)
    sheetBusy(b) { $('#sheetOk').prop('disabled', !!b); },

    /** Messaggio con pulsanti: dialog({ title, text|html, kind, buttons: [{k:'si', label:DRF.__('Sì'), cls:'primary'}, …] }) → promise con la chiave premuta ('esc' se annullato) */
    dialog(o) {
      const ICONE = { info: ['info', 'fa-solid fa-circle-info'], question: ['interrogation', 'fa-solid fa-question'], warn: ['exclamation', 'fa-solid fa-triangle-exclamation'], error: ['cross-circle', 'fa-solid fa-circle-xmark'], success: ['check', 'fa-solid fa-check'] };
      const kind = ICONE[o.kind] ? o.kind : 'info';
      $('#dialogTitle').text(o.title || ''); $('#dialogText').html(o.html || DRF.esc(o.text || ''));
      $('#dialogIcon').attr('class', 'dialog-icon ' + kind).html(DRF.icons.html(...ICONE[kind]));
      const btns = o.buttons || [{ k: 'no', label: DRF.__('Annulla'), cls: 'ghost' }, { k: 'si', label: DRF.__('Conferma'), cls: 'primary' }];
      $('#dialogBtns').html(btns.map(b => `<button class="btn ${b.cls || 'ghost'}" type="button" data-dlg="${DRF.esc(b.k)}">${DRF.esc(b.label)}</button>`).join(''));
      DRF.icons.apply($('#dialog')[0]);
      $('#dialog').addClass('open'); DRF.sound.play(kind === 'error' ? 'error' : 'notify');
      setTimeout(() => ($('#dialogBtns .btn.primary').first()[0] || $('#dialogBtns .btn').last()[0] || {}).focus?.(), 50);
      return new Promise(res => { dialogResolve = res; });
    },
    /** Conferma sì/no → promise true/false */
    confirm(title, text, yesLabel, kind) { return UI.dialog({ title, text, kind: kind || 'question', buttons: [{ k: 'no', label: DRF.__('Annulla'), cls: 'ghost' }, { k: 'si', label: yesLabel || DRF.__('Conferma'), cls: 'primary' }] }).then(k => k === 'si'); },
    /** Sì / No / Annulla → promise 'si' | 'no' | 'annulla' */
    confirm3(title, text, labels) { const l = Object.assign({ si: DRF.__('Sì'), no: 'No', annulla: DRF.__('Annulla') }, labels || {}); return UI.dialog({ title, text, kind: 'question', buttons: [{ k: 'annulla', label: l.annulla, cls: 'ghost' }, { k: 'no', label: l.no, cls: 'danger' }, { k: 'si', label: l.si, cls: 'primary' }] }).then(k => k === 'esc' ? 'annulla' : k); },
    /** Avviso con il solo OK */
    alert(title, text, kind) { return UI.dialog({ title, text, kind: kind || 'info', buttons: [{ k: 'ok', label: 'OK', cls: 'primary' }] }); },
    _dialogDone(v) { $('#dialog').removeClass('open'); if (dialogResolve) { const r = dialogResolve; dialogResolve = null; r(v); } },

    /** Modale: modal({ title, html, size:'sm'|'lg'|'xl', ok:'OK'|false, cancel:DRF.__('Chiudi'), onOpen($body), onOk($body) }) → promise true/false.
        onOk può restituire false per tenere aperta la modale (validazione). */
    modal(o) {
      const $m = $('#modal');
      $m.removeClass('sm lg xl').addClass(o.size || 'sm');
      $('#modalTitle').text(o.title || ''); $('#modalBody').html(o.html || '');
      $('#modalOk').text(o.ok || 'OK').toggle(o.ok !== false); $('#modalCancel').text(o.cancel || DRF.__('Chiudi'));
      $m.data('onOk', o.onOk || null);
      UI.wire($('#modalBody')[0]); DRF.icons.apply($m[0]);
      $m.addClass('open'); if (o.onOpen) o.onOpen($('#modalBody'));
      setTimeout(() => $('#modalBody').find('input:not([type=hidden]),select,textarea,button').first().trigger('focus'), 60);
      return new Promise(res => { modalResolve = res; });
    },
    _modalDone(ok) {
      const $m = $('#modal'), onOk = $m.data('onOk');
      if (ok && onOk && onOk($('#modalBody')) === false) return;
      $m.removeClass('open'); if (modalResolve) { const r = modalResolve; modalResolve = null; r(!!ok); }
    },
    closeModal() { UI._modalDone(false); },

    /** Chiede un testo: prompt('Rinomina', 'Nome', 'attuale') → promise con la stringa (null se annullato) */
    prompt(title, label, value) {
      let val = null;
      return UI.modal({ title, ok: 'OK', cancel: DRF.__('Annulla'), html: `<div class="field"><label>${DRF.esc(label || '')}</label><input class="input" id="uiPromptIn" value="${DRF.esc(value || '')}" autocomplete="off"></div>`,
        onOpen($b) { setTimeout(() => $b.find('#uiPromptIn').trigger('focus').get(0).select(), 60); $b.find('#uiPromptIn').on('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#modalOk').trigger('click'); } }); },
        onOk($b) { val = $b.find('#uiPromptIn').val(); } }).then(ok => ok ? val : null);
    },

    /** Select2 su una select (già inclusa in wire, utile dopo un rendering dinamico) */
    select($sel, opts) {
      $sel.each(function () {
        const $s = $(this); if ($s.data('select2')) return;
        const parent = $s.closest('.sheet, .dialog-box');
        const first = $s.find('option').first();
        $s.select2(Object.assign({ language: ((DRF.config.locale || 'it_IT').slice(0, 2) === 'it' ? 'it' : 'en'), width: '100%', minimumResultsForSearch: $s.find('option').length > 7 ? 0 : Infinity,
          placeholder: first.val() === '' ? first.text() : undefined, allowClear: false, dropdownParent: parent.length ? parent : $('body') }, opts || {}));
      });
      return $sel;
    },
    setSelect($sel, val) { $sel.val(val == null ? '' : String(val)).trigger('change'); },

    /** DataTable con lingua italiana e stile DRFacile. opts come DataTables 2 (columns, data, order…) */
    datatable($table, opts) {
      const dt = new DataTable($table[0], Object.assign({ language: DT_IT, pageLength: 15, lengthMenu: [10, 15, 25, 50, 100], autoWidth: false,
        layout: { topStart: 'search', topEnd: 'pageLength', bottomStart: 'info', bottomEnd: 'paging' },
        initComplete() { const $w = $(this.api().table().container()); UI.select($w.find('.dt-length select').addClass('select'), { minimumResultsForSearch: Infinity }); } }, opts || {}));
      $table.on('draw.dt', () => { DRF.icons.apply($table[0]); });
      DRF.icons.apply($table[0]);   // il primo draw avviene nel costruttore, prima del binding
      return dt;
    },

    /** Valore "grezzo" di un campo: numero per le maschere, Y-m-d per le date, valore della select */
    val($el) {
      const el = $el[0]; if (!el) return '';
      if (el.inputmask) { const u = $el.inputmask('unmaskedvalue'); return u === '' || u == null ? '' : u; }
      return $el.val();
    },
    /** Imposta un valore aggiornando Select2, flatpickr e Inputmask */
    setVal($el, v) {
      const el = $el[0]; if (!el) return;
      v = v == null ? '' : v;
      if (el._drfRich) { el._drfRich.set(v); return; }
      if (el._flatpickr) { try { if (v) el._flatpickr.setDate(v, false); else el._flatpickr.clear(); } catch (e) { el._flatpickr.clear(); } return; }
      if (el.inputmask) { $el.val(v === '' ? '' : String(v).replace('.', ',')); return; }
      $el.val(String(v)); if ($el.is('select')) $el.trigger('change.select2');
    },
    /** Date e ore con flatpickr (input[type=date|time]) */
    dates(root) {
      if (!window.flatpickr) return;
      $(root).find('input[type=date],input[type=time]').addBack('input[type=date],input[type=time]').each(function () {
        if (this._flatpickr) return;
        const time = this.type === 'time', v = this.value; this.type = 'text';
        const opts = time ? { enableTime: true, noCalendar: true, dateFormat: 'H:i', time_24hr: true, minuteIncrement: +(this.getAttribute('step') || 900) / 60 || 15, defaultDate: v || null }
          : { dateFormat: 'Y-m-d', altInput: true, altFormat: 'd/m/Y', altInputClass: this.className, allowInput: true, defaultDate: v || null };
        const lang = (DRF.config.locale || 'it_IT').slice(0, 2);
        flatpickr(this, Object.assign({ locale: (window.flatpickr.l10ns && window.flatpickr.l10ns[lang]) ? lang : 'default', disableMobile: true, onChange: () => $(this).trigger('change') }, opts));
      });
    },
    /** Maschere numeriche (data-mask="euros|numero|decimale|sconto|intero|decimale1|cap") */
    masks(root) {
      if (!window.Inputmask) return; initMasks();
      $(root).find('[data-mask]').addBack('[data-mask]').each(function () {
        if (this.inputmask) return;
        const opt = {};
        if (this.dataset.min !== undefined) opt.min = parseFloat(this.dataset.min);
        if (this.dataset.max !== undefined) opt.max = parseFloat(this.dataset.max);
        Inputmask(this.dataset.mask, opt).mask(this);
      });
    },
    /** Select2 con ricerca AJAX sui comuni: alla scelta compila CAP / provincia / codice catastale (data-fill) */
    comuni($sel) {
      $sel.each(function () {
        const $s = $(this); if ($s.data('select2')) return;
        const parent = $s.closest('.sheet, .dialog-box'), fill = $s.data('fill') || {};
        $s.select2({ language: ((DRF.config.locale || 'it_IT').slice(0, 2) === 'it' ? 'it' : 'en'), width: '100%', placeholder: DRF.__('Cerca comune…'), allowClear: true, minimumInputLength: 2, dropdownParent: parent.length ? parent : $('body'),
          ajax: { url: 'ajax/comuni.php?action=cerca', dataType: 'json', delay: 150, data: p => ({ q: p.term }), processResults: r => ({ results: r.ok ? r.data : [] }) } });
        $s.on('select2:select', e => { const d = e.params.data, $f = $s.closest('form, .sheet-body, .card, .panel'); Object.keys(fill).forEach(k => { const $t = $f.find(`[name="${fill[k]}"]`); if ($t.length && d[k] != null) UI.setVal($t, d[k]); }); });
        $s.on('select2:clear', () => { const $f = $s.closest('form, .sheet-body, .card, .panel'); Object.keys(fill).forEach(k => UI.setVal($f.find(`[name="${fill[k]}"]`), '')); });
      });
    },
    /** Editor DRF.rich su ogni <textarea class="rich"> (la textarea resta sincronizzata) */
    rich(root) { if (DRF.rich) $(root).find('textarea.rich').addBack('textarea.rich').each(function () { DRF.rich.mount(this); }); },

    /** Campi condizionati: [data-show-if="campo"] visibili solo se l'input hidden "campo" vale 1 */
    showIf(root) {
      const $r = $(root), refresh = () => $r.find('[data-show-if]').each(function () { const neg = this.dataset.showIf.startsWith('!'), nome = neg ? this.dataset.showIf.slice(1) : this.dataset.showIf; const v = $r.find(`[name="${nome}"]`).val(); const on = (v === '1' || v === 'true' || v === 'on'); this.hidden = neg ? on : !on; });
      $r.find('[data-show-if]').each(function () { const nome = this.dataset.showIf.replace(/^!/, ''); const $src = $r.find(`[name="${nome}"]`); if (!$src.data('showif')) { $src.data('showif', true); $src.on('change', refresh); } });
      refresh();
    },
    /** Codice fiscale: verifica in tempo reale, calcolo dai dati anagrafici, decodifica di data/sesso/comune */
    cf(root) {
      const $r = $(root), $cf = $r.find('input[data-cf]'); if (!$cf.length || $cf.data('cf')) return; $cf.data('cf', true);
      const $field = $cf.closest('.field'), f = n => $r.find(`[name="${n}"]`);
      const hint = (t, ok) => { $field.find('.hint').remove(); $field.removeClass('cf-ok cf-ko'); if (t) { $field.addClass(ok ? 'cf-ok' : 'cf-ko').append(`<div class="hint ${ok ? 'ok' : 'ko'}">${t}</div>`); } };
      const verifica = () => {
        const v = $cf.val().toUpperCase().trim(); $cf.val(v); if (!v) return hint('');
        if (!DRF.cf.valida(v)) return hint(DRF.__('Codice fiscale non valido'), false);
        const d = DRF.cf.decodifica(v), nasc = UI.val(f('nascita'));
        if (!nasc) UI.setVal(f('nascita'), d.nascita);
        else if (nasc !== d.nascita) return hint(`${DRF.__('Codice valido ma la data di nascita (')}${DRF.util.fmtIso(nasc)}${DRF.__(') non corrisponde: nel codice è')} ${DRF.util.fmtIso(d.nascita)}`, false);
        if (f('sesso').length) { f('sesso').val(d.sesso); f('sesso').prev('.seg').find('button').removeClass('on').filter(`[data-v="${d.sesso}"]`).addClass('on'); }
        if (f('cod_nascita').length && !f('cod_nascita').val()) { f('cod_nascita').val(d.cod); if (!f('comune_nascita').val()) DRF.api.get('comuni', 'codice', { cod: d.cod }).then(c => { if (c) { const $s = f('comune_nascita'); $s.append(new Option(c.nome, c.nome, true, true)).trigger('change'); } }); }
        hint(`${DRF.__('Valido ·')} ${DRF.util.fmtIso(d.nascita)} · ${d.sesso}`, true);
      };
      $cf.on('blur change', verifica);
      $r.find('[data-cf-calc]').on('click', () => {
        const cod = f('cod_nascita').val(), cf = DRF.cf.calcola(f('cognome').val(), f('nome').val(), UI.val(f('nascita')), f('sesso').val(), cod);
        if (!cf) return UI.toast(DRF.__('Per calcolare servono cognome, nome, data di nascita, sesso e comune di nascita'), 'warn');
        $cf.val(cf); verifica(); UI.toast(DRF.__('Codice fiscale calcolato'), 'info');
      });
      if ($cf.val()) verifica();
    },

    /** Attiva i controlli "seg" (segmented con input hidden), "switch", Select2, comuni, date, maschere, campi condizionati e CF */
    wire(root) {
      const $r = $(root);
      UI.comuni($r.find('select.comune').addBack('select.comune'));
      UI.select($r.find('select.select').not('.comune').addBack('select.select:not(.comune)'));
      UI.dates(root); UI.masks(root); UI.showIf(root); UI.cf(root); UI.rich(root);
      $r.find('.seg').addBack('.seg').each(function () {
        const $seg = $(this);
        if ($seg.data('wired')) return; $seg.data('wired', true);
        $seg.on('click', 'button', function () {
          $seg.find('button').removeClass('on'); $(this).addClass('on');
          const name = $seg.data('seg'); if (name) $seg.next(`input[name="${name}"]`).val($(this).data('v')).trigger('change');
          $seg.trigger('seg:change', [$(this).data('v')]);
        });
      });
      $r.find('.switch[data-switch]').addBack('.switch[data-switch]').each(function () {
        const $s = $(this); if ($s.data('wired')) return; $s.data('wired', true);
        $s.on('click', function () { $s.toggleClass('on'); $s.next('input[type=hidden]').val($s.hasClass('on') ? '1' : '0').trigger('change'); });
      });
    },
    segValue($seg) { return $seg.find('button.on').data('v'); },

    /** Legge tutti i campi con name dentro root → oggetto */
    formData(root) {
      const out = {};
      $(root).find(':input[name]').each(function () {
        const n = this.name; let v = UI.val($(this));
        if (this.type === 'checkbox') v = this.checked ? 1 : 0;
        out[n] = v;
      });
      return out;
    },
    badge(cls, text) { return `<span class="badge ${cls}">${DRF.esc(text)}</span>`; },
    avatar(nome, extra) { return `<div class="av" style="${DRF.util.avStyle(nome)}${extra || ''}">${DRF.util.initials(nome)}</div>`; },
    empty(html) { return `<div class="empty">${html}</div>`; },

    setTheme(t, persist) {
      document.documentElement.dataset.theme = t;
      const i = $('#themeBtn i')[0];
      if (i) { i.dataset.fi = t === 'dark' ? 'sun' : 'moon'; i.dataset.fa = t === 'dark' ? 'fa-regular fa-sun' : 'fa-regular fa-moon'; DRF.icons.apply(i); }
      $('#prefTheme').toggleClass('on', t === 'dark');
      DRF.config.pref = DRF.config.pref || {}; DRF.config.pref.tema = t;
      if (persist) DRF.api.post('impostazioni', 'save', { pref_tema: t });
    }
  };
  return UI;
})(jQuery);
