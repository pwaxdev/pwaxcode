<?php
/**
 * DRFacile · configurazione dell'applicazione (config/config.php)
 * Modifica questo file per adattare il gestionale al tuo studio: credenziali, database, percorsi, parametri.
 */
return [
    'app' => [
        'name'     => 'DRFacile',
        // la versione NON si imposta qui: viaggia con il codice (Installer::VERSIONE)
        'timezone' => 'Europe/Rome',
        'debug'    => true,   // in produzione: false
        'demo'     => true,   // alla prima installazione carica i dati dimostrativi (pazienti, agenda, referti…)
    ],

    // Database: SQLite (zero configurazione, ideale per il monoutente) oppure MySQL
    'db' => [
        'driver' => 'sqlite',
        'sqlite' => DRF_ROOT . '/data/drfacile.sqlite',
        'mysql'  => ['dsn' => 'mysql:host=127.0.0.1;dbname=drfacile;charset=utf8mb4', 'user' => 'drfacile', 'pass' => ''],
        // SaaS: database delle tabelle condivise fra tutti i professionisti (comuni, AIFA, ICD…). Vuoto = stesse tabelle nel database dell'ambiente.
        'common' => '',
    ],

    // Accesso. Le credenziali qui sotto servono SOLO alla prima installazione: al primo avvio diventano
    // il primo utente dello studio (poi si gestiscono da Impostazioni → Utenti).
    // La password predefinita è NOTA a tutti: prima di esporre il sito in rete cambiala, generando l'hash con
    //   php -r 'echo password_hash("nuova-password", PASSWORD_DEFAULT);'
    'auth' => [
        'username'      => 'medico',
        'password_hash' => '$2y$10$xlaxdPqPL4xaq1R05q/aUO3Qfz7RkwzFSXw/ejjcoaLSNhKJfBd5.', // password iniziale: drfacile — CAMBIALA
        'session_name'  => 'DRFSESSID',
        'lifetime'      => 8 * 3600,
        // Cookie di sessione solo su HTTPS: 'auto' (Secure quando la richiesta è HTTPS, anche dietro proxy),
        // true (sempre: il sito è raggiungibile solo in HTTPS — consigliato in produzione), false (solo sviluppo in HTTP)
        'cookie_secure' => 'auto',
    ],

    // Abbonamento SaaS (scadenza e periodo stanno nella riga dello studio, tabella comune `studi`; gestione: php strumenti/abbonamento.php).
    // attivo = true: X giorni prima della scadenza compare il banner di rinnovo, a scadenza superata il login dello studio è sospeso.
    // Alla prima installazione in modalità demo lo studio nasce con 30 giorni di abbonamento, così si può provare tutto il ciclo.
    'abbonamento' => ['attivo' => true, 'avviso_giorni' => 7, 'rinnovo_url' => 'https://drfacile.it/rinnova'],

    // Store: il repository dei pacchetti (estensioni e moduli). URL pubblicato via HTTPS oppure una cartella locale
    // (utile per sviluppare: php strumenti/pacchetto.php + php strumenti/repository.php la creano). Vuoto = solo i pacchetti
    // distribuiti con il programma. revisore = true: si vedono (e si possono installare) anche i pacchetti in revisione,
    // non ancora approvati — è il flag di chi testa i pacchetti prima di pubblicarli. cache = secondi fra due letture del catalogo.
    // Esempi: 'https://store.drfacile.it' · DRF_ROOT . '/../drfacile-store' · 'drfacile-store' (relativo alla root di DRFacile)
    'store' => ['repository' => '', 'revisore' => false, 'cache' => 3600, 'voti_url' => ''],

    // Archivio dei file dello studio (documenti generati, archiviati, caricati): quota predefinita in MB per studio (0 = illimitata).
    // La quota del singolo studio sta nel database comune (studi.quota_mb) e si amplia dallo Store / dal portale: php strumenti/studio.php quota <id> +5120
    'archivio' => ['quota_mb' => 2048],

    // Comunicazioni in uscita (Comunicazioni::invia). Email: 'log' (solo registro), 'mail' (mail() di PHP) o 'smtp' (PHPMailer, incluso in vendor/).
    // SMS: 'log' oppure 'clickatell' (il cliente attiva il servizio e compra i pacchetti dallo Store; qui solo le credenziali del provider).
    'comunicazioni' => [
        'email' => ['driver' => 'log', 'da' => 'noreply@tuostudio.it', 'da_nome' => '', 'rispondi_a' => '',
            'smtp' => ['host' => '', 'porta' => 587, 'sicurezza' => 'tls', 'utente' => '', 'password' => '']],
        'sms' => ['driver' => 'log', 'clickatell' => ['api_key' => '', 'mittente' => '']],
        'whatsapp' => ['driver' => 'log'],
    ],

    // Acquisti dallo Store con Stripe Checkout (carta): chiavi del tuo account Stripe (test o live). Vuoto = niente carta, solo attivazioni manuali.
    // Il webhook (Stripe → Developers → Webhooks) punta a https://tuodominio/drfacile/ajax/pagamenti.php?action=webhook con gli eventi
    // checkout.session.completed e customer.subscription.deleted. app.url (opzionale) = indirizzo pubblico del programma per i ritorni.
    'stripe' => ['secret_key' => '', 'publishable_key' => '', 'webhook_secret' => '', 'valuta' => 'eur'],
    // Amministratore di sistema: questa installazione può attivare pacchetti e servizi a mano (bonifico, omaggio, prova) dallo Store.
    'sistema' => ['amministratore' => false],

    'paths' => [
        'docs'     => DRF_ROOT . '/docs',
        'archivio' => DRF_ROOT . '/docs/archivio',
        'backup'   => DRF_ROOT . '/docs/backup',
        'temp'     => DRF_ROOT . '/temp',
    ],

    'agenda'  => ['ora_inizio' => 8, 'ora_fine' => 18, 'durata_default' => 30],
    'fattura' => ['bollo_soglia' => 77.47, 'bollo_importo' => 2.00, 'esenzione_iva' => 'Operazione esente IVA art. 10 n. 18 DPR 633/72'],
    'ricetta' => ['prefisso_nre' => '050A'],
    'postit'  => ['font_size' => 14],   // dimensione iniziale del testo dei post-it (poi si cambia su ogni post-it con + e −)
];
