<?php
/**
 * Generatore di form (CRUD) a partire da una definizione in form/definitions/<nome>.php
 *
 * Definizione:
 *   return [
 *     'title' => 'Nuovo paziente', 'title_edit' => 'Modifica paziente',
 *     'endpoint' => 'pazienti', 'action' => 'save',            // dove viene inviata la form (ajax/pazienti.php?action=save)
 *     'submit' => 'Crea paziente', 'submit_edit' => 'Salva modifiche',
 *     'model' => 'Paziente',                                    // per precompilare con id
 *     'fields' => [ ['name'=>'nome','label'=>'Nome','type'=>'text','required'=>true,'row'=>1], ... ],
 *   ];
 *
 * Tipi di campo: text, email, tel, number, date, time, color, textarea, select, seg, switch, hidden, section, cf, comune
 * 'options' può essere un array [valore => etichetta] oppure una closure che lo restituisce.
 * Campi con lo stesso 'row' vengono affiancati; con 'w' (1..12) si assegna la larghezza in dodicesimi, altrimenti colonne uguali.
 * 'mask' => 'euros' | 'numero' | 'decimale' | 'sconto' | 'cap' applica Inputmask; 'show_if' => 'campo' mostra il campo solo se lo switch è attivo.
 * A livello di form: 'wide' => true apre il pannello largo.
 */
final class FormBuilder
{
    public static function definizione(string $name): array
    {
        $name = preg_replace('/[^a-z0-9_]/', '', strtolower($name));
        $file = DRF_ROOT . "/form/definitions/$name.php";
        if (!is_file($file)) throw new ApiException("Form non trovata: $name", 404);
        // le estensioni aggiungono campi (hook form.campi): $def['fields'][] = ['name' => 'dieta_kcal', 'label' => 'Kcal', 'type' => 'number', 'row' => 90];
        // i campi <codice>_<campo> vengono salvati da soli nella colonna JSON `dati` di pazienti e appuntamenti (Model::datiEstensioni)
        return (array) Hooks::filter('form.campi', require $file, $name);
    }

    /** Restituisce title, html, endpoint, action, submit pronti per la sheet */
    public static function render(string $name, ?int $id = null, array $values = []): array
    {
        $def = self::definizione($name);
        $edit = $id !== null && $id > 0;
        if ($edit) {
            $rec = null;
            if (!empty($def['model']) && class_exists($def['model'])) $rec = $def['model']::find($id);
            elseif (!empty($def['table'])) $rec = Database::one("SELECT * FROM {$def['table']} WHERE id = ?", [$id]);
            if (!$rec) throw new ApiException(__('Record non trovato'), 404);
            $datiExt = $rec['dati'] ?? null; if (is_string($datiExt)) $datiExt = json_decode($datiExt, true);
            foreach ((array) ($datiExt ?: []) as $cod => $campi) if (is_array($campi)) foreach ($campi as $k => $v) $rec["{$cod}_$k"] = $v;   // i campi delle estensioni tornano nella form
            $values = $rec + $values;
        }
        return [
            'name' => $name, 'id' => $edit ? $id : null,
            'title' => $edit ? ($def['title_edit'] ?? $def['title']) : $def['title'],
            'submit' => $edit ? ($def['submit_edit'] ?? __('Salva modifiche')) : ($def['submit'] ?? __('Salva')),
            'endpoint' => $def['endpoint'], 'action' => $def['action'] ?? 'save', 'wide' => !empty($def['wide']),
            'html' => self::html($def['fields'], $values, $edit ? $id : null),
        ];
    }

    public static function html(array $fields, array $values = [], ?int $id = null): string
    {
        $out = $id ? '<input type="hidden" name="id" value="' . (int) $id . '">' : '';
        $rows = [];
        foreach ($fields as $f) {
            if (($f['type'] ?? 'text') === 'hidden') { $out .= self::field($f, $values); continue; }
            $rows[$f['row'] ?? uniqid('r')][] = $f;
        }
        foreach ($rows as $group) {
            $n = count($group);
            if ($n === 1) { $out .= self::field($group[0], $values); continue; }
            $pesati = array_filter($group, fn($f) => isset($f['w']));
            $html = '';
            foreach ($group as $f) $html .= self::field($f, $values, $pesati ? ' style="grid-column:span ' . (int) ($f['w'] ?? 12 / $n) . '"' : '');
            $out .= ($pesati ? '<div class="grid12">' : ($n === 2 ? '<div class="grid2">' : '<div class="gridn" style="grid-template-columns:repeat(' . $n . ',1fr)">')) . $html . '</div>';
        }
        return $out;
    }

    public static function field(array $f, array $values, string $wrapAttr = ''): string
    {
        $name = $f['name'] ?? ''; $type = $f['type'] ?? 'text';
        if ($type === 'section') return '<div class="form-section"' . $wrapAttr . '><b>' . e($f['label'] ?? '') . '</b>' . (isset($f['hint']) ? '<span>' . e($f['hint']) . '</span>' : '') . '</div>';
        $raw = $values[$name] ?? ($f['default'] ?? '');
        if ($raw instanceof Closure) $raw = $raw();
        if (is_array($raw)) $raw = implode(', ', $raw);
        $val = e((string) $raw);
        $attrs = '';
        foreach (($f['attrs'] ?? []) as $k => $v) $attrs .= ' ' . e($k) . '="' . e((string) $v) . '"';
        if (!empty($f['required'])) $attrs .= ' required';
        if (!empty($f['mask'])) $attrs .= ' data-mask="' . e($f['mask']) . '"';
        if (!empty($f['placeholder'])) $attrs .= ' placeholder="' . e($f['placeholder']) . '"';
        $cls = e($f['class'] ?? '');
        $idAttr = 'f_' . e($name);

        if ($type === 'hidden') return '<input type="hidden" name="' . e($name) . '" value="' . $val . '">';

        $ctrl = match ($type) {
            'textarea' => '<textarea class="textarea ' . $cls . '" id="' . $idAttr . '" name="' . e($name) . '"' . $attrs . '>' . $val . '</textarea>',
            'rich' => '<textarea class="rich ' . $cls . '" id="' . $idAttr . '" name="' . e($name) . '" data-campi="' . e(implode(',', $f['campi'] ?? [])) . '"' . (isset($f['height']) ? ' data-height="' . (int) $f['height'] . '"' : '') . $attrs . ' hidden>' . $val . '</textarea>',
            'select' => self::select($f, (string) $raw, $attrs, $cls, $idAttr),
            'seg' => self::seg($f, (string) $raw),
            'switch' => '<button type="button" class="switch ' . ($raw ? 'on' : '') . '" data-switch="' . e($name) . '"></button><input type="hidden" name="' . e($name) . '" value="' . ($raw ? '1' : '0') . '">',
            'cf' => '<div class="row" style="gap:6px"><input class="input mono ' . $cls . '" id="' . $idAttr . '" name="' . e($name) . '" value="' . $val . '" maxlength="16" data-cf autocomplete="off" style="text-transform:uppercase"' . $attrs . '><button type="button" class="btn soft" data-cf-calc title="' . e(__('Calcola dal nome, data e comune di nascita')) . '"><i class="ico" data-fi="id-badge" data-fa="fa-regular fa-id-card"></i></button></div>',
            'comune' => '<select class="select comune" id="' . $idAttr . '" name="' . e($name) . '" data-fill=\'' . json_txt($f['fill'] ?? []) . '\'' . $attrs . '>' . ($val !== '' ? '<option value="' . $val . '" selected>' . $val . '</option>' : '') . '</select>',
            'color' => '<div class="row colorpick"><input type="color" id="' . $idAttr . '" name="' . e($name) . '" value="' . ($val ?: '#6B6FE6') . '"><span class="mono">' . ($val ?: '#6B6FE6') . '</span></div>',
            default => '<input class="input ' . $cls . '" id="' . $idAttr . '" type="' . e($type) . '" name="' . e($name) . '" value="' . $val . '"' . $attrs . '>',
        };
        $label = isset($f['label']) ? '<label for="' . $idAttr . '">' . e($f['label']) . (!empty($f['required']) ? ' *' : '') . '</label>' : '';
        if ($type === 'switch' && !empty($f['inline'])) return '<div class="field field-inline"' . $wrapAttr . '><div class="row" style="gap:10px">' . $ctrl . '<span class="switch-label">' . e($f['label'] ?? '') . '</span></div></div>';
        $show = !empty($f['show_if']) ? ' data-show-if="' . e($f['show_if']) . '"' : '';
        $help = !empty($f['help']) ? '<span class="small muted" style="display:block;margin-top:6px">' . e($f['help']) . '</span>' : '';
        return '<div class="field"' . $wrapAttr . $show . '>' . $label . $ctrl . $help . '</div>';
    }

    private static function select(array $f, string $val, string $attrs, string $cls, string $id): string
    {
        $opts = is_callable($f['options'] ?? null) ? ($f['options'])() : ($f['options'] ?? []);
        $html = '<select class="select ' . $cls . '" id="' . $id . '" name="' . e($f['name']) . '"' . $attrs . '>';
        if (!empty($f['empty'])) $html .= '<option value="">' . e($f['empty']) . '</option>';
        foreach ($opts as $v => $l) $html .= '<option value="' . e((string) $v) . '"' . ((string) $v === $val ? ' selected' : '') . '>' . e((string) $l) . '</option>';
        return $html . '</select>';
    }

    private static function seg(array $f, string $val): string
    {
        $opts = is_callable($f['options'] ?? null) ? ($f['options'])() : ($f['options'] ?? []);
        if ($val === '' || !isset($opts[$val])) $val = (string) array_key_first($opts);
        $html = '<div class="seg" data-seg="' . e($f['name']) . '">';
        foreach ($opts as $v => $l) $html .= '<button type="button" class="' . ((string) $v === $val ? 'on' : '') . '" data-v="' . e((string) $v) . '">' . e((string) $l) . '</button>';
        return $html . '</div><input type="hidden" name="' . e($f['name']) . '" value="' . e($val) . '">';
    }
}
