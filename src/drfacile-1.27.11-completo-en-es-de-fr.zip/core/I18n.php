<?php
/**
 * TRADUZIONI: gettext standard (.po/.mo, Poedit, msgctxt, plurali) con un LOADER IN PHP PURO — nessuna dipendenza
 * dall'estensione gettext di PHP, che sugli hosting spesso manca. Per chi traduce non cambia nulla: file .po/.mo normali.
 *
 *   locale/<lingua>/LC_MESSAGES/drfacile.mo                       core (dominio drfacile)
 *   estensioni/<codice>/locale/<lingua>/LC_MESSAGES/<codice>.mo   ogni estensione: dominio = codice (regola dello Store)
 *
 *   __('Salva')                       __('Salva', 'ginecologia')
 *   _n('%d paziente', '%d pazienti', $n)         sprintf incluso: _n('%d paziente', '%d pazienti', $n) → "3 pazienti"
 *   _p('medical', 'Visita')           contesto per le stringhe ambigue (msgctxt)
 *   _np('ctx', 'sing', 'plur', $n)
 *
 * La lingua: preferenza dell'utente (utenti.lingua) → config app.locale → it_IT. Le stringhe SORGENTE sono in italiano:
 * con la lingua italiana non serve alcun catalogo. I cataloghi per il JavaScript (DRF.__) li genera I18n::catalogoJs()
 * dai .mo, con cache in data/cache/i18n/. Strumento: php strumenti/i18n.php (estrai .pot, compila .po → .mo).
 */
final class I18n
{
    public const PREDEFINITA = 'it_IT';
    private static string $locale = self::PREDEFINITA;
    private static array $domini = [];      // dominio => cartella locale/
    private static array $cataloghi = [];   // dominio => ['msg' => [...], 'plurali' => n, 'regola' => callable]

    public static function init(?string $locale = null): void
    {
        self::$locale = self::normalizza($locale ?: (string) Config::get('app.locale', self::PREDEFINITA));
        self::lega('drfacile', DRF_ROOT . '/locale');
    }

    public static function locale(): string { return self::$locale; }
    public static function lingua(): string { return substr(self::$locale, 0, 2); }

    /** Le lingue disponibili nel core: it_IT + quelle con un .mo in locale/ */
    public static function disponibili(): array
    {
        $out = [self::PREDEFINITA => 'Italiano'];
        $nomi = ['en_US' => 'English', 'en_GB' => 'English (UK)', 'de_DE' => 'Deutsch', 'fr_FR' => 'Français', 'es_ES' => 'Español', 'pt_PT' => 'Português', 'ro_RO' => 'Română', 'sq_AL' => 'Shqip', 'ar_SA' => 'العربية', 'zh_CN' => '中文'];
        foreach (glob(DRF_ROOT . '/locale/*/LC_MESSAGES/drfacile.mo') ?: [] as $f) { $l = basename(dirname(dirname($f))); $out[$l] = $nomi[$l] ?? $l; }
        return $out;
    }

    /** Registra un dominio (le estensioni lo fanno da sole in Estensioni::carica) */
    public static function lega(string $dominio, string $cartella): void
    {
        self::$domini[$dominio] = rtrim($cartella, '/');
        unset(self::$cataloghi[$dominio]);
    }

    public static function normalizza(string $l): string
    {
        $l = str_replace('-', '_', trim($l));
        if (preg_match('/^([a-z]{2})(?:_([a-zA-Z]{2}))?/', $l, $m)) return strtolower($m[1]) . '_' . strtoupper($m[2] ?? ($m[1] === 'en' ? 'US' : $m[1]));
        return self::PREDEFINITA;
    }

    /* ------------------------------------------------------------------ traduzione */

    public static function traduci(string $msgid, string $dominio = 'drfacile', ?string $ctx = null): string
    {
        $cat = self::catalogo($dominio);
        $k = ($ctx !== null ? $ctx . "\x04" : '') . $msgid;
        $t = $cat['msg'][$k][0] ?? null;
        return $t !== null && $t !== '' ? $t : $msgid;
    }

    public static function plurale(string $sing, string $plur, int $n, string $dominio = 'drfacile', ?string $ctx = null): string
    {
        $cat = self::catalogo($dominio);
        $k = ($ctx !== null ? $ctx . "\x04" : '') . $sing;
        $forme = $cat['msg'][$k] ?? null;
        if ($forme && count($forme) > 1) { $i = min(($cat['regola'])($n), count($forme) - 1); $t = $forme[$i] ?? ''; if ($t !== '') return $t; }
        return $n === 1 ? $sing : $plur;
    }

    /** Il catalogo di un dominio per la lingua corrente (cache in memoria; con l'italiano è vuoto) */
    public static function catalogo(string $dominio): array
    {
        if (isset(self::$cataloghi[$dominio])) return self::$cataloghi[$dominio];
        $vuoto = ['msg' => [], 'plurali' => 2, 'regola' => fn(int $n) => $n !== 1 ? 1 : 0];
        if (self::$locale === self::PREDEFINITA || !isset(self::$domini[$dominio])) return self::$cataloghi[$dominio] = $vuoto;
        $file = self::$domini[$dominio] . '/' . self::$locale . '/LC_MESSAGES/' . $dominio . '.mo';
        if (!is_file($file)) { $solo = self::lingua(); foreach (glob(self::$domini[$dominio] . "/{$solo}_*/LC_MESSAGES/$dominio.mo") ?: [] as $alt) { $file = $alt; break; } }   // en_GB → en_US
        return self::$cataloghi[$dominio] = is_file($file) ? (self::leggiMo($file) ?: $vuoto) : $vuoto;
    }

    /* ------------------------------------------------------------------ lettore .mo (formato GNU gettext, little/big endian) */

    public static function leggiMo(string $file): ?array
    {
        $d = (string) @file_get_contents($file);
        if (strlen($d) < 28) return null;
        $magic = unpack('V', substr($d, 0, 4))[1];
        $f = $magic === 0x950412de ? 'V' : ($magic === 0xde120495 ? 'N' : null);
        if (!$f) return null;
        [$rev, $n, $oOrig, $oTrad] = array_values(unpack("{$f}4", substr($d, 4, 16)));   // revisione, numero di stringhe, offset tabella originali, offset tabella traduzioni
        if ($n < 0 || $n > 200000 || $oOrig + $n * 8 > strlen($d) || $oTrad + $n * 8 > strlen($d)) return null;
        $msg = []; $testa = '';
        for ($i = 0; $i < $n; $i++) {
            [$lo, $po] = array_values(unpack("{$f}2", substr($d, $oOrig + $i * 8, 8)));
            [$lt, $pt] = array_values(unpack("{$f}2", substr($d, $oTrad + $i * 8, 8)));
            $orig = substr($d, $po, $lo); $trad = substr($d, $pt, $lt);
            if ($orig === '') { $testa = $trad; continue; }
            if (!mb_check_encoding($orig, 'UTF-8') || !mb_check_encoding($trad, 'UTF-8')) continue;   // mai byte non validi nel catalogo (json_encode fallirebbe)
            $chiave = explode("\0", $orig)[0];   // msgctxt\x04msgid oppure msgid\0plurale → la chiave è msgctxt\x04msgid (senza la forma plurale)
            $msg[$chiave] = explode("\0", $trad);
        }
        $plurali = 2; $regola = fn(int $n) => $n !== 1 ? 1 : 0;
        if (preg_match('/Plural-Forms:\s*nplurals\s*=\s*(\d+)\s*;\s*plural\s*=\s*([^;\n]+)/i', $testa, $m)) { $plurali = (int) $m[1]; $regola = self::regola($m[2]) ?? $regola; }
        return ['msg' => $msg, 'plurali' => $plurali, 'regola' => $regola];
    }

    /** L'espressione C di Plural-Forms → funzione PHP (solo caratteri ammessi: n, numeri, operatori) */
    private static function regola(string $expr): ?callable
    {
        $e = trim($expr);
        if (!preg_match('/^[n0-9\s()<>=!&|?:%+\-*\/]+$/', $e)) return null;
        $php = preg_replace('/\bn\b/', '$n', $e);
        // gli operatori ternari annidati vanno tra parentesi in PHP 8: li racchiudiamo ricorsivamente
        $php = self::parentesizzaTernari($php);
        try { return eval("return function (int \$n): int { return (int) ($php); };"); } catch (Throwable $t) { return null; }
    }

    private static function parentesizzaTernari(string $s): string
    {
        // "a ? b : c ? d : e" → "a ? b : (c ? d : e)": si cerca il primo ':' di livello 0 e si parentesizza il resto se contiene '?'
        $liv = 0; $q = -1;
        for ($i = 0; $i < strlen($s); $i++) { $c = $s[$i]; if ($c === '(') $liv++; elseif ($c === ')') $liv--; elseif ($c === '?' && $liv === 0 && $q < 0) $q = $i; elseif ($c === ':' && $liv === 0 && $q >= 0) { $resto = substr($s, $i + 1); if (strpos($resto, '?') !== false) return substr($s, 0, $i + 1) . ' (' . self::parentesizzaTernari(trim($resto)) . ')'; return $s; } }
        return $s;
    }

    /* ------------------------------------------------------------------ catalogo per il JavaScript */

    /** { "msgid": "trad", "ctx\u0004msgid": "trad", "sing": ["sing", "plur"] } + regola dei plurali, con cache su file */
    public static function catalogoJs(string $dominio): array
    {
        if (self::$locale === self::PREDEFINITA) return ['msg' => new \stdClass(), 'plurali' => 2, 'regola' => 'n != 1'];
        $cat = self::catalogo($dominio);
        $file = self::$domini[$dominio] . '/' . self::$locale . '/LC_MESSAGES/' . $dominio . '.mo';
        $regola = 'n != 1';
        if (is_file($file)) { $t = (string) file_get_contents($file, false, null, 0, 4096); if (preg_match('/plural\s*=\s*([^;\n\0]+)/i', $t, $m)) $regola = trim($m[1]); }
        $msg = [];
        foreach ($cat['msg'] as $k => $forme) $msg[$k] = count($forme) > 1 ? $forme : ($forme[0] ?? '');
        return ['msg' => $msg ?: new \stdClass(), 'plurali' => $cat['plurali'], 'regola' => $regola];
    }

    /** Tutti i cataloghi per la pagina: core + estensioni attive */
    public static function cataloghiPagina(): array
    {
        $out = [];
        foreach (array_keys(self::$domini) as $d) $out[$d] = self::catalogoJs($d);
        return $out;
    }
}

/* ---------- funzioni globali (stile gettext) */
function __(string $s, string $dominio = 'drfacile'): string { return I18n::traduci($s, $dominio); }
function _p(string $ctx, string $s, string $dominio = 'drfacile'): string { return I18n::traduci($s, $dominio, $ctx); }
function _n(string $sing, string $plur, int $n, string $dominio = 'drfacile'): string { return sprintf(I18n::plurale($sing, $plur, $n, $dominio), $n); }
function _np(string $ctx, string $sing, string $plur, int $n, string $dominio = 'drfacile'): string { return sprintf(I18n::plurale($sing, $plur, $n, $dominio, $ctx), $n); }
