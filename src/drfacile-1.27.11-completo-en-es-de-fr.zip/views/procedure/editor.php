<?php /** Pagina demo "Editor DRF.rich": esempi dal vivo con il codice per usarlo. Logica in assets/js/procedure.js → viste.editor */ ?>
<div class="ctl-grid">
  <div class="ctl">
    <div class="ctl-head"><div><b><?= __('Editor di base') ?></b><span><?= __('Grassetto, corsivo, sottolineato (⌘B/I/U), titoletto, elenchi, link, pulisci, annulla/ripeti e contatore caratteri. Segue il tema del programma, anche scuro.') ?></span></div>
      <button class="icon-btn sm" type="button" data-code title="<?= __('Mostra il codice') ?>"><i class="ico" data-fi="brackets-curly" data-fa="fa-solid fa-code"></i></button></div>
    <div id="edBase"></div>
    <pre hidden>const ed = DRF.rich.mount('#box', {
  value: '<p><?= __('Testo') ?> <b>iniziale</b></p>',
  placeholder: 'Scrivi qui…', height: 140,
  onChange: e => console.log(e.get())
});
ed.get();          // HTML pulito (whitelist di tag, link sicuri)
ed.set(html);      // reimposta il contenuto
ed.exec('bold');   // qualsiasi comando dell'editor
ed.destroy();</pre>
  </div>

  <div class="ctl">
    <div class="ctl-head"><div><b><?= __('Campi {segnaposto}') ?></b><span><?= __('Entità atomiche: si inseriscono dal menu "Campo", si eliminano in blocco con un solo Backspace, viaggiano come {campo} nel valore salvato. Prova a scrivere {telefono} a mano: diventa un chip.') ?></span></div>
      <button class="icon-btn sm" type="button" data-code title="<?= __('Mostra il codice') ?>"><i class="ico" data-fi="brackets-curly" data-fa="fa-solid fa-code"></i></button></div>
    <div id="edCampi"></div>
    <div class="ctl-btns" style="margin-top:10px">
      <button class="btn primary sm" type="button" data-ed="valore"><?= __('Leggi il valore') ?></button>
      <button class="btn soft sm" type="button" data-ed="anteprima"><?= __('Anteprima con dati di prova') ?></button>
      <button class="btn ghost sm" type="button" data-ed="campo"><?= __('Inserisci {data} da codice') ?></button>
    </div>
    <pre hidden>DRF.rich.mount('#box', {
  campi: ['paziente', 'prestazione', 'data', 'ora', 'medico', 'studio'],
  value: '<p><?= __('Gentile {paziente}, la aspettiamo il {data} alle {ora}.') ?></p>\'
});
ed.insertCampo(\'data\');       // inserisce un chip alla posizione del cursore
ed.get();                     // → \'<p><?= __('Gentile {paziente}, …') ?></p>' (chip serializzati)
// nelle form del FormBuilder basta:
// ['name' => 'testo', 'type' => 'rich', 'campi' => ['paziente', 'data'], 'height' => 170]</pre>
  </div>

  <div class="ctl">
    <div class="ctl-head"><div><b><?= __('Estendere con un modulo') ?></b><span><?= __('Un modulo aggiunge pulsanti e comandi a tutti gli editor (o solo ad alcuni). Qui sotto: "Separatore" ed "Evidenzia", registrati da questa pagina in quattro righe. Domani: le immagini.') ?></span></div>
      <button class="icon-btn sm" type="button" data-code title="<?= __('Mostra il codice') ?>"><i class="ico" data-fi="brackets-curly" data-fa="fa-solid fa-code"></i></button></div>
    <div id="edModuli"></div>
    <pre hidden>DRF.rich.use({
  name: 'separatore',
  button: { fi: 'minus', fa: 'fa-solid fa-minus', title: 'Separatore' },
  run: ed => ed.insertHTML('<hr>')
});
DRF.rich.use({
  name: 'evidenzia',
  button: { fi: 'highlighter', fa: 'fa-solid fa-highlighter', title: 'Evidenzia' },
  run: ed => ed.exec('hiliteColor', '#FBEB9B')   // → <mark> nel valore salvato
});
DRF.rich.allow('IMG');   // un modulo può ampliare i tag ammessi (es. per le immagini)
// negli editor: moduli: true (tutti, predefinito) · ['separatore'] (solo alcuni) · false (nessuno)</pre>
  </div>

  <div class="ctl">
    <div class="ctl-head"><div><b><?= __('Dove è già in uso') ?></b><span><?= __('Le istruzioni pre-visita delle prestazioni (Archivi → Prestazioni → switch "Istruzioni pre-visita") usano questo editor con i campi paziente, prestazione, data, ora, medico e studio. La textarea resta sincronizzata: FormBuilder e DRF.ui.formData funzionano da soli.') ?></span></div>
      <button class="icon-btn sm" type="button" data-code title="<?= __('Mostra il codice') ?>"><i class="ico" data-fi="brackets-curly" data-fa="fa-solid fa-code"></i></button></div>
    <div class="ctl-btns"><button class="btn primary sm" type="button" data-ed="prestazione"><?= __('Apri la form della prestazione "Ecografia"') ?></button></div>
    <pre hidden>// in una definizione del FormBuilder (form/definitions/…):
['name' => 'previsita_testo', 'label' => 'Testo delle istruzioni', 'type' => 'rich',
 'campi' => ['paziente', 'prestazione', 'data', 'ora', 'medico', 'studio'], 'height' => 170]

// oppure in HTML, montato in automatico da DRF.ui.wire:
&lt;textarea class="rich" name="testo" data-campi="paziente,data" data-height="150"&gt;&lt;/textarea&gt;</pre>
  </div>
</div>
