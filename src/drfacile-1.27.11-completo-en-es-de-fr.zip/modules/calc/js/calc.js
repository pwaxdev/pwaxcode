/* Modulo Scrivania: Calcolatrice (derivata da Igea). Percentuale in logica IVA:
   a + b% aggiunge (1000 + 22% = 1220), a − b% scorpora (1000 − 22% = 819,67), a × b% percentuale di, a ÷ b% divide per b/100. */
DRF.desk.register('calc', (function () {
  'use strict';
  const SYM = { add: '+', sub: '−', mul: '×', div: '÷' };
  const KMAP = { '+': 'add', '-': 'sub', '*': 'mul', '/': 'div', '=': 'eq', Enter: 'eq', Backspace: 'back', Escape: 'clear', '%': 'pct', '.': 'dot', ',': 'dot' };
  return {
    init($win) {
      const $expr = $win.find('.calc-expr'), $cur = $win.find('.calc-cur'), $disp = $win.find('.calc-display'), $hist = $win.find('.calc-hist');
      let cur = '0', acc = null, op = null, typing = false, afterEq = false, expr = '';
      const numToStr = n => isFinite(n) ? String(Math.round(n * 1e10) / 1e10) : '0';
      const fmt = s => { s = String(s); const neg = s[0] === '-'; if (neg) s = s.slice(1); const [ip, dp] = s.split('.'); return (neg ? '-' : '') + (ip || '0').replace(/\B(?=(\d{3})+(?!\d))/g, '.') + (dp != null ? ',' + dp : ''); };
      const apply = (a, o, b) => ({ add: a + b, sub: a - b, mul: a * b, div: b === 0 ? Infinity : a / b })[o] ?? b;
      const render = () => { $expr.html(expr || '&nbsp;'); $cur.text(fmt(cur)); };
      const error = () => { cur = '0'; acc = null; op = null; typing = false; afterEq = true; expr = DRF.__('Errore'); render(); };
      const storico = (e, r) => { const $s = $(`<span title="${DRF.esc(e)}">${DRF.esc(fmt(r))}</span>`).on('click', () => { cur = r; typing = true; afterEq = false; render(); }); $hist.prepend($s); if ($hist.children().length > 12) $hist.children().last().remove(); };
      const fn = {
        digit(d) { if (!typing) { if (afterEq) { acc = null; op = null; expr = ''; } cur = d; typing = true; afterEq = false; } else cur = cur === '0' ? d : cur + d; render(); },
        dot() { if (!typing) { if (afterEq) { acc = null; op = null; expr = ''; } cur = '0.'; typing = true; afterEq = false; } else if (!cur.includes('.')) cur += '.'; render(); },
        setOp(o) { if (op !== null && typing) { const r = apply(acc, op, parseFloat(cur)); if (!isFinite(r)) return error(); acc = r; cur = numToStr(r); } else acc = parseFloat(cur); op = o; typing = false; afterEq = false; expr = fmt(numToStr(acc)) + ' ' + SYM[o]; render(); },
        eq() { if (op === null) return; const a = acc, b = parseFloat(cur), r = apply(a, op, b); if (!isFinite(r)) return error(); expr = `${fmt(numToStr(a))} ${SYM[op]} ${fmt(numToStr(b))} =`; cur = numToStr(r); storico(expr, cur); op = null; acc = null; typing = false; afterEq = true; render(); },
        clear() { cur = '0'; acc = null; op = null; typing = false; afterEq = false; expr = ''; render(); },
        neg() { if (cur !== '0') { cur = cur[0] === '-' ? cur.slice(1) : '-' + cur; render(); } },
        pct() {
          const b = parseFloat(cur); let r;
          if (op !== null && acc !== null) {
            r = op === 'add' ? acc * (1 + b / 100) : op === 'sub' ? acc / (1 + b / 100) : op === 'mul' ? acc * (b / 100) : (b === 0 ? Infinity : acc / (b / 100));
            if (!isFinite(r)) return error();
            r = Math.round(r * 100) / 100; expr = `${fmt(numToStr(acc))} ${SYM[op]} ${fmt(numToStr(b))}% =`; cur = numToStr(r); storico(expr, cur); op = null; acc = null; typing = false; afterEq = true;
          } else { cur = numToStr(b / 100); typing = true; }
          render();
        },
        back() { if (afterEq) return; cur = cur.slice(0, -1); if (cur === '' || cur === '-') { cur = '0'; typing = false; } render(); },
      };
      const press = k => { if (/^[0-9]$/.test(k)) return fn.digit(k); if (['add', 'sub', 'mul', 'div'].includes(k)) return fn.setOp(k); if (fn[k]) fn[k](); };
      $win.on('click', '.calc-btn', function () { $disp.trigger('focus'); press(this.dataset.k); });
      $disp.on('keydown', e => { const k = e.key; if (/^[0-9]$/.test(k)) { e.preventDefault(); press(k); } else if (KMAP[k]) { e.preventDefault(); press(KMAP[k]); } });
      render();
    },
    open($win) { $win.find('.calc-display').trigger('focus'); }
  };
})());
