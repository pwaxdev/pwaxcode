<?php
/**
 * ACQUISTI dallo Store: Stripe Checkout (carta) oppure attivazione manuale dell'amministratore di sistema (bonifico, omaggio, prova).
 * Config: 'stripe' => ['secret_key' => 'sk_…', 'publishable_key' => 'pk_…', 'webhook_secret' => 'whsec_…', 'valuta' => 'eur']
 *         'sistema' => ['amministratore' => true]  → questa installazione può attivare pacchetti a mano (vedi anche store.revisore)
 * Gli ordini stanno nel database comune (`ordini`): uno per acquisto, con stato e metodo; a pagamento confermato Pagamenti::evadi()
 * applica l'acquisto: estensione/servizio attivato, spazio o SMS accreditati. Il webhook Stripe (ajax/pagamenti.php?action=webhook)
 * conferma anche senza il ritorno del browser e gestisce la disdetta degli abbonamenti.
 */
final class Pagamenti
{
    public const STATI = ['creato' => 'In attesa di pagamento', 'pagato' => 'Pagato', 'manuale' => 'Attivato manualmente', 'annullato' => 'Annullato', 'disdetto' => 'Abbonamento disdetto'];

    public static function tabelle(): void
    {
        $id = Database::driver() === 'mysql' ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
        Database::run('CREATE TABLE IF NOT EXISTS ' . Database::comune('ordini') . " (
            id $id, studio_id INTEGER NOT NULL, codice VARCHAR(40) NOT NULL, nome VARCHAR(160), tipo VARCHAR(20), importo REAL DEFAULT 0, valuta VARCHAR(5) DEFAULT 'eur',
            stato VARCHAR(20) DEFAULT 'creato', metodo VARCHAR(20), stripe_session VARCHAR(120), stripe_subscription VARCHAR(120), stripe_customer VARCHAR(120),
            note VARCHAR(255), utente_id INTEGER, creato_il VARCHAR(19), pagato_il VARCHAR(19), evaso_il VARCHAR(19))");
    }

    public static function stripeAttivo(): bool { return trim((string) (Config::get('stripe.secret_key') ?? '')) !== ''; }
    public static function amministratore(): bool { return (bool) Config::get('sistema.amministratore', false) || Store::revisore(); }

    /** L'articolo dello Store da comprare (catalogo comune) */
    private static function articolo(string $codice): array
    {
        $m = Database::one('SELECT * FROM ' . Database::comune('store_moduli') . ' WHERE codice = ? AND attivo = 1', [$codice]) ?? throw new ApiException(__('Articolo non trovato nello Store'));
        if ($m['prezzo_tipo'] === 'gratis') throw new ApiException(__('Questo articolo è gratuito: si installa direttamente'));
        if ($codice === 'sms_500' || $codice === 'sms_2000') { if (!Estensioni::attiva('sms')) throw new ApiException(__('Prima attiva il Servizio SMS')); }
        return $m;
    }

    private static function nuovoOrdine(string $codice, array $m, string $metodo, string $stato = 'creato', string $note = ''): int
    {
        return Database::insert(Database::comune('ordini'), ['studio_id' => Auth::studioId(), 'codice' => $codice, 'nome' => $m['nome'], 'tipo' => $m['prezzo_tipo'], 'importo' => (float) $m['prezzo'], 'valuta' => (string) Config::get('stripe.valuta', 'eur'),
            'stato' => $stato, 'metodo' => $metodo, 'note' => mb_substr($note, 0, 255), 'utente_id' => (int) (Auth::utente()['id'] ?? 0) ?: null, 'creato_il' => date('Y-m-d H:i:s')]);
    }

    /* ------------------------------------------------------------------ Stripe Checkout */

    /** Crea l'ordine e la sessione di Checkout: ritorna l'URL a cui mandare il browser */
    public static function checkout(string $codice): string
    {
        if (!self::stripeAttivo()) throw new ApiException(__('Pagamenti con carta non configurati (stripe.secret_key in config.php)'));
        $m = self::articolo($codice);
        $oid = self::nuovoOrdine($codice, $m, 'stripe');
        $base = self::baseUrl();
        $dati = [
            'mode' => $m['prezzo_tipo'] === 'abbonamento' ? 'subscription' : 'payment',
            'success_url' => $base . 'ajax/pagamenti.php?action=ritorno&ordine=' . $oid . '&sessione={CHECKOUT_SESSION_ID}',
            'cancel_url' => $base . 'ajax/pagamenti.php?action=annullato&ordine=' . $oid,
            'client_reference_id' => (string) $oid,
            'metadata[ordine]' => (string) $oid, 'metadata[studio]' => (string) Auth::studioId(), 'metadata[codice]' => $codice,
            'line_items[0][quantity]' => '1',
            'line_items[0][price_data][currency]' => (string) Config::get('stripe.valuta', 'eur'),
            'line_items[0][price_data][unit_amount]' => (string) (int) round((float) $m['prezzo'] * 100),
            'line_items[0][price_data][product_data][name]' => 'DRFacile · ' . $m['nome'],
            'line_items[0][price_data][product_data][description]' => mb_substr(strip_tags((string) $m['sottotitolo']), 0, 200),
        ];
        if ($m['prezzo_tipo'] === 'abbonamento') { $dati['line_items[0][price_data][recurring][interval]'] = 'month'; $dati['subscription_data[metadata][ordine]'] = (string) $oid; $dati['subscription_data[metadata][studio]'] = (string) Auth::studioId(); $dati['subscription_data[metadata][codice]'] = $codice; }
        $email = Auth::utente()['email'] ?? Impostazione::profilo()['email'];
        if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) $dati['customer_email'] = $email;
        $s = self::stripe('POST', '/v1/checkout/sessions', $dati);
        Database::update(Database::comune('ordini'), ['stripe_session' => (string) $s['id']], 'id = :id', ['id' => $oid]);
        return (string) $s['url'];
    }

    /** Ritorno dal Checkout: verifica la sessione e, se pagata, evade l'ordine */
    public static function ritorno(int $oid, string $sessione): array
    {
        $o = Database::one('SELECT * FROM ' . Database::comune('ordini') . ' WHERE id = ? AND studio_id = ?', [$oid, Auth::studioId()]) ?? throw new ApiException(__('Ordine non trovato'));
        if ($o['stato'] === 'pagato') return $o;
        $s = self::stripe('GET', '/v1/checkout/sessions/' . rawurlencode($sessione));
        if (($s['metadata']['ordine'] ?? '') !== (string) $oid) throw new ApiException('Sessione non corrispondente all\'ordine');
        $pagata = ($s['payment_status'] ?? '') === 'paid' || (($s['mode'] ?? '') === 'subscription' && !empty($s['subscription']));
        if (!$pagata) throw new ApiException(__('Pagamento non ancora confermato'));
        Database::update(Database::comune('ordini'), ['stripe_subscription' => (string) ($s['subscription'] ?? ''), 'stripe_customer' => (string) ($s['customer'] ?? '')], 'id = :id', ['id' => $oid]);
        return self::evadi($oid, 'pagato', 'stripe');
    }

    /** Webhook Stripe: firma verificata, eventi checkout.session.completed e customer.subscription.deleted */
    public static function webhook(string $payload, string $firma): string
    {
        $segreto = trim((string) (Config::get('stripe.webhook_secret') ?? ''));
        if ($segreto === '') throw new RuntimeException('webhook_secret non configurato');
        $t = null; $v1 = [];
        foreach (explode(',', $firma) as $parte) { [$k, $v] = array_pad(explode('=', trim($parte), 2), 2, ''); if ($k === 't') $t = $v; if ($k === 'v1') $v1[] = $v; }
        if (!$t || !$v1 || abs(time() - (int) $t) > 600) throw new RuntimeException('Firma non valida');
        $atteso = hash_hmac('sha256', "$t.$payload", $segreto);
        $ok = false; foreach ($v1 as $v) if (hash_equals($atteso, $v)) $ok = true;
        if (!$ok) throw new RuntimeException('Firma non valida');
        $ev = json_decode($payload, true);
        $tipo = (string) ($ev['type'] ?? ''); $obj = (array) ($ev['data']['object'] ?? []);
        if ($tipo === 'checkout.session.completed') {
            $oid = (int) ($obj['metadata']['ordine'] ?? 0); $sid = (int) ($obj['metadata']['studio'] ?? 0);
            if ($oid && $sid) { self::contesto($sid); Database::update(Database::comune('ordini'), ['stripe_subscription' => (string) ($obj['subscription'] ?? ''), 'stripe_customer' => (string) ($obj['customer'] ?? '')], 'id = :id', ['id' => $oid]); self::evadi($oid, 'pagato', 'stripe'); }
            return "ordine $oid evaso";
        }
        if ($tipo === 'customer.subscription.deleted') {
            $o = Database::one('SELECT * FROM ' . Database::comune('ordini') . ' WHERE stripe_subscription = ?', [(string) ($obj['id'] ?? '')]);
            if ($o) { self::contesto((int) $o['studio_id']); Database::update(Database::comune('ordini'), ['stato' => 'disdetto'], 'id = :id', ['id' => (int) $o['id']]); Estensioni::disinstalla((string) $o['codice']); return "abbonamento {$o['codice']} disdetto"; }
        }
        return "evento $tipo ignorato";
    }

    /** Nel webhook non c'è sessione: si entra nello studio dell'ordine */
    private static function contesto(int $studioId): void
    {
        $_SESSION['drf_user'] = ['utente_id' => 0, 'studio_id' => $studioId, 'username' => 'stripe'];
        Tenant::attiva($studioId);
        if (!Database::tableExists('estensioni')) Estensioni::tabelle();
    }

    /* ------------------------------------------------------------------ manuale (amministratore di sistema) */

    public static function manuale(string $codice, string $metodo, string $note = ''): array
    {
        if (!self::amministratore()) throw new ApiException('Solo l\'amministratore di sistema può attivare manualmente', 403);
        $m = self::articolo($codice);
        $oid = self::nuovoOrdine($codice, $m, in_array($metodo, ['bonifico', 'contanti', 'omaggio', 'prova', 'altro'], true) ? $metodo : 'altro', 'creato', $note);
        return self::evadi($oid, 'manuale', $metodo);
    }

    /* ------------------------------------------------------------------ evasione */

    /** Applica l'acquisto allo studio: spazio, SMS, oppure estensione/servizio attivato (scaricando i file se servono) */
    public static function evadi(int $oid, string $stato, string $metodo): array
    {
        $T = Database::comune('ordini');
        $o = Database::one("SELECT * FROM $T WHERE id = ?", [$oid]) ?? throw new ApiException(__('Ordine non trovato'));
        if ($o['evaso_il']) return $o;
        $S = Database::comune('studi'); $sid = (int) $o['studio_id'];
        switch ($o['codice']) {
            case 'spazio': Database::run("UPDATE $S SET quota_mb = COALESCE(quota_mb, ?) + 5120 WHERE id = ?", [(int) Config::get('archivio.quota_mb', 2048), $sid]); break;
            case 'sms_500': Database::run("UPDATE $S SET sms_credito = COALESCE(sms_credito, 0) + 500 WHERE id = ?", [$sid]); break;
            case 'sms_2000': Database::run("UPDATE $S SET sms_credito = COALESCE(sms_credito, 0) + 2000 WHERE id = ?", [$sid]); break;
            default:
                if (!Store::installato($o['codice'])) Capabilities::comeCore(fn() => Store::scarica($o['codice']));
                Estensioni::installa($o['codice']);
        }
        Database::update($T, ['stato' => $stato, 'metodo' => $metodo, 'pagato_il' => date('Y-m-d H:i:s'), 'evaso_il' => date('Y-m-d H:i:s')], 'id = :id', ['id' => $oid]);
        try { Attivita::registra('acquisto', 'negozio', $oid, $o['nome'] . ' · ' . $metodo); } catch (Throwable $e) { /* senza studio attivo (webhook) */ }
        Hooks::run('store.acquisto', $o['codice'], $oid, $metodo);
        return Database::one("SELECT * FROM $T WHERE id = ?", [$oid]);
    }

    public static function ordini(int $limit = 50): array
    {
        return Database::all('SELECT * FROM ' . Database::comune('ordini') . ' WHERE studio_id = ? ORDER BY id DESC LIMIT ' . (int) $limit, [Auth::studioId()]);
    }

    /* ------------------------------------------------------------------ REST Stripe (senza SDK) */

    private static function stripe(string $metodo, string $percorso, array $dati = []): array
    {
        $chiave = trim((string) Config::get('stripe.secret_key'));
        $url = 'https://api.stripe.com' . $percorso;
        $c = curl_init($url);
        curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $chiave, 'Content-Type: application/x-www-form-urlencoded', 'Stripe-Version: 2024-06-20']]);
        if ($metodo === 'POST') { curl_setopt($c, CURLOPT_POST, true); curl_setopt($c, CURLOPT_POSTFIELDS, http_build_query($dati)); }
        $r = curl_exec($c); $code = (int) curl_getinfo($c, CURLINFO_RESPONSE_CODE); $err = curl_error($c); curl_close($c);
        if ($r === false) throw new ApiException("Stripe non raggiungibile: $err");
        $j = json_decode((string) $r, true);
        if ($code >= 400) throw new ApiException('Stripe: ' . ($j['error']['message'] ?? "errore HTTP $code"));
        return (array) $j;
    }

    private static function baseUrl(): string
    {
        $cfg = trim((string) (Config::get('app.url') ?? ''));
        if ($cfg !== '') return rtrim($cfg, '/') . '/';
        $https = drf_https(); $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
        $dir = rtrim(dirname(dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/ajax/x.php'))), '/');   // …/drfacile
        return ($https ? 'https' : 'http') . "://$host$dir/";
    }
}
