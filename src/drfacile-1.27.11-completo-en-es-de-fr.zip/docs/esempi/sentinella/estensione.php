<?php
/**
 * SENTINELLA (codice: sentinella) — vigilanza clinica. Esempio di riferimento della Extension API 2.0.
 *   STRUTTURA: moduli.elenco (modulo sulla costa), menu.voci, scorciatoie, notifiche.tipi, scadenzario.controlli (job quotidiano), cli.comandi, impostazioni.pannelli
 *   DATI/DOCUMENTI: paziente.salva (normalizza), visita.chiusa (chiude le segnalazioni), fattura.incassata, documento.render (promemoria sul referto), backup.contenuto
 *   INTERFACCIA: js/sentinella.js (paziente.scheda, dashboard.widget, topbar.azioni, search.comandi, notifiche.tipi, referto.editor) + modulo/sentinella.js (il modulo)
 * Capabilities: pazienti.leggi, visite.leggi, fatture.leggi, notifiche.crea, scadenzario.crea, database.tabelle. Tabella: ext_sentinella_segnalazioni.
 */
final class Sentinella
{
    public const T = 'ext_sentinella_segnalazioni';
    public const TIPI = ['assente' => 'Non visto da tempo', 'controllo' => 'Controllo saltato', 'fattura' => 'Fattura scaduta', 'anagrafica' => 'Anagrafica incompleta'];

    public static function mesi(): int { return max(1, (int) (Impostazione::get('sentinella_mesi', '12') ?: 12)); }
    public static function eta(): int { return max(0, (int) (Impostazione::get('sentinella_eta', '75') ?: 75)); }

    /** Apre (o riapre) una segnalazione; se già aperta e uguale non fa nulla. Ritorna true se è nuova. */
    public static function segnala(?int $pazienteId, string $tipo, int $gravita, string $titolo, string $testo = '', ?string $rifT = null, ?int $rifId = null): bool
    {
        $ex = Database::one('SELECT id, stato FROM ' . self::T . ' WHERE tipo = ? AND COALESCE(paziente_id, 0) = ? AND COALESCE(rif_id, 0) = ? ORDER BY id DESC LIMIT 1', [$tipo, (int) $pazienteId, (int) $rifId]);
        if ($ex && $ex['stato'] === 'aperta') return false;
        Database::insert(self::T, ['paziente_id' => $pazienteId, 'tipo' => $tipo, 'gravita' => $gravita, 'titolo' => mb_substr($titolo, 0, 160), 'testo' => mb_substr($testo, 0, 400), 'rif_tabella' => $rifT, 'rif_id' => $rifId, 'stato' => 'aperta', 'creato_il' => date('Y-m-d H:i:s')]);
        return true;
    }

    public static function chiudi(string $tipo, ?int $pazienteId = null, ?int $rifId = null): int
    {
        $w = 'stato = ? AND tipo = ?'; $p = ['aperta', $tipo];
        if ($pazienteId) { $w .= ' AND paziente_id = ?'; $p[] = $pazienteId; }
        if ($rifId) { $w .= ' AND rif_id = ?'; $p[] = $rifId; }
        return Database::update(self::T, ['stato' => 'chiusa', 'chiuso_il' => date('Y-m-d H:i:s')], $w, $p);
    }

    /** IL CONTROLLO: scandisce l'archivio e apre le segnalazioni. Ritorna il conteggio delle nuove. */
    public static function scansione(): array
    {
        $nuove = ['assente' => 0, 'controllo' => 0, 'fattura' => 0, 'anagrafica' => 0];
        $limite = date('Y-m-d', strtotime('-' . self::mesi() . ' months'));
        // 1) pazienti non visti da troppo (con almeno una visita in archivio)
        foreach (Database::all('SELECT id, nome, cognome, ultima_visita FROM pazienti WHERE ultima_visita IS NOT NULL AND ultima_visita <> ? AND ultima_visita < ? ORDER BY ultima_visita', ['', $limite]) as $p) {
            $n = nome_completo($p);
            if (self::segnala((int) $p['id'], 'assente', 1, "$n: non lo vedi dal " . data_it($p['ultima_visita']), 'Più di ' . self::mesi() . ' mesi dall\'ultima visita: un richiamo?')) $nuove['assente']++;
        }
        self::chiudiRisolti('assente', 'SELECT id FROM pazienti WHERE ultima_visita >= ?', [$limite]);
        // 2) controlli programmati e mai fatti (data di controllo passata, nessuna visita successiva)
        foreach (Database::all("SELECT v.id, v.paziente_id, v.controllo, p.nome, p.cognome FROM visite v JOIN pazienti p ON p.id = v.paziente_id WHERE v.stato = 'chiusa' AND v.controllo IS NOT NULL AND v.controllo <> '' AND v.controllo < ? AND NOT EXISTS (SELECT 1 FROM visite x WHERE x.paziente_id = v.paziente_id AND x.stato = 'chiusa' AND x.data >= v.controllo)", [oggi()]) as $v) {
            if (self::segnala((int) $v['paziente_id'], 'controllo', 2, nome_completo($v) . ': controllo previsto il ' . data_it($v['controllo']) . ' non effettuato', 'Programmato alla chiusura della visita', 'visite', (int) $v['id'])) $nuove['controllo']++;
        }
        // 3) fatture scadute non pagate
        foreach (Database::all("SELECT f.id, f.numero, f.totale, f.scadenza, f.paziente_id, p.nome, p.cognome FROM fatture f JOIN pazienti p ON p.id = f.paziente_id WHERE f.stato IN ('attesa', 'scaduta') AND f.scadenza < ?", [oggi()]) as $f) {
            if (self::segnala((int) $f['paziente_id'], 'fattura', 2, 'Fattura ' . $f['numero'] . ' scaduta il ' . data_it($f['scadenza']), nome_completo($f) . ' · ' . euro((float) $f['totale']), 'fatture', (int) $f['id'])) $nuove['fattura']++;
        }
        // 4) anagrafiche senza codice fiscale o data di nascita (con almeno una visita)
        foreach (Database::all("SELECT id, nome, cognome, cf, nascita FROM pazienti WHERE ultima_visita IS NOT NULL AND ultima_visita <> '' AND (cf IS NULL OR cf = '' OR nascita IS NULL OR nascita = '')") as $p) {
            $manca = implode(' e ', array_filter([empty($p['cf']) ? 'codice fiscale' : null, empty($p['nascita']) ? 'data di nascita' : null]));
            if (self::segnala((int) $p['id'], 'anagrafica', 1, nome_completo($p) . ": manca $manca", 'Serve per ricette, fatture e Sistema TS')) $nuove['anagrafica']++;
        }
        self::chiudiRisolti('anagrafica', "SELECT id FROM pazienti WHERE cf IS NOT NULL AND cf <> '' AND nascita IS NOT NULL AND nascita <> ''", []);
        $tot = array_sum($nuove);
        if ($tot) Notifica::aggiungi('sentinella', "Sentinella: $tot " . ($tot === 1 ? 'nuova segnalazione' : 'nuove segnalazioni'), implode(' · ', array_filter(array_map(fn($k, $n) => $n ? "$n " . mb_strtolower(self::TIPI[$k]) : null, array_keys($nuove), $nuove))), ['modulo' => 'sentinella', 'opts' => []]);
        Impostazione::set('sentinella_ultima', date('Y-m-d H:i'));
        return $nuove;
    }

    private static function chiudiRisolti(string $tipo, string $sqlIdOk, array $p): void
    {
        $ok = array_column(Database::all($sqlIdOk, $p), 'id');
        foreach (Database::all('SELECT id, paziente_id FROM ' . self::T . " WHERE stato = 'aperta' AND tipo = ?", [$tipo]) as $s) {
            if (in_array((int) $s['paziente_id'], array_map('intval', $ok), true)) Database::update(self::T, ['stato' => 'chiusa', 'chiuso_il' => date('Y-m-d H:i:s')], 'id = :id', ['id' => (int) $s['id']]);
        }
    }

    /** Le segnalazioni aperte, con il nome del paziente */
    public static function aperte(int $limit = 300): array
    {
        return Database::all('SELECT s.*, p.nome, p.cognome FROM ' . self::T . " s LEFT JOIN pazienti p ON p.id = s.paziente_id WHERE s.stato = 'aperta' ORDER BY s.gravita DESC, s.creato_il DESC LIMIT $limit");
    }

    /** I semafori di un paziente (per la scheda): [['colore', 'testo'], …] */
    public static function semafori(array $p): array
    {
        $out = [];
        $eta = $p['eta'] ?? eta($p['nascita'] ?? null);
        if ($eta !== null && $eta >= self::eta()) $out[] = ['amber', "$eta anni: paziente fragile"];
        if (!empty($p['allergie'])) $out[] = ['rose', count((array) $p['allergie']) . ' ' . (count((array) $p['allergie']) === 1 ? 'allergia nota' : 'allergie note')];
        if (!empty($p['ultima_visita'])) {
            $mesi = (int) floor((time() - strtotime($p['ultima_visita'])) / (30.44 * 86400));
            $out[] = $mesi >= self::mesi() ? ['rose', "Non lo vedi da $mesi mesi"] : ['mint', $mesi ? "Ultima visita $mesi " . ($mesi === 1 ? 'mese' : 'mesi') . ' fa' : 'Visto questo mese'];
        } else $out[] = ['gray', 'Mai visitato'];
        $n = (int) Database::value('SELECT COUNT(*) FROM ' . self::T . " WHERE paziente_id = ? AND stato = 'aperta'", [(int) $p['id']]);
        if ($n) $out[] = ['amber', "$n " . ($n === 1 ? 'segnalazione aperta' : 'segnalazioni aperte')];
        return $out;
    }
}

/* ---------------- STRUTTURA */

// il modulo sulla costa: vista, css e js stanno nella cartella dell'estensione (modulo/, non js/: js/ viene caricato comunque)
Hooks::add('moduli.elenco', function (array $m) {
    $m[] = ['key' => 'sentinella', 'label' => 'Sentinella', 'fi' => 'eye', 'fa' => 'fa-regular fa-eye', 'permesso' => 'pazienti.leggi',
        'vista' => Store::dir('sentinella') . '/views/sentinella.php', 'css' => ['estensioni/sentinella/modulo/sentinella.css'], 'js' => ['estensioni/sentinella/modulo/sentinella.js']];
    return $m;
});
Hooks::add('menu.voci', function (array $v) {
    $v[] = ['label' => 'Segnalazioni di Sentinella', 'fi' => 'eye', 'fa' => 'fa-regular fa-eye', 'modulo' => 'sentinella'];
    return $v;
});
Hooks::add('scorciatoie', fn(array $s) => [...$s, ['label' => 'Sentinella: apri le segnalazioni', 'tasti' => 'Ctrl+Shift+S']]);
Hooks::add('notifiche.tipi', fn(array $t) => [...$t, 'sentinella']);
// il job quotidiano senza cron: gira al primo accesso del giorno, nel database dello studio
Hooks::add('scadenzario.controlli', fn() => Sentinella::scansione());
Hooks::add('cli.comandi', function (array $c) {
    $c['sentinella:scansione'] = ['descrizione' => 'Scandisce l\'archivio e apre le segnalazioni (come al primo accesso del giorno)', 'fn' => function (array $arg, array $opt) {
        $n = Sentinella::scansione(); printf("Nuove segnalazioni: %d (%s)\n", array_sum($n), implode(', ', array_map(fn($k, $v) => "$k $v", array_keys($n), $n))); return 0;
    }];
    $c['sentinella:aperte'] = ['descrizione' => 'Elenca le segnalazioni aperte', 'fn' => function () {
        foreach (Sentinella::aperte() as $s) printf("  [%d] %-12s %s\n", $s['gravita'], $s['tipo'], $s['titolo']); return 0;
    }];
    return $c;
});
Hooks::add('impostazioni.pannelli', function (array $p) {
    $p['sentinella'] = ['titolo' => 'Sentinella', 'fi' => 'eye', 'fa' => 'fa-regular fa-eye',
        'html' => '<p class="small muted" style="margin-bottom:10px">Le soglie della vigilanza. Ultima scansione: <b>' . e(Impostazione::get('sentinella_ultima') ?: 'mai') . '</b>.</p>
            <div class="grid2"><div class="field"><label>Mesi senza visita per segnalare</label><input class="input" name="sentinella_mesi" inputmode="numeric" placeholder="12"></div>
            <div class="field"><label>Età "paziente fragile"</label><input class="input" name="sentinella_eta" inputmode="numeric" placeholder="75"></div></div>
            <div class="pref"><div><b>Promemoria del controllo sul referto</b><span>Se la visita ha una data di controllo, il referto stampato la ricorda in fondo</span></div><button class="switch" type="button" data-name="sentinella_referto" aria-label="Sul referto"></button><input type="hidden" name="sentinella_referto" value="1"></div>',
        'chiavi' => ['sentinella_mesi', 'sentinella_eta', 'sentinella_referto'], 'salva' => 'Salva soglie'];
    return $p;
});

/* ---------------- DATI E DOCUMENTI */

// normalizzazione all'atto del salvataggio: cellulare senza spazi, email minuscola
Hooks::add('paziente.salva', function (array $d) {
    if (!empty($d['cellulare'])) $d['cellulare'] = preg_replace('/[\s.\-]+/', '', $d['cellulare']);
    if (!empty($d['email'])) $d['email'] = mb_strtolower($d['email']);
    return $d;
});
// una visita chiusa risolve "non visto da tempo" e "controllo saltato" per quel paziente
Hooks::add('visita.chiusa', function (int $id, int $rid, array $v) { Sentinella::chiudi('assente', (int) $v['paziente_id']); Sentinella::chiudi('controllo', (int) $v['paziente_id']); });
Hooks::add('fattura.incassata', fn(int $id) => Sentinella::chiudi('fattura', null, $id));
Hooks::add('paziente.salvato', fn(int $id, array $d) => (!empty($d['cf']) && !empty($d['nascita'])) ? Sentinella::chiudi('anagrafica', $id) : null);
// il promemoria del controllo in fondo al referto stampato
Hooks::add('documento.render', function (string $html, string $tipo, array $d) {
    if ($tipo !== 'referto' || Impostazione::get('sentinella_referto', '1') !== '1') return $html;
    $v = !empty($d['doc']['visita_id']) ? Visita::find((int) $d['doc']['visita_id']) : null;
    if (!$v || empty($v['controllo'])) return $html;
    $box = '<div style="margin-top:18px;padding:10px 14px;border:1.5px dashed #E8735A;border-radius:10px;font-size:12px"><b>Prossimo controllo: ' . e(data_it($v['controllo'])) . '</b> — la ricordiamo noi, ma segnala sull\'agenda.</div>';
    return preg_replace('~</body>~i', $box . '</body>', $html, 1) ?: $html . $box;
});
Hooks::add('backup.contenuto', fn(array $t) => [...$t, Sentinella::T]);
