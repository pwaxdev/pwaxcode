<?php
require __DIR__ . '/../core/bootstrap.php';

// Esportazione completa dell'archivio in JSON (download diretto, fuori dal router JSON)
// Le tabelle di backup/esportazione: quelle del core + quelle che le estensioni aggiungono (hook backup.contenuto: le loro ext_*)
$tabelleBackup = fn() => array_values(array_unique(Hooks::filter('backup.contenuto', ['pazienti', 'appuntamenti', 'visite', 'referti', 'ricette', 'fatture', 'farmaci', 'prestazioni', 'storico', 'impostazioni', 'consensi', 'documenti', 'scadenze', 'comunicazioni', 'estensioni', 'estensioni_migrazioni'])));
// I formati di esportazione: 'json' del core + quelli delle estensioni (hook export.formati: chiave => [label, mime, estensione, fn(array $tabelle): string])
$formati = Hooks::filter('export.formati', ['json' => ['label' => 'Archivio completo (JSON)', 'mime' => 'application/json', 'ext' => 'json', 'fn' => function (array $tabelle) {
    $out = [];
    foreach ($tabelle as $t) if (Database::tableExists($t)) $out[$t] = Database::all("SELECT * FROM $t");
    return json_encode(['app' => Config::get('app.name'), 'versione' => Config::get('app.version'), 'esportato_il' => date('c'), 'dati' => $out], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}]]);
if (($_GET['action'] ?? '') === 'export') {
    Auth::requireAjax();
    Auth::richiedi('impostazioni.backup');
    $f = $formati[$_GET['formato'] ?? 'json'] ?? $formati['json'];
    header('Content-Type: ' . ($f['mime'] ?? 'application/octet-stream') . '; charset=utf-8');
    header('Content-Disposition: attachment; filename="drfacile-export-' . date('Ymd-Hi') . '.' . ($f['ext'] ?? 'dat') . '"');
    echo $f['fn']($tabelleBackup());
    exit;
}

$chiaviAmmesse = ['profilo_titolo', 'profilo_nome', 'profilo_sesso', 'profilo_specializzazione', 'profilo_email', 'profilo_telefono', 'studio_nome', 'studio_indirizzo', 'studio_piva', 'studio_ordine', 'pref_tema', 'pref_sms', 'pref_firma_auto', 'pref_durata', 'pref_suoni',
    'fattura_spese_attive', 'fattura_spese_importo', 'fattura_spese_desc', 'fattura_contributi_perc', 'fattura_contributi_desc',
    'fattura_formato', 'fattura_prossimo', 'pref_prezzi_visita'];
$chiaviAmmesse = array_merge($chiaviAmmesse, ['stampa_formato', 'stampa_orientamento', 'stampa_font', 'stampa_corpo', 'stampa_preset', 'stampa_m_sup', 'stampa_m_des', 'stampa_m_inf', 'stampa_m_sin', 'stampa_intestazione', 'stampa_piede', 'stampa_bordo', 'stampa_colore',
    'stampa_mittente_fattura', 'stampa_mittente_clinico', 'stampa_logo_posizione', 'stampa_logo_altezza', 'stampa_logo_solo', 'stampa_logo_su', 'stampa_piede_testo', 'stampa_piede_pagine', 'stampa_piede_generato', 'email_da_nome', 'email_rispondi_a', 'email_firma'], Impostazione::chiaviEstensioni());   // le chiavi dichiarate dai pannelli delle estensioni (hook impostazioni.pannelli / impostazioni.chiavi)

Api::run([
    'get'    => fn() => ['impostazioni' => Impostazione::tutte(), 'medico' => Impostazione::profilo(), 'prestazioni' => Prestazione::attive(), 'archivio' => Documenti::archivio(20), 'fattura_prossimo_calcolato' => Fattura::prossimoNumero(),
        'spazio' => Spazio::stato(), 'stampa' => Documenti::stampa(), 'sms' => Sms::pronto(), 'lingue' => I18n::disponibili(), 'lingua' => I18n::locale(),
        'formati_export' => array_map(fn($k, $f) => ['chiave' => $k, 'label' => $f['label']], array_keys($formati), $formati)],
    'save'   => function (array $in) use ($chiaviAmmesse) {
        $n = 0;
        foreach ($in as $k => $v) { if (in_array($k, $chiaviAmmesse, true)) { Impostazione::set($k, is_array($v) ? json_txt($v) : (string) $v); $n++; } }
        return ['salvate' => $n, 'medico' => Impostazione::profilo(), 'messaggio' => __('Impostazioni salvate')];
    },
    // logo per i documenti: nell'archivio dello studio (studio/logo.<ext>), incorporato nelle stampe come data-URL
    'logo' => function () {
        $f = $_FILES['logo'] ?? null;
        if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK) throw new ApiException(__('Nessuna immagine ricevuta'));
        $ext = strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['png', 'jpg', 'jpeg', 'svg', 'webp'], true)) throw new ApiException(__('Formati ammessi: PNG, JPG, SVG, WebP'));
        if ((int) $f['size'] > 1500000) throw new ApiException(__('Logo troppo pesante: massimo 1,5 MB'));
        $bin = (string) file_get_contents($f['tmp_name']);
        if ($ext !== 'svg' && !@getimagesizefromstring($bin)) throw new ApiException('Il file non è un\'immagine valida');
        if ($ext === 'svg' && (stripos($bin, '<script') !== false || stripos($bin, 'onload') !== false)) throw new ApiException(__('SVG non ammesso (contiene script)'));
        foreach (glob(Spazio::base() . '/studio/logo.*') ?: [] as $v) @unlink($v);
        $rel = Spazio::scrivi("studio/logo.$ext", $bin);
        Impostazione::set('stampa_logo', $rel);
        return ['messaggio' => __('Logo salvato'), 'stampa' => Documenti::stampa()];
    },
    'logo_rimuovi' => function () { foreach (glob(Spazio::base() . '/studio/logo.*') ?: [] as $v) @unlink($v); Impostazione::set('stampa_logo', ''); Spazio::azzeraCache(); return ['messaggio' => __('Logo rimosso'), 'stampa' => Documenti::stampa()]; },
    'lingua' => function (array $in) { $l = I18n::normalizza(Api::str($in, 'lingua')); if (!isset(I18n::disponibili()[$l])) throw new ApiException(__('Lingua non disponibile')); $id = (int) (Auth::utente()['id'] ?? 0); if ($id) Database::run('UPDATE ' . Database::comune('utenti') . ' SET lingua = ? WHERE id = ?', [$l, $id]); return ['messaggio' => __('Lingua salvata: la pagina si ricarica'), 'lingua' => $l]; },
    'novita_viste' => function () { Impostazione::set('novita_viste_' . (int) (Auth::utente()['id'] ?? 0), Installer::VERSIONE); return ['ok' => true]; },
    'backup' => function () use ($tabelleBackup) {
        $dir = Config::get('paths.backup'); if (!is_dir($dir)) mkdir($dir, 0775, true);
        if (Database::driver() === 'sqlite') {
            $file = $dir . '/drfacile-' . date('Ymd-His') . '.sqlite';
            Database::pdo()->exec("VACUUM INTO '" . str_replace("'", "''", $file) . "'");
        } else {
            // MySQL/MariaDB: dump SQL generato da PHP (struttura + dati), ripristinabile con: mysql drfacile < file.sql
            $file = $dir . '/drfacile-' . date('Ymd-His') . '.sql';
            $out = "-- DRFacile backup " . date('c') . "\nSET FOREIGN_KEY_CHECKS=0;\n";
            foreach ($tabelleBackup() as $t) {
                if (!Database::tableExists($t)) continue;
                $create = Database::one("SHOW CREATE TABLE `$t`");
                $out .= "\nDROP TABLE IF EXISTS `$t`;\n" . array_values($create)[1] . ";\n";
                foreach (Database::all("SELECT * FROM `$t`") as $row) {
                    $vals = array_map(fn($v) => $v === null ? 'NULL' : Database::pdo()->quote((string) $v), array_values($row));
                    $out .= "INSERT INTO `$t` (`" . implode('`,`', array_keys($row)) . "`) VALUES (" . implode(',', $vals) . ");\n";
                }
            }
            file_put_contents($file, $out . "SET FOREIGN_KEY_CHECKS=1;\n");
        }
        Impostazione::set('backup_ultimo', date('Y-m-d H:i'));
        Attivita::registra('sistema.backup', null, null, basename($file));
        Notifica::aggiungi('success', 'Backup completato', basename($file) . ' · ' . round(filesize($file) / 1024) . ' KB', ['modulo' => 'impostazioni']);
        return ['file' => basename($file), 'dimensione' => filesize($file), 'quando' => date('Y-m-d H:i'), 'messaggio' => 'Backup completato (' . round(filesize($file) / 1024) . ' KB)'];
    },
    'reset_demo' => function () { Installer::reset(); return ['messaggio' => __('Archivio dimostrativo ripristinato')]; },
], ['*' => 'impostazioni.leggi', 'save' => 'impostazioni.modifica', 'logo' => 'impostazioni.modifica', 'logo_rimuovi' => 'impostazioni.modifica', 'novita_viste' => null, 'lingua' => null, 'backup' => 'impostazioni.backup', 'reset_demo' => 'impostazioni.backup']);
