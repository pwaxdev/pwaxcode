/* Mappa corporea interattiva (quadro soggettivo / oggettivo) sul motore BodyModel di Igea (assets/vendor/igea/bodymodel.js).
   Modello scelto da sesso ed età del paziente (neonato ≤3, ragazzo/a ≤14, uomo/donna), con scelta manuale; vista fronte/retro.
   Uso:  const bm = DRF.bodymap({ box: '#bmSintomi', mode: 'sintomi'|'esame', getMeta: () => ({ sesso: 'F', nascita: '1980-01-01' }), onChange: () => {} });
         bm.load(lista); bm.getData(); bm.reload(); bm.clear(); bm.setReadonly(true)
   Dati: sintomi → {regione, label, lato, scala (1-10), tipo, nota}   esame → {regione, label, lato, severita (ok|warn|alto|critico), nota} */
DRF.bodymap = (function ($) {
  'use strict';
  const BANDE = [{ max: 3, M: 'neonato', F: 'neonato' }, { max: 14, M: 'ragazzo', F: 'ragazza' }, { max: Infinity, M: 'uomo', F: 'donna' }];
  const MODELLI = { auto: DRF.__('Automatico'), donna: DRF.__('Donna'), uomo: DRF.__('Uomo'), ragazza: DRF.__('Ragazza'), ragazzo: DRF.__('Ragazzo'), neonato: DRF.__('Neonato') };
  const TIPI = ['dolore', 'gonfiore', 'rigidità', 'parestesia', 'rossore', 'prurito', 'altro'];
  // i18n: DRF.__('dolore') DRF.__('gonfiore') DRF.__('rigidità') DRF.__('parestesia') DRF.__('rossore') DRF.__('prurito') DRF.__('altro')  (etichette tradotte alla visualizzazione)
  const SEV = [['ok', DRF.__('Nella norma')], ['warn', DRF.__('Lieve')], ['alto', DRF.__('Marcato')], ['critico', DRF.__('Severo')]];
  const LATI = [['dx', 'Dx'], ['sx', 'Sx'], ['bilat', 'Bilaterale']];
  const SEV_LABEL = Object.fromEntries(SEV);
  const scalaSev = n => { n = +n || 0; return n >= 9 ? 'critico' : n >= 7 ? 'alto' : n >= 4 ? 'warn' : n >= 1 ? 'ok' : ''; };
  const scalaDesc = n => ({ ok: DRF.__('lieve'), warn: DRF.__('moderato'), alto: DRF.__('forte'), critico: DRF.__('molto forte') }[scalaSev(n)] || '');
  let pool = null, poolReq = null;

  /** Il pool degli SVG viene scaricato una sola volta (views/partials/svgbody.php) */
  function caricaPool() {
    if (pool) return $.Deferred().resolve(pool).promise();
    if (!poolReq) poolReq = $.get('ajax/bodymap.php?action=svg').then(html => { pool = $('<div>').html(html); return pool; });
    return poolReq;
  }
  function etaDa(nascita) {
    if (!nascita) return null; const d = DRF.util.pd(nascita), t = new Date();
    let a = t.getFullYear() - d.getFullYear(); const m = t.getMonth() - d.getMonth(); if (m < 0 || (m === 0 && t.getDate() < d.getDate())) a--; return a;
  }
  function modelloAuto(meta) {
    const s = String((meta && meta.sesso) || 'F').toUpperCase() === 'M' ? 'M' : 'F';
    const eta = etaDa(meta && meta.nascita); const a = eta == null ? 30 : eta;
    return (BANDE.find(b => a <= b.max) || BANDE[BANDE.length - 1])[s];
  }
  function triangolo(livello) {
    const W = 200, base = 52, top = 6, H = base - top, seg = W / 10; let p = '';
    for (let i = 1; i <= 10; i++) {
      const x0 = (i - 1) * seg, x1 = i * seg, yL = base - ((i - 1) / 10) * H, yR = base - (i / 10) * H;
      p += `<polygon class="bm-seg ${i <= livello ? 'on sev-' + scalaSev(i) : ''}" data-seg="${i}" points="${x0},${base} ${x1},${base} ${x1.toFixed(1)},${yR.toFixed(1)} ${x0},${yL.toFixed(1)}"></polygon>`;
    }
    return `<svg class="bm-scala" viewBox="0 0 200 58">${p}</svg>`;
  }

  function Bodymap(opts) {
    const self = this;
    this.$box = $(opts.box); this.mode = opts.mode === 'sintomi' ? 'sintomi' : 'esame'; this.getMeta = opts.getMeta || (() => ({}));
    this.onChange = opts.onChange || (() => {}); this.override = 'auto'; this.view = 'anterior'; this.readonly = false; this.engine = null; this.edit = null;
    this.$box.addClass('bodymap').html(`
      <div class="bm-toolbar">
        <div class="seg bm-view"><button type="button" class="on" data-v="anterior">${DRF.__('Fronte')}</button><button type="button" data-v="posterior">${DRF.__('Retro')}</button></div>
        <select class="select bm-model">${Object.keys(MODELLI).map(k => `<option value="${k}">${MODELLI[k]}</option>`).join('')}</select>
        <span class="bm-auto muted small"></span>
        <button type="button" class="icon-btn sm bm-clear" title="${DRF.__('Azzera')}"><i class="ico" data-fi="trash" data-fa="fa-solid fa-trash"></i></button>
      </div>
      <div class="bm-wrap"><div class="bm-stage"></div><div class="bm-side"><div class="bm-editor" hidden></div><ul class="bm-list"></ul></div></div>`);
    DRF.ui.select(this.$box.find('.bm-model'), { minimumResultsForSearch: Infinity });
    DRF.icons.apply(this.$box[0]);
    this.$box.find('.bm-view').on('click', 'button', function () { self.$box.find('.bm-view button').removeClass('on'); $(this).addClass('on'); self.view = this.dataset.v; self._monta(); });
    this.$box.find('.bm-model').on('change', function () { self.override = this.value; self._monta(); });
    this.$box.find('.bm-clear').on('click', () => { if (!self.engine || !Object.keys(self.engine.state).length) return; DRF.ui.confirm(DRF.__('Azzerare la mappa?'), DRF.__('Tutte le regioni segnate verranno rimosse.'), DRF.__('Azzera')).then(ok => { if (ok) self.clear(); }); });
    this.$box.find('.bm-list').on('click', 'li', function (e) { if ($(e.target).closest('.bm-rm').length) { self.engine.deselect(this.dataset.region); self._lista(); return; } self._apri(this.dataset.region); });
    this.$box.find('.bm-side').on('click', '[data-bm-salva]', () => self._salva()).on('click', '[data-bm-rimuovi]', () => { if (self.edit) { self.engine.deselect(self.edit.region); } self._chiudi(); self._lista(); }).on('click', '[data-bm-chiudi]', () => self._chiudi());
    this.$box.find('.bm-side').on('click', '.bm-seg', function () { self.$box.find('.bm-scala').replaceWith(triangolo(+this.dataset.seg)); self.$box.find('.bm-scala-lbl').text(self._scalaTesto(+this.dataset.seg)); self.$box.find('[data-bm-scala]').val(this.dataset.seg); });
    this.$box.find('.bm-side').on('click', '.bm-chip', function () { $(this).siblings().removeClass('on'); $(this).addClass('on'); });
    caricaPool().then(() => self._monta());
  }

  Bodymap.prototype._modello = function () { return this.override !== 'auto' ? this.override : modelloAuto(this.getMeta()); };

  /** Inserisce l'SVG del modello/vista corrente nello stage, ricreando il motore ma conservando lo stato */
  Bodymap.prototype._monta = function () {
    if (!pool) return;
    const modello = this._modello(), $src = pool.find(`.mg-model[data-model="${modello}"][data-view="${this.view}"] svg`);
    const stato = this.engine ? this.engine.state : {};
    const $stage = this.$box.find('.bm-stage').empty();
    // Se il vendor BodyModel non è stato servito (es. permessi/403), non montare un SVG grezzo:
    // senza il motore i path userebbero il fill SVG predefinito nero, producendo il classico "blob".
    if (typeof window.BodyModel !== 'function') {
      try { console.error('DRFacile: assets/vendor/igea/bodymodel.js non caricato'); } catch (e) {}
      return;
    }
    if ($src.length) $stage.append($src.clone());
    this.$box.find('.bm-auto').text(this.override === 'auto' ? `${DRF.__('Modello')}: ${MODELLI[modello]}` : '');
    if (this.engine) this.engine.destroy();
    const self = this;
    this.engine = BodyModel({ box: $stage[0], view: this.view, multi: true, readonly: this.readonly, onPick: p => self._apri(p.region, p.latoHint), onChange: () => {} });
    this.engine.state = stato; this.engine.paint();
    this._lista();
  };

  Bodymap.prototype._scalaTesto = function (n) { return n ? `${n}/10 · ${scalaDesc(n)}` : 'Indica l\'intensità'; };

  /** Apre l'editor per una regione (nuova o esistente) */
  Bodymap.prototype._apri = function (region, latoHint) {
    if (this.readonly) return;
    const eng = this.engine, cur = eng.state[region] || {}, lab = eng.labelOf(region), bil = BodyModel.isBilateral(region);
    this.edit = { region, nuovo: !eng.state[region] };
    const lato = cur.lato || latoHint || '';
    this.$box.find('.bm-stage [part]').removeClass('bm-pending'); this.$box.find(`.bm-stage [part="${region}"]`).addClass('bm-pending');
    const latoHtml = bil ? `<div class="field"><label>${DRF.__('Lato')}</label><div class="seg bm-lato">${LATI.map(l => `<button type="button" class="${l[0] === lato ? 'on' : ''}" data-v="${l[0]}">${l[1]}</button>`).join('')}</div></div>` : '';
    let corpo;
    if (this.mode === 'sintomi') {
      const scala = +cur.scala || 0;
      corpo = `<div class="field"><label>${DRF.__('Tipo di sintomo')}</label><div class="bm-chips">${TIPI.map(t => `<button type="button" class="chip bm-chip ${t === (cur.tipo || 'dolore') ? 'on' : ''}" data-v="${t}">${DRF.__(t)}</button>`).join('')}</div></div>
        <div class="field"><label>${DRF.__('Intensità')}</label>${triangolo(scala)}<div class="bm-scala-lbl small">${this._scalaTesto(scala)}</div><input type="hidden" data-bm-scala value="${scala}"></div>`;
    } else {
      corpo = `<div class="field"><label>${DRF.__('Reperto')}</label><div class="seg bm-sev">${SEV.map(s => `<button type="button" class="${s[0] === (cur.severita || 'warn') ? 'on' : ''} sev-${s[0]}" data-v="${s[0]}">${s[1]}</button>`).join('')}</div></div>`;
    }
    this.$box.find('.bm-editor').html(`<div class="bm-ed-head"><b>${DRF.esc(lab)}</b><button type="button" class="icon-btn sm" data-bm-chiudi title="${DRF.__('Chiudi')}"><i class="ico" data-fi="cross-small" data-fa="fa-solid fa-xmark"></i></button></div>
      ${latoHtml}${corpo}
      <div class="field"><label>${DRF.__('Nota')}</label><input class="input" data-bm-nota value="${DRF.esc(cur.nota || '')}" placeholder="${DRF.__('Facoltativa')}"></div>
      <div class="row" style="gap:8px;margin-top:10px"><button type="button" class="btn primary sm" data-bm-salva>${DRF.__('Salva')}</button>${this.edit.nuovo ? '' : '<button type="button" class="btn danger sm" data-bm-rimuovi>' + DRF.__('Rimuovi') + '</button>'}</div>`).prop('hidden', false);
    DRF.ui.wire(this.$box.find('.bm-editor')[0]); DRF.icons.apply(this.$box.find('.bm-editor')[0]);
    this.$box.find('[data-bm-nota]').trigger('focus');
  };

  Bodymap.prototype._salva = function () {
    if (!this.edit) return;
    const $ed = this.$box.find('.bm-editor'), d = { lato: DRF.ui.segValue($ed.find('.bm-lato')) || '', nota: $ed.find('[data-bm-nota]').val().trim() };
    if (this.mode === 'sintomi') { d.scala = +$ed.find('[data-bm-scala]').val() || 0; d.tipo = $ed.find('.bm-chip.on').data('v') || 'dolore'; d.severita = scalaSev(d.scala); if (!d.scala) return DRF.ui.toast('Indica l\'intensità del sintomo', 'warn'); }
    else d.severita = DRF.ui.segValue($ed.find('.bm-sev')) || 'warn';
    this.engine.set(this.edit.region, d);
    this._chiudi(); this._lista();
  };

  Bodymap.prototype._chiudi = function () { this.edit = null; this.$box.find('.bm-editor').prop('hidden', true).empty(); this.$box.find('.bm-stage [part]').removeClass('bm-pending'); };

  Bodymap.prototype._lista = function () {
    const items = this.getData(), $l = this.$box.find('.bm-list').empty();
    if (!items.length) $l.append(`<li class="bm-empty">${this.mode === 'sintomi' ? DRF.__('Nessun sintomo segnato: tocca una regione del modello.') : DRF.__('Nessun reperto segnato: tocca una regione del modello.')}</li>`);
    items.forEach(it => {
      const meta = this.mode === 'sintomi' ? `${it.scala ? it.scala + '/10 · ' + scalaDesc(it.scala) : ''}${it.tipo ? ' · ' + it.tipo : ''}` : (SEV_LABEL[it.severita] || '');
      const sev = this.mode === 'sintomi' ? scalaSev(it.scala) : it.severita;
      $l.append(`<li data-region="${DRF.esc(it.regione)}"><span class="bm-dot sev-${sev || 'none'}"></span><span><b>${DRF.esc(it.label)}</b>${it.lato ? ' (' + DRF.esc(it.lato) + ')' : ''} <span class="muted">${DRF.esc(meta)}</span>${it.nota ? `<div class="small muted">${DRF.esc(it.nota)}</div>` : ''}</span><i class="ico bm-rm" data-fi="cross-small" data-fa="fa-solid fa-xmark" title="${DRF.__('Rimuovi')}"></i></li>`);
    });
    DRF.icons.apply($l[0]);
    try { this.onChange(items); } catch (e) { /* ignora */ }
  };

  /** Elenco pronto per il salvataggio */
  Bodymap.prototype.getData = function () {
    if (!this.engine) return this._cache || [];
    const st = this.engine.state, eng = this.engine;
    return Object.keys(st).map(r => { const d = st[r]; return this.mode === 'sintomi'
      ? { regione: r, label: eng.labelOf(r), lato: d.lato || '', scala: +d.scala || 0, tipo: d.tipo || '', nota: d.nota || '' }
      : { regione: r, label: eng.labelOf(r), lato: d.lato || '', severita: d.severita || '', nota: d.nota || '' }; });
  };
  /** Carica uno stato salvato */
  Bodymap.prototype.load = function (lista) {
    const self = this; this._cache = lista || [];
    caricaPool().then(() => {
      if (!self.engine) self._monta();
      const st = {};
      (lista || []).forEach(r => { st[r.regione] = self.mode === 'sintomi' ? { scala: +r.scala || 0, tipo: r.tipo || '', lato: r.lato || '', nota: r.nota || '', severita: scalaSev(r.scala) } : { severita: r.severita || '', lato: r.lato || '', nota: r.nota || '' }; });
      self.engine.state = st; self.engine.paint(); self._chiudi(); self._lista();
    });
    return this;
  };
  Bodymap.prototype.reload = function () { this._monta(); return this; };
  Bodymap.prototype.clear = function () { if (this.engine) { this.engine.state = {}; this.engine.paint(); } this._chiudi(); this._lista(); return this; };
  Bodymap.prototype.setReadonly = function (v) { this.readonly = !!v; if (this.engine) this.engine.setReadonly(this.readonly); this.$box.find('.bm-toolbar .bm-clear').prop('disabled', this.readonly); return this; };

  /** Testo riassuntivo per referti e stampe */
  Bodymap.testo = function (lista, mode) {
    return (lista || []).map(it => { const lato = it.lato ? ` (${it.lato})` : '', nota = it.nota ? `: ${it.nota}` : '';
      return mode === 'sintomi' ? `${it.label}${lato}: ${it.tipo || 'sintomo'} ${it.scala || 0}/10 (${scalaDesc(it.scala) || '—'})${nota}` : `${it.label}${lato}: ${SEV_LABEL[it.severita] || it.severita || '—'}${nota}`; }).join('\n');
  };

  return opts => new Bodymap(opts);
})(jQuery);
