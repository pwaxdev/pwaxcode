<?php
return [
    'title' => __('Nuova fattura'),
    'endpoint' => 'fatture', 'action' => 'save', 'submit' => __('Emetti fattura'),
    'fields' => [
        ['name' => 'paziente_id', 'label' => __('Paziente'), 'type' => 'select', 'required' => true, 'empty' => __('Seleziona…'), 'options' => fn() => Paziente::optionsMap()],
        ['name' => 'prestazione', 'label' => __('Prestazione'), 'type' => 'select', 'required' => true, 'options' => fn() => Prestazione::optionsMap()],
        ['name' => 'importo', 'label' => __('Importo'), 'type' => 'text', 'mask' => 'euros', 'class' => 'num', 'default' => '', 'row' => 1],
        ['name' => 'metodo', 'label' => __('Incasso'), 'type' => 'select', 'options' => fn() => Fattura::metodiMap(), 'row' => 1],
        ['name' => 'note', 'label' => __('Note in fattura'), 'type' => 'text', 'placeholder' => __('Facoltative')],
    ],
];
