<?php
/** PIÈ DI PAGINA comune (Impostazioni → Stampa): riga dello studio, testo libero, numerazione, firma del programma.
    Variabili: $medico, $stampa, $piede_extra = HTML aggiuntivo (es. note fattura). Sempre in fondo alla pagina. */
$tst = $stampa ?? Documenti::stampa();
if (!$tst['piede']) return;
?>
<footer>
  <?php if (!empty($medico['riga_documenti'])): ?><div class="riga-studio"><?= e($medico['riga_documenti']) ?></div><?php endif; ?>
  <?php if ($tst['piede_testo'] !== ''): ?><div class="riga-studio"><?= nl2br(e($tst['piede_testo'])) ?></div><?php endif; ?>
  <?= $piede_extra ?? '' ?>
  <table class="piede-riga"><tr><td><?= $tst['piede_generato'] ? 'Documento generato con DRFacile' : '' ?></td><td class="pagine"><?php if ($tst['piede_pagine']): ?><span class="pagine-num">Pagina <span class="n">1</span></span><?php endif; ?></td></tr></table>
</footer>
<?php unset($tst); ?>
