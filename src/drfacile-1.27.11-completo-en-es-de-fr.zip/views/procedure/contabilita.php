<?php /** Vista Contabilità (estensione Commercialista): esportazione fatture del periodo. Logica in procedure.js → viste.contabilita */ ?>
<div class="ctl-grid">
  <div class="ctl">
    <div class="ctl-head"><div><b><?= __('Esporta le fatture del periodo') ?></b><span><?= __('Un archivio ZIP con un file') ?> <b><?= __('XML in formato elettronico') ?></b> per ogni fattura (dati studio, intestatario, righe, IVA, bollo, pagamento, eventuale opposizione al Sistema TS) più il <b><?= __('riepilogo CSV') ?></b> <?= __('con i totali per aliquota: pronto per il gestionale del commercialista.') ?></span></div></div>
    <div class="ctb-periodo">
      <div class="field"><label><?= __('Mese') ?></label><select class="select" id="ctbMese"><option value=""><?= __('Periodo libero…') ?></option></select></div>
      <div class="field"><label><?= __('Dal') ?></label><input class="input" id="ctbDa" type="date"></div>
      <div class="field"><label><?= __('Al') ?></label><input class="input" id="ctbA" type="date"></div>
    </div>
    <div class="ctl-btns" style="margin-top:6px">
      <button class="btn primary sm" type="button" id="ctbEsporta"><i class="ico" data-fi="download" data-fa="fa-solid fa-download"></i><?= __('Esporta ZIP') ?></button>
      <span class="small muted" id="ctbEsito"></span>
    </div>
  </div>
  <div class="ctl">
    <div class="ctl-head"><div><b><?= __('Riepilogo del periodo') ?></b><span><?= __('Quello che finirà nell\'esportazione, con lo spaccato per aliquota IVA: gli stessi totali che il commercialista si aspetta di quadrare.') ?></span></div></div>
    <div class="ctb-tiles" id="ctbTiles"></div>
    <table class="ctb-iva" id="ctbIva" hidden><thead><tr><th><?= __('Aliquota') ?></th><th><?= __('Fatture') ?></th><th><?= __('Imponibile') ?></th><th><?= __('Imposta') ?></th></tr></thead><tbody></tbody></table>
    <p class="small muted" id="ctbNote" style="margin-top:10px"></p>
  </div>
</div>
