/* DRF.rich — l'editor di testo della casa (pseudo-Froala, in 300 righe).
   Grassetto/corsivo/sottolineato, titoletto, elenchi, link, annulla/ripeti, contatore caratteri,
   CAMPI {segnaposto} come entità atomiche (chip nere: si inseriscono dal menu e si eliminano in blocco)
   e MODULI per estenderlo (domani: immagini).

     const ed = DRF.rich.mount('#box', { campi: ['paziente', 'data'], value: '<p>Ciao {paziente}</p>', onChange: v => … });
     ed.get(); ed.set(html); ed.insertCampo('data'); ed.exec('bold'); ed.insertHTML('<hr>'); ed.focus(); ed.destroy();

   Automatico su ogni <textarea class="rich" data-campi="paziente,data"> (via DRF.ui.wire): la textarea resta
   sincronizzata, quindi form del FormBuilder e DRF.ui.formData funzionano senza altro codice.

     DRF.rich.use({ name: 'hr', button: { fi: 'minus', fa: 'fa-solid fa-minus', title: DRF.__('Separatore') }, run: ed => ed.insertHTML('<hr>') });
     DRF.rich.allow('IMG');   // un modulo può ampliare i tag ammessi */
DRF.rich = (function ($) {
  'use strict';
  const I = (fi, fa) => DRF.icons.html(fi, fa);
  const MODULI = [];
  const TAGS = { B: 1, STRONG: 1, I: 1, EM: 1, U: 1, P: 1, BR: 1, DIV: 1, UL: 1, OL: 1, LI: 1, H3: 1, A: 1, HR: 1, MARK: 1 };
  const RE_CAMPO = /\{([a-z0-9_]+)\}/gi;

  /* --- igiene: solo i tag ammessi, niente attributi (tranne i link sicuri e i chip dei campi) --- */
  function sanitize(root) {
    [...root.querySelectorAll('script,style,iframe,object,embed,meta,link')].forEach(n => n.remove());
    const walk = el => {
      [...el.children].forEach(c => {
        if (c.classList && c.classList.contains('rich-campo') && c.dataset.campo) {
          const nome = c.dataset.campo.replace(/[^a-z0-9_]/gi, '');
          const chip = campoEl(nome); c.replaceWith(chip); return;
        }
        walk(c);
        let t = c.tagName;
        if (!TAGS[t] && (t === 'SPAN' || t === 'FONT') && /background/i.test(c.getAttribute('style') || '')) {
          const m = document.createElement('mark'); m.append(...c.childNodes); c.replaceWith(m); c = m; t = 'MARK';
        }
        if (!TAGS[t]) { c.replaceWith(...c.childNodes); return; }
        [...c.attributes].forEach(a => { if (!(t === 'A' && a.name === 'href')) c.removeAttribute(a.name); });
        if (t === 'A') {
          const h = c.getAttribute('href') || '';
          if (!/^(https?:\/\/|mailto:)/i.test(h)) c.replaceWith(...c.childNodes);
          else { c.setAttribute('target', '_blank'); c.setAttribute('rel', 'noopener'); }
        }
      });
    };
    walk(root);
  }
  function campoEl(nome) {
    const s = document.createElement('span');
    s.className = 'rich-campo'; s.contentEditable = 'false'; s.dataset.campo = nome; s.textContent = nome;
    return s;
  }
  /** Nei nodi di testo, {campo} diventa un chip */
  function idrata(root) {
    const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT), nodi = [];
    while (tw.nextNode()) if (RE_CAMPO.test(tw.currentNode.data)) nodi.push(tw.currentNode); 
    nodi.forEach(n => {
      const frag = document.createDocumentFragment(); let last = 0; RE_CAMPO.lastIndex = 0; let m;
      while ((m = RE_CAMPO.exec(n.data))) {
        if (m.index > last) frag.appendChild(document.createTextNode(n.data.slice(last, m.index)));
        frag.appendChild(campoEl(m[1])); last = m.index + m[0].length;
      }
      if (last < n.data.length) frag.appendChild(document.createTextNode(n.data.slice(last)));
      n.replaceWith(frag);
    });
  }

  function mount(el, opts) {
    opts = opts || {};
    const $src = $(el).first(); if (!$src.length || $src[0]._drfRich) return $src.length ? $src[0]._drfRich : null;
    const isTa = $src.is('textarea');
    const campi = opts.campi || ($src.data('campi') ? String($src.data('campi')).split(',').map(s => s.trim()).filter(Boolean) : []);
    const height = opts.height || +$src.data('height') || 150;
    const placeholder = opts.placeholder || $src.attr('placeholder') || DRF.__('Scrivi qui…');
    const attivi = opts.moduli === false ? [] : MODULI.filter(m => opts.moduli === undefined || opts.moduli === true || (Array.isArray(opts.moduli) && opts.moduli.includes(m.name)));

    const CORE = [
      { cmd: 'bold', fi: 'bold', fa: 'fa-solid fa-bold', title: DRF.__('Grassetto · ⌘B') },
      { cmd: 'italic', fi: 'italic', fa: 'fa-solid fa-italic', title: DRF.__('Corsivo · ⌘I') },
      { cmd: 'underline', fi: 'underline', fa: 'fa-solid fa-underline', title: DRF.__('Sottolineato · ⌘U') },
      { sep: 1 },
      { k: 'h3', fi: 'text', fa: 'fa-solid fa-heading', title: DRF.__('Titoletto') },
      { cmd: 'insertUnorderedList', fi: 'list', fa: 'fa-solid fa-list-ul', title: DRF.__('Elenco puntato') },
      { cmd: 'insertOrderedList', fi: 'list-check', fa: 'fa-solid fa-list-ol', title: DRF.__('Elenco numerato') },
      { sep: 1 },
      { k: 'link', fi: 'link', fa: 'fa-solid fa-link', title: DRF.__('Link') },
      { k: 'clear', fi: 'eraser', fa: 'fa-solid fa-eraser', title: DRF.__('Pulisci formattazione') },
    ];
    const bHtml = (b, extra) => b.sep ? '<i class="rich-sep"></i>' : `<button type="button" class="rich-btn" data-rb="${b.k || b.cmd}" ${extra || ''} title="${DRF.esc(b.title || '')}">${I(b.fi, b.fa)}</button>`;
    const $box = $(`<div class="rich-box">
      <div class="rich-bar">${CORE.map(b => bHtml(b)).join('')}${campi.length ? `<i class="rich-sep"></i><button type="button" class="rich-btn rich-btn-campo" data-rb="campo" title="${DRF.__('Inserisci un campo')}">${I('brackets-curly', 'fa-solid fa-code')}<span>${DRF.__('Campo')}</span></button>` : ''}${attivi.length ? '<i class="rich-sep"></i>' + attivi.map(m => bHtml({ k: 'mod:' + m.name, ...m.button })).join('') : ''}<span class="rich-spacer"></span>${bHtml({ cmd: 'undo', fi: 'undo', fa: 'fa-solid fa-rotate-left', title: DRF.__('Annulla · ⌘Z') })}${bHtml({ cmd: 'redo', fi: 'redo', fa: 'fa-solid fa-rotate-right', title: DRF.__('Ripeti · ⇧⌘Z') })}</div>
      <div class="rich-editor" contenteditable="true" data-placeholder="${DRF.esc(placeholder)}" style="min-height:${height}px"></div>
      <div class="rich-foot"><span class="rich-count">${DRF.__('Caratteri: 0')}</span></div>
      <div class="rich-menu" hidden>${campi.map(c => `<button type="button" data-campo="${DRF.esc(c)}"><span class="rich-campo mini">${DRF.esc(c)}</span></button>`).join('')}</div>
    </div>`);
    if (isTa) { $src.attr('hidden', true).after($box); } else { $src.append($box); }
    DRF.icons.apply($box[0]);
    const ed = $box.find('.rich-editor')[0], $menu = $box.find('.rich-menu');
    let range = null;   // ultima selezione dentro l'editor (per inserire dai pulsanti)

    /* --- valore --- */
    function set(html) {
      ed.innerHTML = html == null ? '' : String(html);
      sanitize(ed); idrata(ed); refresh();
    }
    function get() {
      const c = ed.cloneNode(true);
      c.querySelectorAll('.rich-campo').forEach(s => s.replaceWith('{' + (s.dataset.campo || '') + '}'));
      sanitize(c);
      const txt = c.textContent.replace(/\u00a0/g, ' ').trim();
      return txt === '' && !c.querySelector('hr,li') ? '' : c.innerHTML.trim();
    }
    function refresh() {
      const testo = ed.textContent.replace(/\u00a0/g, ' ');
      $box.find('.rich-count').text(DRF.__('Caratteri: ') + testo.replace(/\n/g, '').length);
      $box.toggleClass('is-empty', testo.trim() === '' && !ed.querySelector('.rich-campo,hr,li'));
      if (isTa) $src.val(get());
      if (opts.onChange) opts.onChange(api);
    }
    function salvaRange() { const s = window.getSelection(); if (s.rangeCount && ed.contains(s.anchorNode)) range = s.getRangeAt(0).cloneRange(); }
    function ripristina() { ed.focus(); if (range) { const s = window.getSelection(); s.removeAllRanges(); s.addRange(range); } }
    function exec(cmd, val) { ripristina(); document.execCommand(cmd, false, val || null); salvaRange(); refresh(); stato(); }
    function insertHTML(html) { const d = document.createElement('div'); d.innerHTML = html; sanitize(d); idrata(d); exec('insertHTML', d.innerHTML); }
    function insertCampo(nome) { exec('insertHTML', campoEl(nome).outerHTML + '&nbsp;'); }

    /* --- stato dei pulsanti --- */
    function stato() {
      ['bold', 'italic', 'underline', 'insertUnorderedList', 'insertOrderedList'].forEach(c => { let on = false; try { on = document.queryCommandState(c); } catch (e) {} $box.find(`[data-rb="${c}"]`).toggleClass('on', on); });
      let blocco = ''; try { blocco = String(document.queryCommandValue('formatBlock')).toLowerCase(); } catch (e) {}
      $box.find('[data-rb="h3"]').toggleClass('on', blocco === 'h3');
    }

    /* --- eventi --- */
    $box.find('.rich-bar').on('mousedown', 'button', e => e.preventDefault());   // non rubare la selezione
    $box.on('click', '[data-rb]', function () {
      const k = this.dataset.rb;
      if (k === 'campo') { $menu.prop('hidden', !$menu.prop('hidden')); return; }
      if (k === 'h3') { let b = ''; try { b = String(document.queryCommandValue('formatBlock')).toLowerCase(); } catch (e) {} return exec('formatBlock', b === 'h3' ? '<p>' : '<h3>'); }
      if (k === 'clear') { exec('removeFormat'); return exec('formatBlock', '<p>'); }
      if (k === 'link') {
        const sel = range ? range.toString() : '';
        DRF.ui.modal({ title: DRF.__('Inserisci link'), ok: DRF.__('Inserisci'), cancel: DRF.__('Annulla'),
          html: `<div class="field"><label>${DRF.__('Indirizzo')}</label><input class="input" id="richUrl" placeholder="https://…" value="https://"></div>${sel ? '' : '<div class="field"><label>' + DRF.__('Testo') + '</label><input class="input" id="richTxt" placeholder="' + DRF.__('Testo del link') + '"></div>'}`,
          onOk($b) { const u = $b.find('#richUrl').val().trim(); if (!/^(https?:\/\/|mailto:).+/i.test(u)) { DRF.ui.toast(DRF.__('Indirizzo non valido'), 'warn'); return false; }
            if (sel) exec('createLink', u); else insertHTML(`<a href="${DRF.esc(u)}">${DRF.esc($b.find('#richTxt').val().trim() || u)}</a>&nbsp;`); } });
        return;
      }
      if (k.startsWith('mod:')) { const m = attivi.find(x => 'mod:' + x.name === k); if (m && m.run) m.run(api); return; }
      exec(k);
    });
    $menu.on('click', '[data-campo]', function () { insertCampo(this.dataset.campo); $menu.prop('hidden', true); });
    $(document).on('mousedown.rich' + (mount._n = (mount._n || 0) + 1), e => { if (!$menu.prop('hidden') && !$(e.target).closest($box.find('.rich-btn-campo')).length && !$(e.target).closest($menu).length) $menu.prop('hidden', true); });
    $(ed).on('keyup mouseup focus', () => { salvaRange(); stato(); })
      .on('input', () => { salvaRange(); refresh(); if (isTa) $src.trigger('input'); })
      .on('blur', () => setTimeout(refresh, 0))
      .on('click', '.rich-campo', function () { const r = document.createRange(); r.selectNode(this); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r); salvaRange(); })
      .on('paste', e => {
        e.preventDefault();
        const cd = e.originalEvent.clipboardData;
        const html = cd.getData('text/html');
        if (html) { insertHTML(html); } else { exec('insertText', cd.getData('text/plain')); }
      });

    const api = { el: $(ed), box: $box, get, set, focus: () => ed.focus(), exec, insertHTML, insertCampo, campi,
      enable(b) { ed.contentEditable = b ? 'true' : 'false'; $box.toggleClass('is-disabled', !b); $box.find('.rich-btn').prop('disabled', !b); return api; },
      destroy() { $box.remove(); if (isTa) $src.removeAttr('hidden'); delete $src[0]._drfRich; } };
    attivi.forEach(m => { if (m.init) m.init(api); });
    set(isTa ? $src.val() : (opts.value || ''));
    if (opts.value != null && isTa) set(opts.value);
    $src[0]._drfRich = api;
    return api;
  }

  return {
    mount,
    /** Registra un modulo: { name, button: { fi, fa, title }, run(editor), init(editor)? } */
    use(mod) { if (mod && mod.name && !MODULI.some(m => m.name === mod.name)) MODULI.push(mod); },
    /** Un modulo può ampliare i tag ammessi (es. DRF.rich.allow('IMG')) */
    allow(tag) { TAGS[String(tag).toUpperCase()] = 1; },
    moduli: () => MODULI.map(m => m.name),
  };
})(jQuery);
