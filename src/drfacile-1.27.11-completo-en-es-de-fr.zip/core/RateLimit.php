<?php
/**
 * RATE LIMITING persistente per login e recupero password (tabella comune `tentativi`).
 * Una chiave per IP e una per nome utente; a ogni errore il contatore sale e scatta un blocco a scaglioni
 * (config auth.rate_limit): 5 errori → 30 secondi, 10 → 5 minuti, 20 → 30 minuti. Il contatore si azzera
 * al primo accesso riuscito o dopo la finestra (15 minuti senza errori). Nessun blocco permanente.
 *
 *   RateLimit::bloccato(['login:ip:1.2.3.4', 'login:utente:rossi'])  → secondi di attesa (0 = libero)
 *   RateLimit::fallito([...]) / RateLimit::azzera([...])
 */
final class RateLimit
{
    private const SCAGLIONI = [20 => 1800, 10 => 300, 5 => 30];   // errori → secondi di blocco
    private const FINESTRA = 900;

    public static function tabelle(): void
    {
        Database::run('CREATE TABLE IF NOT EXISTS ' . Database::comune('tentativi') . " (
            chiave VARCHAR(120) PRIMARY KEY, errori INTEGER DEFAULT 0, primo_il INTEGER, ultimo_il INTEGER, bloccato_fino INTEGER DEFAULT 0)");
    }

    /** Chiavi standard per un tentativo di accesso: IP + nome utente */
    public static function chiavi(string $ambito, string $utente = ''): array
    {
        $k = [$ambito . ':ip:' . ($_SERVER['REMOTE_ADDR'] ?? 'cli')];
        if ($utente !== '') $k[] = $ambito . ':utente:' . mb_substr(mb_strtolower($utente), 0, 80);
        return $k;
    }

    /** Secondi da attendere prima di poter riprovare (0 = via libera) */
    public static function bloccato(array $chiavi): int
    {
        $max = 0;
        try {
            foreach ($chiavi as $k) {
                $r = Database::one('SELECT bloccato_fino FROM ' . Database::comune('tentativi') . ' WHERE chiave = ?', [$k]);
                if ($r) $max = max($max, (int) $r['bloccato_fino'] - time());
            }
        } catch (Throwable $e) { /* tabella non pronta: non blocchiamo */ }
        return max(0, $max);
    }

    /** Registra un errore su ogni chiave e restituisce i secondi di blocco eventualmente scattati */
    public static function fallito(array $chiavi): int
    {
        $blocco = 0; $ora = time();
        try {
            $t = Database::comune('tentativi');
            foreach ($chiavi as $k) {
                $r = Database::one("SELECT * FROM $t WHERE chiave = ?", [$k]);
                $errori = ($r && $ora - (int) $r['ultimo_il'] < self::FINESTRA) ? (int) $r['errori'] + 1 : 1;
                $fino = 0;
                foreach (self::SCAGLIONI as $n => $sec) if ($errori >= $n) { $fino = $ora + $sec; break; }
                if ($r) Database::update($t, ['errori' => $errori, 'ultimo_il' => $ora, 'bloccato_fino' => $fino], 'chiave = :k', ['k' => $k]);
                else Database::insert($t, ['chiave' => $k, 'errori' => $errori, 'primo_il' => $ora, 'ultimo_il' => $ora, 'bloccato_fino' => $fino]);
                $blocco = max($blocco, $fino ? $fino - $ora : 0);
            }
            if (random_int(1, 50) === 1) Database::run("DELETE FROM $t WHERE ultimo_il < ?", [$ora - 86400]);   // pulizia occasionale
        } catch (Throwable $e) { error_log('RateLimit: ' . $e->getMessage()); }
        return $blocco;
    }

    public static function azzera(array $chiavi): void
    {
        try { foreach ($chiavi as $k) Database::run('DELETE FROM ' . Database::comune('tentativi') . ' WHERE chiave = ?', [$k]); } catch (Throwable $e) { /* niente */ }
    }

    /** "Riprova fra 30 secondi" / "fra 5 minuti" */
    public static function messaggio(int $secondi): string
    {
        if ($secondi >= 120) return 'Troppi tentativi: riprova fra ' . ceil($secondi / 60) . ' minuti';
        return 'Troppi tentativi: riprova fra ' . max(1, $secondi) . ' secondi';
    }
}
