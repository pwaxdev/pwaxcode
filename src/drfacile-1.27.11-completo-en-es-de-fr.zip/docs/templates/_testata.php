<?php
/** INTESTAZIONE comune ai documenti (Impostazioni → Stampa): logo, mittente (studio / professionista / entrambi), blocco di destra.
    Variabili: $tipo, $medico, $stampa (Documenti::stampa()), $destra = HTML del blocco di destra (destinatario o dati documento). */
// variabili con prefisso: il template che include può usare $righe, $st, $logo per conto suo
$tst = $stampa ?? Documenti::stampa();
$tstRighe = Documenti::mittente($tipo ?? 'referto', $medico, $tst);
$tstLogo = $tst['logo_data'] && in_array($tipo ?? 'referto', $tst['logo_su'], true) ? $tst['logo_data'] : null;
if (!$tst['intestazione']) return;
?>
<header class="pos-<?= e($tst['logo_posizione']) ?><?= $tst['bordo'] ? ' bordo' : '' ?>">
  <?php if ($tstLogo && $tst['logo_posizione'] === 'centro'): ?><div class="logo centro"><img src="<?= $tstLogo ?>" alt="" style="height:<?= (int) $tst['logo_altezza'] ?>mm"></div><?php endif; ?>
  <div class="riga">
    <div class="medico">
      <?php if ($tstLogo && $tst['logo_posizione'] === 'sinistra'): ?><img class="logo-inl" src="<?= $tstLogo ?>" alt="" style="height:<?= (int) $tst['logo_altezza'] ?>mm"><?php endif; ?>
      <?php if (!($tstLogo && $tst['logo_solo'])): ?><div class="mitt"><?php foreach ($tstRighe as $i => $r): ?><?= $i === 0 ? '<b>' . e($r) . '</b>' : '<div>' . e($r) . '</div>' ?><?php endforeach; ?></div><?php endif; ?>
    </div>
    <div class="destra">
      <?php if ($tstLogo && $tst['logo_posizione'] === 'destra'): ?><img class="logo-inl" src="<?= $tstLogo ?>" alt="" style="height:<?= (int) $tst['logo_altezza'] ?>mm"><?php endif; ?>
      <?= $destra ?? '' ?>
    </div>
  </div>
</header>
<?php unset($tst, $tstRighe, $tstLogo); ?>
