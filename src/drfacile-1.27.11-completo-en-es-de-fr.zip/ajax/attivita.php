<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'recenti' => fn(array $in) => Attivita::recenti(max(5, min(300, Api::int($in, 'n', 30))), Api::int($in, 'utente_id') ?: null, Api::str($in, 'q')),
    'utenti' => fn() => ['utenti' => Attivita::utenti()],
], 'attivita.leggi');   // il registro è del medico/amministratore (core/permessi.php)
