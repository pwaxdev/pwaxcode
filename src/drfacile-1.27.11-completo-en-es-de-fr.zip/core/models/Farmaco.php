<?php
final class Farmaco extends Model
{
    protected static string $table = 'farmaci';
    protected static array $fillable = ['nome', 'principio', 'confezione', 'posologia', 'preferito'];

    public static function cerca(string $q = ''): array
    {
        if ($q === '') return self::all('1=1', [], 'preferito DESC, nome');
        return self::all('LOWER(nome) LIKE :q OR LOWER(principio) LIKE :q', ['q' => '%' . mb_strtolower($q) . '%'], 'preferito DESC, nome');
    }
}
