<div class="archivi stagger">
  <div class="arch-list" id="archList"></div>
  <div>
    <div class="arch-head" id="archHead"></div>
    <div class="card"><table id="archTable" class="dt" style="width:100%"><thead></thead><tbody></tbody></table></div>
  </div>
</div>
