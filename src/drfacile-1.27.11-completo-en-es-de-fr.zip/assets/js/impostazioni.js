/* Modulo Impostazioni: profilo, studio, preferenze, backup, esportazione, archivio documentale */
DRF.register('impostazioni', (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;

  const st = {};

  /* ---------------- STAMPA dei documenti: riassunto in card + pannello laterale di configurazione */
  const PRESET = { normale: [20, 20, 20, 20], stretto: [12, 12, 12, 12], medio: [25, 20, 25, 20], largo: [30, 30, 30, 30], intestazione: [45, 20, 25, 20] };
  const PRESET_LBL = { normale: DRF.__('Normale'), stretto: DRF.__('Stretto'), medio: DRF.__('Medio'), largo: DRF.__('Largo'), intestazione: DRF.__('Carta intestata'), personalizzato: DRF.__('Personalizzato') };
  const FONT_LBL = { sans: 'Sans (DejaVu)', serif: 'Serif (DejaVu)', mono: 'Monospazio', helvetica: 'Helvetica / Arial', times: 'Times' };
  const pagina = (m, land) => { const w = land ? 60 : 44, h = land ? 44 : 60, k = w / (land ? 297 : 210) * 1.0; return `<span class="stp-page ${land ? 'land' : ''}"><i style="top:${(m[0] * k).toFixed(1)}px;right:${(m[1] * k).toFixed(1)}px;bottom:${(m[2] * k).toFixed(1)}px;left:${(m[3] * k).toFixed(1)}px"></i>${m[0] >= 40 ? `<i style="top:${(m[0] * k * .35).toFixed(1)}px;left:${(m[3] * k).toFixed(1)}px;right:${(m[1] * k).toFixed(1)}px;height:0;border-width:1px 0 0"></i>` : ''}</span>`; };
  function stampaRiass(c) {
    if (!c) return;
    $('#stampaRiass').html([DRF.ui.badge('violet', `${c.formato} ${c.orientamento === 'landscape' ? 'orizzontale' : 'verticale'}`), DRF.ui.badge('gray', `${DRF.__('Margini:')} ${PRESET_LBL[c.preset] || c.preset} (${c.m_sup}/${c.m_des}/${c.m_inf}/${c.m_sin} mm)`), DRF.ui.badge('gray', FONT_LBL[c.font_chiave] || c.font_chiave),
      DRF.ui.badge('mint', DRF.__('Fatture: ') + (c.mittente_fattura === 'studio' ? 'nome dello studio' : c.mittente_fattura === 'professionista' ? 'professionista' : 'entrambi')), DRF.ui.badge('mint', DRF.__('Referti: ') + (c.mittente_clinico === 'studio' ? 'studio' : c.mittente_clinico === 'professionista' ? 'professionista' : 'entrambi')),
      c.logo_data ? `<span class="badge sky"><img src="${c.logo_data}" alt=""> logo ${c.logo_posizione}, ${c.logo_altezza} mm</span>` : DRF.ui.badge('gray', DRF.__('Nessun logo'))].join(' '));
  }
  function stampaCfg() {
    const c = st.stampa; if (!c) return;
    const sel = (name, opts, val) => `<select class="select" name="${name}">${Object.entries(opts).map(([k, v]) => `<option value="${k}" ${k === val ? 'selected' : ''}>${v}</option>`).join('')}</select>`;
    const sw = (name, label, sub, on, bloccato) => `<div class="pref pref-sm ${bloccato ? 'bloccato' : ''}"><div><b>${label}</b>${sub ? `<span>${sub}</span>` : ''}</div><button class="switch ${on ? 'on' : ''}" type="button" ${bloccato ? 'disabled title="Opzione dello Store"' : `data-name="${name}"`}></button>${bloccato ? '' : `<input type="hidden" name="${name}" value="${on ? 1 : 0}">`}</div>`;
    const land = c.orientamento === 'landscape';
    DRF.ui.openSheet(DRF.__('Stampa dei documenti'), `
      <div class="stp">
        <h4>${DRF.__('Modelli di pagina')}</h4>
        <div class="stp-preset">${Object.keys(PRESET).map(k => `<button type="button" data-preset="${k}" class="${c.preset === k ? 'on' : ''}">${pagina(PRESET[k], land)}${PRESET_LBL[k]}</button>`).join('')}<button type="button" data-preset="personalizzato" class="${c.preset === 'personalizzato' ? 'on' : ''}"><span class="stp-page ${land ? 'land' : ''}" style="display:flex;align-items:center;justify-content:center">${I('star', 'fa-solid fa-star')}</span>${DRF.__('Personalizzato')}</button></div>
        <input type="hidden" name="stampa_preset" value="${c.preset}">
        <div class="stp-margini"><div class="field"><label>${DRF.__('Superiore (mm)')}</label><input class="input" name="stampa_m_sup" inputmode="decimal" value="${c.m_sup}"></div><div class="field"><label>${DRF.__('Destro')}</label><input class="input" name="stampa_m_des" inputmode="decimal" value="${c.m_des}"></div><div class="field"><label>${DRF.__('Inferiore')}</label><input class="input" name="stampa_m_inf" inputmode="decimal" value="${c.m_inf}"></div><div class="field"><label>${DRF.__('Sinistro')}</label><input class="input" name="stampa_m_sin" inputmode="decimal" value="${c.m_sin}"></div></div>
        <h4>${DRF.__('Pagina e carattere')}</h4>
        <div class="grid2"><div class="field"><label>${DRF.__('Formato')}</label>${sel('stampa_formato', { A4: 'A4', A5: 'A5', Letter: 'Letter' }, c.formato)}</div><div class="field"><label>${DRF.__('Orientamento')}</label>${sel('stampa_orientamento', { portrait: 'Verticale', landscape: DRF.__('Orizzontale') }, c.orientamento)}</div>
        <div class="field"><label>${DRF.__('Carattere')}</label>${sel('stampa_font', FONT_LBL, c.font_chiave)}</div><div class="field"><label>${DRF.__('Dimensione del testo (px)')}</label>${sel('stampa_corpo', { 11: '11 · compatto', 12: '12', 13: '13 · normale', 14: '14', 15: '15 · grande' }, String(c.corpo))}</div></div>
        <h4>${DRF.__('Intestazione')}</h4>
        <div class="grid2"><div class="field"><label>${DRF.__('Mittente sulle fatture')}</label>${sel('stampa_mittente_fattura', { studio: DRF.__('Nome dello studio'), professionista: DRF.__('Professionista'), entrambi: DRF.__('Entrambi') }, c.mittente_fattura)}</div><div class="field"><label>${DRF.__('Mittente su referti e ricette')}</label>${sel('stampa_mittente_clinico', { professionista: DRF.__('Professionista (chi ha visitato)'), studio: DRF.__('Nome dello studio'), entrambi: DRF.__('Entrambi') }, c.mittente_clinico)}</div></div>
        <div class="stp-logo" id="stpLogo"><div class="stp-logo-img">${c.logo_data ? `<img src="${c.logo_data}" alt="">` : I('picture', 'fa-regular fa-image')}</div><div><b>${DRF.__('Logo o immagine')}</b><div class="small muted">${DRF.__('PNG, JPG, SVG o WebP fino a 1,5 MB. Trascinalo qui o scegli il file.')}</div><div class="row" style="gap:6px;margin-top:8px"><button class="btn ghost sm" type="button" id="stpLogoSel">${I('cloud-upload', 'fa-solid fa-cloud-arrow-up')}${DRF.__('Scegli')}</button>${c.logo ? `<button class="btn ghost sm" type="button" id="stpLogoDel" style="color:var(--red-ink)">${I('trash', 'fa-solid fa-trash')}${DRF.__('Rimuovi')}</button>` : ''}<input type="file" hidden id="stpLogoIn" accept=".png,.jpg,.jpeg,.svg,.webp"></div></div></div>
        <div class="grid2"><div class="field"><label>${DRF.__('Posizione del logo')}</label>${sel('stampa_logo_posizione', { sinistra: 'A sinistra, sopra il mittente', centro: DRF.__('Centrato, sopra tutto'), destra: 'A destra' }, c.logo_posizione)}</div><div class="field"><label>${DRF.__('Altezza del logo (mm)')}</label>${sel('stampa_logo_altezza', { 10: '10', 14: '14', 18: '18', 22: '22', 28: '28', 35: '35', 45: '45' }, String(c.logo_altezza))}</div></div>
        <div class="field"><label>${DRF.__('Logo su')}</label><div class="stp-chk">${['referto', 'fattura', 'ricetta', 'documento'].map(t => `<label><input type="checkbox" data-logo-su="${t}" ${c.logo_su.includes(t) ? 'checked' : ''}> ${t.charAt(0).toUpperCase() + t.slice(1)}</label>`).join('')}</div><input type="hidden" name="stampa_logo_su" value="${c.logo_su.join(',')}"></div>
        ${sw('stampa_logo_solo', DRF.__('Solo il logo, senza testo del mittente'), DRF.__('Per la carta intestata già stampata con i dati dello studio'), c.logo_solo)}
        ${sw('stampa_intestazione', DRF.__('Stampa l\'intestazione'), DRF.__('Disattivala se usi carta prestampata (scegli il modello "Carta intestata")'), c.intestazione)}
        ${sw('stampa_bordo', 'Riga colorata sotto l\'intestazione', '', c.bordo)}
        <div class="field"><label>${DRF.__('Colore degli accenti')}</label><div class="stp-colore"><input type="color" name="stampa_colore" value="${c.colore}"><span class="small muted">${DRF.__('Riga dell\'intestazione, totale fattura, firma')}</span></div></div>
        <h4>${DRF.__('Piè di pagina')}</h4>
        ${sw('stampa_piede', DRF.__('Stampa il piè di pagina'), DRF.__('Sempre in fondo alla pagina, su ogni pagina'), c.piede)}
        <div class="field"><label>${DRF.__('Testo aggiuntivo')}</label><textarea class="input" name="stampa_piede_testo" rows="2" placeholder="${DRF.__('Es. Orari di apertura, IBAN, note legali…')}">${DRF.esc(c.piede_testo)}</textarea></div>
        ${sw('stampa_piede_pagine', DRF.__('Numero di pagina ("Pagina 1 di 2")'), '', c.piede_pagine)}
        ${sw('stampa_piede_generato', '"Documento generato con DRFacile"', c.marchio_bloccato ? DRF.__('Si può togliere con l\'opzione "Documenti senza firma DRFacile" dello Store') : '', c.piede_generato, c.marchio_bloccato)}
        <div class="row" style="gap:8px"><button class="btn ghost" type="button" data-doc="prova" data-id="0">${I('eye', 'fa-regular fa-eye')}<span>${DRF.__('Prova di stampa')}</span></button><span class="small muted">${DRF.__('Salva prima, poi guarda la prova.')}</span></div>
      </div>`, () => {
        const $b = $('#sheetBody'), dati = {};
        $b.find('[name]').each(function () { dati[this.name] = this.type === 'checkbox' ? (this.checked ? 1 : 0) : $(this).val(); });
        DRF.api.post('impostazioni', 'save', dati).then(() => { DRF.ui.toast(DRF.__('Impostazioni di stampa salvate'), 'success'); DRF.ui.closeSheet(); load(); });
        return false;
      }, DRF.__('Salva'));
    $('#sheet').addClass('wide');
    const $b = $('#sheetBody');
    const applica = k => { const land = $b.find('[name=stampa_orientamento]').val() === 'landscape'; $b.find('[data-preset]').removeClass('on').filter(`[data-preset="${k}"]`).addClass('on'); $b.find('[name=stampa_preset]').val(k); if (PRESET[k]) ['sup', 'des', 'inf', 'sin'].forEach((m, i) => $b.find(`[name=stampa_m_${m}]`).val(PRESET[k][i])); $b.find('.stp-margini .input').prop('readonly', k !== 'personalizzato'); $b.find('[data-preset]').each(function () { const p = PRESET[this.dataset.preset]; if (p) $(this).find('.stp-page').replaceWith(pagina(p, land)); }); };
    applica(c.preset);
    $b.on('click', '[data-preset]', function () { applica(this.dataset.preset); });
    $b.on('change', '[name=stampa_orientamento]', () => applica($b.find('[name=stampa_preset]').val()));
    $b.on('change', '[data-logo-su]', () => $b.find('[name=stampa_logo_su]').val($b.find('[data-logo-su]:checked').map(function () { return this.dataset.logoSu; }).get().join(',')));
    $b.on('click', '.switch[data-name]', function () { $(this).toggleClass('on'); $(this).siblings('input[name]').val($(this).hasClass('on') ? '1' : '0'); });
    const logo = f => { if (!f) return; const fd = new FormData(); fd.append('logo', f); DRF.api.post('impostazioni', 'logo', fd).then(r => { st.stampa = r.stampa; DRF.ui.toast(r.messaggio, 'success'); stampaRiass(r.stampa); $('#stpLogo .stp-logo-img').html(`<img src="${r.stampa.logo_data}" alt="">`); if (!$('#stpLogoDel').length) $('#stpLogoSel').after(`<button class="btn ghost sm" type="button" id="stpLogoDel" style="color:var(--red-ink)">${I('trash', 'fa-solid fa-trash')}${DRF.__('Rimuovi')}</button>`); DRF.icons.apply($('#stpLogo')[0]); }); };
    $b.on('click', '#stpLogoSel', () => $('#stpLogoIn').trigger('click'));
    $b.on('change', '#stpLogoIn', function () { logo(this.files[0]); this.value = ''; });
    $b.on('click', '#stpLogoDel', () => DRF.api.post('impostazioni', 'logo_rimuovi').then(r => { st.stampa = r.stampa; DRF.ui.toast(r.messaggio); stampaRiass(r.stampa); $('#stpLogo .stp-logo-img').html(I('picture', 'fa-regular fa-image')); $('#stpLogoDel').remove(); DRF.icons.apply($('#stpLogo')[0]); }));
    $b.on('dragover', '#stpLogo', e => { e.preventDefault(); $('#stpLogo').addClass('over'); }).on('dragleave drop', '#stpLogo', () => $('#stpLogo').removeClass('over')).on('drop', '#stpLogo', e => { const f = e.originalEvent.dataTransfer.files[0]; if (f) { e.preventDefault(); logo(f); } });
  }

  function load() {
    return DRF.api.get('impostazioni', 'get').then(d => {
      const s = d.impostazioni;
      st.formati = d.formati_export || [];
      st.stampa = d.stampa || null; stampaRiass(st.stampa);
      if (d.lingue) { const $l = $('#setLingua'); if ($l.data('select2')) $l.select2('destroy'); $l.html(Object.entries(d.lingue).map(([k, v]) => `<option value="${k}" ${k === d.lingua ? 'selected' : ''}>${DRF.esc(v)}</option>`).join('')); DRF.ui.select($l, { minimumResultsForSearch: Infinity }); }
      if (d.sms) { const s = d.sms; $('#smsStato').html(s.attivo ? `${DRF.ui.badge(s.credito > 50 ? 'mint' : s.credito > 0 ? 'amber' : 'rose', s.credito + ' SMS disponibili')} ${s.driver === 'log' ? DRF.ui.badge('gray', DRF.__('invio simulato (driver log)')) : ''}${s.problemi.filter(p => !p.startsWith('Credito')).map(p => ' ' + DRF.ui.badge('amber', p)).join('')}` : DRF.ui.badge('gray', DRF.__('Servizio non attivo')) + ' <span class="small muted">' + DRF.__('Attivalo dallo Store per inviare promemoria via SMS.') + '</span>'); }
      if (d.spazio) { const s = d.spazio; $('#cardSpazio .spazio-bar i').css('width', Math.max(s.uso > 0 ? 1 : 0, s.percentuale) + '%').toggleClass('pieno', s.percentuale >= 90).toggleClass('poco', s.uso > 0 && s.percentuale < 2); $('#spazioUso').text(s.uso_umano + (s.quota_mb ? ' · ' + s.percentuale + '%' : '')); $('#spazioQuota').text(s.quota_mb ? 'su ' + s.quota_umano : 'spazio illimitato'); }   // formati di esportazione: json del core + quelli delle estensioni (hook export.formati)
      $('.settings [name]').each(function () { if (s[this.name] != null) DRF.ui.setVal($(this), s[this.name]); });
      $('.settings .switch[data-pref]').each(function () { $(this).toggleClass('on', s[this.dataset.pref] === '1'); });
      $('.settings .switch[data-name]').each(function () { $(this).toggleClass('on', s[this.dataset.name] === '1'); });
      $('.settings .switch[data-name]').each(function () { const on = s[this.dataset.name] === '1'; $(this).toggleClass('on', on); $(this).siblings(`input[name="${this.dataset.name}"]`).val(on ? '1' : '0'); });
      // punto di aggancio per le estensioni: i loro pannelli (hook PHP impostazioni.pannelli) sono già in pagina e riempiti
      DRF.hooks.run('impostazioni.pronto', { $root: $('[data-panel="impostazioni"] .settings'), impostazioni: s, pannello: k => $(`.settings [data-ext="${k}"]`) });
      $('.settings .switch[data-name]').each(function () { $(this).toggleClass('on', s[this.dataset.name] === '1'); $(this).siblings(`input[name="${this.dataset.name}"]`).val(s[this.dataset.name] === '1' ? '1' : '0'); });
      $('.settings select[data-pref]').each(function () { if (s[this.dataset.pref]) $(this).val(s[this.dataset.pref]).trigger('change.select2'); });
      $('#prefTheme').toggleClass('on', document.documentElement.dataset.theme === 'dark');
      const pn = d.fattura_prossimo_calcolato || {};
      const anteprima = () => {
        let fmt = String(DRF.ui.val($('.settings [name=fattura_formato]')) || '').trim() || '{aaaa}/{nnn}';
        if (!fmt.includes('{n}') && !fmt.includes('{nnn}')) fmt = '{aaaa}/{nnn}';
        const forz = parseInt(String(DRF.ui.val($('.settings [name=fattura_prossimo]')) || '').replace(',', '.'), 10) || 0;
        const prog = Math.max(+pn.progressivo || 1, forz);
        $('#fmtAnteprima').text(fmt.replaceAll('{nnn}', String(prog).padStart(3, '0')).replaceAll('{n}', String(prog)).replaceAll('{aaaa}', String(pn.anno || new Date().getFullYear())).replaceAll('{aa}', String(pn.anno || new Date().getFullYear()).slice(-2)).slice(0, 20));
      };
      $('.settings [name=fattura_formato], .settings [name=fattura_prossimo]').off('input.num').on('input.num', anteprima);
      if (!DRF.ui.val($('.settings [name=fattura_prossimo]'))) DRF.ui.setVal($('.settings [name=fattura_prossimo]'), '');
      anteprima();
      $('#backupInfo').html(s.backup_ultimo ? `${DRF.__('Ultimo backup:')} <b>${DRF.esc(s.backup_ultimo)}</b> ${DRF.__('· archivio SQLite locale · copie in')} <span class="mono">docs/backup</span>` : DRF.__('Nessun backup ancora eseguito. Le copie vengono salvate in') + ' <span class="mono">docs/backup</span>.');
      $('#archivio').html(d.archivio.map(a => `<a href="#" data-doc="file" data-file="${DRF.esc(a.file)}">${I('document', 'fa-regular fa-file-lines')}<span>${DRF.esc(a.file.split('/').pop())}</span><small>${DRF.esc(a.modificato)}</small></a>`).join('') || '<span class="muted small">' + DRF.__('Nessun documento archiviato: referti firmati, ricette e fatture verranno salvati qui.') + '</span>');
      DRF.icons.apply($('#archivio')[0]);
    });
  }
  function salvaPref(k, v) { DRF.api.post('impostazioni', 'save', { [k]: v }).then(() => { DRF.ui.toast(DRF.__('Preferenza salvata')); if (k === 'pref_suoni') DRF.config.pref.suoni = v === '1'; if (k === 'pref_durata') DRF.config.pref.durata = v; if (k === 'pref_prezzi_visita') DRF.config.pref.prezzi_visita = v === '1'; }); }

  /* --- avatar: anteprima, drag&drop e crop quadrato su canvas --- */
  function avaPreview() {
    const u = DRF.config.utente || {};
    $('#avaCur').html(u.avatar ? `<img src="${u.avatar}">` : DRF.ui.avatar(u.nome_completo || 'Dr'));
    $('#avaDel').prop('hidden', !u.avatar);
  }
  function avaCrop(file) {
    if (!file || !/^image\//.test(file.type)) return DRF.ui.toast('Scegli un\'immagine', 'warn');
    const rd = new FileReader();
    rd.onload = () => {
      const img = new Image();
      img.onload = () => {
        const VIS = 280, OUT = 256;
        const min = VIS / Math.min(img.width, img.height);   // copre sempre il riquadro
        let scala = min, x = (VIS - img.width * scala) / 2, y = (VIS - img.height * scala) / 2, drag = null;
        DRF.ui.modal({ title: DRF.__('Ritaglia la foto'), ok: DRF.__('Usa questa foto'), cancel: DRF.__('Annulla'),
          html: `<div class="ava-crop"><canvas id="avaCv" width="${VIS}" height="${VIS}"></canvas><div class="ava-zoom">${DRF.icons.html('picture', 'fa-regular fa-image')}<input type="range" id="avaZoom" min="100" max="300" value="100">${DRF.icons.html('zoom-in', 'fa-solid fa-magnifying-glass-plus')}</div><p class="small muted" style="text-align:center;margin-top:8px">${DRF.__('Trascina per inquadrare, usa il cursore per lo zoom')}</p></div>`,
          onOpen($b) {
            const cv = $b.find('#avaCv')[0], cx = cv.getContext('2d');
            const clamp = () => { x = Math.min(0, Math.max(VIS - img.width * scala, x)); y = Math.min(0, Math.max(VIS - img.height * scala, y)); };
            const draw = () => { clamp(); cx.fillStyle = '#fff'; cx.fillRect(0, 0, VIS, VIS); cx.drawImage(img, x, y, img.width * scala, img.height * scala); };
            draw();
            cv.addEventListener('pointerdown', e => { drag = { x: e.clientX - x, y: e.clientY - y }; cv.setPointerCapture(e.pointerId); });
            cv.addEventListener('pointermove', e => { if (drag) { x = e.clientX - drag.x; y = e.clientY - drag.y; draw(); } });
            cv.addEventListener('pointerup', () => drag = null);
            $b.find('#avaZoom').on('input', function () {
              const nuova = min * this.value / 100, cxm = VIS / 2, cym = VIS / 2;
              x = cxm - (cxm - x) * nuova / scala; y = cym - (cym - y) * nuova / scala; scala = nuova; draw();
            });
            $b.data('crop', () => { const out = document.createElement('canvas'); out.width = out.height = OUT; out.getContext('2d').drawImage(cv, 0, 0, VIS, VIS, 0, 0, OUT, OUT); return out.toDataURL('image/png'); });
          },
          onOk($b) {
            DRF.api.post('avatar', 'salva', { img: $b.data('crop')() }).then(r => {
              DRF.config.utente.avatar = r.url;
              avaPreview();
              $('#avatarBtn').contents().filter(function () { return this.nodeType === 3; }).remove();
              $('#avatarBtn img').remove(); $('#avatarBtn').prepend(`<img src="${r.url}">`);
              DRF.ui.toast(DRF.__('Foto del profilo aggiornata'), 'success');
            });
            return false;
          } });
      };
      img.src = rd.result;
    };
    rd.readAsDataURL(file);
  }

  /* --- utenti dello studio (tabella comune) --- */
  function utLista() {
    DRF.api.get('utenti', 'lista').then(d => {
      $('#utList').html(d.utenti.map(u => `
        <div class="ut-row ${+u.attivo ? '' : 'off'}" data-id="${u.id}">
          ${DRF.ui.avatar((u.nome || '') + ' ' + (u.cognome || ''))}
          <div class="ut-mid"><b>${DRF.esc(((u.cognome || '') + ' ' + (u.nome || '')).trim() || u.username)}${+u.id === +d.io ? ' <span class="badge gray" style="font-size:10px">tu</span>' : ''}</b>
          <span class="mono">${DRF.esc(u.username)}</span></div>
          ${DRF.ui.badge(u.ruolo === 'medico' ? 'violet' : u.ruolo === 'commercialista' ? 'mint' : 'gray', { medico: DRF.__('Medico'), segreteria: DRF.__('Segreteria'), commercialista: DRF.__('Commercialista') }[u.ruolo] || u.ruolo)}${+u.admin ? ' ' + DRF.ui.badge('amber', DRF.__('Amministratore')) : ''}
          <button class="icon-btn sm" data-ut-mod="${u.id}" title="${DRF.__('Modifica')}">${DRF.icons.html('pencil', 'fa-solid fa-pen')}</button>
          <button class="icon-btn sm" data-ut-stato="${u.id}" title="${+u.attivo ? DRF.__('Disattiva') : DRF.__('Riattiva')}">${DRF.icons.html(+u.attivo ? 'ban' : 'check', +u.attivo ? 'fa-solid fa-ban' : 'fa-solid fa-check')}</button>
        </div>`).join(''));
      DRF.icons.apply($('#utList')[0]);
      $('#utList').data('utenti', d.utenti).data('ruoli', d.ruoli);
    });
  }
  function utForm(u) {
    u = u || {};
    DRF.api.get('utenti', 'lista').then(d => { $('#utList').data('ruoli', d.ruoli); apriUtForm(u); });
  }
  function apriUtForm(u) {
    DRF.ui.modal({ title: u.id ? DRF.__('Modifica utente') : DRF.__('Nuovo utente'), ok: u.id ? DRF.__('Salva') : DRF.__('Crea utente'), cancel: DRF.__('Annulla'),
      html: `<div class="grid2"><div class="field"><label>${DRF.__('Cognome')}</label><input class="input" id="utCog" value="${DRF.esc(u.cognome || '')}"></div><div class="field"><label>${DRF.__('Nome')}</label><input class="input" id="utNom" value="${DRF.esc(u.nome || '')}"></div></div>
        <div class="grid2"><div class="field"><label>${DRF.__('Nome utente')}</label><input class="input mono" id="utUser" value="${DRF.esc(u.username || '')}" autocomplete="off"></div><div class="field"><label>${DRF.__('Ruolo')}</label><select class="select" id="utRuolo">${(($('#utList').data('ruoli')) || ['medico', 'segreteria']).map(r => `<option value="${r}" ${u.ruolo === r || (!u.ruolo && r === 'medico') ? 'selected' : ''}>${{ medico: DRF.__('Medico'), segreteria: DRF.__('Segreteria'), commercialista: DRF.__('Commercialista') }[r] || r}</option>`).join('')}</select></div></div>
        <div class="grid2"><div class="field"><label>${DRF.__('Email')}</label><input class="input" id="utEmail" value="${DRF.esc(u.email || '')}"></div><div class="field"><label>${DRF.__('Telefono')}</label><input class="input" id="utTel" value="${DRF.esc(u.telefono || '')}"></div></div>
        <div class="grid2"><div class="field"><label>${u.id ? `${DRF.__('Nuova password')} <span class="hint-ico" title="${DRF.__('Vuota = invariata')}">${DRF.icons.html('info', 'fa-solid fa-circle-info')}</span>` : DRF.__('Password (min 8 caratteri)')}</label><input class="input" id="utPwd" type="password" autocomplete="new-password"></div><div class="field"><label>${DRF.__('Sesso')}</label><select class="select" id="utSesso"><option value="F" ${u.sesso !== 'M' ? 'selected' : ''}>${DRF.__('Dottoressa / Sig.ra')}</option><option value="M" ${u.sesso === 'M' ? 'selected' : ''}>${DRF.__('Dottore / Sig.')}</option></select></div></div>
        <label class="row" style="gap:8px;align-items:center;margin-top:4px"><input type="checkbox" id="utAdmin" ${+u.admin ? 'checked' : ''} ${u.id && +u.id === +((DRF.config.utente || {}).id) ? 'disabled' : ''}> <span>${DRF.__('Amministratore dello studio')} <span class="small muted">${DRF.__('(gestisce utenti e Negozio; il ruolo decide il resto)')}</span></span></label>
        <p class="small muted">${DRF.__('Email e telefono servono anche per il recupero della password.')}</p>`,
      onOk($b) {
        DRF.api.post('utenti', 'salva', { id: u.id || null, cognome: $b.find('#utCog').val(), nome: $b.find('#utNom').val(), username: $b.find('#utUser').val(), ruolo: $b.find('#utRuolo').val(), email: $b.find('#utEmail').val(), telefono: $b.find('#utTel').val(), password: $b.find('#utPwd').val(), sesso: $b.find('#utSesso').val(), admin: $b.find('#utAdmin').is(':checked') ? 1 : 0 })
          .then(r => { DRF.ui.toast(r.messaggio, 'success'); DRF.ui.closeModal(); utLista(); });
        return false;
      } });
  }

  function registroComunicazioni() {
    DRF.api.get('comunicazioni', 'registro').then(d => {
      Object.entries(d.driver).forEach(([k, v]) => $(`[data-drv="${k}"]`).text(v));
      const STATO = { log: ['gray', DRF.__('Solo registro')], inviata: ['mint', 'Inviata'], errore: ['rose', 'Errore'] };
      DRF.ui.modal({ title: DRF.__('Registro comunicazioni'), size: 'xl', ok: false, cancel: DRF.__('Chiudi'),
        html: '<table id="comTable" class="dt" style="width:100%"><thead><tr><th>' + DRF.__('Quando') + '</th><th>' + DRF.__('Canale') + '</th><th>' + DRF.__('Destinatario') + '</th><th>' + DRF.__('Oggetto') + '</th><th>' + DRF.__('Stato') + '</th></tr></thead><tbody></tbody></table>',
        onOpen($b) {
          DRF.ui.datatable($b.find('#comTable'), { data: d.comunicazioni, order: [[0, 'desc']], pageLength: 10, columns: [
            { data: 'creato_il', render: (v, t) => t === 'display' ? `<span class="num">${DRF.util.fmtDateTime(v)}</span>` : v },
            { data: 'canale', render: v => DRF.esc(v) },
            { data: 'destinatario', render: v => `<span class="mono">${DRF.esc(v)}</span>` },
            { data: 'oggetto', render: (v, t, r) => `${DRF.esc(v || '—')}${r.rif ? `<div class="small muted">${DRF.esc(r.rif)}</div>` : ''}` },
            { data: 'stato', render: (v, t, r) => { const [c, l] = STATO[v] || ['gray', v]; return DRF.ui.badge(c, l) + (r.errore ? `<div class="small muted">${DRF.esc(r.errore)}</div>` : ''); } },
          ] });
        } });
    });
  }

  return {
    title: DRF.__('Impostazioni'), sub: DRF.__('Profilo, studio e preferenze'), action: null,
    init() {
      // permessi (core/permessi.php): il server rifiuta comunque, qui si tolgono solo i pulsanti inutili
      if (!DRF.can('impostazioni.modifica')) $('[data-panel="impostazioni"] [data-save]').remove();
      if (!DRF.can('impostazioni.backup')) $('#btnBackup, #btnExport, #btnImportIgea, #btnResetDemo').remove();

      $(document).on('click', '#setRegistroCom', registroComunicazioni);
      $('#btnStampaCfg').on('click', stampaCfg);
      // I miei dati (self-service di ogni utente)
      const miei = () => DRF.api.get('utenti', 'me').then(d => { const u = d.utente; $('#mieiNome').val(u.nome); $('#mieiCognome').val(u.cognome); $('#mieiEmail').val(u.email); $('#mieiTelefono').val(u.telefono); $('#mieiPwd, #mieiPwdAttuale').val(''); });
      if ($('#mieiNome').length) miei();
      $('#mieiSalva').on('click', () => DRF.api.post('utenti', 'salva_me', { nome: $('#mieiNome').val(), cognome: $('#mieiCognome').val(), email: $('#mieiEmail').val(), telefono: $('#mieiTelefono').val(), password: $('#mieiPwd').val(), password_attuale: $('#mieiPwdAttuale').val() }).then(r => { DRF.ui.toast(r.messaggio, 'success'); miei(); }));
      $(document).on('change', '#setLingua', function () { DRF.api.post('impostazioni', 'lingua', { lingua: this.value }).then(r => { DRF.ui.toast(r.messaggio, 'success'); setTimeout(() => location.reload(), 700); }); });
      $('#btnExport').on('click', function (e) {   // più formati (estensioni) → menu di scelta
        if ((st.formati || []).length <= 1) return;
        e.preventDefault();
        DRF.menu.showAt($(this), st.formati.map(f => ({ label: f.label, fi: 'download', fa: 'fa-solid fa-download', run: () => { location.href = 'ajax/impostazioni.php?action=export&formato=' + encodeURIComponent(f.chiave); } })), { title: DRF.__('Esporta come') });
      });
      $(document).on('click', '#utNuovo', () => utForm(null));
      $(document).on('click', '[data-ut-mod]', function () { const u = ($('#utList').data('utenti') || []).find(x => +x.id === +this.dataset.utMod); utForm(u); });
      $(document).on('click', '[data-ut-stato]', function () { DRF.api.post('utenti', 'stato', { id: +this.dataset.utStato }).then(() => utLista()); });
      $(document).on('click', '#avaDrop, #avaCur', () => $('#avaFile').trigger('click'));
      $(document).on('change', '#avaFile', function () { avaCrop(this.files[0]); this.value = ''; });
      $(document).on('dragover', '#avaDrop', e => { e.preventDefault(); $(e.currentTarget).addClass('over'); });
      $(document).on('dragleave drop', '#avaDrop', e => { e.preventDefault(); $(e.currentTarget).removeClass('over'); });
      $(document).on('drop', '#avaDrop', e => { const f = e.originalEvent.dataTransfer.files[0]; avaCrop(f); });
      $(document).on('click', '#avaDel', e => { e.stopPropagation(); DRF.ui.confirm(DRF.__('Rimuovere la foto del profilo?'), DRF.__('Tornano le iniziali.'), DRF.__('Rimuovi')).then(ok => { if (ok) DRF.api.post('avatar', 'rimuovi').then(() => { DRF.config.utente.avatar = null; avaPreview(); $('#avatarBtn img').remove(); $('#avatarBtn').prepend(document.createTextNode(DRF.config.utente.iniziali || '')); DRF.ui.toast(DRF.__('Foto rimossa')); }); }); });
      $('.settings [name=profilo_sesso]').on('change', function () {
        const $t = $('.settings [name=profilo_titolo]'), t = String(DRF.ui.val($t) || '').trim();
        if (this.value === 'M' && /^dr\.?\s*ssa$|^dott\.?\s*ssa$|^dottoressa$/i.test(t)) DRF.ui.setVal($t, t.toLowerCase().startsWith('dott') ? 'Dott.' : 'Dr.');
        if (this.value === 'F' && /^dr\.?$|^dott\.?$|^dottore$/i.test(t)) DRF.ui.setVal($t, t.toLowerCase().startsWith('dott') ? 'Dott.ssa' : 'Dr.ssa');
      });
      $('.settings [data-save]').on('click', function () {
        const $card = $(this).closest('[data-form]');
        DRF.api.post('impostazioni', 'save', DRF.ui.formData($card)).then(r => { DRF.ui.toast(r.messaggio); DRF.config.medico = r.medico; if (!$('#avatarBtn img').length) $('#avatarBtn').contents().filter(function () { return this.nodeType === 3; }).first().replaceWith(r.medico.iniziali); });   // con la foto restano l'immagine e basta
      });
      $('.settings .switch[data-pref]').on('click', function () { $(this).toggleClass('on'); salvaPref(this.dataset.pref, $(this).hasClass('on') ? '1' : '0'); });
      $('.settings .switch[data-name]').on('click', function () { $(this).toggleClass('on'); $(this).siblings(`input[name="${this.dataset.name}"]`).val($(this).hasClass('on') ? '1' : '0'); });
      $('.settings').on('click', '.switch[data-name]', function () { const on = $(this).toggleClass('on').hasClass('on'); $(this).siblings(`input[name="${this.dataset.name}"]`).val(on ? '1' : '0'); });
      $('.settings .switch[data-name]').on('click', function () { $(this).toggleClass('on'); $(this).siblings(`input[name="${this.dataset.name}"]`).val($(this).hasClass('on') ? '1' : '0'); });
      $('.settings select[data-pref]').on('change', function () { salvaPref(this.dataset.pref, this.value); });
      $('#prefTheme').on('click', () => $('#themeBtn').trigger('click'));
      $('#numSblocca').on('click', function () {
        DRF.ui.confirm(DRF.__('Sbloccare la numerazione?'), DRF.__('Cambiare il progressivo può creare buchi o duplicati nella numerazione: fallo solo se sai cosa stai facendo (es. primo avvio con numerazione già iniziata altrove).'), DRF.__('Sblocca'), 'warn')
          .then(ok => { if (ok) { $('.settings [name=fattura_prossimo]').prop('disabled', false).trigger('focus'); $(this).prop('disabled', true); } });
      });
      $('#btnBackup').on('click', function () { $(this).prop('disabled', true); DRF.api.post('impostazioni', 'backup').then(r => { DRF.ui.toast(r.messaggio); load(); }).always(() => $(this).prop('disabled', false)); });
      $('#btnImportIgea').on('click', () => DRF.ui.toast('Importazione da Igea: la procedura guidata verrà collegata all\'export di Igea', 'info'));
      $('#btnResetDemo').on('click', () => DRF.ui.confirm(DRF.__('Ripristinare i dati dimostrativi?'), DRF.__('Tutti i dati attuali verranno cancellati e sostituiti con l\'archivio demo.'), DRF.__('Ripristina')).then(ok => { if (ok) DRF.api.post('impostazioni', 'reset_demo').then(r => { DRF.ui.toast(r.messaggio); setTimeout(() => location.reload(), 800); }); }));
    },
    show() { load(); avaPreview(); if ($('#utList').length) utLista(); DRF.api.get('comunicazioni', 'registro').then(d => Object.entries(d.driver).forEach(([k, v]) => $(`[data-drv="${k}"]`).text(v))); }
  };
})(jQuery));
