<?php
/**
 * TENANT RESOLVER (SaaS): dall'utente collegato al database del suo studio.
 *
 *   utente (sessione) → studio_id → riga `studi` → colonna `database` (JSON) → Database::tenant()
 *
 * La colonna `studi.database` è OPZIONALE: vuota = lo studio vive nel database base di config.php
 * (installazione monostudio, o il primo studio migrato dal monoutente). Solo gli studi con un database
 * dedicato — creati con `php strumenti/studio.php crea …` — cambiano connessione dopo il login.
 *
 * Il bootstrap chiama Tenant::risolvi() dopo la sessione e PRIMA di tutto ciò che tocca le tabelle dello studio
 * (installer, estensioni, scadenzario), così ogni richiesta lavora sul database giusto.
 * Da riga di comando: DRF_STUDIO=3 php strumenti/estensione.php … seleziona lo studio 3.
 */
final class Tenant
{
    private static ?array $studio = null;

    /** Risolve e attiva il database dello studio della richiesta corrente. Ritorna la riga dello studio (o null = base) */
    public static function risolvi(): ?array
    {
        $id = 0;
        if (PHP_SAPI === 'cli') $id = (int) (getenv('DRF_STUDIO') ?: 0);
        elseif (session_status() === PHP_SESSION_ACTIVE) $id = (int) ($_SESSION['drf_user']['studio_id'] ?? 0);
        if (!$id) return null;
        return self::attiva($id);
    }

    /** Attiva esplicitamente uno studio (usato anche dalle pagine pubbliche con ?s=ID e dagli strumenti CLI) */
    public static function attiva(int $id): ?array
    {
        $s = null;
        try { $s = Utente::studio($id); } catch (Throwable $e) { /* comune non pronto */ }
        if (!$s) return null;
        self::$studio = $s;
        $cfg = self::configDb($s);
        if ($cfg) {
            Database::tenant($id, $cfg);
            Impostazione::reset();
            Estensioni::reset();
        }
        return $s;
    }

    /** La configurazione db della riga studi (JSON in `database`), o null se lo studio usa il database base */
    public static function configDb(array $studio): ?array
    {
        $raw = trim((string) ($studio['database'] ?? ''));
        if ($raw === '') return null;
        $cfg = json_decode($raw, true);
        if (!is_array($cfg) || empty($cfg['driver'])) { error_log("Studio {$studio['id']}: colonna database non valida"); return null; }
        if ($cfg['driver'] === 'sqlite' && empty($cfg['sqlite'])) return null;
        if ($cfg['driver'] === 'mysql' && empty($cfg['mysql']['dsn'])) return null;
        return $cfg;
    }

    /** Lo studio attivo (null = database base) */
    public static function studio(): ?array { return self::$studio; }

    /** Vero se la richiesta lavora sul database base (nessun tenant dedicato attivo) */
    public static function base(): bool { return Database::tenantId() === null; }
}
