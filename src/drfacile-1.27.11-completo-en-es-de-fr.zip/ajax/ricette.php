<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'dati'    => fn() => ['farmaci' => Farmaco::cerca(), 'pazienti' => Paziente::options(), 'esenzioni' => Database::all('SELECT codice, descrizione FROM esenzioni ORDER BY codice'), 'recenti' => Ricetta::recenti(), 'totale' => Ricetta::count()],
    'farmaci' => fn(array $in) => Farmaco::cerca(Api::str($in, 'q')),
    'invia'   => function (array $in) { $r = Ricetta::emetti($in); return ['ricetta' => $r, 'recenti' => Ricetta::recenti(), 'totale' => Ricetta::count()]; },
    'get'     => fn(array $in) => Ricetta::find(Api::int($in, 'id')) ?? throw new ApiException(__('Ricetta non trovata'), 404),
], ['*' => 'ricette.leggi', 'invia' => 'ricette.emetti']);
