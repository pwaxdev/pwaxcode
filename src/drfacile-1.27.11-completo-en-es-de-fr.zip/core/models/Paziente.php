<?php
final class Paziente extends Model
{
    protected static string $table = 'pazienti';
    protected static array $fillable = ['nome', 'cognome', 'nascita', 'sesso', 'cf', 'telefono', 'cellulare', 'email', 'pec', 'indirizzo', 'cap', 'citta', 'provincia', 'comune_nascita', 'cod_nascita', 'piva', 'professione', 'inviato_da', 'provenienza', 'rappresentato', 'rapp_nome', 'rapp_cf', 'rapp_telefono', 'allergie', 'note', 'dati', 'ultima_visita'];
    protected static array $json = ['allergie', 'dati'];

    /** Aggiunge i campi calcolati usati dall'interfaccia */
    public static function decode(array $row): array
    {
        $row = parent::decode($row);
        $row['nome_completo'] = nome_completo($row);
        $row['eta'] = eta($row['nascita'] ?? null);
        $row['iniziali'] = iniziali($row['nome_completo']);
        return $row;
    }

    public static function cerca(string $q = '', string $filtro = 'tutti'): array
    {
        $where = ['1=1']; $p = [];
        if ($q !== '') {
            $nc = Database::concat('nome', "' '", 'cognome'); $cn = Database::concat('cognome', "' '", 'nome');
            $where[] = "(LOWER($nc) LIKE :q OR LOWER($cn) LIKE :q OR LOWER(cf) LIKE :q OR telefono LIKE :q OR cellulare LIKE :q)";
            $p['q'] = '%' . mb_strtolower($q) . '%';
        }
        if ($filtro === 'recenti') { $where[] = 'ultima_visita >= :da'; $p['da'] = date('Y-m-d', strtotime('-30 days')); }
        if ($filtro === 'allergie') { $where[] = "allergie IS NOT NULL AND allergie <> '[]' AND allergie <> ''"; }
        $rows = self::all(implode(' AND ', $where), $p, 'cognome, nome');
        // privacy firmata e non scaduta (registro consensi)
        $ok = [];
        foreach (Database::all("SELECT paziente_id FROM consensi WHERE tipo = 'Privacy' AND firmato = 1 AND (scadenza IS NULL OR scadenza = '' OR scadenza >= ?)", [oggi()]) as $c) $ok[(int) $c['paziente_id']] = true;
        foreach ($rows as &$r) $r['privacy_ok'] = isset($ok[(int) $r['id']]);
        return $rows;
    }

    /** Elimina il paziente e tutto ciò che gli appartiene (esplicito, così vale anche senza chiavi esterne) */
    public static function delete(int $id): bool
    {
        return Database::transaction(function () use ($id) {
            foreach (['storico', 'ricette', 'referti', 'visite', 'appuntamenti'] as $t) Database::delete($t, 'paziente_id = ?', [$id]);
            return parent::delete($id);
        });
    }

    /** [{id, nome_completo}] per le select */
    public static function options(): array
    {
        return array_map(fn($r) => ['id' => (int) $r['id'], 'nome_completo' => nome_completo($r)], Database::all('SELECT id, nome, cognome FROM pazienti ORDER BY cognome, nome'));
    }

    /** [id => nome_completo] per il FormBuilder */
    public static function optionsMap(): array
    {
        $m = [];
        foreach (self::options() as $o) $m[$o['id']] = $o['nome_completo'];
        return $m;
    }

    /** Salvataggio dal form: normalizza i campi e verifica il codice fiscale */
    public static function salvaDaForm(array $in): int
    {
        Api::require($in, ['nome', 'cognome'], ['nome' => 'Nome', 'cognome' => 'Cognome']);
        $t = fn(string $k) => trim((string) ($in[$k] ?? '')) ?: null;
        $cf = strtoupper((string) $t('cf'));
        if ($cf !== '' && !CodiceFiscale::valida($cf)) throw new ApiException(__('Codice fiscale non valido: controlla i caratteri o ricalcolalo'));
        $data = [
            'id' => (int) ($in['id'] ?? 0),
            'nome' => ucfirst(trim($in['nome'])), 'cognome' => ucfirst(trim($in['cognome'])),
            'nascita' => $t('nascita'), 'sesso' => in_array($in['sesso'] ?? '', ['F', 'M']) ? $in['sesso'] : 'F',
            'cf' => $cf ?: null, 'piva' => strtoupper((string) $t('piva')) ?: null,
            'telefono' => $t('telefono'), 'cellulare' => $t('cellulare'), 'email' => $t('email'), 'pec' => $t('pec'),
            'indirizzo' => $t('indirizzo'), 'cap' => $t('cap'), 'citta' => $t('citta'), 'provincia' => strtoupper((string) $t('provincia')) ?: null,
            'comune_nascita' => $t('comune_nascita'), 'cod_nascita' => strtoupper((string) $t('cod_nascita')) ?: null,
            'professione' => $t('professione'), 'inviato_da' => $t('inviato_da'), 'provenienza' => $t('provenienza'),
            'rappresentato' => (int) !empty($in['rappresentato']), 'rapp_nome' => $t('rapp_nome'), 'rapp_cf' => strtoupper((string) $t('rapp_cf')) ?: null, 'rapp_telefono' => $t('rapp_telefono'),
            'allergie' => is_array($in['allergie'] ?? null) ? $in['allergie'] : lista_da_testo($in['allergie'] ?? ''),
            'note' => $t('note'),
        ];
        // dal codice fiscale valido ricaviamo ciò che manca (data di nascita, sesso, comune di nascita)
        if ($cf && ($dec = CodiceFiscale::decodifica($cf))) {
            $data['nascita'] = $data['nascita'] ?: $dec['nascita'];
            if (empty($in['sesso'])) $data['sesso'] = $dec['sesso'];
            $data['cod_nascita'] = $data['cod_nascita'] ?: $dec['cod_catastale'];
            if (!$data['comune_nascita'] && ($c = Comune::daCodice($data['cod_nascita']))) $data['comune_nascita'] = $c['nome'];
        }
        if (!$data['rappresentato']) $data['rapp_nome'] = $data['rapp_cf'] = $data['rapp_telefono'] = null;
        if ($data['rapp_cf'] && !CodiceFiscale::valida($data['rapp_cf'])) throw new ApiException(__('Codice fiscale del rappresentante non valido'));
        foreach (['email', 'pec'] as $k) if ($data[$k] && !filter_var($data[$k], FILTER_VALIDATE_EMAIL)) throw new ApiException(strtoupper($k) . ' non valida');
        $nuovo = $data['id'] === 0;
        $data['dati'] = Model::datiEstensioni($in, $nuovo ? [] : (array) ((self::find($data['id'])['dati'] ?? []) ?: []));   // campi delle estensioni (form.campi): <codice>_<campo> → dati[codice][campo]
        $data = Hooks::filter('paziente.salva', $data, $in);   // le estensioni completano/validano (lanciare ApiException per rifiutare)
        $id = self::save($data);
        Hooks::run('paziente.salvato', $id, $data, $nuovo);
        Attivita::registra($nuovo ? 'paziente.creato' : 'paziente.modificato', 'pazienti', $id, $data['cognome'] . ' ' . $data['nome']);
        if ($nuovo) { Storico::aggiungi($id, oggi(), 'Anagrafica', 'Paziente registrato'); Notifica::aggiungi('info', 'Nuovo paziente registrato', $data['cognome'] . ' ' . $data['nome'], ['modulo' => 'pazienti', 'opts' => ['select' => $id]]);
            if (Impostazione::get('assistente_attivo', '1') === '1') Percorso::apri('nuovo_paziente', $id, 'Nuovo paziente · ' . $data['cognome'] . ' ' . $data['nome']); }
        return $id;
    }
}
