<?php
require __DIR__ . '/../core/bootstrap.php';

$stato = function (?array $v): array {
    $p = $v ? Paziente::find((int) $v['paziente_id']) : null;
    return [
        'visita' => $v, 'paziente' => $p, 'storico' => $p ? Storico::diPaziente((int) $p['id'], 12) : [],
        'appuntamento' => $v && $v['appuntamento_id'] ? Appuntamento::find((int) $v['appuntamento_id']) : null,
        'visite_precedenti' => $p ? Visita::storicoPaziente((int) $p['id']) : [],
        'pazienti' => Paziente::options(), 'tipi' => Appuntamento::tipiNomi(),
        'diagnosi_frequenti' => Database::all('SELECT codice, descrizione FROM diagnosi ORDER BY descrizione'),
        'esami_catalogo' => Database::all('SELECT nome, categoria FROM esami ORDER BY categoria, nome'),
        'prestazioni_catalogo' => Prestazione::listino(),
    ];
};

Api::run([
    'corrente' => fn() => $stato(Visita::aperta()),
    'stato'    => function () { $v = Visita::aperta(); return ['aperta' => (bool) $v, 'paziente' => $v ? nome_completo(Paziente::find((int) $v['paziente_id']) ?? []) : null]; },
    'avvia'    => function (array $in) use ($stato) {
        $d = $stato(Visita::avvia(Api::int($in, 'paziente_id'), Api::int($in, 'appuntamento_id') ?: null));
        $p = $d['paziente'] ?? [];
        $manca = array_keys(array_filter(['codice fiscale' => empty($p['cf']), 'data di nascita' => empty($p['nascita']), 'indirizzo' => empty($p['indirizzo'])]));
        $d['anagrafica_incompleta'] = $manca ? implode(', ', $manca) : null;
        return $d;
    },
    'salva'    => fn(array $in) => ['visita' => Visita::aggiorna(Api::int($in, 'id'), $in)],
    'annulla'  => function (array $in) { $v = Visita::find(Api::int($in, 'id')); if ($v && $v['stato'] === 'bozza') Visita::delete((int) $v['id']); return ['annullata' => true]; },
    'chiudi'   => function (array $in) { $rid = Visita::chiudi(Api::int($in, 'id'), $in); $r = Referto::find($rid); return ['referto_id' => $rid, 'stato' => $r['stato']]; },
    // Modifica di una visita già chiusa (dallo storico)
    'apri'     => function (array $in) use ($stato) { $v = Visita::find(Api::int($in, 'id')) ?? throw new ApiException(__('Visita non trovata'), 404); return $stato($v); },
    'salva_chiusa' => fn(array $in) => Visita::salvaChiusa(Api::int($in, 'id'), $in) + ['messaggio' => __('Visita aggiornata')],
    'elimina'  => function (array $in) { Visita::elimina(Api::int($in, 'id')); return ['eliminata' => true, 'messaggio' => __('Visita eliminata')]; },
], ['*' => 'visita.leggi', 'stato' => null, 'avvia' => 'visita.modifica', 'salva' => 'visita.modifica', 'annulla' => 'visita.modifica', 'chiudi' => 'visita.modifica', 'salva_chiusa' => 'visita.modifica', 'elimina' => 'visita.modifica']);
