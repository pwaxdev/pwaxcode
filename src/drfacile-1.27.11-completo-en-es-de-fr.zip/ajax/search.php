<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'q' => function (array $in) {
        $q = mb_strtolower(Api::str($in, 'q'));
        if (mb_strlen($q) < 2) return [];
        $like = "%$q%"; $out = [];
        $nc = Database::concat('p.nome', "' '", 'p.cognome'); $cn = Database::concat('p.cognome', "' '", 'p.nome');
        foreach (Database::all("SELECT p.id, p.nome, p.cognome, p.nascita, p.cf FROM pazienti p WHERE LOWER($nc) LIKE ? OR LOWER($cn) LIKE ? OR LOWER(p.cf) LIKE ? ORDER BY p.cognome LIMIT 4", [$like, $like, $like]) as $p)
            $out[] = ['tipo' => 'paziente', 'id' => (int) $p['id'], 'titolo' => nome_completo($p), 'sotto' => 'Paziente · ' . eta($p['nascita']) . ' anni'];
        foreach (Database::all("SELECT a.id, a.data, a.ora, p.nome, p.cognome FROM appuntamenti a JOIN pazienti p ON p.id = a.paziente_id WHERE a.data >= ? AND a.stato <> 'annullato' AND LOWER($nc) LIKE ? ORDER BY a.data, a.ora LIMIT 3", [oggi(), $like]) as $a)
            $out[] = ['tipo' => 'appuntamento', 'id' => (int) $a['id'], 'data' => $a['data'], 'titolo' => nome_completo($a) . ' · ' . $a['ora'], 'sotto' => 'Appuntamento · ' . ($a['data'] === oggi() ? 'oggi' : data_it($a['data']))];
        foreach (Database::all("SELECT r.id, r.tipo, r.data, p.nome, p.cognome FROM referti r JOIN pazienti p ON p.id = r.paziente_id WHERE LOWER(" . Database::concat('p.nome', "' '", 'p.cognome', "' '", 'r.tipo') . ") LIKE ? ORDER BY r.data DESC LIMIT 3", [$like]) as $r)
            $out[] = ['tipo' => 'referto', 'id' => (int) $r['id'], 'titolo' => $r['tipo'], 'sotto' => nome_completo($r) . ' · ' . data_it($r['data'])];
        foreach (Database::all("SELECT f.id, f.numero, f.totale, f.stato, p.nome, p.cognome FROM fatture f JOIN pazienti p ON p.id = f.paziente_id WHERE LOWER(" . Database::concat('p.nome', "' '", 'p.cognome', "' '", 'f.numero') . ") LIKE ? ORDER BY f.data DESC LIMIT 3", [$like]) as $f)
            $out[] = ['tipo' => 'fattura', 'id' => (int) $f['id'], 'titolo' => 'Fattura ' . $f['numero'], 'sotto' => nome_completo($f) . ' · ' . euro($f['totale']) . ' · ' . (Fattura::STATI[$f['stato']] ?? $f['stato'])];
        return $out;
    },
], 'pazienti.leggi');
