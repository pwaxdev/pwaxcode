-- DRFacile · schema del database
-- Scritto in sintassi SQLite; l'Installer lo adatta a MySQL/MariaDB (AUTO_INCREMENT, ENGINE, chiavi esterne).

CREATE TABLE pazienti (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome VARCHAR(80) NOT NULL,
  cognome VARCHAR(80) NOT NULL,
  nascita VARCHAR(10),
  sesso VARCHAR(1) DEFAULT 'F',
  cf VARCHAR(16),
  telefono VARCHAR(40),
  email VARCHAR(120),
  indirizzo VARCHAR(200),
  cap VARCHAR(5),
  citta VARCHAR(80),
  provincia VARCHAR(2),
  comune_nascita VARCHAR(80),
  cod_nascita VARCHAR(4),
  piva VARCHAR(16),
  professione VARCHAR(80),
  inviato_da VARCHAR(120),
  provenienza VARCHAR(40),
  cellulare VARCHAR(40),
  pec VARCHAR(120),
  rappresentato INTEGER DEFAULT 0,
  rapp_nome VARCHAR(120),
  rapp_cf VARCHAR(16),
  rapp_telefono VARCHAR(40),
  allergie TEXT,
  note TEXT,
  dati TEXT,
  ultima_visita VARCHAR(10),
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);

CREATE TABLE appuntamenti (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  paziente_id INTEGER NOT NULL REFERENCES pazienti(id) ON DELETE CASCADE,
  data VARCHAR(10) NOT NULL,
  ora VARCHAR(5) NOT NULL,
  durata INTEGER NOT NULL DEFAULT 30,
  tipo VARCHAR(20) NOT NULL DEFAULT 'visita',
  urgente INTEGER DEFAULT 0,
  note VARCHAR(255),
  dati TEXT,
  stato VARCHAR(20) NOT NULL DEFAULT 'prenotato',
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);
CREATE INDEX idx_app_data ON appuntamenti(data, ora);

CREATE TABLE visite (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  paziente_id INTEGER NOT NULL REFERENCES pazienti(id) ON DELETE CASCADE,
  appuntamento_id INTEGER,
  utente_id INTEGER,
  data VARCHAR(10) NOT NULL,
  ora VARCHAR(5),
  pa_sys VARCHAR(10), pa_dia VARCHAR(10), fc VARCHAR(10), spo2 VARCHAR(10), temp VARCHAR(10), peso VARCHAR(10), altezza VARCHAR(10), glicemia VARCHAR(10),
  motivo VARCHAR(200),
  anamnesi TEXT,
  sintomi TEXT,
  reperti TEXT,
  esame_obiettivo TEXT,
  diagnosi TEXT,
  terapia TEXT,
  esami TEXT,
  prestazioni TEXT,
  dati TEXT,
  indicazioni TEXT,
  controllo VARCHAR(10),
  complicanze TEXT,
  stato VARCHAR(20) NOT NULL DEFAULT 'bozza',
  referto_id INTEGER,
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);

CREATE TABLE referti (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  paziente_id INTEGER NOT NULL REFERENCES pazienti(id) ON DELETE CASCADE,
  visita_id INTEGER,
  tipo VARCHAR(80) NOT NULL,
  data VARCHAR(10) NOT NULL,
  stato VARCHAR(20) NOT NULL DEFAULT 'bozza',
  sezioni TEXT,
  file VARCHAR(255),
  firmato_il VARCHAR(19),
  inviato_il VARCHAR(19),
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);

CREATE TABLE ricette (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  paziente_id INTEGER NOT NULL REFERENCES pazienti(id) ON DELETE CASCADE,
  data VARCHAR(10) NOT NULL,
  tipo VARCHAR(20) NOT NULL DEFAULT 'bianca',
  esenzione VARCHAR(20),
  note VARCHAR(255),
  righe TEXT,
  nre VARCHAR(30),
  stato VARCHAR(20) NOT NULL DEFAULT 'inviata',
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);

CREATE TABLE farmaci (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome VARCHAR(120) NOT NULL,
  principio VARCHAR(120),
  confezione VARCHAR(80),
  posologia VARCHAR(160),
  preferito INTEGER DEFAULT 0
);

CREATE TABLE prestazioni (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome VARCHAR(120) NOT NULL,
  prezzo REAL NOT NULL DEFAULT 0,
  durata INTEGER DEFAULT 30,
  colore VARCHAR(20),
  iva_id INTEGER,
  prenotabile INTEGER DEFAULT 0,
  previsita INTEGER DEFAULT 0,
  previsita_titolo VARCHAR(160),
  previsita_testo TEXT,
  previsita_quando VARCHAR(20) DEFAULT 'prenotazione',
  attiva INTEGER DEFAULT 1
);

CREATE TABLE iva (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome VARCHAR(80) NOT NULL,
  aliquota REAL NOT NULL DEFAULT 0,
  nota VARCHAR(200),
  predefinita INTEGER DEFAULT 0,
  attiva INTEGER DEFAULT 1
);

CREATE TABLE fatture (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  numero VARCHAR(20) NOT NULL,
  anno INTEGER NOT NULL,
  progressivo INTEGER NOT NULL,
  data VARCHAR(10) NOT NULL,
  paziente_id INTEGER NOT NULL REFERENCES pazienti(id) ON DELETE RESTRICT,
  visita_id INTEGER,
  prestazione VARCHAR(200) NOT NULL,
  righe TEXT,
  importo REAL NOT NULL DEFAULT 0,
  iva REAL NOT NULL DEFAULT 0,
  contributi REAL NOT NULL DEFAULT 0,
  contributi_desc VARCHAR(160),
  opposizione INTEGER DEFAULT 0,
  bollo REAL NOT NULL DEFAULT 0,
  totale REAL NOT NULL DEFAULT 0,
  metodo VARCHAR(40),
  stato VARCHAR(20) NOT NULL DEFAULT 'attesa',
  scadenza VARCHAR(10),
  pagata_il VARCHAR(10),
  stampata_il VARCHAR(19),
  inviata_il VARCHAR(19),
  note VARCHAR(255),
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);
CREATE INDEX idx_fat_data ON fatture(data);

CREATE TABLE storico (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  paziente_id INTEGER NOT NULL REFERENCES pazienti(id) ON DELETE CASCADE,
  data VARCHAR(10) NOT NULL,
  tipo VARCHAR(40) NOT NULL,
  descrizione VARCHAR(255),
  rif_tabella VARCHAR(40),
  rif_id INTEGER,
  creato_il VARCHAR(19)
);
CREATE INDEX idx_storico_paz ON storico(paziente_id, data);

CREATE TABLE impostazioni (
  chiave VARCHAR(60) PRIMARY KEY,
  valore TEXT
);

-- Archivi (tabelle di base gestite dal modulo Archivi)
CREATE TABLE tipi_appuntamento (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codice VARCHAR(20) NOT NULL,
  nome VARCHAR(60) NOT NULL,
  colore VARCHAR(20),
  durata INTEGER DEFAULT 30,
  attivo INTEGER DEFAULT 1
);

CREATE TABLE diagnosi (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codice VARCHAR(20),
  descrizione VARCHAR(200) NOT NULL
);

CREATE TABLE esenzioni (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codice VARCHAR(20) NOT NULL,
  descrizione VARCHAR(200)
);

CREATE TABLE metodi_pagamento (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome VARCHAR(60) NOT NULL,
  giorni INTEGER DEFAULT 0,
  conto VARCHAR(80),
  sdi VARCHAR(20),
  non_esporta INTEGER DEFAULT 0,
  predefinito INTEGER DEFAULT 0,
  attivo INTEGER DEFAULT 1
);

CREATE TABLE esami (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome VARCHAR(120) NOT NULL,
  categoria VARCHAR(60)
);

CREATE TABLE consensi (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  paziente_id INTEGER NOT NULL,
  tipo VARCHAR(80) NOT NULL,
  data VARCHAR(10) NOT NULL,
  scadenza VARCHAR(10),
  firmato INTEGER DEFAULT 1,
  note VARCHAR(255),
  creato_il VARCHAR(19)
);

CREATE TABLE postit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ident VARCHAR(40) NOT NULL,
  sezione VARCHAR(40) NOT NULL,
  record_id INTEGER DEFAULT 0,
  testo TEXT,
  posx INTEGER DEFAULT 40,
  posy INTEGER DEFAULT 40,
  width INTEGER DEFAULT 220,
  height INTEGER DEFAULT 190,
  rotation INTEGER DEFAULT 0,
  fontsize INTEGER DEFAULT 20,
  back VARCHAR(9) DEFAULT '#FFF4A3',
  color VARCHAR(9) DEFAULT '#1F2233',
  bold INTEGER DEFAULT 0,
  zindex INTEGER DEFAULT 1,
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);
CREATE INDEX idx_postit_ctx ON postit(sezione, record_id);

CREATE TABLE notifiche (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo VARCHAR(10) NOT NULL DEFAULT 'info',
  titolo VARCHAR(160) NOT NULL,
  testo VARCHAR(400),
  link TEXT,
  letta INTEGER DEFAULT 0,
  creato_il VARCHAR(19)
);
CREATE INDEX idx_notif_letta ON notifiche(letta, id);

CREATE TABLE messaggi (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codice VARCHAR(20) NOT NULL,
  descrizione VARCHAR(160) NOT NULL,
  canale VARCHAR(10) NOT NULL DEFAULT 'email',
  per_tipo VARCHAR(20) NOT NULL DEFAULT 'generico',
  oggetto VARCHAR(200),
  contenuto TEXT,
  predefinito INTEGER DEFAULT 0,
  abilitato INTEGER DEFAULT 1,
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);

CREATE TABLE documenti (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codice VARCHAR(20) NOT NULL,
  descrizione VARCHAR(160) NOT NULL,
  categoria VARCHAR(20) NOT NULL DEFAULT 'standard',
  contenuto TEXT,
  durata INTEGER DEFAULT 0,
  abilitato INTEGER DEFAULT 1,
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);

CREATE TABLE estensioni (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  codice VARCHAR(40) NOT NULL,
  attiva INTEGER DEFAULT 1,
  versione VARCHAR(20),
  scadenza VARCHAR(10),
  installata_il VARCHAR(19)
);

CREATE TABLE percorsi (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  percorso VARCHAR(40) NOT NULL,
  rif_id INTEGER,
  etichetta VARCHAR(120),
  manuali TEXT,
  stato VARCHAR(20) NOT NULL DEFAULT 'aperto',
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);

CREATE TABLE comunicazioni (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  canale VARCHAR(20) NOT NULL,
  destinatario VARCHAR(160) NOT NULL,
  oggetto VARCHAR(200),
  testo TEXT,
  stato VARCHAR(20) NOT NULL DEFAULT 'log',
  errore VARCHAR(250),
  rif VARCHAR(80),
  creato_il VARCHAR(19)
);

CREATE TABLE scadenze (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo VARCHAR(30) NOT NULL,
  data VARCHAR(10) NOT NULL,
  titolo VARCHAR(160) NOT NULL,
  testo VARCHAR(300),
  link TEXT,
  rif_tabella VARCHAR(40),
  rif_id INTEGER,
  stato VARCHAR(20) NOT NULL DEFAULT 'aperta',
  creato_il VARCHAR(19),
  aggiornato_il VARCHAR(19)
);
CREATE INDEX idx_scad_stato ON scadenze(stato, data);

CREATE TABLE attivita (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  azione VARCHAR(40) NOT NULL,
  entita VARCHAR(40),
  entita_id INTEGER,
  descrizione VARCHAR(255),
  utente_id INTEGER,
  utente VARCHAR(80),
  ip VARCHAR(45),
  creato_il VARCHAR(19)
);
CREATE INDEX idx_attivita_id ON attivita(id);
CREATE INDEX idx_attivita_utente ON attivita(utente_id);
