<?php
/** Sentinella · tabella delle segnalazioni (una riga per paziente e tipo, riaperta se il problema torna) */
return function () {
    Migrazioni::tabella('ext_sentinella_segnalazioni', "
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        paziente_id INTEGER,
        tipo VARCHAR(30) NOT NULL,
        gravita INTEGER DEFAULT 1,
        titolo VARCHAR(160) NOT NULL,
        testo VARCHAR(400),
        rif_tabella VARCHAR(30), rif_id INTEGER,
        stato VARCHAR(12) DEFAULT 'aperta',
        creato_il VARCHAR(19), chiuso_il VARCHAR(19)");
    Migrazioni::indice('ext_sentinella_segnalazioni', 'stato');
    Migrazioni::indice('ext_sentinella_segnalazioni', 'paziente_id');
};
