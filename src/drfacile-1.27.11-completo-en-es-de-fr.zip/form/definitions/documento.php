<?php
return [
    'title' => __('Nuovo documento'), 'title_edit' => __('Modifica documento'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Salva documento'),
    'table' => 'documenti', 'wide' => true,
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'documenti'],
        ['name' => 'codice', 'label' => __('Codice'), 'type' => 'text', 'required' => true, 'class' => 'mono', 'row' => 1, 'placeholder' => __('Es. PRIV01')],
        ['name' => 'categoria', 'label' => __('Categoria'), 'type' => 'select', 'row' => 1, 'options' => ['standard' => __('Documenti standard'), 'email' => __('Comunicazioni email'), 'consensi' => __('Consensi')]],
        ['name' => 'descrizione', 'label' => __('Descrizione'), 'type' => 'text', 'required' => true, 'placeholder' => __('Es. Informativa privacy e consenso al trattamento')],
        ['name' => 'contenuto', 'label' => __('Contenuto'), 'type' => 'rich', 'height' => 240,
            'campi' => ['paziente', 'cf', 'nascita', 'indirizzo', 'data', 'medico', 'studio', 'studio_indirizzo', 'scadenza'],
            'placeholder' => __('Il testo del documento: usa i campi {paziente}, {data}… dal pulsante "Campo"')],
        ['name' => 'durata', 'label' => __('Validità (giorni)'), 'type' => 'text', 'mask' => 'intero', 'default' => 0, 'row' => 2, 'help' => __('0 = senza scadenza. Per i consensi: alla stampa la firma entra nel registro e la scadenza nello scadenzario')],
        ['name' => 'abilitato', 'label' => __('Abilitato'), 'type' => 'switch', 'default' => 1, 'row' => 2],
    ],
];
