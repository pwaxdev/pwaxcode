<?php
if (!function_exists('module_attivita_render')) {
    function module_attivita_render(array $ctx): string { return '<div class="att"><div class="att-list"><div class="empty">' . __('Caricamento…') . '</div></div></div>'; }
}
