<?php
/** Accesso alla configurazione con notazione a punti: Config::get('app.name') */
final class Config
{
    private static array $data = [];

    public static function init(array $data): void { self::$data = $data; }

    /** Sovrascrittura puntuale (es. app.version, che viaggia con il codice e non con config.php) */
    public static function override(string $key, mixed $value): void
    {
        $node = &self::$data;
        foreach (explode('.', $key) as $part) { if (!isset($node[$part]) || !is_array($node)) $node[$part] = []; $node = &$node[$part]; }
        $node = $value;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $node = self::$data;
        foreach (explode('.', $key) as $part) {
            if (!is_array($node) || !array_key_exists($part, $node)) return $default;
            $node = $node[$part];
        }
        return $node;
    }

    public static function set(string $key, mixed $value): void
    {
        $node = &self::$data;
        foreach (explode('.', $key) as $part) {
            if (!isset($node[$part]) || !is_array($node[$part])) $node[$part] = [];
            $node = &$node[$part];
        }
        $node = $value;
    }
}
