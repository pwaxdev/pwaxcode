<?php
/**
 * Comunicazioni in uscita: UN endpoint per email, SMS e WhatsApp.
 *
 *     Comunicazioni::invia('email', 'paziente@esempio.it', 'Promemoria', '<p>Testo…</p>');
 *     Comunicazioni::invia('sms', '+39333…', '', 'Il suo codice è 123456');
 *     Comunicazioni::invia('whatsapp', '+39333…', '', 'Gentile paziente…');   // predisposto
 *
 * Ogni invio finisce nel registro (tabella `comunicazioni`) con lo stato. Il canale è scelto
 * in config/config.php → 'comunicazioni': ogni canale ha un driver.
 *
 *   driver 'log'  → non spedisce davvero: registra e basta (demo/sviluppo, predefinito)
 *   driver 'mail' → email con la mail() di PHP (richiede un server configurato)
 *   driver 'smtp' → email via SMTP con PHPMailer (vendor/phpmailer): config comunicazioni.email.smtp (host, porta, sicurezza, utente, password)
 *   driver 'clickatell' → SMS via Clickatell (core/Sms.php): serve il servizio SMS attivo (Store) e credito; config comunicazioni.sms.clickatell
 *   $opz['allegati'] = [['nome' => 'referto.pdf', 'contenuto' => $bytes, 'mime' => 'application/pdf']] per le email
 *
 * I moduli non devono sapere nulla del trasporto: chiamano invia() e leggono l'id del registro.
 */
final class Comunicazioni
{
    public const CANALI = ['email' => 'Email', 'sms' => 'SMS', 'whatsapp' => 'WhatsApp'];

    /** Invia (o registra) un messaggio. Restituisce l'id nel registro comunicazioni. */
    public static function invia(string $canale, string $a, string $oggetto, string $testo, array $opz = []): int
    {
        Capabilities::richiedi('comunicazioni.invia');
        if (!isset(self::CANALI[$canale])) throw new ApiException(__('Canale non valido'));
        $cfg = (array) (Config::get("comunicazioni.$canale") ?? []);
        $driver = $cfg['driver'] ?? 'log';
        $stato = 'inviata'; $errore = null;
        try {
            if ($canale === 'sms' && $driver !== 'log') { $p = Sms::pronto(); if ($p['problemi']) throw new ApiException(implode(' · ', $p['problemi'])); }
            self::trasporto($driver, $canale, $cfg, $a, $oggetto, $testo, $opz);
            if ($driver === 'log') $stato = 'log';
            elseif ($canale === 'sms') Sms::scala(max(1, (int) ceil(mb_strlen($testo) / 160)));   // un credito ogni 160 caratteri
        } catch (Throwable $e) { $stato = 'errore'; $errore = mb_substr($e->getMessage(), 0, 250); }
        return (int) Database::insert('comunicazioni', ['canale' => $canale, 'destinatario' => mb_substr($a, 0, 160), 'oggetto' => mb_substr($oggetto, 0, 200),
            'testo' => $testo, 'stato' => $stato, 'errore' => $errore, 'rif' => mb_substr((string) ($opz['rif'] ?? ''), 0, 80), 'creato_il' => date('Y-m-d H:i:s')]);
    }

    /** Il trasporto vero e proprio: qui si agganciano SMTP e gateway SMS/WhatsApp */
    private static function trasporto(string $driver, string $canale, array $cfg, string $a, string $oggetto, string $testo, array $opz): void
    {
        switch ($driver) {
            case 'log':
                return;                       // nessun invio reale: resta nel registro
            case 'mail':                      // email con la mail() di PHP
                if ($canale !== 'email') throw new ApiException("Il driver 'mail' vale solo per le email");
                $da = $cfg['da'] ?? 'noreply@drfacile.local';
                $ok = @mail($a, '=?UTF-8?B?' . base64_encode($oggetto) . '?=', $testo,
                    "MIME-Version: 1.0\r\nContent-Type: text/html; charset=UTF-8\r\nFrom: $da");
                if (!$ok) throw new ApiException('mail() ha rifiutato l\'invio');
                return;
            case 'smtp':                      // email via PHPMailer
                if ($canale !== 'email') throw new ApiException("Il driver 'smtp' vale solo per le email");
                self::smtp($cfg, $a, $oggetto, $testo, $opz);
                return;
            case 'clickatell':                // SMS via Clickatell
                if ($canale !== 'sms') throw new ApiException("Il driver 'clickatell' vale solo per gli SMS");
                Sms::clickatell($a, strip_tags($testo), (array) ($cfg['clickatell'] ?? []));
                return;
            default:
                throw new ApiException("Driver '$driver' non ancora implementato per il canale $canale");
        }
    }

    /** Email via PHPMailer (SMTP): mittente da config, HTML + testo semplice, allegati facoltativi */
    private static function smtp(array $cfg, string $a, string $oggetto, string $testo, array $opz): void
    {
        $base = DRF_ROOT . '/vendor/phpmailer/src/';
        if (!is_file($base . 'PHPMailer.php')) throw new ApiException(__('PHPMailer non presente in vendor/phpmailer'));
        foreach (['Exception', 'PHPMailer', 'SMTP'] as $c) require_once $base . $c . '.php';
        $s = (array) ($cfg['smtp'] ?? []);
        if (empty($s['host'])) throw new ApiException(__('SMTP non configurato (comunicazioni.email.smtp.host in config.php)'));
        $m = new \PHPMailer\PHPMailer\PHPMailer(true);
        $m->CharSet = 'UTF-8'; $m->isSMTP(); $m->Host = (string) $s['host']; $m->Port = (int) ($s['porta'] ?? 587);
        $sic = strtolower((string) ($s['sicurezza'] ?? 'tls'));
        if ($sic === 'ssl') $m->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS; elseif ($sic === 'tls') $m->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS; else $m->SMTPAutoTLS = false;
        if (!empty($s['utente'])) { $m->SMTPAuth = true; $m->Username = (string) $s['utente']; $m->Password = (string) ($s['password'] ?? ''); }
        $m->Timeout = 20;
        $profilo = Impostazione::profilo();
        $daNome = Impostazione::get('email_da_nome') ?: (string) ($cfg['da_nome'] ?? '') ?: ($profilo['studio'] ?: 'DRFacile');   // il nome del mittente e il rispondi-a li decide lo studio (Impostazioni → Email)
        $rispondi = Impostazione::get('email_rispondi_a') ?: (string) ($cfg['rispondi_a'] ?? '') ?: $profilo['email'];
        $m->setFrom((string) ($cfg['da'] ?? $s['utente'] ?? 'noreply@drfacile.local'), $daNome);
        if ($rispondi && filter_var($rispondi, FILTER_VALIDATE_EMAIL)) $m->addReplyTo($rispondi, $daNome);
        foreach (array_filter(array_map('trim', explode(',', $a))) as $dest) $m->addAddress($dest);
        foreach ((array) ($opz['cc'] ?? []) as $cc) $m->addCC($cc);
        foreach ((array) ($opz['allegati'] ?? []) as $al) if (!empty($al['contenuto'])) $m->addStringAttachment((string) $al['contenuto'], (string) ($al['nome'] ?? 'allegato'), 'base64', (string) ($al['mime'] ?? 'application/octet-stream'));
        $m->Subject = $oggetto;
        $m->isHTML(true); $m->Body = $testo; $m->AltBody = trim(html_entity_decode(strip_tags(preg_replace('~<br\s*/?>|</p>~i', "\n", $testo))));
        $m->send();
    }

    /** Le ultime comunicazioni registrate (per verifiche e per il supporto) */
    public static function registro(int $limit = 50): array
    {
        return Database::all('SELECT * FROM comunicazioni ORDER BY id DESC LIMIT ' . (int) $limit);
    }
}
