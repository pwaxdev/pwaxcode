<?php
return [
    'title' => __('Nuova esenzione'), 'title_edit' => __('Modifica esenzione'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Aggiungi'),
    'table' => 'esenzioni',
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'esenzioni'],
        ['name' => 'codice', 'label' => __('Codice'), 'type' => 'text', 'required' => true, 'attrs' => ['maxlength' => 20]],
        ['name' => 'descrizione', 'label' => __('Descrizione'), 'type' => 'text'],
    ],
];
