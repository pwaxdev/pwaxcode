<?php
/** CRUD generico sulle tabelle di base definite in core/archivi.php */
final class Archivio
{
    private static ?array $registro = null;

    public static function registro(): array { return self::$registro ??= require DRF_ROOT . '/core/archivi.php'; }

    public static function def(string $nome): array
    {
        $r = self::registro();
        if (!isset($r[$nome])) throw new ApiException("Archivio non trovato: $nome", 404);
        return $r[$nome] + ['nome' => $nome];
    }

    /** Elenco degli archivi con il numero di voci */
    public static function elenco(): array
    {
        $out = [];
        foreach (self::registro() as $k => $d) if (empty($d['nascosto'])) $out[] = ['nome' => $k, 'label' => $d['label'], 'desc' => $d['desc'], 'fi' => $d['fi'], 'fa' => $d['fa'], 'n' => (int) Database::value("SELECT COUNT(*) FROM {$d['table']}")];
        return $out;
    }

    public static function righe(string $nome): array
    {
        $d = self::def($nome);
        $rows = Database::all($d['select'] ?? "SELECT * FROM {$d['table']} ORDER BY {$d['order']}");
        if ($rows && array_key_exists('paziente_id', $rows[0])) {   // nome del paziente per le tabelle collegate
            $nomi = []; foreach (Paziente::options() as $o) $nomi[$o['id']] = $o['nome_completo'];
            foreach ($rows as &$r) $r['paziente'] = $nomi[(int) $r['paziente_id']] ?? '—';
        }
        return $rows;
    }

    /** Salva (inserisce o aggiorna) usando i campi dichiarati nella form dell'archivio */
    public static function salva(string $nome, array $in): int
    {
        $d = self::def($nome);
        $form = FormBuilder::definizione($d['form']);
        $row = []; $obbl = [];
        foreach ($form['fields'] as $f) {
            if (($f['type'] ?? 'text') === 'hidden' || !array_key_exists($f['name'], $in)) continue;
            $v = $in[$f['name']];
            if (($f['type'] ?? '') === 'number' || in_array($f['mask'] ?? '', ['euros', 'numero', 'decimale', 'sconto', 'intero', 'decimale1'], true)) $v = ($v === '' || $v === null) ? null : numero($v);
            elseif (($f['type'] ?? '') === 'select' && $f['name'] === 'paziente_id') $v = (int) $v;
            elseif (($f['type'] ?? '') === 'switch') $v = (int) !empty($v);
            elseif (($f['type'] ?? '') === 'rich') $v = rich_txt(is_string($v) ? $v : '');
            else $v = is_string($v) ? trim($v) : $v;
            if (!empty($f['required']) && ($v === '' || $v === null)) $obbl[] = $f['label'] ?? $f['name'];
            $row[$f['name']] = $v;
        }
        if ($obbl) throw new ApiException('Campo obbligatorio: ' . implode(', ', $obbl));
        $id = (int) ($in['id'] ?? 0);
        if ($id > 0) { Database::update($d['table'], $row, 'id = :id', ['id' => $id]); }
        else { $id = Database::insert($d['table'], $row); }
        if (($d['dopo'] ?? null) instanceof Closure) ($d['dopo'])($id, $row);
        return $id;
    }

    public static function elimina(string $nome, int $id): bool
    {
        $d = self::def($nome);
        return Database::delete($d['table'], 'id = ?', [$id]) > 0;
    }
}
