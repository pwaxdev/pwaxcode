<?php
/** Gestione documentale · endpoint (ajax/ext.php?ext=documentale) */
$pid = fn(array $in) => Api::int($in, 'paziente_id') ?: throw new ApiException('Paziente mancante');
return [
    'azioni' => [
        'albero' => fn(array $in) => Documentale::albero($pid($in)),
        'upload' => function (array $in) use ($pid) {
            $p = $pid($in); $c = Api::int($in, 'cartella_id');
            $out = []; $files = $_FILES['file'] ?? null;
            if (!$files) throw new ApiException('Nessun file ricevuto');
            $n = is_array($files['name']) ? count($files['name']) : 1;
            for ($i = 0; $i < $n; $i++) {
                $f = is_array($files['name']) ? ['name' => $files['name'][$i], 'tmp_name' => $files['tmp_name'][$i], 'size' => $files['size'][$i], 'error' => $files['error'][$i]] : $files;
                $out[] = Documentale::carica($p, $c, $f);
            }
            return ['caricati' => count($out), 'messaggio' => count($out) === 1 ? 'File caricato' : count($out) . ' file caricati'];
        },
        'cartella_crea' => function (array $in) use ($pid) {
            $nome = trim(Api::str($in, 'nome')); if ($nome === '') throw new ApiException('Dai un nome alla cartella');
            $parent = Api::int($in, 'parent_id') ?: null;
            return ['id' => Database::insert(Documentale::C, ['paziente_id' => $pid($in), 'parent_id' => $parent, 'nome' => mb_substr($nome, 0, 120), 'sistema' => null, 'creato_il' => date('Y-m-d H:i:s')]), 'messaggio' => 'Cartella creata'];
        },
        'cartella_rinomina' => function (array $in) use ($pid) {
            $c = Database::one('SELECT * FROM ' . Documentale::C . ' WHERE id = ? AND paziente_id = ?', [Api::int($in, 'id'), $pid($in)]) ?? throw new ApiException('Cartella non trovata');
            if ($c['sistema']) throw new ApiException('Le cartelle di sistema non si rinominano');
            Database::update(Documentale::C, ['nome' => mb_substr(trim(Api::str($in, 'nome')) ?: $c['nome'], 0, 120)], 'id = :id', ['id' => (int) $c['id']]); return ['ok' => true];
        },
        'cartella_elimina' => function (array $in) use ($pid) {
            $c = Database::one('SELECT * FROM ' . Documentale::C . ' WHERE id = ? AND paziente_id = ?', [Api::int($in, 'id'), $pid($in)]) ?? throw new ApiException('Cartella non trovata');
            if ($c['sistema']) throw new ApiException('Le cartelle di sistema non si eliminano');
            if (Database::value('SELECT COUNT(*) FROM ' . Documentale::F . ' WHERE cartella_id = ?', [(int) $c['id']]) || Database::value('SELECT COUNT(*) FROM ' . Documentale::C . ' WHERE parent_id = ?', [(int) $c['id']])) throw new ApiException('La cartella non è vuota: sposta prima i file');
            Database::delete(Documentale::C, 'id = ?', [(int) $c['id']]); return ['messaggio' => 'Cartella eliminata'];
        },
        'rinomina' => function (array $in) use ($pid) {
            $f = Documentale::file(Api::int($in, 'id'), $pid($in));
            $nome = trim(Api::str($in, 'nome')); if ($nome === '') throw new ApiException('Nome vuoto');
            $ext = pathinfo($f['nome'], PATHINFO_EXTENSION); if ($ext && !str_ends_with(mb_strtolower($nome), '.' . mb_strtolower($ext))) $nome .= ".$ext";   // l'estensione resta
            Database::update(Documentale::F, ['nome' => mb_substr($nome, 0, 200)], 'id = :id', ['id' => (int) $f['id']]); return ['ok' => true];
        },
        'sposta' => function (array $in) use ($pid) {
            $p = $pid($in); $f = Documentale::file(Api::int($in, 'id'), $p);
            if ($f['origine'] !== 'upload') throw new ApiException('I documenti generati dal programma restano nella loro cartella');
            if (!Database::value('SELECT id FROM ' . Documentale::C . ' WHERE id = ? AND paziente_id = ?', [Api::int($in, 'cartella_id'), $p])) throw new ApiException('Cartella non valida');
            Database::update(Documentale::F, ['cartella_id' => Api::int($in, 'cartella_id')], 'id = :id', ['id' => (int) $f['id']]); return ['messaggio' => 'Spostato'];
        },
        'note' => function (array $in) use ($pid) { $f = Documentale::file(Api::int($in, 'id'), $pid($in)); Database::update(Documentale::F, ['note' => mb_substr(Api::str($in, 'note'), 0, 255)], 'id = :id', ['id' => (int) $f['id']]); return ['ok' => true]; },
        'elimina' => function (array $in) use ($pid) {
            $f = Documentale::file(Api::int($in, 'id'), $pid($in));
            if ($f['origine'] !== 'upload') throw new ApiException('I documenti generati dal programma non si eliminano da qui');
            Spazio::elimina($f['percorso']); Database::delete(Documentale::F, 'id = ?', [(int) $f['id']]);
            Attivita::registra('documento.eliminato', 'documenti', (int) $f['id'], $f['nome']);
            return ['messaggio' => 'File eliminato', 'spazio' => Spazio::stato()];
        },
    ],
    'permessi' => ['*' => 'documenti.leggi', 'upload' => 'documenti.modifica', 'cartella_crea' => 'documenti.modifica', 'cartella_rinomina' => 'documenti.modifica', 'cartella_elimina' => 'documenti.modifica', 'rinomina' => 'documenti.modifica', 'sposta' => 'documenti.modifica', 'note' => 'documenti.modifica', 'elimina' => 'documenti.modifica'],
];
