<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run(['voci' => fn() => ['voci' => require DRF_ROOT . '/core/aiuto.php']]);
