<?php
/**
 * Diagnosi via web: la stessa dello strumento CLI, ma servita dallo STESSO vhost
 * che usa il browser — così vediamo cosa gira davvero lì. Richiede il login.
 * Uso: http://.../drfacile/diagnosi.php
 */
require __DIR__ . '/core/bootstrap.php';
if (!Auth::check()) { header('Location: login.php'); exit; }
header('Content-Type: text/plain; charset=utf-8');

echo "DRFacile — diagnosi via web\n";
echo "  cartella servita: " . __DIR__ . "\n";
echo "  versione:         " . Config::get('app.version') . " · schema atteso " . Installer::SCHEMA . " · schema nel db " . (Impostazione::get('schema_versione') ?: '—') . "\n";
echo "  https:            " . (drf_https() ? 'sì' : 'NO') . " · cookie Secure: " . (Config::get('auth.cookie_secure', 'auto') === 'auto' ? 'auto → ' . (drf_https() ? 'attivo' : 'NON attivo') : (Config::get('auth.cookie_secure') ? 'forzato' : 'disattivato')) . " · sessione: " . session_name() . "\n";
echo "  password:         " . (Auth::passwordPredefinita() ? 'PREDEFINITA (medico / drfacile) ← cambiala!' : 'personalizzata') . "\n";
echo "  studio:           " . (Auth::studioId() ?: '—') . (Database::tenantId() ? ' · database dedicato' : ' · database base') . " · ruolo " . (Auth::utente()['ruolo'] ?? '—') . (Auth::admin() ? ' (amministratore)' : '') . "\n";
echo "  database:         " . Database::driver() . (Database::driver() === 'mysql' ? ' · ' . (string) Config::get('db.mysql.dsn') : '') . "\n";
$c = Database::colonneTipi('visite');
echo "  visite.dati:      " . (isset($c['dati']) ? "presente ({$c['dati']})" : 'ASSENTE ← problema!') . "\n";
$attese = is_file(__DIR__ . '/docs/impronte.json') ? (json_decode((string) file_get_contents(__DIR__ . '/docs/impronte.json'), true) ?: []) : [];
if (!$attese) {
    echo "  docs/impronte.json ASSENTE ← pacchetto applicato a metà!\n";
} else {
    $marci = [];
    foreach ($attese as $f => $md5) {
        $mio = is_file(__DIR__ . "/$f") ? substr(md5_file(__DIR__ . "/$f"), 0, 10) : 'MANCANTE';
        if ($mio !== $md5) $marci[$f] = $mio;
    }
    echo "  controllo INTEGRALE dei file: " . count($attese) . " nel manifest · " . (count($attese) - count($marci)) . " aggiornati\n";
    if ($marci) {
        echo "  FILE VECCHI O MANCANTI (← ecco il problema):\n";
        foreach (array_slice($marci, 0, 40, true) as $f => $mio) printf("    ✘ %-46s %s\n", $f, $mio);
    } else {
        echo "  → TUTTI i file serviti sono quelli giusti.\n";
    }
}
echo "  estensioni attive: " . implode(', ', array_map(fn($e) => "{$e['codice']} v{$e['versione']}", Database::all('SELECT codice, versione FROM estensioni WHERE attiva = 1'))) . "\n";
echo "  js estensioni in pagina: " . implode(', ', Estensioni::assets()['js'] ?: ['nessuno ← problema!']) . "\n";
echo "  ultime 3 visite:\n";
foreach (Database::all('SELECT id, stato, diagnosi, dati, aggiornato_il FROM visite ORDER BY id DESC LIMIT 3') as $v) {
    $dati = json_decode((string) $v['dati'], true) ?: [];
    $dx = json_decode((string) $v['diagnosi'], true) ?: [];
    echo "    #{$v['id']} ({$v['stato']}, agg. {$v['aggiornato_il']}) · diagnosi: " . ($dx ? implode('; ', $dx) : '—') . " · dati estensioni: " . ($dati ? implode(', ', array_map(fn($k, $x) => "$k(" . count((array) $x) . " campi)", array_keys($dati), $dati)) : 'VUOTI') . "\n";
}
echo "\nApri una visita, compila un campo ginecologico, aspetta 3 secondi, ricarica questa pagina:\nse i 'dati estensioni' dell'ultima bozza restano VUOTI, il problema è fra il browser e il server.\n";
