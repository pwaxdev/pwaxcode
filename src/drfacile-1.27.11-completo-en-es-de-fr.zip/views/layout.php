<?php /** Layout principale: costa dei moduli + area di lavoro. Variabili: $modules, $medico, $tema, $jsConfig */ ?>
<!DOCTYPE html>
<html lang="<?= e(I18n::lingua()) ?>" data-theme="<?= e($tema) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e(Config::get('app.name')) ?></title>
<link rel="icon" href="assets/images/favicon.svg">
<link rel="stylesheet" href="assets/vendor/fonts/fonts.css">
<!-- Icone: Flaticon UIcons (CDN) con fallback automatico a Font Awesome locale, icona per icona -->
<link rel="stylesheet" href="https://cdn-uicons.flaticon.com/2.6.0/uicons-regular-rounded/css/uicons-regular-rounded.css">
<link rel="stylesheet" href="https://cdn-uicons.flaticon.com/2.6.0/uicons-solid-rounded/css/uicons-solid-rounded.css">
<link rel="stylesheet" href="assets/vendor/fontawesome/css/all.min.css">
<link rel="stylesheet" href="assets/vendor/select2/select2.min.css">
<link rel="stylesheet" href="assets/vendor/datatables/dataTables.dataTables.min.css">
<link rel="stylesheet" href="assets/vendor/flatpickr/flatpickr.min.css">
<link rel="stylesheet" href="assets/css/app.css?v=<?= e(Config::get('app.version')) ?>">
<link rel="stylesheet" href="assets/css/novita.css?v=<?= e(Config::get('app.version')) ?>">
<link rel="stylesheet" href="assets/css/plugins.css?v=<?= e(Config::get('app.version')) ?>">
<link rel="stylesheet" href="assets/css/bodymap.css?v=<?= e(Config::get('app.version')) ?>">
<link rel="stylesheet" href="assets/css/postit.css?v=<?= e(Config::get('app.version')) ?>">
<link rel="stylesheet" href="assets/css/desk.css?v=<?= e(Config::get('app.version')) ?>">
<?php foreach ($modules as $m): foreach ((array) ($m['css'] ?? ["assets/css/{$m['key']}.css"]) as $css): ?>
<link rel="stylesheet" href="<?= e($css) ?>?v=<?= e(Config::get('app.version')) ?>">
<?php endforeach; ?>
<?php endforeach; ?>
</head>
<body>
<div class="app">

<aside class="rail">
  <button class="avatar" id="avatarBtn" title="<?= e(($utente['nome_completo'] ?: $medico['nome_completo']) . ' · ' . __('scrivania')) ?>"><?php if (!empty($utente['avatar'])): ?><img src="<?= e($utente['avatar']) ?>" alt=""><?php else: ?><?= e($utente['iniziali'] ?? $medico['iniziali']) ?><?php endif; ?><span class="dot"></span></button>
  <nav class="rail-nav" id="railNav" aria-label="<?= __('Moduli') ?>">
    <span class="tab instant" id="tab"></span>
    <?php foreach ($modules as $i => $m): ?>
    <button class="rail-btn" data-panel="<?= e($m['key']) ?>"><i class="ico" data-fi="<?= e($m['fi']) ?>" data-fa="<?= e($m['fa']) ?>"></i><span class="tip"><?= e($m['label']) ?></span><?php if ($i < 10): ?><span class="kbd"><?= ($i + 1) % 10 ?></span><?php endif; ?></button>
    <?php endforeach; ?>
  </nav>
  <div class="rail-foot">
    <button class="rail-mini" id="themeBtn" title="<?= __('Tema chiaro / scuro') ?>"><i class="ico" data-fi="moon" data-fa="fa-regular fa-moon"></i></button>
    <button class="rail-mini" id="logoutBtn" title="<?= __('Esci') ?>"><i class="ico" data-fi="sign-out-alt" data-fa="fa-solid fa-arrow-right-from-bracket"></i></button>
  </div>
</aside>

<main class="stage">
  <header class="topbar">
    <div class="tb-title" id="tbTitle"><h1>&nbsp;</h1><p>&nbsp;</p></div>
    <div class="tb-tools">
      <div class="search" id="search">
        <i class="ico" data-fi="search" data-fa="fa-solid fa-magnifying-glass"></i>
        <input id="searchInput" type="search" name="q-<?= substr(md5((string) session_id()), 0, 6) ?>" placeholder="<?= __('Cerca paziente, referto, fattura…') ?>" autocomplete="off" data-lpignore="true" data-1p-ignore data-form-type="other" spellcheck="false" readonly onfocus="this.removeAttribute('readonly')">
        <kbd>⌘K</kbd>
        <div class="search-results" id="searchResults"></div>
      </div>
      <button class="icon-btn" id="postitBtn" title="<?= __('Incolla un post-it') ?>"><i class="ico" data-fi="note-sticky" data-fa="fa-regular fa-note-sticky"></i><span class="n amber" id="postitCount" hidden>0</span></button>
      <div class="notif-wrap">
        <button class="icon-btn" id="bellBtn" title="<?= __('Notifiche') ?>"><i class="ico" data-fi="bell" data-fa="fa-regular fa-bell"></i><span class="n" id="bellCount" hidden>0</span></button>
        <div class="notif-panel" id="notifPanel"><div class="notif-head"><b><?= __('Notifiche') ?></b><button class="btn ghost sm" type="button" data-ntf-all><?= __('Segna tutte lette') ?></button></div><div class="ntf-list"></div><div class="notif-foot"><button class="btn soft block" type="button" data-ntf-centro><i class="ico" data-fi="apps" data-fa="fa-solid fa-table-cells-large"></i><?= __('Centro notifiche') ?></button></div></div>
      </div>
      <span class="tb-ext" id="tbExt"></span>
      <button class="btn primary" id="tbAction"><i class="ico" data-fi="plus" data-fa="fa-solid fa-plus"></i><span></span></button>
    </div>
  </header>
  <div class="postit-layer" id="postitLayer"></div>
  <div class="panels" id="panels">
    <?php foreach ($modules as $m): ?>
    <section class="panel" data-panel="<?= e($m['key']) ?>">
      <?php $vista = Hooks::filter('views.override', $m['vista'] ?? (DRF_ROOT . '/views/sections/' . $m['key'] . '.php'), 'sections/' . $m['key']); if (is_file($vista)) include $vista; elseif (isset($m['html'])) echo $m['html']; ?>
    </section>
    <?php endforeach; ?>
  </div>
</main>
</div>

<?php if (isset($abbonamento) && $abbonamento['stato'] === 'in_scadenza'): ?>
<div class="abb-banner" id="abbBanner">
  <i class="ico" data-fi="hourglass-end" data-fa="fa-solid fa-hourglass-half"></i>
  <span><?= __('Il tuo abbonamento sta per scadere') ?><?= $abbonamento['giorni'] === 0 ? ' <b>' . __('oggi') . '</b>' : ' ' . __('fra') . ' <b>' . $abbonamento['giorni'] . ' ' . _n('giorno', 'giorni', $abbonamento['giorni']) . '</b> (' . data_it($abbonamento['scadenza']) . ')' ?>: <?= __('rinnovalo per non interrompere il lavoro.') ?></span>
  <a class="btn primary sm" href="<?= e($abbonamento['url']) ?>" target="_blank" rel="noopener"><?= __('Rinnova ora') ?></a>
  <button class="icon-btn sm" type="button" onclick="this.parentNode.remove()" title="<?= __('Chiudi') ?>"><i class="ico" data-fi="cross-small" data-fa="fa-solid fa-xmark"></i></button>
</div>
<?php endif; ?>
<!-- Scrivania -->
<div class="desk" id="desk">
  <div class="desk-top">
    <div class="desk-hello"><b>—</b><span class="desk-date"></span></div>
    <div class="desk-clock">—</div>
    <div class="desk-next"></div>
    <button class="icon-btn desk-close" type="button" title="<?= __('Chiudi la scrivania (Esc)') ?>"><i class="ico" data-fi="cross-small" data-fa="fa-solid fa-xmark"></i></button>
  </div>
  <div class="desk-area"></div>
  <div class="desk-dock"></div>
</div>
<!-- Pannello laterale per le form -->
<div class="backdrop" id="backdrop"></div>
<aside class="sheet" id="sheet" aria-modal="true">
  <header><h2 id="sheetTitle"></h2><button class="icon-btn" id="sheetClose" title="<?= __('Chiudi') ?>"><i class="ico" data-fi="cross-small" data-fa="fa-solid fa-xmark"></i></button></header>
  <form class="sheet-body" id="sheetBody" autocomplete="off"></form>
  <footer><button class="btn ghost" id="sheetCancel" type="button"><?= __('Annulla') ?></button><button class="btn primary" id="sheetOk" type="button"><?= __('Salva') ?></button></footer>
</aside>
<!-- Messaggi (conferme, avvisi) -->
<div class="dialog" id="dialog"><div class="dialog-box"><div class="row" style="gap:14px;align-items:flex-start"><span class="dialog-icon" id="dialogIcon"></span><div style="flex:1;min-width:0"><h2 id="dialogTitle"></h2><p id="dialogText"></p></div></div><div class="dialog-btns" id="dialogBtns"></div></div></div>
<!-- Modale -->
<div class="modal" id="modal"><div class="modal-box"><header><h2 id="modalTitle"></h2><button class="icon-btn" id="modalClose" type="button" title="<?= __('Chiudi') ?>"><i class="ico" data-fi="cross-small" data-fa="fa-solid fa-xmark"></i></button></header><div class="modal-body" id="modalBody"></div><footer><button class="btn ghost" id="modalCancel" type="button"><?= __('Chiudi') ?></button><button class="btn primary" id="modalOk" type="button">OK</button></footer></div></div>
<div class="toasts" id="toasts"></div>

<script src="assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/select2/select2.min.js"></script>
<script src="assets/vendor/select2/select2.it.js"></script>
<script src="assets/vendor/datatables/dataTables.min.js"></script>
<script src="assets/vendor/flatpickr/flatpickr.min.js"></script>
<script src="assets/vendor/flatpickr/flatpickr.it.js"></script>
<script src="assets/vendor/inputmask/jquery.inputmask.min.js"></script>
<script src="assets/vendor/igea/bodymodel.js?v=<?= e(Config::get('app.version')) ?>"></script>
<script src="assets/core/drf.js?v=<?= e(Config::get('app.version')) ?>"></script>
<script>DRF.config = <?= json_encode($jsConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR) ?: '{}' ?>;</script>
<?php foreach (['utils', 'icons', 'api', 'sound', 'ui', 'rich', 'cf', 'form', 'nav', 'search', 'menu', 'hooks', 'notify', 'help', 'assistente', 'bodymap', 'crud', 'postit', 'desk', 'storico', 'novita', 'app'] as $js): ?>
<script src="assets/core/<?= $js ?>.js?v=<?= e(Config::get('app.version')) ?>"></script>
<?php endforeach; ?>
<?php foreach ($modules as $m): foreach ((array) ($m['js'] ?? ["assets/js/{$m['key']}.js"]) as $js): ?>
<script src="<?= e($js) ?>?v=<?= e(Config::get('app.version')) ?>"></script>
<?php endforeach; ?>
<?php endforeach; ?>
<?php foreach (($estAssets['js'] ?? []) as $f): ?>
<script src="<?= e($f) ?>?v=<?= e(Config::get('app.version')) ?>"></script>
<?php endforeach; ?>
<?php foreach (($estAssets['css'] ?? []) as $f): ?>
<link rel="stylesheet" href="<?= e($f) ?>?v=<?= e(Config::get('app.version')) ?>">
<?php endforeach; ?>
<script>DRF.boot(DRF.config);</script>
</body>
</html>
