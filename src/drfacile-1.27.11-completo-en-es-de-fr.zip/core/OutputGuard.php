<?php
/**
 * Protegge i punti del core che devono essere "silenziosi" (API JSON, caricamento estensioni,
 * migrazioni) da output accidentale prodotto da file di terze parti: BOM UTF-8, spazi fuori
 * da <?php, echo di debug e warning visualizzati.
 *
 * L'output viene scartato e registrato nel log PHP; eccezioni/return passano normalmente.
 */
final class OutputGuard
{
    public static function run(string $contesto, callable $fn): mixed
    {
        $base = ob_get_level();
        $rumore = '';
        ob_start(static function (string $chunk) use (&$rumore): string {
            $rumore .= $chunk;
            return '';
        });

        try {
            return $fn();
        } finally {
            // Chiude anche eventuali buffer lasciati aperti dal codice chiamato. Gli ob_end_flush
            // dei buffer interni confluiscono nel nostro handler, che li cattura senza inviarli al client.
            while (ob_get_level() > $base) {
                $prima = ob_get_level();
                @ob_end_flush();
                if (ob_get_level() >= $prima) { // buffer non rimovibile: non rischiamo un loop infinito
                    @ob_end_clean();
                    if (ob_get_level() >= $prima) break;
                }
            }

            if ($rumore !== '') {
                $anteprima = json_encode(substr($rumore, 0, 600), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
                error_log('[DRFacile] Output inatteso soppresso in ' . $contesto . ' (' . strlen($rumore) . ' byte): ' . ($anteprima ?: '[non rappresentabile]'));
            }
        }
    }
}
