<?php
/** Funzioni di utilità globali (escape, date, formati italiani) */

function e(?string $s): string { return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function oggi(): string { return date('Y-m-d'); }

/** '2026-08-30' → '30/08/2026' */
function data_it(?string $iso): string
{
    if (!$iso) return '';
    $t = strtotime($iso);
    return $t ? date('d/m/Y', $t) : $iso;
}

/** '2026-08-30' → 'domenica 30 agosto 2026' (senza dipendere dall'estensione intl) */
function data_lunga(?string $iso, bool $anno = true): string
{
    if (!$iso) return '';
    $t = strtotime($iso);
    if (!$t) return $iso;
    $giorni = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
    $mesi = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
    return $giorni[(int) date('w', $t)] . ' ' . (int) date('j', $t) . ' ' . $mesi[(int) date('n', $t) - 1] . ($anno ? ' ' . date('Y', $t) : '');
}

function mese_it(int $m, bool $breve = false): string
{
    $mesi = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
    $n = $mesi[$m - 1];
    return $breve ? ucfirst(mb_substr($n, 0, 3)) : $n;
}

function eta(?string $nascita): ?int
{
    if (!$nascita) return null;
    $n = new DateTime($nascita); $t = new DateTime('today');
    return $n->diff($t)->y;
}

function euro(float|int|string|null $n): string
{
    return '€ ' . number_format((float) $n, 2, ',', '.');
}

function nome_completo(array $p): string
{
    return trim(($p['nome'] ?? '') . ' ' . ($p['cognome'] ?? ''));
}

function iniziali(string $nome): string
{
    $parts = preg_split('/\s+/', trim($nome)) ?: [];
    $s = '';
    foreach ($parts as $w) { if ($w !== '') $s .= mb_substr($w, 0, 1); }
    return mb_strtoupper(mb_substr($s, 0, 2));
}

/** Decodifica sicura di un campo JSON salvato come testo */
function json_arr(mixed $s): array
{
    if (is_array($s)) return $s;
    if (!is_string($s) || $s === '') return [];
    $d = json_decode($s, true);
    return is_array($d) ? $d : [];
}

function json_txt(mixed $v): string
{
    return json_encode($v ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

/** Lista separata da virgola → array pulito */
function lista_da_testo(?string $s): array
{
    return array_values(array_filter(array_map('trim', explode(',', (string) $s)), fn($x) => $x !== ''));
}

/** Converte un valore numerico in formato italiano o mascherato ("€ 1.234,50", "1.234,50", "1234.5") in float */
/** HTML "rich" ripulito: solo i tag dell'editor, niente attributi (link sicuri esclusi) e niente script */
function rich_txt(?string $v): string
{
    $v = trim((string) $v);
    if ($v === '') return '';
    $v = preg_replace('#<(script|style)\b[^>]*>.*?</\1>#is', '', $v);
    $v = strip_tags($v, '<b><strong><i><em><u><p><br><div><ul><ol><li><h3><a><hr>');
    $v = preg_replace('/\son\w+\s*=\s*("[^"]*"|\x27[^\x27]*\x27|[^\s>]+)/i', '', $v);
    $v = preg_replace_callback('/<a\b([^>]*)>/i', function ($m) {
        return preg_match('/href\s*=\s*("(https?:\/\/|mailto:)[^"]*"|\x27(https?:\/\/|mailto:)[^\x27]*\x27)/i', $m[1], $h)
            ? '<a href=' . $h[1] . ' target="_blank" rel="noopener">' : '<a>';
    }, $v);
    return $v;
}

function numero(mixed $v): float
{
    if (is_int($v) || is_float($v)) return (float) $v;
    $s = trim((string) $v);
    if ($s === '') return 0.0;
    $s = preg_replace('/[^\d,.\-]/', '', $s);
    if (str_contains($s, ',')) $s = str_replace('.', '', $s);   // separatore delle migliaia
    $s = str_replace(',', '.', $s);
    return is_numeric($s) ? (float) $s : 0.0;
}

/** La richiesta corrente è arrivata in HTTPS (direttamente o tramite un proxy/bilanciatore che lo dichiara)? */
function drf_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') return true;
    if ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443) return true;
    return strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}
