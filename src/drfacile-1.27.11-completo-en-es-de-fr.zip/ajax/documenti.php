<?php
/**
 * Documenti: apertura (PDF, con link FIRMATO e a scadenza), file archiviati, archivio.
 * L'id da solo non apre nulla: il client chiede un link con `link` (POST) e lo apre; il link vale 15 minuti
 * ed è legato allo studio e all'utente. Il permesso dipende dal tipo (referti.leggi, fatture.leggi…).
 *   render → PDF inline (aggiungi &html=1 per l'HTML stampabile di prima)
 */
require __DIR__ . '/../core/bootstrap.php';
$action = $_GET['action'] ?? '';
$negato = function (string $msg, int $code = 403): void { http_response_code($code); header('Content-Type: text/html; charset=utf-8'); echo '<p style="font-family:sans-serif;padding:30px">' . e($msg) . '</p>'; exit; };

if ($action === 'render') {
    Auth::requirePage();
    $tipo = (string) ($_GET['tipo'] ?? ''); $id = (string) ((int) ($_GET['id'] ?? 0));
    if (!Documenti::verifica('render', $tipo, $id, (int) ($_GET['exp'] ?? 0), (string) ($_GET['t'] ?? ''))) $negato('Link non valido o scaduto: riapri il documento dal programma.');
    if (!Auth::can(Documenti::permesso($tipo))) $negato('Non hai il permesso per vedere questo documento.');
    try {
        if ($tipo === 'fattura') Fattura::segnaStampata((int) $id);
        Attivita::registra('documento.aperto', 'documenti', (int) $id, "$tipo #$id");
        if (isset($_GET['html']) || !Documenti::pdfDisponibile()) { echo Documenti::render($tipo, (int) $id, isset($_GET['stampa'])); exit; }
        ob_start();   // eventuali avvisi di dompdf non devono sporcare il PDF né bloccare gli header
        try { $pdf = Documenti::pdf($tipo, (int) $id); } finally { $rumore = ob_get_clean(); }
        if ($rumore !== '' && Config::get('app.debug')) error_log('dompdf: ' . strip_tags($rumore));
        header('Content-Type: application/pdf');
        header('Content-Disposition: ' . (isset($_GET['scarica']) ? 'attachment' : 'inline') . '; filename="' . $tipo . '-' . $id . '.pdf"');
        header('Content-Length: ' . strlen($pdf)); header('Cache-Control: private, no-store');
        echo $pdf;
    } catch (Throwable $e) { $negato($e->getMessage(), 404); }
    exit;
}
if ($action === 'file') {
    Auth::requirePage();
    $rel = (string) ($_GET['f'] ?? '');
    if (!Documenti::verifica('file', '', $rel, (int) ($_GET['exp'] ?? 0), (string) ($_GET['t'] ?? ''))) $negato('Link non valido o scaduto: riapri il documento dal programma.');
    $tipo = explode('/', $rel)[0] ?? '';
    if (!Auth::can(Documenti::permesso($tipo))) $negato('Non hai il permesso per vedere questo documento.');
    $path = Spazio::percorso($rel);
    if (!$path || !is_file($path)) $negato('Documento non trovato', 404);
    $mime = ['pdf' => 'application/pdf', 'html' => 'text/html; charset=utf-8', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'txt' => 'text/plain; charset=utf-8'][strtolower(pathinfo($path, PATHINFO_EXTENSION))] ?? 'application/octet-stream';
    header('Content-Type: ' . $mime); header('Content-Length: ' . filesize($path)); header('Cache-Control: private, no-store');
    header('Content-Disposition: ' . (isset($_GET['scarica']) || $mime === 'application/octet-stream' ? 'attachment' : 'inline') . '; filename="' . basename($path) . '"');
    readfile($path); exit;
}

Api::run([
    // il client chiede QUI il link (firmato, 15 minuti) e lo apre: DRF.doc.apri(tipo, id) / DRF.doc.file(rel)
    'link' => function (array $in) {
        $tipo = Api::str($in, 'tipo'); $file = Api::str($in, 'file');
        if ($file !== '') { if (!Auth::can(Documenti::permesso(explode('/', $file)[0] ?? ''))) throw new ApiException(__('Permesso negato'), 403); return ['url' => Documenti::link('file', '', $file)]; }
        if (!isset(Documenti::tipi()[$tipo])) throw new ApiException(__('Tipo documento non valido'));
        if (!Auth::can(Documenti::permesso($tipo))) throw new ApiException(__('Non hai il permesso per questo documento'), 403);
        return ['url' => Documenti::link('render', $tipo, (string) Api::int($in, 'id'))];
    },
    // finestra di invio: i modelli disponibili per l'uso e l'anteprima compilata
    'modelli' => function (array $in) {
        $per = Api::str($in, 'per') ?: 'generico'; $tipo = Api::str($in, 'tipo'); $id = Api::int($in, 'id');
        $paz = null; $ctx = [];
        if ($tipo && $id) { $d = Documenti::dati($tipo, $id); $paz = $d['paziente'] ?? null; $ctx = ['documento' => Documenti::etichetta($tipo, $d), 'data' => $d['doc']['data'] ?? oggi(), 'numero' => $d['doc']['numero'] ?? '', 'importo' => $d['doc']['totale'] ?? null, 'medico' => $d['medico']['nome_completo'] ?? null]; }
        elseif ($pid = Api::int($in, 'paziente_id')) { $paz = Paziente::find($pid); $ctx = ['documento' => Api::str($in, 'documento')]; }
        $vars = Messaggi::variabili($paz, $ctx, $per);
        $out = [];
        foreach (Messaggi::elenco('email', $per) as $m) { $c = Messaggi::compila($m['codice'], 'email', $vars); $out[] = ['codice' => $m['codice'], 'descrizione' => $m['descrizione'], 'per_tipo' => $m['per_tipo'], 'oggetto' => $c['oggetto'], 'testo' => $c['testo']]; }
        return ['modelli' => $out, 'email' => $paz['email'] ?? '', 'paziente' => $paz['nome_completo'] ?? '', 'driver' => Config::get('comunicazioni.email.driver', 'log')];
    },
    'invia' => fn(array $in) => ['id' => Documenti::inviaEmail(Api::str($in, 'email'), Api::str($in, 'tipo') ?: null, Api::int($in, 'id') ?: null, Api::str($in, 'file') ?: null, Api::str($in, 'modello'), $in['oggetto'] ?? null, $in['testo'] ?? null, Api::int($in, 'paziente_id') ?: null),
        'messaggio' => Config::get('comunicazioni.email.driver', 'log') === 'log' ? 'Email registrata (driver log: nessun invio reale)' : 'Email inviata a ' . Api::str($in, 'email')],
    'archivia' => fn(array $in) => ['file' => Documenti::archivia(Api::str($in, 'tipo'), Api::int($in, 'id')), 'messaggio' => __('Documento archiviato')],
    'archivio' => fn() => Documenti::archivio(),
    'spazio' => fn() => Spazio::stato(),
], ['*' => 'documenti.leggi', 'link' => null, 'modelli' => null, 'invia' => 'comunicazioni.invia', 'archivia' => 'documenti.modifica']);
