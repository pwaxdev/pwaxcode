<?php
return [
    'title' => __('Nuova prenotazione'), 'title_edit' => __('Modifica prenotazione'),
    'endpoint' => 'agenda', 'action' => 'save', 'submit' => __('Prenota'), 'submit_edit' => __('Salva modifiche'),
    'model' => 'Appuntamento',
    'fields' => [
        ['name' => 'nuovo_paziente', 'label' => __('Paziente non ancora in archivio'), 'type' => 'switch', 'default' => 0, 'help' => __('Crea la scheda al volo con i dati minimi: prima della visita il programma inviterà a completarla')],
        ['name' => 'paziente_id', 'label' => __('Paziente'), 'type' => 'select', 'empty' => __('Seleziona…'), 'options' => fn() => Paziente::optionsMap(), 'show_if' => '!nuovo_paziente'],
        ['name' => 'nuovo_cognome', 'label' => __('Cognome'), 'type' => 'text', 'row' => 5, 'show_if' => 'nuovo_paziente'],
        ['name' => 'nuovo_nome', 'label' => __('Nome'), 'type' => 'text', 'row' => 5, 'show_if' => 'nuovo_paziente'],
        ['name' => 'nuovo_telefono', 'label' => __('Telefono / cellulare'), 'type' => 'text', 'row' => 6, 'show_if' => 'nuovo_paziente'],
        ['name' => 'nuovo_email', 'label' => __('Email (facoltativa)'), 'type' => 'text', 'row' => 6, 'show_if' => 'nuovo_paziente'],
        ['name' => 'data', 'label' => __('Data'), 'type' => 'date', 'required' => true, 'default' => date('Y-m-d'), 'row' => 1],
        ['name' => 'ora', 'label' => __('Ora'), 'type' => 'time', 'required' => true, 'default' => '09:00', 'attrs' => ['step' => 900], 'row' => 1],
        ['name' => 'tipo', 'label' => __('Prestazione'), 'type' => 'select', 'options' => fn() => Appuntamento::tipiNomi(), 'default' => fn() => (string) array_key_first(Appuntamento::tipi()), 'row' => 2, 'help' => __('Durata e colore arrivano dal listino (Archivi → Prestazioni)')],
        ['name' => 'durata', 'label' => __('Durata'), 'type' => 'select', 'options' => [10 => __('10 min'), 15 => __('15 min'), 20 => __('20 min'), 30 => __('30 min'), 45 => __('45 min'), 60 => __('60 min'), 90 => __('90 min')], 'default' => Impostazione::get('pref_durata', '30'), 'row' => 2],
        ['name' => 'note', 'label' => __('Motivo'), 'type' => 'textarea', 'placeholder' => __('Motivo della visita, indicazioni per il paziente…')],
        ['name' => 'urgente', 'label' => __('Urgente'), 'type' => 'switch', 'default' => 0, 'help' => __('Evidenziato in agenda e nella Scrivania')],
    ],
];
