/* Modulo Procedure: voci definite in core/procedure.php. Ogni voce apre un archivio (CRUD standard) o una procedura (form + esecuzione). */
DRF.register('procedure', (function ($) {
  'use strict';
  const I = DRF.icons.html;
  const st = { voci: [], sel: null, voce: null, crud: null };

  function loadElenco() {
    return DRF.api.get('procedure', 'elenco').then(v => {
      st.voci = v; if (!st.sel && v.length) st.sel = v[0].key;
      if (!v.length) { st.sel = null; $('#procArchivio, #procProcedura, #procResult, #procVista').prop('hidden', true); $('#procVuoto').prop('hidden', false).html('<div class="empty">' + DRF.__('Nessuna voce disponibile per il tuo ruolo.') + '</div>'); }
      $('#procList').html(v.map(a => `<div class="arow ${a.key === st.sel ? 'on' : ''}" data-v="${a.key}"><span class="ib">${I(a.fi, a.fa)}</span><div><b>${DRF.esc(a.label)}</b><span>${DRF.esc(a.desc)}</span></div>${DRF.ui.badge({ archivio: 'violet', procedura: 'sky', vista: 'mint' }[a.tipo] || 'gray', { archivio: 'archivio', procedura: 'procedura', vista: 'pagina' }[a.tipo] || '—')}</div>`).join(''));
      DRF.icons.apply($('#procList')[0]);
      DRF.nav.refreshSub();
    });
  }
  function apri() {
    if (!st.sel) return $.Deferred().resolve().promise();   // nessuna voce (ruolo senza permessi): niente da aprire
    if (st.crud) { st.crud.destroy(); st.crud = null; }
    $('#procArchivio, #procProcedura, #procVuoto, #procResult, #procVista').prop('hidden', true); $('#procHead').empty(); $('#procVista').empty();
    return DRF.api.get('procedure', 'voce', { voce: st.sel }).then(v => {
      st.voce = v;
      if (v.tipo === 'archivio') { $('#procArchivio').prop('hidden', false); st.crud = DRF.crud.mount({ head: $('#procHead'), table: $('#procTable'), archivio: v.archivio }); }
      else if (v.tipo === 'procedura') {
        $('#procHead').html(`<div><h2>${DRF.esc(v.form.title)}</h2><p>${DRF.esc(v.form.desc)}</p></div>`);
        $('#procForm').html(v.form.html); DRF.ui.wire($('#procForm')[0]); DRF.icons.apply($('#procForm')[0]);
        $('#procRun').html(`${I('play', 'fa-solid fa-play')}<span>${DRF.esc(v.form.pulsante)}</span>`); DRF.icons.apply($('#procRun')[0]);
        $('#procProcedura').prop('hidden', false);
      } else if (v.tipo === 'vista') {
        $('#procHead').html(`<div><h2>${DRF.esc(v.label)}</h2><p>${DRF.esc(v.desc)}</p></div>`);
        return DRF.api.get('procedure', 'vista', { voce: st.sel }).then(r => { const $v = $('#procVista').html(r.html).prop('hidden', false); DRF.ui.wire($v[0]); DRF.icons.apply($v[0]); if (M.viste[r.vista]) M.viste[r.vista]($v); DRF.nav.updateTopbar(); });
      } else { $('#procHead').html(`<div><h2>${DRF.esc(v.label)}</h2><p>${DRF.esc(v.desc)}</p></div>`); $('#procVuoto').prop('hidden', false); }
      DRF.nav.updateTopbar();
    });
  }
  function esegui() {
    const data = Object.assign(DRF.ui.formData($('#procForm')), { voce: st.sel });
    $('#procRun').prop('disabled', true);
    DRF.api.post('procedure', 'esegui', data).then(r => {
      $('#procResultTitle').text(r.titolo || DRF.__('Risultato')); $('#procResultBody').html(r.html || ''); $('#procResult').prop('hidden', false);
      DRF.icons.apply($('#procResultBody')[0]); DRF.ui.wire($('#procResultBody')[0]);
      DRF.sound.play('success');
    }).always(() => $('#procRun').prop('disabled', false));
  }

  const M = {
    title: DRF.__('Procedure'),
    /** Pagine libere (tipo "vista"): nome → funzione che riceve il contenitore già riempito con views/procedure/<nome>.php */
    viste: {},
    sub() { return `${st.voci.length} ${DRF.__('voci · archivi e procedure dello studio')}`; },
    get action() { return st.voce && st.voce.tipo === 'archivio' ? { label: DRF.__('Aggiungi voce'), fi: 'plus', fa: 'fa-solid fa-plus', run: () => st.crud && st.crud.nuovo() } : st.voce && st.voce.tipo === 'procedura' ? { label: st.voce.form.pulsante, fi: 'play', fa: 'fa-solid fa-play', run: esegui } : null; },
    init() {
      $('#procList').on('click', '.arow', function () { st.sel = this.dataset.v; $('#procList .arow').removeClass('on'); $(this).addClass('on'); apri(); });
      $('#procRun').on('click', esegui);
      $('#procForm').on('submit', e => { e.preventDefault(); esegui(); });
      $('#procResultBody').on('click', '[data-copia]', function () { navigator.clipboard && navigator.clipboard.writeText(this.dataset.copia); DRF.ui.toast(DRF.__('Messaggio copiato'), 'info'); });
    },
    show(opts) { if (opts && opts.voce) st.sel = opts.voce; loadElenco().then(apri); }
  };

  /* ---------- Vista demo "controlli": ogni pulsante lancia un controllo e mostra il codice usato ---------- */
  /* --- Contabilità (estensione Commercialista): riepilogo ed esportazione --- */
  M.viste.contabilita = function ($root) {
    const MESI = DRF.util.mesi();   // nomi dei mesi nella lingua dell'utente
    const iso = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    // ultimi 18 mesi nel selettore
    const $mese = $root.find('#ctbMese'); const oggi = new Date();
    for (let i = 0; i < 18; i++) { const d = new Date(oggi.getFullYear(), oggi.getMonth() - i, 1); $mese.append(`<option value="${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}">${MESI[d.getMonth()]} ${d.getFullYear()}</option>`); }
    const primo = new Date(oggi.getFullYear(), oggi.getMonth(), 1);
    DRF.ui.setVal($root.find('#ctbDa'), iso(primo)); DRF.ui.setVal($root.find('#ctbA'), DRF.util.todayIso());
    $mese.val(`${oggi.getFullYear()}-${String(oggi.getMonth() + 1).padStart(2, '0')}`);

    const riepilogo = () => DRF.api.get('contabilita', 'riepilogo', { da: DRF.ui.val($root.find('#ctbDa')), a: DRF.ui.val($root.find('#ctbA')) }).then(d => {
      const E = DRF.util.eur;
      $root.find('#ctbTiles').html(d.n === 0 ? '<div class="small muted" style="grid-column:1/-1">' + DRF.__('Nessuna fattura nel periodo.') + '</div>' : `
        <div class="ctb-tile"><span>${DRF.__('Fatture')}</span><b>${d.n}</b></div>
        <div class="ctb-tile"><span>${DRF.__('Imponibile')}</span><b>${E(d.imponibile)}</b></div>
        <div class="ctb-tile"><span>IVA</span><b>${E(d.iva)}</b></div>
        <div class="ctb-tile ok"><span>${DRF.__('Incassato')}</span><b>${E(d.incassato)}</b></div>
        <div class="ctb-tile warn"><span>${DRF.__('In attesa (')}${d.attesa_n})</span><b>${E(d.attesa_importo)}</b></div>
        <div class="ctb-tile"><span>${DRF.__('Totale')}</span><b>${E(d.totale)}</b></div>`);
      const $t = $root.find('#ctbIva').prop('hidden', d.n === 0 || !d.aliquote.length);
      $t.find('tbody').html(d.aliquote.map(a => `<tr><td>${a.aliquota ? a.aliquota + '%' : DRF.__('Esente')}</td><td>${a.n}</td><td>${E(a.imponibile)}</td><td>${E(a.imposta)}</td></tr>`).join(''));
      $root.find('#ctbNote').text(d.n === 0 ? '' : [d.bollo > 0 ? `${DRF.__('Bolli:')} ${E(d.bollo)}` : '', d.contributi > 0 ? `${DRF.__('Contributi cassa:')} ${E(d.contributi)}` : '', d.opposizioni ? `${d.opposizioni} ${DRF.__('fatture con opposizione al Sistema TS')}` : ''].filter(Boolean).join(' · '));
    });
    $mese.on('change', function () {
      if (!this.value) return;
      const [y, m] = this.value.split('-').map(Number);
      DRF.ui.setVal($root.find('#ctbDa'), iso(new Date(y, m - 1, 1)));
      DRF.ui.setVal($root.find('#ctbA'), iso(new Date(y, m, 0)));
      riepilogo();
    });
    $root.on('change', '#ctbDa, #ctbA', () => { $mese.val(''); riepilogo(); });
    $root.find('#ctbEsporta').on('click', () => {
      window.open(`ajax/contabilita.php?action=zip&da=${DRF.ui.val($root.find('#ctbDa'))}&a=${DRF.ui.val($root.find('#ctbA'))}`, '_blank');
      $root.find('#ctbEsito').text(DRF.__('Archivio in preparazione: parte il download.'));
    });
    riepilogo();
  };

  /* --- Voce 4: l'editor DRF.rich dal vivo --- */
  M.viste.editor = function ($root) {
    // moduli di esempio, registrati qui (quattro righe ciascuno)
    DRF.rich.use({ name: 'separatore', button: { fi: 'minus', fa: 'fa-solid fa-minus', title: DRF.__('Separatore') }, run: ed => ed.insertHTML('<hr>') });
    DRF.rich.use({ name: 'evidenzia', button: { fi: 'highlighter', fa: 'fa-solid fa-highlighter', title: DRF.__('Evidenzia') }, run: ed => ed.exec('hiliteColor', '#FBEB9B') });

    const CAMPI = ['paziente', 'prestazione', 'data', 'ora', 'medico', 'studio'];
    DRF.rich.mount($root.find('#edBase'), { moduli: false, height: 130, value: '<p>Questo è l\'editor <b>DRF.rich</b>' + DRF.__(': prova la barra qui sopra, i tasti') + ' <u>⌘B</u>' + DRF.__(', gli elenchi…') + '</p>' });
    const edC = DRF.rich.mount($root.find('#edCampi'), { moduli: false, height: 130, campi: CAMPI,
      value: '<p>' + DRF.__('Gentile {paziente},') + '</p><p>' + DRF.__('la aspettiamo per') + ' <b>{prestazione}</b> il {data} alle {ora}.</p><p>{medico} · {studio}</p>' });
    DRF.rich.mount($root.find('#edModuli'), { height: 120, campi: ['paziente'], value: '<p>' + DRF.__('Qui la barra ha anche i pulsanti dei moduli →') + '</p>' });

    const PROVA = { paziente: 'Giulia Ferrari', prestazione: 'Ecografia addome', data: '12/09/2026', ora: '10:30', medico: (DRF.config.medico || {}).nome_completo || 'Dr. Rossi', studio: (DRF.config.medico || {}).studio || 'Studio medico' };
    $root.on('click', '[data-ed]', function () {
      const k = this.dataset.ed;
      if (k === 'valore') DRF.ui.modal({ title: 'Valore serializzato (ed.get())', size: 'lg', ok: false, cancel: DRF.__('Chiudi'), html: `<pre style="white-space:pre-wrap;font-size:12px;line-height:1.6">${DRF.esc(edC.get() || '(vuoto)')}</pre>` });
      if (k === 'anteprima') { let h = edC.get(); Object.keys(PROVA).forEach(c => h = h.split('{' + c + '}').join('<b>' + DRF.esc(PROVA[c]) + '</b>')); DRF.ui.modal({ title: DRF.__('Anteprima con dati di prova'), size: 'lg', ok: false, cancel: DRF.__('Chiudi'), html: `<div style="line-height:1.7">${h}</div>` }); }
      if (k === 'campo') { edC.insertCampo('data'); }
      if (k === 'prestazione') DRF.api.get('archivi', 'list', { archivio: 'prestazioni' }).then(d => { const p = d.righe.find(r => r.nome === 'Ecografia') || d.righe[0]; if (p) DRF.form.open('prestazione', { id: p.id }); });
    });
    $root.on('click', '[data-code]', function () { const $p = $(this).closest('.ctl').find('pre'); $p.prop('hidden', !$p.prop('hidden')); });
  };

  M.viste.controlli = function ($root) {
    const log = (t, v) => { const $l = $root.find('#ctlLog'); $l.prepend(`<div><span class="mono muted">${new Date().toLocaleTimeString(DRF.util.loc())}</span> <b>${DRF.esc(t)}</b> → <span class="mono">${DRF.esc(typeof v === 'string' ? v : JSON.stringify(v))}</span></div>`); };
    const azioni = {
      modal_sm: () => DRF.ui.modal({ title: DRF.__('Modale piccola'), html: '<p>' + DRF.__('Un contenuto qualsiasi: testo, campi, tabelle.') + '</p><div class="field" style="margin-top:12px"><label>' + DRF.__('Un campo') + '</label><input class="input" name="demo" placeholder="' + DRF.__('Scrivi qualcosa') + '"></div>', ok: 'OK', cancel: DRF.__('Chiudi'), onOk: $b => { if (!$b.find('[name=demo]').val()) { DRF.ui.toast(DRF.__('Compila il campo prima di confermare'), 'warn'); return false; } } }).then(ok => log('modal (piccola)', ok ? 'OK' : 'chiusa')),
      modal_lg: () => DRF.ui.modal({ title: DRF.__('Modale grande'), size: 'lg', html: `<p class="muted small" style="margin-bottom:12px">${DRF.__('Le modali grandi ospitano tabelle, griglie di campi, anteprime.')}</p><div class="grid12"><div class="field" style="grid-column:span 6"><label>${DRF.__('Paziente')}</label><select class="select" name="p"><option value="">${DRF.__('Seleziona…')}</option><option>Marco Bianchi</option><option>Anna Russo</option></select></div><div class="field" style="grid-column:span 3"><label>${DRF.__('Data')}</label><input class="input" type="date" name="d"></div><div class="field" style="grid-column:span 3"><label>${DRF.__('Importo')}</label><input class="input" name="i" data-mask="euros" value="120"></div></div><table class="dt" id="ctlModalTable" style="width:100%;margin-top:14px"><thead><tr><th></th><th>${DRF.__('Voce')}</th><th>${DRF.__('Valore')}</th></tr></thead><tbody></tbody></table>`,
        onOpen: $b => DRF.ui.datatable($b.find('#ctlModalTable'), { paging: false, searching: false, info: false, layout: { topStart: null, topEnd: null, bottomStart: null, bottomEnd: null }, data: [['Prestazioni', 5], ['Farmaci', 8], ['Esami', 15]], columns: [{ data: null, orderable: false, className: 'dt-actions', render: () => `<button class="icon-btn sm" type="button">${DRF.icons.html('pencil', 'fa-solid fa-pen')}</button>` }, { data: 0 }, { data: 1, className: 'dt-num' }] }) }).then(ok => log('modal (grande)', ok ? 'OK' : 'chiusa')),
      conf2: () => DRF.ui.confirm(DRF.__('Sei sicuro?'), DRF.__('L\'operazione non può essere annullata.'), DRF.__('Sì, procedi')).then(ok => log('confirm', ok)),
      conf3: () => DRF.ui.confirm3(DRF.__('Salvare le modifiche?'), DRF.__('Hai modifiche non salvate nella scheda.'), { si: DRF.__('Salva'), no: DRF.__('Non salvare'), annulla: DRF.__('Annulla') }).then(k => log('confirm3', k)),
      alert: () => DRF.ui.alert(DRF.__('Operazione completata'), DRF.__('Il documento è stato archiviato correttamente.'), 'success').then(() => log('alert', 'ok')),
      dialog: () => DRF.ui.dialog({ title: DRF.__('Come vuoi procedere?'), text: DRF.__('Un messaggio può avere quanti pulsanti servono.'), kind: 'warn', buttons: [{ k: 'stampa', label: DRF.__('Stampa'), cls: 'ghost' }, { k: 'pdf', label: DRF.__('Salva PDF'), cls: 'soft' }, { k: 'invia', label: DRF.__('Invia'), cls: 'primary' }] }).then(k => log('dialog', k)),
      toast_ok: () => DRF.ui.toast(DRF.__('Salvato correttamente'), 'success'), toast_warn: () => DRF.ui.toast(DRF.__('Attenzione: controlla i dati'), 'warn'), toast_err: () => DRF.ui.toast(DRF.__('Errore: impossibile salvare'), 'error'), toast_info: () => DRF.ui.toast(DRF.__('Informazione'), 'info'), toast_ico: () => DRF.ui.toast(DRF.__('Icona personalizzata'), { fi: 'paper-plane', fa: 'fa-regular fa-paper-plane' }),
      sheet: () => DRF.ui.openSheet(DRF.__('Pannello laterale'), '<div class="field"><label>' + DRF.__('Nome') + '</label><input class="input" name="n"></div><div class="field"><label>' + DRF.__('Note') + '</label><textarea class="textarea" name="note"></textarea></div>', () => { log('sheet', DRF.ui.formData($('#sheetBody'))); DRF.ui.closeSheet(); }, DRF.__('Salva')),
      form: () => DRF.form.open('prestazione', { onSaved: r => log('form (FormBuilder)', r) }),
      form_paz: () => DRF.form.open('paziente', { values: { cognome: 'Rossi', nome: 'Mario' }, onSaved: r => log('form paziente', r.id) }),
      postit: () => { DRF.postit.nuovo(DRF.__('Ricordati di…')); log('postit', 'nuovo post-it nel contesto corrente'); },
      scrivania: () => { DRF.desk.open(); log('desk', 'aperta'); },
      ntf_ok: () => DRF.notify.add({ tipo: 'success', titolo: DRF.__('Operazione completata'), testo: 'Esempio di notifica di successo' }).then(r => log('notify.add', r.id)),
      ntf_warn: () => DRF.notify.add({ tipo: 'warn', titolo: DRF.__('Controlla i dati'), testo: 'Esempio di avviso' }).then(r => log('notify.add', r.id)),
      ntf_err: () => DRF.notify.add({ tipo: 'error', titolo: DRF.__('Fattura scaduta'), testo: DRF.__('Cliccando la notifica si apre la Fatturazione'), link: { modulo: 'fatture' } }).then(r => log('notify.add', r.id)),
      ntf_centro: () => DRF.notify.centro(),
      steps_ok: () => simStep(false), steps_err: () => simStep(true),
      toast_undo: () => DRF.ui.toast(DRF.__('Elemento eliminato'), 'info', { undo: () => log('toast undo', 'ripristinato!') }),
      palette: () => { $('#searchInput').val('nuova').trigger('focus').trigger('input'); log('palette', 'scrivi un comando o un paziente'); },
      keys: () => DRF.app.scorciatoie(),
      evento: () => { const off = DRF.on('demo:evento', d => log('DRF.on(\'demo:evento\')', d)); DRF.emit('demo:evento', { ciao: 'mondo', quando: new Date().toLocaleTimeString(DRF.util.loc()) }); },
      menu_btn: () => DRF.menu.showAt($root.find('[data-ctl=menu_btn]'), [
        { label: DRF.__('Modifica'), fi: 'pencil', fa: 'fa-solid fa-pen', kbd: 'E', run: () => log('menu', 'Modifica') },
        { label: DRF.__('Duplica'), fi: 'copy', fa: 'fa-regular fa-copy', run: () => log('menu', 'Duplica') },
        { label: DRF.__('Non disponibile'), fi: 'lock', fa: 'fa-solid fa-lock', disabled: true },
        { sep: true },
        { label: DRF.__('Elimina'), fi: 'trash', fa: 'fa-solid fa-trash', danger: true, kbd: 'Canc', run: () => log('menu', 'Elimina') },
      ], { title: DRF.__('Azioni') }),
      suono: () => { ['click', 'notify', 'success', 'error'].forEach((s, i) => setTimeout(() => DRF.sound.play(s), i * 450)); log('sound', 'click → notify → success → error'); },
      vai: () => DRF.nav.go('pazienti', { select: 1 }),
      lettura: () => DRF.api.get('agenda', 'giorno').then(d => log('api.get agenda/giorno', `${d.appuntamenti.length} ${DRF.__('appuntamenti,')} ${d.n_oggi} ${DRF.__('oggi')}`)),
    };
    /** simulazione dell'invio di una ricetta con la barra dei passi in modale */
    function simStep(errore) {
      let s; const passi = [{ label: DRF.__('Firma'), desc: 'firma digitale', fi: 'document-signed', fa: 'fa-solid fa-file-signature' }, { label: 'Invio', desc: DRF.__('Sistema TS'), fi: 'paper-plane', fa: 'fa-regular fa-paper-plane' }, { label: 'NRE', desc: DRF.__('ricezione codice'), fi: 'barcode', fa: 'fa-solid fa-barcode' }, { label: DRF.__('Promemoria'), desc: 'stampa', fi: 'print', fa: 'fa-solid fa-print' }];
      DRF.ui.modal({ title: DRF.__('Invio ricetta al Sistema TS'), ok: DRF.__('Riprova'), cancel: DRF.__('Chiudi'), html: '<div id="ctlSteps"></div><p id="ctlStepMsg" class="small muted" style="text-align:center;margin-top:16px">' + DRF.__('Firma in corso…') + '</p>', onOpen($b) { s = DRF.ui.steps($b.find('#ctlSteps'), { steps: passi, current: 0 }); $('#modalOk').prop('disabled', true); }, onOk() { simStep(false); } }).then(ok => log('steps (modale)', ok ? 'riprova' : 'chiusa'));
      const msg = t => $('#ctlStepMsg').text(t);
      setTimeout(() => { s.set(1); msg(DRF.__('Invio in corso…')); }, 700);
      setTimeout(() => { if (errore) { s.error(1, DRF.__('Timeout del servizio')); msg(DRF.__('Il Sistema TS non ha risposto: puoi riprovare.')); $('#modalOk').prop('disabled', false); } else { s.set(2); msg('NRE ricevuto: 050A 1234 5678 91'); } }, 1500);
      if (!errore) setTimeout(() => { s.done(); msg(DRF.__('Completato: promemoria pronto per la stampa.')); }, 2300);
    }
    // timeline di esempio
    const tl = [
      { data: '2026-06-28', tipo: 'Anamnesi', titolo: DRF.__('Anamnesi'), testo: 'Ipertensione in famiglia, non fumatore', fi: 'notebook', fa: 'fa-regular fa-clipboard', colore: 'var(--ink-3)', run: it => log('timeline', it.titolo) },
      { data: '2026-06-29', tipo: 'Visite', titolo: DRF.__('Visita'), testo: 'Peso 85 kg · IMC 26,2 · PA 92/130 · FC 90', fi: 'stethoscope', fa: 'fa-solid fa-stethoscope', colore: 'var(--accent)', run: it => log('timeline', it.titolo) },
      { data: '2026-06-29', tipo: 'Esami', titolo: 'Esami ematochimici', testo: 'eGFR 66 · LDL 67', fi: 'test-tube', fa: 'fa-solid fa-vial', colore: '#8A2BE2', run: it => log('timeline', it.titolo) },
      { data: '2026-06-29', tipo: 'Terapia', titolo: 'Piano terapeutico', testo: 'Cardioaspirin', fi: 'capsules', fa: 'fa-solid fa-pills', colore: '#7B1FA2' },
      { data: '2026-07-14', tipo: 'Terapia', titolo: 'Piano terapeutico', testo: 'Cardioaspirin, Oki', fi: 'capsules', fa: 'fa-solid fa-pills', colore: '#7B1FA2' },
      { data: '2026-07-14', tipo: 'Complicanze', titolo: 'Nefropatia: rischio moderato', fi: 'exclamation', fa: 'fa-solid fa-triangle-exclamation', colore: 'var(--sky)', run: it => log('timeline', it.titolo) },
      { data: '2025-11-02', tipo: 'Controllo', titolo: DRF.__('Controllo'), testo: 'Esami nella norma', fi: 'stethoscope', fa: 'fa-solid fa-stethoscope', colore: 'var(--mint)' },
    ];
    const drawTl = () => DRF.ui.timeline($root.find('#ctlTimeline').removeClass('alterna compatta'), tl, { compatta: DRF.ui.segValue($root.find('#ctlTlMode')) === 'compatta' });
    $root.find('#ctlTlMode').on('seg:change', drawTl); drawTl();
    $root.on('click', '[data-ctl]', function () { const a = azioni[this.dataset.ctl]; if (a) a(); });
    DRF.menu.bind($root, '[data-ctl-rc="1"]', () => [{ label: DRF.__('Apri'), fi: 'eye', fa: 'fa-regular fa-eye', run: () => log('menu (tasto destro)', 'Apri') }, { label: DRF.__('Stampa'), fi: 'print', fa: 'fa-solid fa-print', run: () => log('menu (tasto destro)', 'Stampa') }, { sep: true }, { label: DRF.__('Elimina'), fi: 'trash', fa: 'fa-solid fa-trash', danger: true, run: () => log('menu (tasto destro)', 'Elimina') }], { title: 'Elemento 1' });
    DRF.menu.bind($root, '[data-ctl-rc="2"]', () => [{ label: DRF.__('Segna letta'), fi: 'check', fa: 'fa-solid fa-check', run: () => log('menu (tasto destro)', DRF.__('Segna letta')) }, { label: DRF.__('Archivia'), fi: 'archive', fa: 'fa-solid fa-box-archive', run: () => log('menu (tasto destro)', 'Archivia') }, { label: DRF.__('Blocca'), fi: 'lock', fa: 'fa-solid fa-lock', disabled: true }], { title: 'Elemento 2' });
    $root.on('click', '[data-code]', function () { const $c = $(this).closest('.ctl').find('pre'); $c.prop('hidden', !$c.prop('hidden')); });
    $root.find('#ctlValori').on('click', () => log('valori dei campi', { data: DRF.ui.val($root.find('[name=demo_data]')), importo: DRF.ui.val($root.find('[name=demo_euro]')), select: $root.find('[name=demo_sel]').val(), switch: $root.find('[name=demo_sw]').val(), seg: DRF.ui.segValue($root.find('#demoSeg')) }));
  };
  return M;
})(jQuery));
