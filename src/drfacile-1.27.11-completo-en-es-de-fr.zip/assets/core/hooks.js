/* DRF.hooks: gli hook lato client del sistema modulare.
   Le estensioni (estensioni/<codice>/js/*.js, caricati solo se l'estensione è attiva) si agganciano così:
     DRF.hooks.add('visita.pannello', ctx => { ... });          // evento: ctx = { $root, visita, paziente, api }
     DRF.hooks.add('punto.filtro', valore => valoreTrasformato); // filtro
   I punti disponibili sono documentati in docs/sviluppo-estensioni.md. */
DRF.hooks = (function () {
  'use strict';
  const reg = {};
  return {
    add(punto, fn, priorita) { (reg[punto] = reg[punto] || []).push({ fn, p: priorita || 10 }); reg[punto].sort((a, b) => a.p - b.p); },
    run(punto, ...args) { (reg[punto] || []).forEach(h => { try { h.fn(...args); } catch (e) { console.error('Hook ' + punto, e); } }); },
    filter(punto, valore, ...extra) { (reg[punto] || []).forEach(h => { try { valore = h.fn(valore, ...extra); } catch (e) { console.error('Hook ' + punto, e); } }); return valore; },
    has(punto) { return !!(reg[punto] || []).length; },
  };
})();
