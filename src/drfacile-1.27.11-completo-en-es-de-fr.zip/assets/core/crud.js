/* CRUD standard su un archivio definito in core/archivi.php: intestazione + DataTable (icone di azione nella prima colonna) + form dal FormBuilder.
   const crud = DRF.crud.mount({ head: $('#archHead'), table: $('#archTable'), archivio: 'prestazioni', onChange: () => {} });
   crud.reload(); crud.destroy(); */
DRF.crud = (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;
  const ENUM_I18N = {
    generico: DRF.__('generico'), referto: DRF.__('referto'), fattura: DRF.__('fattura'), ricetta: DRF.__('ricetta'), documento: DRF.__('documento'), file: DRF.__('file'),
    promemoria: DRF.__('promemoria'), recupero: DRF.__('recupero'), standard: DRF.__('standard'), email: DRF.__('email'), consensi: DRF.__('consensi'),
    Privacy: DRF.__('Privacy'), 'Consenso informato': DRF.__('Consenso informato'), FSE: DRF.__('FSE'), Marketing: DRF.__('Marketing'),
    Laboratorio: DRF.__('Laboratorio'), Strumentale: DRF.__('Strumentale'), Radiologia: DRF.__('Radiologia'), Specialistica: DRF.__('Specialistica')
  };
  const enumLabel = v => ENUM_I18N[String(v)] || String(v);
  function cell(tipo, v) {
    if (tipo === 'euro') return `<b class="num">${U.eur(v)}</b>`;
    if (tipo === 'min') return `<span class="num">${v == null ? '—' : v + ' min'}</span>`;
    if (tipo === 'perc') return `<b class="num">${(+v || 0).toLocaleString(DRF.util.loc(), { maximumFractionDigits: 2 })}%</b>`;
    if (tipo === 'gg') { const n = +v; return n ? `<span class="num">${n} ${DRF._n('giorno', 'giorni', n)}</span>` : '<span class="muted">' + DRF.__('subito') + '</span>'; }
    if (tipo === 'bool') return +v ? DRF.ui.badge('mint', DRF.__('Sì')) : DRF.ui.badge('gray', DRF.__('No'));
    if (tipo === 'color') return `<span class="swatch" style="background:${DRF.esc(v || '#ccc')}"></span><span class="mono">${DRF.esc(v || '')}</span>`;
    if (tipo === 'data') return v ? `<span class="num">${U.fmtIso(v)}</span>` : '—';
    if (tipo === 'badge') return v ? DRF.ui.badge('violet', enumLabel(v)) : '—';
    if (tipo === 'i18n') return v ? DRF.esc(enumLabel(v)) : '—';
    return DRF.esc(v == null || v === '' ? '—' : v);
  }
  function mount(o) {
    const st = { def: null, righe: [], dt: null };
    const $head = $(o.head), $table = $(o.table);
    function render() {
      const d = st.def;
      const extra = (o.extra || []).map((x, i) => `<button class="btn ${x.primary ? 'primary' : 'ghost'}" data-crud-extra="${i}" type="button">${I(x.fi, x.fa)}<span>${DRF.esc(x.label)}</span></button>`).join('');
      $head.html(`<div><h2>${DRF.esc(d.label)}</h2><p>${DRF.esc(d.desc)}</p></div>${extra}${o.senzaNuovo ? '' : `<button class="btn primary" data-crud-new type="button">${I('plus', 'fa-solid fa-plus')}<span>${DRF.__('Aggiungi')}</span></button>`}`);
      $head.off('click.extra').on('click.extra', '[data-crud-extra]', function () { const x = (o.extra || [])[+this.dataset.crudExtra]; if (x && x.run) x.run(); });
      DRF.icons.apply($head[0]);
      if (st.dt) { st.dt.destroy(); $table.empty().append('<thead></thead><tbody></tbody>'); st.dt = null; }
      $table.find('thead').html('<tr><th></th>' + d.columns.map(c => `<th>${DRF.esc(c[1])}</th>`).join('') + '</tr>');
      st.dt = DRF.ui.datatable($table, { data: st.righe, order: [[1, 'asc']], columns: [
        { data: 'id', orderable: false, searchable: false, className: 'dt-actions', render: id => `<button class="icon-btn sm" data-crud-edit="${id}" type="button" title="${DRF.__('Modifica')}">${I('pencil', 'fa-solid fa-pen')}</button><button class="icon-btn sm danger" data-crud-del="${id}" type="button" title="${DRF.__('Elimina')}">${I('trash', 'fa-solid fa-trash')}</button>` },
        ...d.columns.map(c => ({ data: c[0], type: c[2] === 'euro' || c[2] === 'min' || c[2] === 'perc' ? 'num' : 'string', className: c[2] === 'euro' || c[2] === 'min' || c[2] === 'perc' ? 'dt-num' : '', render: (v, t) => t === 'display' ? cell(c[2], v) : (v == null ? '' : v) })),
      ] });
    }
    function load() { return DRF.api.get('archivi', 'list', { archivio: o.archivio }).then(d => { st.def = d.archivio; st.righe = d.righe; render(); }); }
    function apri(id) { DRF.form.open(st.def.form, { id, onSaved: () => { load(); o.onChange && o.onChange(); } }); }
    $head.off('.crud').on('click.crud', '[data-crud-new]', () => apri());
    $table.off('.crud').on('click.crud', '[data-crud-edit]', function () { apri(+this.dataset.crudEdit); })
      .on('click.crud', '[data-crud-del]', function () { const id = +this.dataset.crudDel; DRF.ui.confirm(DRF.__('Eliminare la voce?'), DRF.__('La voce verrà rimossa dall\'archivio. I dati già registrati non vengono modificati.'), DRF.__('Elimina')).then(ok => { if (ok) DRF.api.post('archivi', 'delete', { archivio: o.archivio, id }).then(r => { DRF.ui.toast(r.messaggio); load(); o.onChange && o.onChange(); }); }); });
    load();
    return { reload: load, nuovo: () => apri(), destroy() { if (st.dt) { st.dt.destroy(); $table.empty(); st.dt = null; } $head.empty(); } };
  }
  return { mount, cell };
})(jQuery);
