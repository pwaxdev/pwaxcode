<?php
/** Scrivania: discovery dei moduli in modules/<key>/ (def + render), layout personale salvato nelle impostazioni */
final class Scrivania
{
    public static function moduli(): array
    {
        $out = [];
        // modules/<key>/ (core e app del Negozio distribuite con il programma) + estensioni/<codice>/modules/<key>/ (pacchetti dello Store)
        $cartelle = [];
        foreach (glob(DRF_ROOT . '/modules/*', GLOB_ONLYDIR) ?: [] as $d) $cartelle[] = [$d, 'modules/' . basename($d), null];
        foreach (array_keys(Estensioni::tutteAttive()) as $cod) {
            foreach (glob(DRF_ROOT . "/estensioni/$cod/modules/*", GLOB_ONLYDIR) ?: [] as $d) $cartelle[] = [$d, "estensioni/$cod/modules/" . basename($d), $cod];
        }
        foreach ($cartelle as [$dir, $rel, $cod]) {
            $key = basename($dir);
            if (!preg_match('/^[a-z0-9_]+$/', $key) || !is_file("$dir/$key.def") || !is_file("$dir/$key.php") || isset($out[$key])) continue;
            $def = self::def("$dir/$key.def");
            $ext = trim((string) ($def['estensione'] ?? $cod ?? ''));
            if ($ext !== '' && !Estensioni::attiva($ext)) continue;   // app dello Store: icona solo se l'estensione è attiva
            if (!empty($def['permesso']) && !Auth::can(trim((string) $def['permesso']))) continue;   // app riservate a un permesso (es. attivita.leggi, store.leggi)
            [$fi, $fa] = array_map('trim', explode('|', ($def['icona'] ?? 'cube | fa-solid fa-cube') . '|')) + [1 => 'fa-solid fa-cube'];
            $out[$key] = ['key' => $key, 'nome' => $def['nome'] ?? $key, 'descrizione' => $def['descrizione'] ?? '', 'fi' => $fi ?: 'cube', 'fa' => $fa ?: 'fa-solid fa-cube',
                'larghezza' => (int) ($def['larghezza'] ?? 360), 'altezza' => (int) ($def['altezza'] ?? 320), 'ridimensionabile' => !in_array(strtolower($def['ridimensionabile'] ?? 'si'), ['no', 'false', '0'], true),
                'css' => is_file("$dir/css/$key.css") ? "$rel/css/$key.css" : null, 'js' => is_file("$dir/js/$key.js") ? "$rel/js/$key.js" : null,
                'dir' => $dir, 'estensione' => $ext ?: null, 'categoria' => $def['categoria'] ?? null];
        }
        return $out;
    }

    private static function def(string $file): array
    {
        $d = [];
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
            $l = trim($l); if ($l === '' || $l[0] === '#' || !str_contains($l, ':')) continue;
            [$k, $v] = explode(':', $l, 2); $d[trim($k)] = trim($v);
        }
        return $d;
    }

    /** HTML del modulo (render) */
    public static function render(string $key): string
    {
        $m = self::moduli()[$key] ?? throw new ApiException(__('Modulo non trovato'), 404);
        require_once $m['dir'] . "/$key.php";
        $fn = "module_{$key}_render";
        if (!function_exists($fn)) throw new ApiException("Funzione $fn mancante");
        return (string) $fn(['def' => $m, 'medico' => Impostazione::profilo(), 'config' => Config::get('app')]);
    }

    /** La disposizione è PERSONALE: chiave per utente (scrivania_<id>); il vecchio layout di studio fa da base la prima volta */
    private static function chiave(): string { return 'scrivania_' . (int) (Auth::utente()['id'] ?? 0); }
    public static function layout(): array { $l = Impostazione::get(self::chiave(), ''); return json_arr($l !== '' ? $l : Impostazione::get('scrivania', '')); }
    public static function chiaveLayout(): string { return self::chiave(); }
    public static function salvaLayout(array $l): void { Impostazione::set(self::chiave(), json_txt($l)); }
}
