<?php
final class Visita extends Model
{
    protected static string $table = 'visite';
    protected static array $fillable = ['paziente_id', 'appuntamento_id', 'utente_id', 'data', 'ora', 'pa_sys', 'pa_dia', 'fc', 'spo2', 'temp', 'peso', 'altezza', 'glicemia', 'motivo', 'anamnesi', 'sintomi', 'reperti', 'esame_obiettivo', 'diagnosi', 'terapia', 'esami', 'prestazioni', 'dati', 'indicazioni', 'controllo', 'complicanze', 'stato', 'referto_id'];
    protected static array $json = ['diagnosi', 'terapia', 'esami', 'sintomi', 'reperti', 'prestazioni', 'dati'];
    private const SEV = ['ok' => 'nella norma', 'warn' => 'lieve', 'alto' => 'marcato', 'critico' => 'severo'];
    private const SCALA = [1 => 'lieve', 4 => 'moderato', 7 => 'forte', 9 => 'molto forte'];

    public const CAMPI_VITALI = ['pa_sys', 'pa_dia', 'fc', 'spo2', 'temp', 'peso', 'altezza', 'glicemia'];
    public const CAMPI_TESTO = ['motivo', 'anamnesi', 'esame_obiettivo', 'indicazioni', 'controllo', 'complicanze'];

    /** Visite chiuse del paziente (per la DataTable "storico visite") */
    public static function storicoPaziente(int $pazienteId): array
    {
        $rows = Database::all("SELECT v.id, v.data, v.ora, v.motivo, v.diagnosi, v.referto_id, r.stato referto_stato, r.tipo referto_tipo FROM visite v LEFT JOIN referti r ON r.id = v.referto_id WHERE v.paziente_id = ? AND v.stato = 'chiusa' ORDER BY v.data DESC, v.id DESC", [$pazienteId]);
        return array_map(fn($r) => ['id' => (int) $r['id'], 'data' => $r['data'], 'ora' => $r['ora'], 'motivo' => $r['motivo'], 'diagnosi' => implode(', ', json_arr($r['diagnosi'])), 'referto_id' => $r['referto_id'] ? (int) $r['referto_id'] : null, 'referto_stato' => $r['referto_stato'], 'referto_tipo' => $r['referto_tipo']], $rows);
    }

    /** Visite chiuse con prestazioni non ancora fatturate: la fattura si compila da qui senza riscrivere nulla */
    public static function daFatturare(int $limit = 60): array
    {
        $U = Database::comune('utenti');
        $rows = Database::all("SELECT v.id, v.data, v.ora, v.motivo, v.prestazioni, v.paziente_id, v.utente_id, p.nome, p.cognome, u.nome unome, u.cognome ucognome, u.sesso usesso FROM visite v JOIN pazienti p ON p.id = v.paziente_id LEFT JOIN fatture f ON f.visita_id = v.id LEFT JOIN $U u ON u.id = v.utente_id WHERE v.stato = 'chiusa' AND f.id IS NULL AND v.prestazioni IS NOT NULL AND v.prestazioni <> '' AND v.prestazioni <> '[]' ORDER BY v.data DESC, v.id DESC LIMIT $limit");
        return array_map(fn($r) => ['id' => (int) $r['id'], 'data' => $r['data'], 'ora' => $r['ora'], 'motivo' => $r['motivo'], 'paziente_id' => (int) $r['paziente_id'], 'paziente' => nome_completo($r), 'professionista' => self::professionista($r), 'prestazioni' => json_arr($r['prestazioni'])], $rows);
    }

    /**
     * Il nome del professionista che ha fatto la visita, da una riga con unome/ucognome/usesso (join su utenti).
     * Visite senza utente (registrate prima del multiutente): il profilo dello studio, che era il solo medico.
     */
    public static function professionista(array $r): string
    {
        $n = trim(((string) ($r['unome'] ?? '')) . ' ' . ((string) ($r['ucognome'] ?? '')));
        if ($n !== '') return (($r['usesso'] ?? 'F') === 'M' ? 'Dott. ' : 'Dott.ssa ') . $n;
        return empty($r['utente_id']) ? Impostazione::profilo()['nome_completo'] : '';
    }

    /** La visita in bozza attualmente aperta (monoutente: al massimo una) */
    public static function aperta(): ?array
    {
        $r = Database::one("SELECT * FROM visite WHERE stato = 'bozza' ORDER BY id DESC LIMIT 1");
        return $r ? self::decode($r) : null;
    }

    /** Apre una nuova visita (chiudendo eventuali bozze precedenti come annullate) */
    public static function avvia(int $pazienteId, ?int $appuntamentoId = null): array
    {
        if (!Paziente::find($pazienteId)) throw new ApiException(__('Paziente non trovato'));
        Database::delete('visite', "stato = 'bozza'");
        $uid = (int) (Auth::utente()['id'] ?? 0);   // il professionista che visita (multiutente): finisce in fattura e nell'elenco
        $id = self::save(['paziente_id' => $pazienteId, 'appuntamento_id' => $appuntamentoId ?: null, 'utente_id' => $uid ?: null, 'data' => oggi(), 'ora' => date('H:i'), 'diagnosi' => [], 'terapia' => [], 'stato' => 'bozza']);
        Attivita::registra('visita.avviata', 'visite', $id, nome_completo(Paziente::find($pazienteId) ?? []));
        Hooks::run('visita.avviata', $id, $pazienteId, $appuntamentoId);
        return self::find($id);
    }

    /** Aggiorna i campi della visita (bozza; con $anchePerChiuse anche una visita già chiusa) */
    public static function aggiorna(int $id, array $in, bool $anchePerChiuse = false): array
    {
        $v = self::find($id);
        if (!$v || ($v['stato'] !== 'bozza' && !$anchePerChiuse)) throw new ApiException(__('Visita non trovata o già chiusa'));
        $in = Hooks::filter('visita.salva', $in, $v);   // a ogni autosalvataggio: le estensioni validano/completano (anche i propri dati in $in['dati'])
        $data = ['id' => $id];
        foreach (self::CAMPI_VITALI as $c) if (array_key_exists($c, $in)) $data[$c] = trim((string) $in[$c]) ?: null;
        foreach (self::CAMPI_TESTO as $c) if (array_key_exists($c, $in)) $data[$c] = (in_array($c, ['anamnesi', 'esame_obiettivo'], true) ? rich_txt((string) $in[$c]) : trim((string) $in[$c])) ?: null;
        if (array_key_exists('diagnosi', $in)) $data['diagnosi'] = array_values(array_filter(array_map('trim', (array) $in['diagnosi'])));
        if (array_key_exists('terapia', $in)) $data['terapia'] = array_values(array_filter(array_map('trim', (array) $in['terapia'])));
        foreach (['sintomi', 'reperti'] as $k) if (array_key_exists($k, $in)) $data[$k] = array_values(array_filter(array_map(fn($r) => is_array($r) ? array_intersect_key($r, array_flip(['regione', 'label', 'lato', 'scala', 'tipo', 'severita', 'nota'])) : null, (array) $in[$k]), fn($r) => $r && !empty($r['regione'])));
        if (array_key_exists('prestazioni', $in)) {
            $nomi = []; foreach (Database::all('SELECT id, nome FROM prestazioni') as $p) $nomi[(int) $p['id']] = $p['nome'];
            $data['prestazioni'] = array_values(array_filter(array_map(fn($x) => isset($nomi[(int) (is_array($x) ? ($x['id'] ?? 0) : $x)]) ? ['id' => (int) (is_array($x) ? $x['id'] : $x), 'nome' => $nomi[(int) (is_array($x) ? $x['id'] : $x)]] : null, (array) $in['prestazioni'])));
        }
        // dati delle ESTENSIONI (chiave = codice estensione): fusi per codice, così più moduli convivono
        if (array_key_exists('dati', $in) && is_array($in['dati'])) {
            $dati = $v['dati'] ?: [];
            foreach ($in['dati'] as $codice => $valori) {
                if (!preg_match('/^[a-z0-9_]{2,40}$/', (string) $codice)) continue;
                $dati[$codice] = is_array($valori) ? $valori : null;
            }
            $data['dati'] = (object) array_filter($dati, fn($x) => $x !== null);   // SEMPRE oggetto: vuoto = '{}', mai '[]' (per JavaScript un Array perde le chiavi con nome)
        }
        if (array_key_exists('esami', $in)) $data['esami'] = array_values(array_filter(array_map(fn($e) => is_array($e) ? ['nome' => trim((string) ($e['nome'] ?? '')), 'stato' => in_array($e['stato'] ?? '', ['richiesto', 'eseguito']) ? $e['stato'] : 'richiesto', 'data' => $e['data'] ?? null, 'esito' => trim((string) ($e['esito'] ?? ''))] : ['nome' => trim((string) $e), 'stato' => 'richiesto', 'data' => null, 'esito' => ''], (array) $in['esami']), fn($e) => $e['nome'] !== ''));
        self::save($data);
        return self::find($id);
    }

    /** Sezioni del referto a partire dai dati della visita */
    public static function sezioni(array $v): array
    {
        $par = [];
        if ($v['pa_sys'] && $v['pa_dia']) $par[] = "PA {$v['pa_sys']}/{$v['pa_dia']} mmHg";
        if ($v['fc']) $par[] = "FC {$v['fc']} bpm";
        if ($v['spo2']) $par[] = "SpO₂ {$v['spo2']}%";
        if ($v['temp']) $par[] = "T {$v['temp']} °C";
        if ($v['peso']) $par[] = "Peso {$v['peso']} kg";
        if ($v['altezza']) $par[] = "Altezza {$v['altezza']} cm";
        if ($v['peso'] && $v['altezza']) { $bmi = numero($v['peso']) / pow(numero($v['altezza']) / 100, 2); $par[] = 'BMI ' . number_format($bmi, 1, ',', ''); }
        if ($v['glicemia']) $par[] = "Glicemia {$v['glicemia']} mg/dl";
        $sezioni = [];
        if ($v['motivo']) $sezioni['Motivo della visita'] = $v['motivo'];
        $sezioni['Anamnesi'] = $v['anamnesi'] ?: '—';   // può contenere HTML dell'editor (reso come tale nel referto)
        if (!empty($v['sintomi'])) $sezioni['Quadro soggettivo'] = implode("\n", array_map(function ($s) {
            $desc = ''; foreach (self::SCALA as $min => $d) if ((int) ($s['scala'] ?? 0) >= $min) $desc = $d;
            return '• ' . ($s['label'] ?? $s['regione']) . (!empty($s['lato']) ? " ({$s['lato']})" : '') . ': ' . ($s['tipo'] ?: 'sintomo') . ' ' . (int) ($s['scala'] ?? 0) . '/10' . ($desc ? " ($desc)" : '') . (!empty($s['nota']) ? ' · ' . $s['nota'] : '');
        }, $v['sintomi']));
        $sezioni['Parametri vitali'] = $par ? implode(' · ', $par) : 'Non rilevati';
        $eo = $v['esame_obiettivo'] ?: '';
        if (!empty($v['reperti'])) {
            $voci = array_map(fn($r) => ($r['label'] ?? $r['regione']) . (!empty($r['lato']) ? " ({$r['lato']})" : '') . ': ' . (self::SEV[$r['severita'] ?? ''] ?? '—') . (!empty($r['nota']) ? ' · ' . $r['nota'] : ''), $v['reperti']);
            $eo .= str_contains($eo, '<')
                ? '<ul>' . implode('', array_map(fn($x) => '<li>' . e($x) . '</li>', $voci)) . '</ul>'
                : ($eo ? "\n" : '') . implode("\n", array_map(fn($x) => '• ' . $x, $voci));
        }
        $sezioni['Esame obiettivo'] = $eo ?: '—';
        $sezioni['Diagnosi'] = $v['diagnosi'] ? implode(', ', $v['diagnosi']) : '—';
        if ($v['esami']) $sezioni['Esami'] = implode("\n", array_map(fn($e) => '• ' . $e['nome'] . ' (' . ($e['stato'] === 'eseguito' ? 'eseguito' . ($e['data'] ? ' il ' . data_it($e['data']) : '') : 'richiesto') . ')' . ($e['esito'] ? ': ' . $e['esito'] : ''), $v['esami']));
        $terapia = $v['terapia'] ? implode("\n", array_map(fn($t) => '• ' . $t, $v['terapia'])) : '—';
        if ($v['indicazioni']) $terapia .= "\n" . $v['indicazioni'];
        if ($v['controllo']) $terapia .= "\nProssimo controllo: " . data_it($v['controllo']);
        $sezioni['Terapia e indicazioni'] = $terapia;
        if ($v['complicanze']) $sezioni['Complicanze'] = $v['complicanze'];
        // punto di aggancio: le estensioni inseriscono le loro sezioni specialistiche nel referto
        return class_exists('Hooks') ? Hooks::filter('referto.sezioni', $sezioni, $v) : $sezioni;
    }

    /** Modifica una visita già chiusa: aggiorna i dati e rigenera il referto se è ancora in bozza */
    public static function salvaChiusa(int $id, array $in): array
    {
        $v = self::aggiorna($id, $in, true);
        $rigenerato = false;
        if ($v['referto_id'] && ($r = Referto::find((int) $v['referto_id'])) && $r['stato'] === 'bozza') {
            Referto::save(['id' => $r['id'], 'sezioni' => self::sezioni($v)]);
            $rigenerato = true;
        }
        if ($v['diagnosi']) Database::update('storico', ['descrizione' => implode(', ', $v['diagnosi'])], "rif_tabella = 'referti' AND rif_id = :r", ['r' => $v['referto_id'] ?? 0]);
        return ['visita' => $v, 'referto_rigenerato' => $rigenerato];
    }

    /** Elimina una visita chiusa (solo se il referto non è stato firmato) */
    public static function elimina(int $id): void
    {
        $v = self::find($id); if (!$v) throw new ApiException(__('Visita non trovata'), 404);
        if ($v['referto_id'] && ($r = Referto::find((int) $v['referto_id'])) && $r['stato'] !== 'bozza') throw new ApiException(__('La visita ha un referto firmato e non può essere eliminata'));
        if ($v['referto_id']) { Referto::delete((int) $v['referto_id']); Database::delete('storico', "rif_tabella = 'referti' AND rif_id = ?", [(int) $v['referto_id']]); }
        self::delete($id);
    }

    /** Chiude la visita e genera il referto. Restituisce l'id del referto. */
    public static function chiudi(int $id, array $in): int
    {
        $in = Hooks::filter('visita.chiudi', $in, $id);   // le estensioni possono completare i dati prima della chiusura (o rifiutarla con ApiException)
        $v = self::aggiorna($id, $in);
        $p = Paziente::find((int) $v['paziente_id']);
        $app = $v['appuntamento_id'] ? Appuntamento::find((int) $v['appuntamento_id']) : null;

        $sezioni = self::sezioni($v);
        $tipoLabel = $app ? Appuntamento::tipoNome($app['tipo']) : 'Visita';
        $firmaAuto = Impostazione::get('pref_firma_auto') === '1';
        $rid = Referto::save(['paziente_id' => $p['id'], 'visita_id' => $id, 'tipo' => 'Referto di ' . mb_strtolower($tipoLabel), 'data' => oggi(), 'stato' => $firmaAuto ? 'firmato' : 'bozza', 'sezioni' => $sezioni, 'firmato_il' => $firmaAuto ? date('Y-m-d H:i:s') : null]);
        self::save(['id' => $id, 'stato' => 'chiusa', 'referto_id' => $rid]);
        if ($app) Appuntamento::save(['id' => $app['id'], 'stato' => 'completato']);
        Paziente::save(['id' => $p['id'], 'ultima_visita' => oggi()]);
        Storico::aggiungi((int) $p['id'], oggi(), $tipoLabel, $v['diagnosi'] ? implode(', ', $v['diagnosi']) : 'Visita', 'referti', $rid);
        Attivita::registra('visita.chiusa', 'visite', $id, $p['nome_completo'] . ' · referto ' . ($firmaAuto ? 'firmato' : 'in bozza'));
        Notifica::aggiungi($firmaAuto ? 'success' : 'warn', $firmaAuto ? 'Referto generato e firmato' : 'Referto in bozza da firmare', $p['nome_completo'] . ' · ' . mb_strtolower($tipoLabel), ['modulo' => 'referti', 'opts' => ['select' => $rid]]);
        if (!empty($v['controllo'])) Scadenzario::aggiungi('controllo', $v['controllo'], __('Visita di controllo: ') . $p['nome_completo'], 'Programmata alla chiusura della visita del ' . data_it($v['data']), ['modulo' => 'agenda', 'opts' => []], 'visite', $id);
        if (!empty($v['prestazioni'])) Notifica::aggiungi('info', 'Visita da fatturare', $p['nome_completo'] . ' · ' . implode(', ', array_column($v['prestazioni'], 'nome')), ['modulo' => 'fatture', 'opts' => ['da_visita' => $id]]);
        Hooks::run('visita.chiusa', $id, $rid, self::find($id));   // evento: integrazioni, invii, statistiche
        return $rid;
    }
}
