<?php
/** Registro delle attività (audit multiutente): CHI (utente_id + username fotografato + IP) ha fatto COSA e QUANDO.
    Attivita::registra('fattura.emessa', 'fatture', $id, 'Fattura 2026/045 a Marco Bianchi') — l'utente lo prende da solo dalla sessione;
    da CLI o webhook resta 'cli' / 'stripe' con l'utente 0. Attivita::recenti() / ::perUtente() / ::cerca() per il modulo e per le verifiche. */
final class Attivita
{
    public const ICONE = ['paziente' => ['user', 'fa-solid fa-user'], 'appuntamento' => ['calendar', 'fa-regular fa-calendar'], 'visita' => ['stethoscope', 'fa-solid fa-stethoscope'], 'referto' => ['document', 'fa-regular fa-file-lines'], 'ricetta' => ['prescription', 'fa-solid fa-prescription'], 'fattura' => ['receipt', 'fa-solid fa-file-invoice'], 'sistema' => ['settings', 'fa-solid fa-gear'], 'accesso' => ['sign-in-alt', 'fa-solid fa-right-to-bracket']];

    public static function registra(string $azione, ?string $entita = null, ?int $id = null, string $descrizione = ''): void
    {
        try {
            $u = !empty($_SESSION['drf_user']) ? Auth::utente() : null;
            $nome = $u ? (string) ($u['username'] ?? '') : (PHP_SAPI === 'cli' ? 'cli' : (string) ($_SESSION['drf_user']['username'] ?? 'sistema'));
            Database::insert('attivita', ['azione' => $azione, 'entita' => $entita, 'entita_id' => $id, 'descrizione' => mb_substr($descrizione, 0, 255),
                'utente_id' => (int) ($u['id'] ?? 0) ?: null, 'utente' => mb_substr($nome, 0, 80), 'ip' => PHP_SAPI === 'cli' ? null : mb_substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45), 'creato_il' => date('Y-m-d H:i:s')]);
        }
        catch (Throwable) { /* il registro non deve mai bloccare l'operazione */ }
    }

    public static function recenti(int $n = 30, ?int $utenteId = null, string $cerca = ''): array
    {
        $w = []; $p = [];
        if ($utenteId) { $w[] = 'utente_id = ?'; $p[] = $utenteId; }
        if ($cerca !== '') { $w[] = '(descrizione LIKE ? OR azione LIKE ? OR utente LIKE ?)'; $like = "%$cerca%"; array_push($p, $like, $like, $like); }
        $sql = 'SELECT * FROM attivita' . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . ' ORDER BY id DESC LIMIT ' . $n;
        return array_map(function ($r) { [$e] = explode('.', $r['azione']) + ['']; $r['icona'] = self::ICONE[$e] ?? self::ICONE['sistema']; return $r; }, Database::all($sql, $p));
    }

    /** Gli utenti che compaiono nel registro (per il filtro) */
    public static function utenti(): array
    {
        return Database::all("SELECT utente_id, utente, COUNT(*) n FROM attivita WHERE utente_id IS NOT NULL GROUP BY utente_id, utente ORDER BY n DESC");
    }
}
