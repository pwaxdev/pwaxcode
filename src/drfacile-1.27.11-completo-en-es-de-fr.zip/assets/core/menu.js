/* Menu contestuale (tasto destro o pulsante).
   DRF.menu.show(x, y, [{ label, fi, fa, run, disabled, danger, kbd, sep:true }])
   DRF.menu.bind($root, '.appt', el => [...voci...])   // tasto destro su elementi (anche creati dopo) */
DRF.menu = (function ($) {
  'use strict';
  let $m = null, items = [], hl = -1;
  function el() { if (!$m) { $m = $('<div class="ctx-menu" role="menu" hidden></div>').appendTo('body'); $m.on('click', '.ctx-item:not(.disabled)', function () { const it = items[+this.dataset.i]; M.close(); if (it && it.run) it.run(); }); $m.on('mouseenter', '.ctx-item:not(.disabled)', function () { hl = +this.dataset.i; paint(); }); } return $m; }
  function paint() { $m.find('.ctx-item').removeClass('hl').filter(`[data-i="${hl}"]`).addClass('hl'); }
  const M = {
    show(x, y, lista, opts) {
      const $menu = el(); items = (lista || []).filter(Boolean); hl = -1;
      $menu.html(items.map((it, i) => it.sep ? '<div class="ctx-sep"></div>' : `<div class="ctx-item ${it.disabled ? 'disabled' : ''} ${it.danger ? 'danger' : ''}" data-i="${i}" role="menuitem"><span class="ctx-ico">${it.fi ? DRF.icons.html(it.fi, it.fa || '') : ''}</span><span class="ctx-label">${DRF.esc(it.label)}</span>${it.kbd ? `<kbd>${DRF.esc(it.kbd)}</kbd>` : ''}</div>`).join(''));
      if (opts && opts.title) $menu.prepend(`<div class="ctx-title">${DRF.esc(opts.title)}</div>`);
      DRF.icons.apply($menu[0]);
      $menu.prop('hidden', false).removeClass('in');
      const w = $menu.outerWidth(), h = $menu.outerHeight(), W = window.innerWidth, H = window.innerHeight;
      $menu.css({ left: Math.max(6, Math.min(x, W - w - 6)), top: Math.max(6, Math.min(y, H - h - 6)), transformOrigin: (y + h > H ? 'bottom' : 'top') + ' ' + (x + w > W ? 'right' : 'left') });
      requestAnimationFrame(() => $menu.addClass('in'));
      setTimeout(() => { $(document).on('mousedown.ctx keydown.ctx', onDoc); document.addEventListener('scroll', M.close, true); }, 0);
      $(window).on('resize.ctx blur.ctx', M.close);
      DRF.sound.play('click');
    },
    /** Apre il menu sotto un pulsante */
    showAt($btn, lista, opts) { const r = $btn[0].getBoundingClientRect(); M.show(r.left, r.bottom + 6, lista, opts); },
    close() { if (!$m || $m.prop('hidden')) return; $m.removeClass('in'); setTimeout(() => $m.prop('hidden', true), 120); $(document).off('.ctx'); $(window).off('.ctx'); document.removeEventListener('scroll', M.close, true); },
    isOpen() { return !!($m && !$m.prop('hidden')); },
    /** Tasto destro su elementi (delegato): builder(el, event) restituisce le voci */
    bind($root, selector, builder, opts) {
      $($root).on('contextmenu', selector, function (e) {
        const lista = builder(this, e); if (!lista || !lista.length) return;
        e.preventDefault(); e.stopPropagation(); M.show(e.clientX, e.clientY, lista, typeof opts === 'function' ? opts(this) : opts);
      });
    }
  };
  function onDoc(e) {
    if (e.type === 'mousedown') { if (!$(e.target).closest('.ctx-menu').length) M.close(); return; }
    const n = items.length;
    if (e.key === 'Escape') { M.close(); return; }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); const d = e.key === 'ArrowDown' ? 1 : -1; for (let k = 0; k < n; k++) { hl = (hl + d + n) % n; if (!items[hl].sep && !items[hl].disabled) break; } paint(); }
    if (e.key === 'Enter' && items[hl]) { e.preventDefault(); const it = items[hl]; M.close(); if (it.run) it.run(); }
  }
  return M;
})(jQuery);
