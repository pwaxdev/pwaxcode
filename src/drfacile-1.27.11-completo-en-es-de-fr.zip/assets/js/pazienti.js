/* Modulo Pazienti: elenco con ricerca e filtri, scheda con storico, nuovo/modifica */
DRF.register('pazienti', (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;
  const st = { q: '', filtro: 'tutti', sel: null, list: [] };

  function load() {
    return DRF.api.get('pazienti', 'list', { q: st.q, filtro: st.filtro }).then(list => {
      st.list = list;
      if (!st.sel && list.length) st.sel = +list[0].id;
      renderList(); if (st.sel) loadDetail(); DRF.nav.refreshSub(); DRF.postit.refresh();
    });
  }
  function renderList() {
    $('#plist').html(st.list.map(p => `<div class="prow ${+p.id === st.sel ? 'on' : ''} ${p.privacy_ok ? '' : 'no-privacy'}" data-id="${p.id}" title="${DRF.__('Doppio click per iniziare la visita')}">${DRF.ui.avatar(p.nome_completo)}<div><b>${DRF.esc(p.nome_completo)}${p.privacy_ok ? '' : ` <i class="pv-warn" title="${DRF.__('Privacy non firmata (o scaduta): tasto destro → Firma privacy')}">${I('shield-exclamation', 'fa-solid fa-shield-halved')}</i>`}</b><span>${p.eta != null ? DRF._n('%d anno', '%d anni', p.eta) + ' · ' : ''}<span class="mono">${DRF.esc(p.cf || '—')}</span></span></div><div class="tags">${p.allergie.length ? DRF.ui.badge('rose', p.allergie.length === 1 ? p.allergie[0] : DRF._n('%d allergia', '%d allergie', p.allergie.length)) : ''}${p.ultima_visita ? DRF.ui.badge('gray', U.fmtIso(p.ultima_visita)) : ''}</div>${I('angle-right', 'fa-solid fa-chevron-right', 'arrow')}</div>`).join('')
      || DRF.ui.empty(st.q ? `${DRF.__('Nessun paziente corrisponde a “')}${DRF.esc(st.q)}”.<br>${DRF.__('Controlla il nome oppure crea un nuovo paziente.')}` : DRF.__('Nessun paziente in archivio.') + '<br>' + DRF.__('Usa') + ' <b>' + DRF.__('Nuovo paziente') + '</b> ' + DRF.__('per iniziare.')));
    DRF.icons.apply($('#plist')[0]);
  }
  function loadDetail() {
    return DRF.api.get('pazienti', 'get', { id: st.sel }).then(d => renderDetail(d.paziente, d.storico, d));
  }
  function renderDetail(p, storico, risposta) {
    const $el = $('#pdetail');
    $el.html(`<div class="head">${DRF.ui.avatar(p.nome_completo, ';width:56px;height:56px;border-radius:18px;font-size:18px')}<div><h2>${DRF.esc(p.nome_completo)}</h2><span class="muted small">${p.eta != null ? DRF._n('%d anno', '%d anni', p.eta) + ' · ' : ''}${p.sesso === 'F' ? DRF.__('donna') : DRF.__('uomo')}${p.nascita ? ' · ' + U.fmtIso(p.nascita) : ''}</span></div></div>
      <div class="row" style="gap:6px;flex-wrap:wrap">${p.allergie.map(a => `<span class="badge rose">${I('exclamation', 'fa-solid fa-triangle-exclamation')} ${DRF.esc(a)}</span>`).join('') || DRF.ui.badge('mint', DRF.__('Nessuna allergia nota'))}</div>
      <dl><dt>${DRF.__('Codice fiscale')}</dt><dd class="mono">${DRF.esc(p.cf || '—')}</dd>${p.piva ? `<dt>${DRF.__('Partita IVA')}</dt><dd class="mono">${DRF.esc(p.piva)}</dd>` : ''}<dt>${DRF.__('Nato/a a')}</dt><dd>${DRF.esc(p.comune_nascita || '—')}</dd><dt>${DRF.__('Indirizzo')}</dt><dd>${DRF.esc([p.indirizzo, [p.cap, p.citta].filter(Boolean).join(' '), p.provincia ? '(' + p.provincia + ')' : ''].filter(Boolean).join(', ') || '—')}</dd><dt>${DRF.__('Cellulare')}</dt><dd>${DRF.esc(p.cellulare || '—')}</dd><dt>${DRF.__('Telefono')}</dt><dd>${DRF.esc(p.telefono || '—')}</dd><dt>${DRF.__('Email')}</dt><dd>${DRF.esc(p.email || '—')}</dd>${p.pec ? `<dt>PEC</dt><dd>${DRF.esc(p.pec)}</dd>` : ''}${p.professione ? `<dt>${DRF.__('Professione')}</dt><dd>${DRF.esc(p.professione)}</dd>` : ''}${p.inviato_da || p.provenienza ? `<dt>${DRF.__('Provenienza')}</dt><dd>${DRF.esc([p.provenienza, p.inviato_da].filter(Boolean).join(' · '))}</dd>` : ''}${+p.rappresentato ? `<dt>${DRF.__('Rappresentante')}</dt><dd>${DRF.esc(p.rapp_nome || '—')}${p.rapp_cf ? ` <span class="mono">${DRF.esc(p.rapp_cf)}</span>` : ''}${p.rapp_telefono ? ' · ' + DRF.esc(p.rapp_telefono) : ''}</dd>` : ''}<dt>${DRF.__('Ultima visita')}</dt><dd>${p.ultima_visita ? U.fmtIso(p.ultima_visita) : '—'}</dd></dl>
      ${p.note ? `<p class="small" style="margin-bottom:12px"><b>${DRF.__('Note:')}</b> ${DRF.esc(p.note)}</p>` : ''}
      <div class="actions"><button class="btn primary" id="pdVisit">${I('stethoscope', 'fa-solid fa-stethoscope')}<span>${DRF.__('Inizia visita')}</span></button><button class="btn ghost" id="pdBook">${I('calendar', 'fa-regular fa-calendar')}<span>${DRF.__('Prenota')}</span></button><button class="btn ghost" id="pdRx" title="${DRF.__('Ricetta')}">${I('prescription', 'fa-solid fa-prescription')}</button><button class="btn ghost" id="pdEdit" title="${DRF.__('Modifica scheda')}">${I('pencil', 'fa-solid fa-pen')}</button><button class="btn ghost" id="pdDel" title="${DRF.__('Elimina')}" style="color:var(--red-ink)">${I('trash', 'fa-solid fa-trash')}</button></div>
      <h3>${DRF.__('Storico')}</h3><div class="pstorico"></div>`);
    DRF.icons.apply($el[0]);
    DRF.storico.render($el.find('.pstorico'), storico, true);
    $('#pdVisit').on('click', () => DRF.module('visita').avvia(+p.id));
    $('#pdBook').on('click', () => DRF.module('agenda').prenota({ paziente_id: p.id }));
    $('#pdRx').on('click', () => DRF.nav.go('ricette', { paziente: +p.id }));
    $('#pdEdit').on('click', () => DRF.form.open('paziente', { id: +p.id, onSaved: () => load() }));
    $('#pdDel').on('click', () => DRF.ui.confirm(`${DRF.__('Eliminare')} ${p.nome_completo}?`, DRF.__('Verranno rimossi anche appuntamenti, visite e referti collegati. L\'operazione non è reversibile.'), DRF.__('Elimina')).then(ok => {
      if (ok) DRF.api.post('pazienti', 'delete', { id: +p.id }).then(() => { st.sel = null; DRF.ui.toast(DRF.__('Paziente eliminato')); load(); });
    }));
    // slot per le estensioni: pannelli, pulsanti e dati aggiuntivi nella scheda del paziente
    DRF.hooks.run('paziente.scheda', { $root: $el, paziente: p, storico, risposta: risposta || {},   // risposta = tutto ciò che pazienti/get ha restituito (anche ciò che le estensioni allegano con api.dopo)
      aggiungi: (html, dove) => { const $b = $(html); ({ prima: () => $el.find('.actions').before($b), dopo: () => $el.find('.actions').after($b), fondo: () => $el.append($b) }[dove || 'dopo'])(); DRF.icons.apply($b[0]); return $b; },
      azione: (label, run, opz) => { opz = opz || {}; const $btn = $(`<button class="btn ghost" type="button" title="${DRF.esc(label)}">${DRF.icons.html(opz.fi || 'puzzle-piece', opz.fa || 'fa-solid fa-puzzle-piece')}${opz.icona ? '' : `<span>${DRF.esc(label)}</span>`}</button>`).on('click', run); if (opz.dopo && $el.find(opz.dopo).length) $el.find(opz.dopo).after($btn); else $el.find('.actions').append($btn); DRF.icons.apply($btn[0]); return $btn; },   // opz: { fi, fa, icona: true (solo icona), dopo: '#pdEdit' (posizione) }
      ricarica: loadDetail, avviaVisita: () => DRF.module('visita').avvia(+p.id), prenota: () => DRF.module('agenda').prenota({ paziente_id: p.id }) });
  }
  function select(id) { DRF.emit('paziente:selezionato', { id: +id }); st.sel = +id; $('#plist .prow').removeClass('on').filter(`[data-id="${id}"]`).addClass('on'); loadDetail(); DRF.postit.refresh(); }

  const M = {
    title: DRF.__('Pazienti'),
    sub() { return `${DRF._n('%d paziente', '%d pazienti', st.list.length)}${st.q || st.filtro !== 'tutti' ? ' ' + DRF.__('trovati') : ' ' + DRF.__('in archivio')}`; },
    action: { label: DRF.__('Nuovo paziente'), fi: 'user-add', fa: 'fa-solid fa-user-plus', run: () => DRF.module('pazienti').nuovo() },
    record() { return st.sel ? { sezione: 'paziente', record: st.sel } : null; },
    /** Segnalino con il numero di post-it accanto ai pazienti che ne hanno */
    postitConteggi(c) { $('#plist .prow').each(function () { const n = c[this.dataset.id] || 0; $(this).find('.pn').remove(); if (n) $(this).find('.tags').prepend(`<span class="badge amber pn" title="${n} post-it">${DRF.icons.html('note-sticky', 'fa-regular fa-note-sticky')} ${n}</span>`); }); DRF.icons.apply($('#plist')[0]); },
    nuovo() { DRF.form.open('paziente', { onSaved: r => { st.sel = r.id; st.q = ''; $('#patSearch').val(''); DRF.nav.go('pazienti'); load(); } }); },
    select,

    init() {
      $('#patSearch').on('input', U.debounce(function () { st.q = this.value.trim(); load(); }, 220));
      $('#patFilters').on('click', '.chip', function () { $('#patFilters .chip').removeClass('on'); $(this).addClass('on'); st.filtro = this.dataset.f; load(); });
      $('#plist').on('click', '.prow', function () { select(+this.dataset.id); })
        .on('dblclick', '.prow', function () { DRF.module('visita').avvia(+this.dataset.id); });
      DRF.menu.bind($('#plist'), '.prow', el => {
        const p = st.list.find(x => +x.id === +el.dataset.id); if (!p) return null;
        select(+p.id);
        return DRF.hooks.filter('pazienti.menu', [   // le estensioni aggiungono voci al menu contestuale del paziente
          { label: DRF.__('Inizia visita'), fi: 'stethoscope', fa: 'fa-solid fa-stethoscope', run: () => DRF.module('visita').avvia(+p.id) },
          { label: DRF.__('Prenota'), fi: 'calendar-plus', fa: 'fa-regular fa-calendar-plus', run: () => DRF.module('agenda').prenota({ paziente_id: p.id }) },
          { label: DRF.__('Stampa documento…'), fi: 'print', fa: 'fa-solid fa-print', run: () => M.documento(+p.id) },
          { sep: true },
          { label: p.privacy_ok ? DRF.__('Privacy firmata ✓ (rinnova)') : DRF.__('Firma privacy'), fi: 'shield-check', fa: 'fa-solid fa-shield-halved', run: () => {
            DRF.form.open('consenso', { values: { paziente_id: p.id, tipo: 'Privacy', data: U.todayIso() }, onSaved: () => { DRF.ui.toast(DRF.__('Privacy registrata per ') + p.nome_completo); load(); } });
          } },
          { sep: true },
          { label: DRF.__('Modifica scheda'), fi: 'pencil', fa: 'fa-solid fa-pen', kbd: 'E', run: () => DRF.form.open('paziente', { id: +p.id, onSaved: () => load() }) },
          { label: DRF.__('Metti in oblio (GDPR)'), fi: 'moon', fa: 'fa-solid fa-moon', run: () => DRF.ui.alert('Diritto all\'oblio', DRF.__('La procedura di oblio (anonimizzazione dei dati clinici nel rispetto degli obblighi di conservazione) arriverà in una prossima versione.'), 'info') },
          { label: DRF.__('Elimina paziente'), fi: 'trash', fa: 'fa-solid fa-trash', danger: true, run: () => $('#pdDel').trigger('click') },
        ], p);
      }, el => ({ title: (st.list.find(x => +x.id === +el.dataset.id) || {}).nome_completo }));
    },
    show(opts) {
      if (opts && opts.select) { st.sel = +opts.select; st.q = ''; st.filtro = 'tutti'; $('#patSearch').val(''); $('#patFilters .chip').removeClass('on').first().addClass('on'); }
      load().then(() => { if (opts && opts.modifica && st.sel) DRF.form.open('paziente', { id: st.sel, onSaved: () => load() }); });
    },
    /** Stampa un documento dell'archivio Documenti per il paziente (campi {…} compilati) */
    documento(pid) {
      DRF.api.get('archivi', 'list', { archivio: 'documenti' }).then(d => {
        const doc = (d.righe || []).filter(r => +r.abilitato);
        if (!doc.length) return DRF.ui.alert(DRF.__('Nessun documento'), DRF.__('Crea prima i modelli in Archivi → Documenti (privacy, consensi, comunicazioni…).'), 'info');
        const CAT = { standard: DRF.__('Documenti standard'), email: DRF.__('Comunicazioni email'), consensi: DRF.__('Consensi') };
        const conFirma = (DRF.config.estensioni || []).includes('firma');
        const genera = (id, firma) => DRF.api.post('documenti_modelli', 'genera', { documento: id, paziente_id: pid, firma: firma || null }).then(r => {
          DRF.doc.file(r.file);
          if (r.consenso) DRF.ui.toast(DRF.__('Consenso registrato: scade il ') + DRF.util.fmtIso(r.consenso.scadenza), 'success');
          if (firma) DRF.ui.toast(DRF.__('Documento archiviato con la firma incorporata'), { fi: 'signature', fa: 'fa-solid fa-signature' });
        });
        DRF.ui.modal({ title: DRF.__('Stampa documento'), size: 'lg', ok: false, cancel: DRF.__('Chiudi'),
          html: `<p class="small muted" style="margin-bottom:12px">${DRF.__('I campi {paziente}, {data}, {medico}… vengono compilati con i dati reali. I consensi con durata registrano anche la firma nel registro, con la scadenza.')}${conFirma ? ' Con <b>' + DRF.__('Firma sul tablet') + '</b> il paziente firma sullo schermo e la firma resta dentro al documento archiviato.' : ''}</p><div class="fat-dv">${doc.map(x => `<button type="button" class="fat-dv-it" data-doc="${x.id}"><span class="num fat-dv-data mono">${DRF.esc(x.codice)}</span><span class="fat-dv-who"><b>${DRF.esc(x.descrizione)}</b><small>${DRF.esc(CAT[x.categoria] || x.categoria)}${+x.durata ? ' · validità ' + x.durata + ' gg' : ''}</small></span>${conFirma ? `<span class="btn ghost sm" data-firma="${x.id}">${DRF.icons.html('signature', 'fa-solid fa-signature')}${DRF.__('Firma sul tablet')}</span>` : ''}${DRF.icons.html('print', 'fa-solid fa-print')}</button>`).join('')}</div>`,
          onOpen($b) {
            $b.on('click', '[data-firma]', function (e) {
              e.stopPropagation();
              const id = +this.dataset.firma;
              DRF.ui.closeModal();
              M.padFirma(pid, png => genera(id, png));
            });
            $b.on('click', '.fat-dv-it', function () { DRF.ui.closeModal(); genera(+this.dataset.doc, null); });
          } });
      });
    },

    /** Estensione "Firma sul tablet": il pad dove il paziente firma con il dito */
    padFirma(pid, onFirma) {
      const p = st.righe.find(x => +x.id === pid) || {};
      DRF.ui.modal({ title: DRF.__('Firma del paziente'), ok: DRF.__('Usa questa firma'), cancel: DRF.__('Annulla'),
        html: `<p class="small muted" style="margin-bottom:10px">${DRF.__('Porgi il tablet')} ${p.nome_completo ? DRF.__('a') + ' <b>' + DRF.esc(p.nome_completo) + '</b>' : DRF.__('al paziente')}: ${DRF.__('la firma verrà incorporata nel documento archiviato.')}</p>
          <div class="pad-box"><canvas id="padFirma" width="640" height="240"></canvas></div>
          <div class="row" style="margin-top:8px;justify-content:space-between"><span class="small muted">${DRF.__('Firma nello spazio bianco')}</span><button class="btn ghost sm" type="button" id="padPulisci">${DRF.icons.html('eraser', 'fa-solid fa-eraser')}${DRF.__('Pulisci')}</button></div>`,
        onOpen($b) {
          const cv = $b.find('#padFirma')[0], cx = cv.getContext('2d');
          const reset = () => { cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); cx.strokeStyle = '#1F2233'; cx.lineWidth = 3; cx.lineCap = cx.lineJoin = 'round'; $b.data('tracciato', false); };
          reset();
          const pos = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; };
          let giu = false;
          cv.addEventListener('pointerdown', e => { giu = true; cv.setPointerCapture(e.pointerId); const [x, y] = pos(e); cx.beginPath(); cx.moveTo(x, y); });
          cv.addEventListener('pointermove', e => { if (!giu) return; const [x, y] = pos(e); cx.lineTo(x, y); cx.stroke(); $b.data('tracciato', true); });
          cv.addEventListener('pointerup', () => giu = false);
          $b.find('#padPulisci').on('click', reset);
          $b.data('png', () => cv.toDataURL('image/png'));
        },
        onOk($b) {
          if (!$b.data('tracciato')) { DRF.ui.toast(DRF.__('Il paziente non ha ancora firmato'), 'warn'); return false; }
          const png = $b.data('png')();
          DRF.ui.closeModal();
          onFirma(png);
          return false;
        } });
    }
  };
  return M;
})(jQuery));
