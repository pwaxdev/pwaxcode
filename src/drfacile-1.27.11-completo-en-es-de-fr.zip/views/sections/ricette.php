<div class="rx stagger">
  <div>
    <div class="card" style="margin-bottom:14px">
      <div class="row" style="gap:14px;flex-wrap:wrap">
        <div class="field" style="flex:1;min-width:220px"><label><?= __('Paziente') ?></label><select class="select" id="rxPat"></select></div>
        <div class="field" style="width:190px"><label><?= __('Tipo ricetta') ?></label><div class="seg" id="rxType"><button class="on" data-v="bianca"><?= __('Bianca') ?></button><button data-v="ssn">SSN</button></div></div>
        <div class="field" style="width:220px"><label><?= __('Esenzione') ?></label><select class="select" id="rxEs"><option value=""><?= __('Nessuna') ?></option></select></div>
      </div>
    </div>
    <div class="card">
      <h3><i class="ico" data-fi="search" data-fa="fa-solid fa-magnifying-glass"></i><?= __('Farmaci') ?></h3>
      <div class="row"><input class="input" id="rxSearch" list="rxList" placeholder="<?= __('Cerca per nome commerciale o principio attivo, poi Invio') ?>"><button class="btn soft" id="rxAddBtn" title="<?= __('Aggiungi') ?>"><i class="ico" data-fi="plus" data-fa="fa-solid fa-plus"></i></button><button class="btn ghost" id="rxNewDrug" title="<?= __('Nuovo farmaco nel prontuario') ?>"><i class="ico" data-fi="book-medical" data-fa="fa-solid fa-book-medical"></i></button></div>
      <datalist id="rxList"></datalist>
      <div class="suggest" id="rxSuggest"></div>
      <div class="rxlines" id="rxLines"></div>
      <div class="field"><label><?= __('Nota per il farmacista') ?></label><input class="input" id="rxNote" placeholder="<?= __('Facoltativa') ?>"></div>
    </div>
  </div>
  <div class="side">
    <div class="card white">
      <h3><i class="ico" data-fi="paper-plane" data-fa="fa-regular fa-paper-plane"></i><?= __('Invio') ?></h3>
      <p class="small muted" style="line-height:1.6"><?= __('La ricetta viene firmata e inviata al Sistema TS. Il paziente riceve il promemoria con il codice NRE via email o SMS.') ?></p>
      <div class="row" style="margin-top:14px;gap:8px;flex-wrap:wrap">
        <button class="btn primary" id="rxSend"><i class="ico" data-fi="paper-plane" data-fa="fa-regular fa-paper-plane"></i><span><?= __('Firma e invia') ?></span></button>
      </div>
    </div>
    <div class="card"><h3><i class="ico" data-fi="time-past" data-fa="fa-solid fa-clock-rotate-left"></i><?= __('Ultime ricette') ?></h3><div class="rxhist" id="rxHist"></div></div>
  </div>
</div>
