<?php
/**
 * CAPABILITIES delle estensioni: cosa un pacchetto DICHIARA nel manifest (capabilities: [...]) e cosa il core gli LASCIA fare.
 *
 * Il core sa sempre quale estensione sta girando (Capabilities::corrente()): durante l'inclusione di estensione.php,
 * dentro i suoi hook (Hooks ricorda chi ha registrato ogni callback) e nelle azioni del suo ajax.php. In quel contesto
 * i servizi del core che toccano dati o escono dal programma chiedono `Capabilities::richiedi('…')`: se l'estensione
 * non l'ha dichiarata, l'operazione si ferma con un'eccezione (e finisce nel log). Fuori da un'estensione non c'è limite.
 *
 * Copre ciò che passa dal core (modelli, comunicazioni, notifiche, scadenzario, impostazioni, migrazioni, rete via Rete::…).
 * Non è un sandbox: PHP non lo permette senza un processo separato. Per il resto c'è la revisione del codice.
 *
 * Hook e slot di interfaccia NON richiedono capability: un'estensione che si limita ad aggiungere pannelli, voci, moduli
 * o a trasformare un referto lo fa liberamente. Le capability riguardano i DATI e il MONDO ESTERNO.
 */
final class Capabilities
{
    /** Il catalogo: nome → descrizione mostrata nello Store ("Cosa usa") e al revisore */
    public const CATALOGO = [
        'pazienti.leggi' => 'Legge le anagrafiche dei pazienti',
        'pazienti.scrivi' => 'Crea o modifica anagrafiche',
        'visite.leggi' => 'Legge le visite (anamnesi, esami, diagnosi, terapie)',
        'visite.scrivi' => 'Modifica le visite dal server (in visita, via ctx.setDati, non serve)',
        'referti.scrivi' => 'Crea o modifica referti',
        'ricette.scrivi' => 'Emette ricette',
        'fatture.leggi' => 'Legge le fatture',
        'fatture.scrivi' => 'Emette, modifica o incassa fatture',
        'agenda.scrivi' => 'Crea o modifica appuntamenti',
        'documenti.genera' => 'Genera e archivia documenti',
        'comunicazioni.invia' => 'Invia email, SMS o WhatsApp ai pazienti',
        'notifiche.crea' => 'Crea notifiche per gli utenti',
        'scadenzario.crea' => 'Crea scadenze e promemoria',
        'impostazioni.scrivi' => 'Modifica impostazioni del core (le proprie, con il prefisso del codice, sono sempre libere)',
        'utenti.leggi' => 'Legge gli utenti dello studio',
        'database.tabelle' => 'Crea le proprie tabelle (migrations/)',
        'rete_esterna' => 'Contatta servizi esterni (Rete::get / Rete::post)',
        'export.dati' => 'Aggiunge formati di esportazione dei dati',
        'spazio.scrivi' => 'Salva ed elimina file nell\'archivio dello studio (soggetto alla quota)',
    ];

    /** Tabella → capability necessaria per leggere/scrivere tramite i modelli */
    public const TABELLE = [
        'pazienti' => ['pazienti.leggi', 'pazienti.scrivi'], 'visite' => ['visite.leggi', 'visite.scrivi'], 'referti' => ['visite.leggi', 'referti.scrivi'],
        'ricette' => ['visite.leggi', 'ricette.scrivi'], 'fatture' => ['fatture.leggi', 'fatture.scrivi'], 'appuntamenti' => ['pazienti.leggi', 'agenda.scrivi'],
    ];

    private static array $pila = [];
    private static array $dichiarate = [];

    /** L'estensione in esecuzione (null = core) */
    public static function corrente(): ?string { $c = self::$pila ? end(self::$pila) : null; return $c === '' ? null : $c; }

    /** Esegue $fn come CORE anche dentro un'estensione (per i servizi interni che scrivono chiavi proprie) */
    public static function comeCore(callable $fn, mixed ...$args): mixed { self::$pila[] = ''; try { return $fn(...$args); } finally { array_pop(self::$pila); } }

    /** Esegue $fn "a nome" dell'estensione: tutto ciò che chiede una capability viene verificato sul suo manifest */
    public static function come(?string $codice, callable $fn, mixed ...$args): mixed
    {
        if ($codice === null) return $fn(...$args);
        self::$pila[] = $codice;
        try { return $fn(...$args); } finally { array_pop(self::$pila); }
    }

    /** Le capability dichiarate da un'estensione (manifest.json), in cache */
    public static function dichiarate(string $codice): array
    {
        if (!isset(self::$dichiarate[$codice])) {
            $m = class_exists('Store') ? Store::manifestInstallato($codice) : null;
            self::$dichiarate[$codice] = array_values(array_map('strval', (array) ($m['capabilities'] ?? [])));
        }
        return self::$dichiarate[$codice];
    }

    /** Vero se l'estensione corrente può (o se non c'è nessuna estensione in esecuzione) */
    public static function puo(string $cap): bool
    {
        $c = self::corrente();
        if ($c === null) return true;
        $d = self::dichiarate($c);
        return in_array($cap, $d, true) || in_array('*', $d, true);
    }

    /** Come puo(), ma si ferma: l'estensione non l'ha dichiarata → CapabilityException (loggata) */
    public static function richiedi(string $cap): void
    {
        if (self::puo($cap)) return;
        $c = self::corrente();
        error_log("Capability negata: l'estensione $c non dichiara '$cap' nel manifest");
        throw new CapabilityException("L'estensione $c non è autorizzata a '$cap' (" . (self::CATALOGO[$cap] ?? $cap) . '): va dichiarata nel manifest.json e approvata');
    }

    /** Per una tabella dei modelli: lettura (scrittura = false) o scrittura */
    public static function tabella(string $tabella, bool $scrittura): void
    {
        if (self::corrente() === null) return;
        $t = strtolower(preg_replace('/^.*\./', '', str_replace('`', '', $tabella)));
        if (str_starts_with($t, 'ext_')) return;   // le tabelle delle estensioni sono loro (fidarsi del prefisso: la revisione controlla il codice)
        if (!isset(self::TABELLE[$t])) return;
        self::richiedi(self::TABELLE[$t][$scrittura ? 1 : 0]);
    }

    /** Descrizioni leggibili per lo Store: [['cap' => 'comunicazioni.invia', 'testo' => '…'], …] */
    public static function descrivi(array $caps): array
    {
        return array_map(fn($c) => ['cap' => (string) $c, 'testo' => self::CATALOGO[$c] ?? 'Capability non standard: ' . $c, 'nota' => isset(self::CATALOGO[$c]) ? null : 'sconosciuta al core'], array_values($caps));
    }
}

class CapabilityException extends RuntimeException {}
