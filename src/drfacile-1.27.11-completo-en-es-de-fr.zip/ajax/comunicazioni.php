<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'registro' => fn() => ['comunicazioni' => Comunicazioni::registro(100), 'driver' => [
        'email' => Config::get('comunicazioni.email.driver') ?? 'log',
        'sms' => Config::get('comunicazioni.sms.driver') ?? 'log',
        'whatsapp' => Config::get('comunicazioni.whatsapp.driver') ?? 'log',
    ]],
], ['*' => 'comunicazioni.invia', 'registro' => 'comunicazioni.leggi']);
