<?php /** @var array $doc @var array $paziente @var array $medico @var bool $auto_print */ ?>
<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8"><title>Promemoria ricetta · <?= e($paziente['nome_completo']) ?></title><?php include __DIR__ . '/_stile.php'; ?></head>
<body>
<div class="toolbar"><button class="ghost" onclick="window.close()">Chiudi</button><button onclick="window.print()">Stampa / salva PDF</button></div>
<div class="foglio">
  <?php $destra = '<div class="doc"><b>Promemoria ricetta ' . ($doc['tipo'] === 'ssn' ? 'SSN' : 'bianca') . '</b>' . data_it($doc['data']) . '</div>'; include __DIR__ . '/_testata.php'; ?>
  <h1><?= e($paziente['nome_completo']) ?></h1>
  <div class="paz">CF <span class="mono"><?= e($paziente['cf']) ?></span><?= $doc['esenzione'] ? ' · Esenzione ' . e($doc['esenzione']) : '' ?></div>
  <h2>Numero ricetta elettronica</h2>
  <div class="nre"><?= e($doc['nre']) ?></div>
  <div class="barra">Presenta questo promemoria in farmacia insieme alla tessera sanitaria.</div>
  <table><thead><tr><th>Farmaco</th><th>Principio attivo</th><th class="n">Confezioni</th><th>Posologia</th></tr></thead><tbody>
  <?php foreach ($doc['righe'] as $r): ?>
    <tr><td><b><?= e($r['farmaco']) ?></b></td><td><?= e($r['principio'] ?? '') ?></td><td class="n"><?= (int) $r['quantita'] ?></td><td><?= e($r['posologia'] ?? '') ?></td></tr>
  <?php endforeach; ?>
  </tbody></table>
  <?php if ($doc['note']): ?><h2>Nota per il farmacista</h2><p><?= e($doc['note']) ?></p><?php endif; ?>
  <div class="firma"><div><b><?= e($medico['nome']) ?></b>Firmato elettronicamente il <?= data_it($doc['data']) ?></div></div>
  <?php $piede_extra = '<div class="riga-studio">' . e($medico['studio']) . ($medico['ordine'] ? ' · Ordine ' . e($medico['ordine']) : '') . '</div>'; include __DIR__ . '/_piede.php'; ?>
</div>
<?php if ($auto_print): ?><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),300))</script><?php endif; ?>
</body></html>
