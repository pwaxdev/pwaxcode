/* Gestione documentale · pannello laterale (sheet largo): cartelle, file, upload (pulsante e drag&drop), spostamento
   trascinando sulla cartella, rinomina, note, eliminazione, anteprima di PDF / immagini / Word (mammoth) / testo. */
(function ($) {
  'use strict';
  const I = (fi, fa) => DRF.icons.html(fi, fa), U = DRF.util;
  const st = { pid: null, nome: '', cartelle: [], file: [], cart: 'tutti', q: '', spazio: null };
  const ICONA = { pdf: ['file-pdf', 'fa-regular fa-file-pdf'], immagine: ['picture', 'fa-regular fa-image'], word: ['file-word', 'fa-regular fa-file-word'], testo: ['document', 'fa-regular fa-file-lines'], nessuna: ['file', 'fa-regular fa-file'] };
  const umano = b => b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';
  const puo = DRF.can('documenti.modifica');

  /* ---------- apertura */
  function apri(pid, nome) {
    st.pid = pid; st.nome = nome || ''; st.cart = 'tutti'; st.q = '';
    DRF.ui.openSheet('Documenti · ' + (nome || ''), `
      <div class="dcm">
        <div class="dcm-bar">
          <div class="dcm-cerca"><input class="input sm" type="search" placeholder="Cerca nei documenti…"><span>${I('search', 'fa-solid fa-magnifying-glass')}</span></div>
          ${puo ? `<button class="btn primary sm" type="button" data-dcm="carica">${I('cloud-upload', 'fa-solid fa-cloud-arrow-up')}Carica</button><button class="btn ghost sm" type="button" data-dcm="nuova">${I('folder-add', 'fa-solid fa-folder-plus')}Cartella</button><input type="file" multiple hidden class="dcm-input">` : ''}
        </div>
        <div class="dcm-corpo"><div class="dcm-albero"></div><div class="dcm-file"><div class="empty">Carico…</div></div></div>
        <div class="dcm-piede"><div class="spazio-bar"><i></i></div><span class="dcm-spazio small muted"></span></div>
      </div>`);
    $('#sheet').addClass('wide nofoot');
    carica();
  }
  const carica = () => DRF.api.ext('documentale', 'albero', { paziente_id: st.pid }).then(d => { st.cartelle = d.cartelle; st.file = d.file; st.spazio = d.spazio; albero(); lista(); spazio(); });
  function spazio() {
    const s = st.spazio; if (!s) return;
    $('.dcm-piede .spazio-bar i').css('width', s.percentuale + '%').toggleClass('pieno', s.percentuale >= 90);
    $('.dcm-spazio').text(`${s.uso_umano}${s.quota_mb ? ' su ' + s.quota_umano + ' · ' + s.percentuale + '%' : ' · spazio illimitato'}`);
  }

  /* ---------- albero delle cartelle */
  function albero() {
    const figli = pid => st.cartelle.filter(c => (c.parent_id || null) === pid);
    const conta = c => (+c.n) + figli(c.id).reduce((a, x) => a + conta(x), 0);
    const nodo = (c, liv) => `<div class="dcm-cart ${st.cart === c.id ? 'on' : ''} ${c.sistema ? 'sys' : ''}" data-id="${c.id}" style="--liv:${liv}" draggable="false">
        ${I(c.sistema ? 'folder' : 'folder-open', c.sistema ? 'fa-solid fa-folder' : 'fa-regular fa-folder-open')}<span>${DRF.esc(c.nome)}</span>${c.sistema ? I('lock', 'fa-solid fa-lock') : ''}<b>${conta(c) || ''}</b></div>` + figli(c.id).map(x => nodo(x, liv + 1)).join('');
    $('.dcm-albero').html(`<div class="dcm-cart ${st.cart === 'tutti' ? 'on' : ''}" data-id="tutti">${I('apps', 'fa-solid fa-table-cells')}<span>Tutti i documenti</span><b>${st.file.length || ''}</b></div>` + figli(null).map(c => nodo(c, 0)).join(''));
    DRF.icons.apply($('.dcm-albero')[0]);
  }
  const cartella = id => st.cartelle.find(c => +c.id === +id);
  const nomeCart = id => (cartella(id) || {}).nome || '';

  /* ---------- file */
  function lista() {
    const q = st.q.toLowerCase();
    const l = st.file.filter(f => (st.cart === 'tutti' || +f.cartella_id === +st.cart) && (!q || f.nome.toLowerCase().includes(q) || (f.note || '').toLowerCase().includes(q)));
    $('.dcm-file').html(`<div class="dcm-titolo"><b>${st.cart === 'tutti' ? 'Tutti i documenti' : DRF.esc(nomeCart(st.cart))}</b><span class="muted small">${l.length} ${U.plural(l.length, 'file', 'file')}</span>${st.cart !== 'tutti' && !(cartella(st.cart) || {}).sistema && puo ? `<button class="icon-btn sm" type="button" data-dcm="rinomina-cart" title="Rinomina cartella">${I('pencil', 'fa-solid fa-pen')}</button><button class="icon-btn sm" type="button" data-dcm="elimina-cart" title="Elimina cartella">${I('trash', 'fa-solid fa-trash')}</button>` : ''}</div>
      ${l.length ? `<div class="dcm-grid">${l.map(f => { const [fi, fa] = ICONA[f.anteprima] || ICONA.nessuna; return `
        <div class="dcm-it ${f.protetto ? 'prot' : ''}" data-id="${f.id}" draggable="${f.protetto || !puo ? 'false' : 'true'}" title="${DRF.esc(f.note || f.nome)}">
          <span class="dcm-ico ${f.anteprima}">${I(fi, fa)}</span>
          <div class="dcm-mid"><b>${DRF.esc(f.nome)}</b><span>${umano(+f.dimensione)} · ${U.fmtIso(String(f.creato_il).slice(0, 10))}${st.cart === 'tutti' ? ' · ' + DRF.esc(nomeCart(f.cartella_id)) : ''}${f.da ? ' · ' + DRF.esc(f.da) : ''}</span>${f.note ? `<i>${DRF.esc(f.note)}</i>` : ''}</div>
          ${f.protetto ? `<span class="dcm-lock" title="Generato dal programma: non si sposta né si elimina">${I('lock', 'fa-solid fa-lock')}</span>` : ''}
        </div>`; }).join('')}</div>` : `<div class="dcm-vuoto ${puo ? 'drop' : ''}">${I('cloud-upload', 'fa-solid fa-cloud-arrow-up')}<b>${q ? 'Nessun documento trovato' : 'Nessun documento qui'}</b>${puo && !q ? '<span>Trascina i file in questo riquadro o usa "Carica"</span>' : ''}</div>`}`);
    DRF.icons.apply($('.dcm-file')[0]);
  }

  /* ---------- anteprima */
  function anteprima(f) {
    DRF.api.post('documenti', 'link', { file: f.percorso }).then(r => {
      const url = r.url;
      let corpo = '<div class="empty">Anteprima non disponibile per questo tipo di file: aprilo o scaricalo.</div>';
      if (f.anteprima === 'pdf') corpo = `<iframe class="dcm-frame" src="${url}#toolbar=1"></iframe>`;
      else if (f.anteprima === 'immagine') corpo = `<div class="dcm-img"><img src="${url}" alt=""></div>`;
      else if (f.anteprima === 'word' || f.anteprima === 'testo') corpo = '<div class="dcm-doc"><div class="empty">Converto…</div></div>';
      DRF.ui.modal({ title: f.nome, size: 'xl', ok: false, cancel: 'Chiudi', html: `<div class="dcm-prev">${corpo}</div><div class="row dcm-prev-bar"><a class="btn ghost sm" href="${url}" target="_blank">${I('expand', 'fa-solid fa-up-right-from-square')}Apri in una scheda</a><a class="btn ghost sm" href="${url}&scarica=1">${I('download', 'fa-solid fa-download')}Scarica</a>${f.rif_id && f.rif_tabella ? `<button class="btn ghost sm" type="button" data-dcm-vai="${f.rif_tabella}" data-rid="${f.rif_id}">${I('angle-right', 'fa-solid fa-chevron-right')}Vai al ${DRF.esc(f.origine)}</button>` : ''}</div>`,
        onOpen() {
          if (f.anteprima === 'word') $.getScript('estensioni/documentale/assets/mammoth.browser.min.js').then(() => fetch(url).then(x => x.arrayBuffer()).then(ab => window.mammoth.convertToHtml({ arrayBuffer: ab })).then(res => $('.dcm-doc').html(`<div class="dcm-word">${res.value}</div>`)).catch(() => $('.dcm-doc').html('<div class="empty">Documento Word non leggibile: aprilo o scaricalo.</div>')));
          if (f.anteprima === 'testo') fetch(url).then(x => x.text()).then(t => $('.dcm-doc').html(f.nome.toLowerCase().endsWith('.html') ? `<iframe class="dcm-frame" srcdoc="${DRF.esc(t)}"></iframe>` : `<pre class="dcm-pre">${DRF.esc(t)}</pre>`));
        } });
    });
  }

  /* ---------- eventi */
  $(document).on('input', '.dcm-cerca input', U.debounce(function () { st.q = this.value; lista(); }, 150));
  $(document).on('click', '.dcm-cart', function () { st.cart = this.dataset.id === 'tutti' ? 'tutti' : +this.dataset.id; albero(); lista(); });
  $(document).on('click', '.dcm-it', function () { const f = st.file.find(x => +x.id === +this.dataset.id); if (f) anteprima(f); });
  $(document).on('click', '[data-dcm-vai]', function () { DRF.ui.closeModal(); DRF.ui.closeSheet(); DRF.nav.go(this.dataset.dcmVai, { select: +this.dataset.rid }); });
  $(document).on('click', '[data-dcm="carica"]', () => $('.dcm-input').trigger('click'));
  $(document).on('change', '.dcm-input', function () { upload(this.files); this.value = ''; });
  $(document).on('click', '[data-dcm="nuova"]', () => DRF.ui.prompt('Nuova cartella', 'Nome della cartella', '').then(n => { if (n) DRF.api.ext('documentale', 'cartella_crea', { paziente_id: st.pid, nome: n, parent_id: st.cart !== 'tutti' && !(cartella(st.cart) || {}).sistema ? st.cart : null }).then(r => { st.cart = r.id; DRF.ui.toast(r.messaggio, 'success'); carica(); }); }));
  $(document).on('click', '[data-dcm="rinomina-cart"]', () => DRF.ui.prompt('Rinomina cartella', 'Nome', nomeCart(st.cart)).then(n => { if (n) DRF.api.ext('documentale', 'cartella_rinomina', { paziente_id: st.pid, id: st.cart, nome: n }).then(carica); }));
  $(document).on('click', '[data-dcm="elimina-cart"]', () => DRF.ui.confirm('Eliminare la cartella?', 'Solo se è vuota.', 'Elimina').then(ok => { if (ok) DRF.api.ext('documentale', 'cartella_elimina', { paziente_id: st.pid, id: st.cart }).then(r => { st.cart = 'tutti'; DRF.ui.toast(r.messaggio); carica(); }); }));

  // menu contestuale sul file
  DRF.menu.bind($(document), '.dcm-it', el => {
    const f = st.file.find(x => +x.id === +el.dataset.id); if (!f) return null;
    const voci = [{ label: 'Anteprima', fi: 'eye', fa: 'fa-regular fa-eye', run: () => anteprima(f) },
      { label: 'Apri in una scheda', fi: 'expand', fa: 'fa-solid fa-up-right-from-square', run: () => DRF.doc.file(f.percorso) },
      { label: 'Scarica', fi: 'download', fa: 'fa-solid fa-download', run: () => DRF.doc.file(f.percorso, { scarica: 1 }) },
      { label: 'Invia via email', fi: 'paper-plane', fa: 'fa-regular fa-paper-plane', run: () => DRF.doc.invia({ file: f.percorso, paziente_id: st.pid, documento: f.nome }) }];
    if (puo) {
      voci.push({ sep: true }, { label: 'Rinomina', fi: 'pencil', fa: 'fa-solid fa-pen', run: () => DRF.ui.prompt('Rinomina', 'Nome del file', f.nome).then(n => { if (n) DRF.api.ext('documentale', 'rinomina', { paziente_id: st.pid, id: f.id, nome: n }).then(carica); }) },
        { label: f.note ? 'Modifica nota' : 'Aggiungi nota', fi: 'note-sticky', fa: 'fa-regular fa-note-sticky', run: () => DRF.ui.prompt('Nota', 'Una riga che spiega il documento', f.note || '').then(n => { if (n !== null) DRF.api.ext('documentale', 'note', { paziente_id: st.pid, id: f.id, note: n }).then(carica); }) });
      if (!f.protetto) {
        const dest = st.cartelle.filter(c => +c.id !== +f.cartella_id);
        voci.push({ label: 'Sposta in…', fi: 'folder-tree', fa: 'fa-solid fa-folder-tree', run: () => DRF.ui.modal({ title: 'Sposta "' + f.nome + '" in', ok: false, cancel: 'Annulla', html: `<div class="dcm-scelta">${dest.map(c => `<button class="btn ghost" type="button" data-dcm-sposta="${c.id}">${I(c.sistema ? 'folder' : 'folder-open', c.sistema ? 'fa-solid fa-folder' : 'fa-regular fa-folder-open')}${DRF.esc(c.nome)}</button>`).join('')}</div>`, onOpen($b) { $b.on('click', '[data-dcm-sposta]', function () { sposta(f.id, +this.dataset.dcmSposta); DRF.ui.closeModal(); }); } }) },
          { sep: true }, { label: 'Elimina', fi: 'trash', fa: 'fa-solid fa-trash', danger: true, run: () => DRF.ui.confirm('Eliminare il file?', f.nome + ' verrà cancellato dall\'archivio.', 'Elimina').then(ok => { if (ok) DRF.api.ext('documentale', 'elimina', { paziente_id: st.pid, id: f.id }).then(r => { DRF.ui.toast(r.messaggio); carica(); }); }) });
      }
    }
    return voci;
  });
  const sposta = (id, cart) => DRF.api.ext('documentale', 'sposta', { paziente_id: st.pid, id, cartella_id: cart }).then(r => { DRF.ui.toast(r.messaggio, 'success'); carica(); });

  // drag di un file sulla cartella
  let trascinato = null;
  $(document).on('dragstart', '.dcm-it[draggable="true"]', function (e) { trascinato = +this.dataset.id; e.originalEvent.dataTransfer.effectAllowed = 'move'; e.originalEvent.dataTransfer.setData('text/plain', 'dcm:' + trascinato); $(this).addClass('drag'); });
  $(document).on('dragend', '.dcm-it', function () { $(this).removeClass('drag'); $('.dcm-cart').removeClass('over'); });
  $(document).on('dragover', '.dcm-cart:not([data-id="tutti"])', function (e) { if (trascinato) { e.preventDefault(); $(this).addClass('over'); } });
  $(document).on('dragleave', '.dcm-cart', function () { $(this).removeClass('over'); });
  $(document).on('drop', '.dcm-cart:not([data-id="tutti"])', function (e) { if (!trascinato) return; e.preventDefault(); $(this).removeClass('over'); const f = st.file.find(x => +x.id === trascinato); trascinato = null; if (f && +f.cartella_id !== +this.dataset.id) sposta(f.id, +this.dataset.id); });
  // drop di file dal computer nell'area dei documenti
  $(document).on('dragover', '.dcm-file', function (e) { if (puo && !trascinato && e.originalEvent.dataTransfer.types.includes('Files')) { e.preventDefault(); $(this).addClass('over'); } });
  $(document).on('dragleave drop', '.dcm-file', function () { $(this).removeClass('over'); });
  $(document).on('drop', '.dcm-file', function (e) { if (trascinato || !puo) return; const fs = e.originalEvent.dataTransfer.files; if (fs && fs.length) { e.preventDefault(); upload(fs); } });

  function upload(files) {
    if (!files || !files.length) return;
    const cart = st.cart !== 'tutti' ? st.cart : (st.cartelle.find(c => c.sistema === 'documenti') || {}).id;
    const fd = new FormData(); fd.append('paziente_id', st.pid); fd.append('cartella_id', cart);
    Array.from(files).forEach(f => fd.append('file[]', f));
    DRF.ui.toast(`Carico ${files.length} ${U.plural(files.length, 'file', 'file')}…`, { fi: 'cloud-upload', fa: 'fa-solid fa-cloud-arrow-up' });
    DRF.api.ext('documentale', 'upload', fd).then(r => { DRF.ui.toast(r.messaggio, 'success'); if (st.cart === 'tutti') st.cart = cart; carica(); });
  }

  /* ---------- integrazione: scheda paziente, menu contestuale, visita, ricerca */
  DRF.hooks.add('paziente.scheda', ctx => {
    const n = ctx.risposta.documentale_n;
    const $b = ctx.azione('Documenti', () => apri(+ctx.paziente.id, ctx.paziente.nome_completo), { fi: 'folder-open', fa: 'fa-regular fa-folder-open', icona: true, dopo: '#pdEdit' });
    if (n) $b.append(`<b class="dcm-badge">${n}</b>`);
  });
  DRF.hooks.add('pazienti.menu', (voci, p) => { voci.splice(3, 0, { label: 'Documenti', fi: 'folder-open', fa: 'fa-regular fa-folder-open', kbd: 'D', run: () => apri(+p.id, p.nome_completo) }); return voci; });
  DRF.hooks.add('topbar.azioni', (az, modulo) => { if (modulo !== 'visita') return az; const p = DRF.module('visita').paziente && DRF.module('visita').paziente(); return p ? [...az, { label: 'Documenti', fi: 'folder-open', fa: 'fa-regular fa-folder-open', run: () => apri(+p.id, p.nome_completo) }] : az; });
  DRF.hooks.add('search.comandi', ctx => ctx.comando({ label: 'Documenti del paziente in visita', fi: 'folder-open', fa: 'fa-regular fa-folder-open', kw: 'documenti allegati file cartelle', run: () => { const p = DRF.module('visita').paziente(); if (p) apri(+p.id, p.nome_completo); else DRF.ui.toast('Nessuna visita in corso: apri i documenti dalla scheda del paziente'); } }));
  DRF.tasti.add('ctrl+shift+d', () => { const p = DRF.module('visita').paziente(); if (p) apri(+p.id, p.nome_completo); }, 'Documenti del paziente in visita');
  window.DRFDocumentale = { apri };   // per altre estensioni: DRFDocumentale.apri(pazienteId, nome)
})(jQuery);
