/* Navigazione: costa dei moduli con linguetta fluida, pannelli, barra del titolo, tastiera */
DRF.nav = (function ($) {
  'use strict';
  let $btns, $tab, $rail;

  function moveTab(btn, instant) {
    $tab.toggleClass('instant', !!instant);
    $tab[0].style.setProperty('--y', btn.offsetTop + 'px');
    if (!instant) { $tab[0].style.setProperty('--s', '1.18'); setTimeout(() => $tab[0].style.setProperty('--s', '1'), 280); }
  }

  const N = {
    init() {
      $btns = $('.rail-btn'); $tab = $('#tab'); $rail = $('#railNav');
      $btns.on('click', function () { N.go(this.dataset.panel); });
      $('#tbAction').on('click', () => { const m = DRF.current(); if (m && m.action && m.action.run) m.action.run(); });
      $(document).on('keydown', e => {
        const ae = document.activeElement;
        const typing = /INPUT|TEXTAREA|SELECT/.test(ae.tagName) || ae.isContentEditable || $('#sheet').hasClass('open') || $('#modal').hasClass('open') || $('#dialog').hasClass('open');
        if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); $('#searchInput').trigger('focus').trigger('select'); return; }
        // scorciatoie registrate dalle estensioni (DRF.tasti.add): valgono anche con Ctrl/Alt, mai mentre si scrive
        if (!typing && DRF.tasti.gestisci(e)) return;
        if (typing || e.metaKey || e.ctrlKey || e.altKey) return;
        const keys = DRF.keys();
        if (/^[0-9]$/.test(e.key)) { const i = e.key === '0' ? 9 : +e.key - 1; if (i < 10 && keys[i]) N.go(keys[i]); }   // 1-9 e 0: i primi dieci moduli; oltre, le estensioni si danno la loro scorciatoia (DRF.tasti)
        if (e.key === 'ArrowDown') { e.preventDefault(); N.go(keys[(keys.indexOf(DRF.state.current) + 1) % keys.length]); }
        if (e.key === 'ArrowUp') { e.preventDefault(); N.go(keys[(keys.indexOf(DRF.state.current) - 1 + keys.length) % keys.length]); }
      });
      requestAnimationFrame(() => $tab.removeClass('instant'));
    },

    /** Passa al modulo `key`. opts.instant evita l'animazione; il modulo riceve show(opts). */
    go(key, opts = {}) {
      const m = DRF.module(key); if (!m || !$btns.filter(`[data-panel="${key}"]`).length) return;
      const same = key === DRF.state.current;
      if (!same) {
        const btn = $btns.filter(`[data-panel="${key}"]`)[0];
        $btns.removeClass('is-active pop'); btn.classList.add('is-active'); void btn.offsetWidth; btn.classList.add('pop');
        DRF.icons.apply($rail[0]);
        moveTab(btn, opts.instant);
        $('.panel').removeClass('active').filter(`[data-panel="${key}"]`).addClass('active');
        DRF.state.current = key;
        $('#panels').scrollTop(0);
        if (!opts.instant) DRF.sound.play('click');
      }
      if (DRF.postit) DRF.postit.refresh();
      if (!same) DRF.emit('modulo:aperto', { modulo: key, opts });
      N.updateTopbar();
      if (m.show) m.show(opts);
    },

    updateTopbar() {
      const m = DRF.current(); if (!m) return;
      const $t = $('#tbTitle');
      $t.removeClass('swap'); void $t[0].offsetWidth; $t.addClass('swap');
      $t.find('h1').text(m.title || m.key);
      $t.find('p').text(typeof m.sub === 'function' ? m.sub() : (m.sub || ''));
      const $a = $('#tbAction');
      if (m.action) {
        $a.show().html(DRF.icons.html(m.action.fi || 'plus', m.action.fa || 'fa-solid fa-plus') + `<span>${DRF.esc(m.action.label)}</span>`);
        DRF.icons.apply($a[0]);
      } else $a.hide();
      // azioni delle estensioni nella barra del titolo: filtro topbar.azioni (modulo corrente) → [{ label, fi, fa, run, primario }]
      const $ext = $('#tbExt').empty();
      (DRF.hooks.filter('topbar.azioni', [], m.key) || []).forEach(az => {
        const $b = $(`<button class="${az.primario ? 'btn primary' : 'btn ghost'}" type="button" title="${DRF.esc(az.label || '')}">${DRF.icons.html(az.fi || 'puzzle-piece', az.fa || 'fa-solid fa-puzzle-piece')}${az.label ? `<span>${DRF.esc(az.label)}</span>` : ''}</button>`).on('click', az.run);
        $ext.append($b);
      });
      DRF.icons.apply($ext[0]);
    },

    /** Pallino di stato su un'icona della costa (es. visita in corso) */
    setDot(key, on, title) { const $b = $btns.filter(`[data-panel="${key}"]`); $b.find('.dot').remove(); if (on) $b.append(`<span class="dot" title="${DRF.esc(title || '')}"></span>`); },

    /** Aggiorna solo il sottotitolo del modulo corrente (dopo un salvataggio) */
    refreshSub() { const m = DRF.current(); if (m) $('#tbTitle p').text(typeof m.sub === 'function' ? m.sub() : (m.sub || '')); }
  };
  return N;
})(jQuery);
