<div class="procedure stagger">
  <div class="arch-list" id="procList"></div>
  <div id="procBody">
    <div class="arch-head" id="procHead"></div>
    <div class="card" id="procArchivio" hidden><table id="procTable" class="dt" style="width:100%"><thead></thead><tbody></tbody></table></div>
    <div id="procProcedura" hidden>
      <div class="card"><form id="procForm" autocomplete="off"></form><div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn primary" id="procRun" type="button"></button></div></div>
      <div class="card white" id="procResult" style="margin-top:14px" hidden><h3 id="procResultTitle"></h3><div id="procResultBody"></div></div>
    </div>
    <div id="procVista" hidden></div>
    <div class="card" id="procVuoto" hidden>
      <div class="empty" style="text-align:left;line-height:1.8">
        <b><?= __('Questa voce non è ancora collegata.') ?></b><br>
        Per farne un <b>archivio</b>: aggiungi la tabella in <span class="mono">core/schema.sql</span>, una voce in <span class="mono">core/archivi.php</span> e la form in <span class="mono">form/definitions/</span>; poi in <span class="mono">core/procedure.php</span> imposta <span class="mono">\'tipo\' =&gt; \'archivio\'</span>.<br>
        Per farne una <b>procedura</b>: crea <span class="mono">core/procedure/NomeProcedura.php</span> (estende <span class="mono"><?= __('Procedura') ?></span>: <span class="mono">campi()</span> + <span class="mono">esegui()</span>) e imposta <span class="mono">\'tipo\' =&gt; \'procedura\'</span>.<br>
        Per una <b>pagina libera</b>: crea <span class="mono">views/procedure/nome.php</span> (HTML) e, se serve logica, <span class="mono">DRF.module(\'procedure\').viste.nome = ($root) =&gt; {…}</span> in <span class="mono">assets/js/procedure.js</span>; imposta <span class="mono">\'tipo\' =&gt; \'vista\'</span>.
      </div>
    </div>
  </div>
</div>
