<?php
return [
    'title' => __('Nuovo metodo di pagamento'), 'title_edit' => __('Modifica metodo di pagamento'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Salva metodo'),
    'table' => 'metodi_pagamento',
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'metodi_pagamento'],
        ['name' => 'nome', 'label' => __('Nome'), 'type' => 'text', 'required' => true],
        ['name' => 'giorni', 'label' => __('Giorni per l\'incasso'), 'type' => 'text', 'mask' => 'intero', 'default' => 0, 'row' => 1, 'help' => __('0 = incasso immediato; con un valore la fattura nasce "in attesa" con scadenza a quei giorni')],
        ['name' => 'predefinito', 'label' => __('Predefinito'), 'type' => 'switch', 'default' => 0, 'row' => 1, 'help' => __('Proposto nelle nuove fatture')],
        ['name' => 'conto', 'label' => __('Conto'), 'type' => 'text', 'placeholder' => __('Es. IBAN o conto contabile'), 'row' => 2],
        ['name' => 'sdi', 'label' => __('Codice SDI'), 'type' => 'text', 'placeholder' => __('Es. MP01, MP05, MP08'), 'class' => 'mono', 'row' => 2, 'help' => __('Modalità di pagamento per fattura elettronica / Sistema TS')],
        ['name' => 'non_esporta', 'label' => __('Non esportare'), 'type' => 'switch', 'default' => 0, 'help' => __('Le fatture con questo metodo verranno escluse dalle esportazioni (SDI / STS)')],
        ['name' => 'attivo', 'label' => __('Attivo'), 'type' => 'switch', 'default' => 1],
    ],
];
