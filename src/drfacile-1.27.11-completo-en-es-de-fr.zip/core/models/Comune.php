<?php
/** Comuni italiani (tabella condivisa). Ricerca per Select2 e lookup per CAP/provincia/codice catastale */
final class Comune
{
    public static function cerca(string $q, int $limit = 20): array
    {
        $t = Database::comune('comuni');
        $q = mb_strtolower(trim($q));
        $where = $q === '' ? '1=1' : (preg_match('/^\d{3,5}$/', $q) ? 'cap LIKE :q' : 'LOWER(nome) LIKE :q');
        $p = $q === '' ? [] : ['q' => $q . '%'];
        $rows = Database::all("SELECT * FROM $t WHERE $where ORDER BY nome LIMIT $limit", $p);
        return array_map(fn($r) => ['id' => $r['nome'], 'text' => $r['nome'] . ' (' . $r['provincia'] . ')' . ($r['cap'] ? ' · ' . $r['cap'] : ''), 'nome' => $r['nome'], 'provincia' => $r['provincia'], 'cap' => $r['cap'], 'cod' => $r['cod_catastale']], $rows);
    }

    public static function daNome(string $nome): ?array
    {
        return Database::one('SELECT * FROM ' . Database::comune('comuni') . ' WHERE LOWER(nome) = ? LIMIT 1', [mb_strtolower(trim($nome))]);
    }

    public static function daCodice(string $cod): ?array
    {
        return Database::one('SELECT * FROM ' . Database::comune('comuni') . ' WHERE cod_catastale = ? LIMIT 1', [strtoupper($cod)]);
    }
}
