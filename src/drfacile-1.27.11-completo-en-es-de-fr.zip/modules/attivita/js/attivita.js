/* Modulo Scrivania: Attività (registro delle operazioni) */
DRF.desk.register('attivita', {
  init($win) {
    const AZ = { 'paziente.creato': DRF.__('Nuovo paziente'), 'paziente.modificato': DRF.__('Scheda paziente aggiornata'), 'appuntamento.creato': DRF.__('Prenotazione'), 'appuntamento.modificato': DRF.__('Prenotazione modificata'), 'visita.avviata': DRF.__('Visita avviata'), 'visita.chiusa': DRF.__('Visita chiusa'), 'referto.firmato': DRF.__('Referto firmato'), 'referto.inviato': DRF.__('Referto inviato'), 'ricetta.inviata': DRF.__('Ricetta inviata'), 'fattura.emessa': DRF.__('Fattura emessa'), 'fattura.incassata': DRF.__('Fattura incassata'), 'sistema.backup': DRF.__('Backup'), 'accesso.login': DRF.__('Accesso') };
    const st = { utente: 0, q: '' };
    $win.find('.att').prepend('<div class="att-bar"><div class="att-ut-w"><select class="select att-ut"><option value="0">' + DRF.__('Tutti gli utenti') + '</option></select></div><input class="input sm att-q" type="search" placeholder="' + DRF.__('Cerca…') + '"></div>');
    DRF.api.get('attivita', 'utenti').then(d => { $win.find('.att-ut').append(d.utenti.map(u => `<option value="${u.utente_id}">${DRF.esc(u.utente)} (${u.n})</option>`).join('')); DRF.ui.select($win.find('.att-ut'), { dropdownParent: $win, minimumResultsForSearch: Infinity }); });
    $win.on('change', '.att-ut', function () { st.utente = +this.value; load(); }).on('input', '.att-q', DRF.util.debounce(function () { st.q = this.value; load(); }, 200));
    const load = () => DRF.api.get('attivita', 'recenti', { n: 60, utente_id: st.utente, q: st.q }).then(l => { $win.find('.att-list').html(l.map(a => `<div class="att-it"><span class="att-ico">${DRF.icons.html(a.icona[0], a.icona[1])}</span><div><b>${DRF.esc(AZ[a.azione] || a.azione)}</b><span>${DRF.esc(a.descrizione || '')}</span><small>${a.utente ? '<b class="att-chi">' + DRF.esc(a.utente) + '</b> · ' : ''}${DRF.notify.rel(a.creato_il)} · ${DRF.util.fmtDateTime(a.creato_il)}${a.ip && a.ip !== '::1' && a.ip !== '127.0.0.1' ? ' · ' + DRF.esc(a.ip) : ''}</small></div></div>`).join('') || '<div class="empty">' + DRF.__('Nessuna attività registrata.') + '</div>'); DRF.icons.apply($win[0]); });
    $win.data('load', load); load();
  },
  open($win) { const l = $win.data('load'); if (l) l(); }
});
