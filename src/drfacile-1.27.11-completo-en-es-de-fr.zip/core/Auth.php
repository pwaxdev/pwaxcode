<?php
/**
 * Autenticazione basata su sessione (utenti del database comune, ripiego legacy su config) + token CSRF per le chiamate AJAX in scrittura.
 */
final class Auth
{
    /**
     * Stato dell'abbonamento SaaS DELLO STUDIO: ['stato' => attivo|in_scadenza|scaduto|non_gestito, 'scadenza', 'giorni', 'url', 'periodo'].
     * Lo studio è quello passato, altrimenti quello della sessione. Senza studio noto (login, CLI, installazioni legacy
     * non migrate) si legge il ripiego nelle impostazioni del database dedicato — MAI "il primo studio del comune":
     * in un SaaS con più studi mostrerebbe l'abbonamento di qualcun altro.
     */
    public static function abbonamento(?int $studioId = null): array
    {
        $cfg = (array) (Config::get('abbonamento') ?? []);
        $url = $cfg['rinnovo_url'] ?? 'https://drfacile.it/rinnova';
        $scad = null; $periodo = null;
        $studioId = $studioId ?? (self::studioId() ?: null);
        if ($studioId) {
            try {
                $s = Database::one('SELECT abbonamento_scadenza, abbonamento_periodo FROM ' . Database::comune('studi') . ' WHERE id = ?', [$studioId]);
                if ($s) { $scad = $s['abbonamento_scadenza'] ?: null; $periodo = $s['abbonamento_periodo'] ?: null; }
            } catch (Throwable $e) { /* comune non pronto */ }
        }
        $scad = $scad ?: Impostazione::get('abbonamento_scadenza');
        $periodo = $periodo ?: Impostazione::get('abbonamento_periodo', 'mensile');
        if (empty($cfg['attivo']) || !$scad) return ['stato' => 'non_gestito', 'scadenza' => null, 'giorni' => null, 'url' => $url, 'periodo' => $periodo];
        $giorni = (int) floor((strtotime($scad) - strtotime(oggi())) / 86400);
        $avviso = (int) ($cfg['avviso_giorni'] ?? 7);
        return ['stato' => $giorni < 0 ? 'scaduto' : ($giorni <= $avviso ? 'in_scadenza' : 'attivo'), 'scadenza' => $scad, 'giorni' => $giorni, 'url' => $url, 'periodo' => $periodo];
    }

    /** Vero se la password predefinita della prima installazione (medico / drfacile) è ancora in uso: dall'utente collegato, o dall'utente `medico` se nessuno è collegato */
    public static function passwordPredefinita(): bool
    {
        $hash = null;
        try {
            $id = $_SESSION['drf_user']['utente_id'] ?? null;
            $u = $id ? Utente::trova((int) $id) : Utente::perUsername('medico');
            if ($u) $hash = (string) ($u['password_hash'] ?? '');
        } catch (Throwable $e) { /* comune non pronto */ }
        if ($hash === null) $hash = Impostazione::get('auth_password_hash') ?: (string) Config::get('auth.password_hash');   // legacy non migrato
        return $hash !== '' && password_verify('drfacile', $hash);
    }

    public static function check(): bool
    {
        if (empty($_SESSION['drf_user'])) return false;
        $life = (int) Config::get('auth.lifetime', 28800);
        if ($life > 0 && time() - ($_SESSION['drf_user']['ultimo_accesso'] ?? 0) > $life) { self::logout(); return false; }
        $_SESSION['drf_user']['ultimo_accesso'] = time();
        return true;
    }

    public static function user(): ?array { return $_SESSION['drf_user'] ?? null; }

    public static function login(string $username, string $password): bool
    {
        $u = null;
        try { $u = Utente::perUsername(strtolower(trim($username))); } catch (Throwable $e) { /* tabella comune non ancora pronta */ }
        if ($u) {
            if (!password_verify($password, $u['password_hash'])) { usleep(300000); return false; }
            $studio = Utente::studio((int) $u['studio_id']);
            if ($studio && !(int) $studio['attivo']) { usleep(300000); return false; }   // studio sospeso dal portale (strumenti/studio.php disattiva)
        } else {
            // ripiego legacy SOLO finché la tabella utenti è vuota (installazione non ancora migrata):
            // appena esiste un utente vero, le credenziali di config.php non aprono più nulla
            $vuota = true;
            try { $vuota = !Database::value('SELECT COUNT(*) FROM ' . Database::comune('utenti')); } catch (Throwable $e) { /* comune non pronto: legacy */ }
            if (!$vuota) { usleep(300000); return false; }
            $hash = Impostazione::get('auth_password_hash') ?: (string) Config::get('auth.password_hash');
            if (!hash_equals((string) Config::get('auth.username'), $username) || !password_verify($password, $hash)) { usleep(300000); return false; }
        }
        if ($u) Utente::assicuraAdmin((int) $u['studio_id']);   // ogni studio ha almeno un amministratore (il primo medico)
        session_regenerate_id(true);
        $_SESSION['drf_user'] = ['username' => $u['username'] ?? $username, 'utente_id' => $u ? (int) $u['id'] : null, 'studio_id' => $u ? (int) $u['studio_id'] : null, 'login' => time(), 'ultimo_accesso' => time()];
        $_SESSION['drf_csrf'] = bin2hex(random_bytes(24));
        $_SESSION['drf_login_da_registrare'] = 'Accesso riuscito';   // utente e IP li registra Attivita da sé   // il registro attività è dello STUDIO: lo scrive il bootstrap della prossima richiesta, a tenant risolto
        return true;
    }

    /** L'utente collegato (dalla tabella comune), con iniziali e avatar personale */
    public static function utente(): ?array
    {
        static $cache = null;
        if ($cache !== null) return $cache;
        if (empty($_SESSION['drf_user'])) return null;   // nessuno collegato: nessun utente (mai uno fittizio)
        $id = $_SESSION['drf_user']['utente_id'] ?? null;
        $u = $id ? Utente::trova((int) $id) : null;
        if (!$u) {   // legacy (sessione aperta con le credenziali di config, tabella utenti vuota): utente fittizio dal profilo
            $p = Impostazione::profilo();
            $u = ['id' => 0, 'studio_id' => 0, 'username' => $_SESSION['drf_user']['username'] ?? '', 'nome' => $p['nome'] ?? '', 'cognome' => $p['cognome'] ?? '', 'sesso' => $p['sesso'] ?? 'F', 'ruolo' => 'medico', 'admin' => 1, 'email' => $p['email'] ?? '', 'telefono' => $p['telefono'] ?? ''];
        }
        unset($u['password_hash']);
        $u['nome_completo'] = trim(($u['nome'] ?? '') . ' ' . ($u['cognome'] ?? ''));
        $u['iniziali'] = mb_strtoupper(mb_substr((string) $u['nome'], 0, 1) . mb_substr((string) $u['cognome'], 0, 1)) ?: 'DR';
        $ava = DRF_ROOT . '/data/avatar-u' . (int) $u['id'] . '.png';
        $u['avatar'] = is_file($ava) ? 'ajax/avatar.php?action=img&v=' . filemtime($ava) : null;
        return $cache = $u;
    }

    public static function studioId(): int { return (int) ($_SESSION['drf_user']['studio_id'] ?? 0); }

    /* ------------------------------------------------------------------ PERMESSI (core/permessi.php) */

    private static ?array $mappa = null;

    /** La mappa dei permessi per ruolo, passata dall'hook `auth.permessi` (le estensioni possono ampliarla) */
    public static function mappaPermessi(): array
    {
        if (self::$mappa === null) {
            $m = require DRF_ROOT . '/core/permessi.php';
            self::$mappa = class_exists('Hooks') ? (array) Hooks::filter('auth.permessi', $m) : $m;
        }
        return self::$mappa;
    }

    /** L'utente collegato è l'amministratore dello studio? (flag utenti.admin; le installazioni legacy non migrate contano come admin) */
    public static function admin(): bool
    {
        if (empty($_SESSION['drf_user'])) return false;
        $u = self::utente();
        return $u !== null && ((int) ($u['admin'] ?? 0) === 1 || (int) ($u['id'] ?? 0) === 0);
    }

    /**
     * Auth::can('visite.modifica'): l'utente collegato ha il permesso?
     * Regole: l'amministratore può tutto; i permessi in 'solo_admin' sono negati a chiunque altro;
     * per gli altri vale la lista del ruolo ('*' = tutto, 'agenda.*' = tutta l'area, 'agenda.leggi' = puntuale).
     * Vuoto o null = nessun permesso richiesto (basta essere autenticati).
     */
    public static function can(?string $permesso): bool
    {
        if ($permesso === null || $permesso === '') return true;
        if (empty($_SESSION['drf_user'])) return false;   // nessuno collegato: nessun permesso
        $u = self::utente();
        if (!$u) return false;
        $ok = self::valuta($permesso, (string) ($u['ruolo'] ?? ''), self::admin());
        return class_exists('Hooks') ? (bool) Hooks::filter('auth.can', $ok, $permesso, $u) : $ok;
    }

    /** Come can(), ma per un ruolo/flag qualsiasi (utile per liste e anteprime) */
    public static function valuta(string $permesso, string $ruolo, bool $admin): bool
    {
        $m = self::mappaPermessi();
        if ($admin) return true;
        if (in_array($permesso, $m['solo_admin'] ?? [], true)) return false;
        foreach ((array) ($m[$ruolo] ?? []) as $regola) {
            if ($regola === '*' || $regola === $permesso) return true;
            if (str_ends_with($regola, '.*') && str_starts_with($permesso, substr($regola, 0, -1))) return true;
        }
        return false;
    }

    /** Vero o eccezione 403 (per gli endpoint fuori dal router Api::run, es. download) */
    public static function richiedi(string $permesso): void
    {
        if (self::can($permesso)) return;
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => false, 'error' => 'Non hai il permesso per questa operazione (' . $permesso . ')']);
        exit;
    }

    /** L'elenco dei permessi effettivi dell'utente collegato (per l'interfaccia: DRF.can) */
    public static function permessi(): array
    {
        if (empty($_SESSION['drf_user'])) return [];
        $u = self::utente();
        if (!$u) return [];
        $tutti = [];
        foreach (self::mappaPermessi() as $k => $lista) if ($k !== 'solo_admin') foreach ((array) $lista as $p) if ($p !== '*' && !str_ends_with($p, '.*')) $tutti[] = $p;
        // il catalogo completo: regole puntuali della mappa + permessi noti del core (l'interfaccia chiede solo questi)
        $core = ['agenda.leggi', 'agenda.modifica', 'pazienti.leggi', 'pazienti.modifica', 'pazienti.elimina', 'visita.leggi', 'visita.modifica', 'ricette.leggi', 'ricette.emetti',
            'referti.leggi', 'referti.modifica', 'referti.invia', 'fatture.leggi', 'fatture.emetti', 'fatture.modifica', 'fatture.incassa', 'documenti.leggi', 'documenti.modifica',
            'comunicazioni.leggi', 'comunicazioni.invia', 'archivi.leggi', 'archivi.modifica', 'procedure.leggi', 'procedure.esegui', 'statistiche.leggi', 'contabilita.leggi',
            'impostazioni.leggi', 'impostazioni.modifica', 'impostazioni.backup', 'store.leggi', 'utenti.gestisci', 'store.gestisci', 'attivita.leggi', 'scadenzario.leggi', 'scadenzario.chiudi', 'assistente.usa'];
        $tutti = array_unique(array_merge($core, $tutti, self::mappaPermessi()['solo_admin'] ?? []));
        return array_values(array_filter($tutti, fn($p) => self::can($p)));
    }

    public static function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    /** Per le pagine: reindirizza al login */
    public static function requirePage(): void
    {
        if (!self::check()) { header('Location: login.php'); exit; }
    }

    /** Per gli endpoint AJAX: risponde 401 in JSON */
    public static function requireAjax(): void
    {
        if (!self::check()) {
            http_response_code(401);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => 'Sessione scaduta, accedi di nuovo']);
            exit;
        }
    }

    public static function csrf(): string
    {
        if (empty($_SESSION['drf_csrf'])) $_SESSION['drf_csrf'] = bin2hex(random_bytes(24));
        return $_SESSION['drf_csrf'];
    }

    public static function verifyCsrf(): bool
    {
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $_POST['_csrf'] ?? '';
        return $token !== '' && hash_equals(self::csrf(), $token);
    }
}
