# DRFacile

Gestionale monoutente per lo studio medico, derivato dai moduli di **Igea**. PHP 8.1+, jQuery, CSS puro, database SQLite (o MySQL).
L'interfaccia è quella del prototipo approvato: costa dei moduli a sinistra con la linguetta fluida, area di lavoro a destra.

## Requisiti

- PHP **8.1 o superiore** con le estensioni `pdo_sqlite` (oppure `pdo_mysql`), `mbstring`, `json`
- Un web server (Apache con `mod_rewrite` non necessario, Nginx, oppure `php -S` per lo sviluppo)
- Nessuna dipendenza esterna obbligatoria: jQuery, Select2, DataTables, flatpickr, Inputmask, Font Awesome e i font sono inclusi in `assets/vendor`.
  Le icone Flaticon UIcons vengono caricate dal CDN e, se non raggiungibili, il sistema passa da solo a Font Awesome icona per icona.

## Installazione

1. Copia la cartella sul server (es. `/var/www/drfacile`) e punta il virtual host alla cartella principale.
2. Rendi scrivibili dal web server le cartelle `data/`, `docs/archivio/`, `docs/backup/`, `temp/`.
3. Copia `config/config.esempio.php` in `config/config.php` e imposta:
   - `auth.username` e `auth.password_hash` (genera l'hash con `php -r 'echo password_hash("nuova-password", PASSWORD_DEFAULT);'`) — la password predefinita **drfacile** è pubblica: su un server in rete va cambiata *prima* del primo accesso
   - `app.debug = false` e, se non vuoi i dati dimostrativi, `app.demo = false`
   - `auth.cookie_secure`: `'auto'` va bene se il sito è servito in HTTPS (anche dietro proxy che manda `X-Forwarded-Proto`); `true` per imporlo
   - eventualmente `db.driver = 'mysql'` con le credenziali (vedi sotto)
4. Apri il sito: al primo accesso il database viene creato e (in modalità demo) popolato con pazienti, agenda della settimana e 12 mesi di storico.
5. Accedi con l'utente configurato al punto 3 (poi gli altri utenti si aggiungono da Impostazioni → Utenti).

Su un server raggiungibile dalla rete DRFacile **non** crea `config.php` da solo: senza il file risponde con le istruzioni (503). La copia automatica dall'esempio avviene solo in locale (`php -S`, CLI, o richieste da 127.0.0.1).

Per provare in locale: `php -S 127.0.0.1:8080 -t .` e apri `http://127.0.0.1:8080/login.php` — qui la configurazione d'esempio viene copiata da sola e si entra con **medico / drfacile**.

### MySQL / MariaDB

In `config/config.php` imposta `'driver' => 'mysql'` e le credenziali in `db.mysql`. Se il database indicato nel DSN non esiste, DRFacile lo crea da solo al primo accesso (`utf8mb4`), purché l'utente abbia il privilegio `CREATE`; in alternativa crealo prima tu:

```sql
CREATE DATABASE drfacile CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Le tabelle vengono create in InnoDB con chiavi esterne; lo schema è lo stesso di SQLite (`core/schema.sql`), adattato automaticamente dall'Installer. Il backup dal pannello Impostazioni produce un file `.sql` in `docs/backup`, ripristinabile con `mysql drfacile < file.sql`.

## Struttura

```
index.php, login.php        entry point e pagina di accesso
config/config.php           configurazione: credenziali, database, percorsi, parametri agenda/fattura
core/                       sistema PHP
  bootstrap.php             autoload, sessione, database, installazione automatica
  Config, Database, Auth, Api, Model, Helpers, Installer, Seed, Documenti
  modules.php               elenco dei moduli (ordine della costa, icone, file css/js)
  schema.sql                schema del database
  models/                   Paziente, Appuntamento, Visita, Referto, Ricetta, Farmaco, Prestazione, Fattura, Impostazione, Storico
  archivi.php               registro degli archivi di base (tabella, form, colonne della DataTable)
  schema-comune.sql         tabelle condivise fra tutti gli ambienti (comuni; poi AIFA, ICD9/ICD10…)
  CodiceFiscale.php         calcolo, verifica e decodifica del codice fiscale (stessa logica in assets/core/cf.js)
ajax/                       endpoint JSON, uno per modulo: ajax/<modulo>.php?action=<azione>
                            agenda, pazienti, visita, ricette, referti, fatture, statistiche, archivi, impostazioni, search, form, documenti, auth
form/                       generatore di form (CRUD)
  FormBuilder.php           rende una definizione in HTML e la precompila per la modifica
  definitions/              paziente, appuntamento, fattura, prestazione, farmaco, tipo_appuntamento, diagnosi, esenzione, metodo_pagamento
views/                      layout.php + sections/<modulo>.php (markup di ogni sezione)
assets/core/                JavaScript di sistema (drf, utils, icons, api, sound, ui, form, nav, search, app)
  procedure.php             voci del modulo Procedure (archivio o procedura per ogni voce)
  procedure/                Procedura.php (classe base) e le procedure dello studio (es. Promemoria.php)
  Scrivania.php             discovery dei moduli della Scrivania (modules/<key>/) e layout personale
modules/                    moduli della Scrivania (vedi modules/MODULE.md): calc (calcolatrice), oggi (agenda del giorno), attivita (registro), timer (cronometro visita), ritmo (gioco di memoria)
assets/js/                  un file per modulo: agenda, pazienti, visita, ricette, referti, fatture, statistiche, archivi, procedure, impostazioni
assets/css/                 app.css (sistema), plugins.css (tema Select2/DataTables), un file per modulo, login.css
assets/images/              logo, favicon, avatar
assets/sounds/              success, error, notify, click
assets/vendor/              jquery, select2, datatables, flatpickr, inputmask, fontawesome, font Sora/Manrope, igea/bodymodel.js (motore mappa corporea)
views/partials/svgbody.php  modelli corporei SVG (uomo, donna, ragazzo, ragazza, neonato · fronte e retro), da Igea
docs/templates/             modelli stampabili: referto, ricetta (promemoria NRE), fattura
docs/archivio/<tipo>/<anno> documenti generati (referti firmati, ricette, fatture) in HTML
docs/backup/                copie del database
data/                       database SQLite
temp/                       file temporanei
```

## Come funziona un modulo

Ogni modulo è composto da quattro file con lo stesso nome (`agenda`, `pazienti`, …):

| File | Ruolo |
|---|---|
| `views/sections/<modulo>.php` | markup della sezione, incluso nel layout |
| `assets/css/<modulo>.css` | stile della sezione |
| `assets/js/<modulo>.js` | logica: `DRF.register('<modulo>', { title, sub(), action, init(), show(opts) })` |
| `ajax/<modulo>.php` | azioni JSON: `Api::run(['list' => fn($in) => ..., 'save' => fn($in) => ...])` |

Per aggiungere un modulo basta creare i quattro file e una riga in `core/modules.php`.

### Convenzioni

- **AJAX**: `DRF.api.get('agenda','giorno',{data})` per le letture, `DRF.api.post('agenda','save',{...})` per le scritture (JSON + token CSRF automatico). La risposta è `{ok:true, data:...}` oppure `{ok:false, error:"..."}`.
- **Form**: `DRF.form.open('paziente', {id, values, onSaved})` chiede a `ajax/form.php` la form definita in `form/definitions/paziente.php`, la apre nel pannello laterale e la invia all'endpoint indicato nella definizione.
- **Navigazione**: `DRF.nav.go('referti', {select: 12})` apre un modulo passando opzioni a `show()`.
- **Interfaccia**: `DRF.ui.toast(msg, 'success'|'error'|'warn'|'info')`, `DRF.ui.confirm(titolo, testo)` → true/false, `DRF.ui.confirm3(titolo, testo)` → 'si'|'no'|'annulla', `DRF.ui.alert(...)`, `DRF.ui.dialog({ title, text, kind, buttons })` → chiave premuta, `DRF.ui.modal({ title, html, size, ok, cancel, onOpen, onOk })` → true/false, `DRF.ui.openSheet(...)`. La pagina **Procedure → Voce 3 "Controlli"** mostra ogni controllo dal vivo con il codice per usarlo.
- **Componenti di base**: `DRF.ui.steps($el, { steps, current })` barra dei passi (set/error/done); `DRF.ui.timeline($el, voci, { compatta })` linea del tempo da array (data, tipo, titolo, testo, icona, colore, run) con `DRF.storico.render()` già pronto per lo storico paziente; `DRF.ui.toast(msg, kind, { undo })` con "Annulla" (usato su eliminazione di appuntamenti e post-it); bus di eventi `DRF.on / DRF.emit` (`modulo:aperto`, `paziente:selezionato`, `visita:avviata`, `visita:chiusa`); ⌘K trova anche i **comandi** (`DRF.search.comando({ label, fi, fa, kw, run })`); `?` apre le scorciatoie.
- **Registro attività**: `Attivita::registra('fattura.emessa', 'fatture', $id, 'testo')` traccia le operazioni (pazienti, agenda, visite, referti, ricette, fatture, accessi, backup); si consulta dal modulo "Attività" della Scrivania (`ajax/attivita.php`).
- **Notifiche**: `Notifica::aggiungi(tipo, titolo, testo, link)` in PHP o `DRF.notify.add({ tipo, titolo, testo, link })` in JS. La campanella apre il pannello con le ultime (tempo relativo: poco fa, 2 minuti fa, ieri…), `DRF.notify.centro()` la modale con tutte (lette/non lette, eliminazione). Il sistema ne genera da solo: referto da firmare, fattura scaduta, ricetta inviata, nuovo paziente, sovrapposizioni in agenda, backup.
- **Menu contestuale**: `DRF.menu.show(x, y, voci, { title })`, `DRF.menu.showAt($btn, voci)`, `DRF.menu.bind($root, selettore, el => voci)` per il tasto destro; voci con icona, `disabled`, `danger`, `kbd`, `{ sep: true }`; frecce e Invio da tastiera. Usato su agenda (appuntamenti, spazi liberi, giorni del mese), post-it e dock della Scrivania.
- **Scrivania**: click sull'avatar. Moduli in `modules/<key>/` (def + php + css + js, sistema a discovery: vedi `modules/MODULE.md`); chiusi nel dock, aperti come finestre trascinabili; posizione, dimensione e stato salvati nelle impostazioni e ripristinati al prossimo accesso. `DRF.desk.open()`, `DRF.desk.apri('calc')`.
- **Post-it**: l'icona in alto incolla un post-it (trascinabile, ridimensionabile, ruotabile, colori, dimensione testo, grassetto) legato al contesto: `sezione` + `record`. Un modulo espone il record con `record()` → `{ sezione: 'paziente', record: id }`; così un post-it su un paziente lo segue in Pazienti e in Visita. Tabella `postit`, endpoint `ajax/postit.php`, motore `assets/core/postit.js` (senza jQuery UI). `DRF.postit.nuovo(testo)` e `DRF.postit.refresh()`; tasto destro sull'icona: nascondi/mostra, ordina in pila, elimina tutti.
- **Select e tabelle**: ogni `<select class="select">` diventa una Select2 (automatico via `DRF.ui.wire`), le tabelle si creano con `DRF.ui.datatable($table, opzioni)` (DataTables 2 in italiano, stile del gestionale). Standard: la prima colonna contiene le icone di azione (modifica, elimina, altro).
- **Date e numeri**: ogni `input[type=date|time]` diventa un flatpickr (visualizzazione gg/mm/aaaa, valore Y-m-d); i campi numerici usano Inputmask con gli alias `euros`, `numero`, `decimale`, `sconto` (gli stessi di Igea) più `intero`, `decimale1` e `cap` (`data-mask="euros"` o `'mask' => 'euros'` nelle definizioni). `DRF.ui.val($el)` restituisce sempre il valore grezzo, `DRF.ui.setVal($el, v)` imposta aggiornando Select2/flatpickr/Inputmask.
- **Form paziente**: definita in `form/definitions/paziente.php` su griglia a 12 colonne (`'row'` + `'w'`), con sezioni, campo `cf` (calcolo dal nome/data/comune, verifica in tempo reale, decodifica di data, sesso e comune di nascita) e campo `comune` (Select2 con ricerca sulla tabella comuni, compila CAP/provincia/codice catastale). Il codice fiscale è verificato anche dal server.
- **CRUD standard**: `DRF.crud.mount({ head, table, archivio })` monta intestazione, DataTable (icone di azione nella prima colonna) e form di un archivio definito in `core/archivi.php`. Lo usano i moduli Archivi e Procedure.
- **Procedure**: le voci sono in `core/procedure.php`. Una voce di tipo `archivio` punta a un archivio (CRUD standard); una di tipo `procedura` a una classe in `core/procedure/` che estende `Procedura` con `campi()` (parametri, nel formato del FormBuilder) ed `esegui()` (restituisce titolo e HTML del risultato); una di tipo `vista` a una pagina libera `views/procedure/<nome>.php` con logica opzionale in `DRF.module('procedure').viste.<nome>($root)`. Le demo (registro consensi, promemoria appuntamenti, pagina dei controlli) sono il modello per crearne di nuove.
- **Mappa corporea**: `DRF.bodymap({ box, mode: 'sintomi'|'esame', getMeta })` (assets/core/bodymap.js) sul motore BodyModel di Igea; il modello (neonato ≤3 anni, ragazzo/a ≤14, uomo/donna) segue sesso ed età del paziente, con scelta manuale e vista fronte/retro. In Visita: quadro soggettivo (sintomi: tipo e intensità 1–10) in Anamnesi e quadro oggettivo (reperti: nella norma/lieve/marcato/severo) nella scheda Visita; entrambi finiscono nel referto.
- **Archivi**: le tabelle di base (prestazioni, farmaci, tipi di appuntamento, diagnosi, esenzioni, metodi di pagamento, aliquote IVA) si gestiscono dal modulo Archivi. Per aggiungerne uno: una riga in `core/archivi.php` + una definizione in `form/definitions/`; il modulo genera DataTable e form da solo.
- **Tastiera**: tasti 1–9 e 0 per i dieci moduli, ↑/↓ per scorrerli, ⌘K / Ctrl+K per la ricerca, Esc chiude (prima calendari e tendine, poi messaggi, modali e pannello).

- **Fatturazione a righe**: la fattura è composta da più righe — prestazioni dal listino, righe libere e righe descrittive — con quantità, prezzo e aliquota IVA modificabili riga per riga. Ogni prestazione ha la sua aliquota (archivio **Aliquote IVA**: esente art. 10 per le prestazioni sanitarie, 22% per la medicina estetica…); il riepilogo calcola imponibile, IVA per aliquota, contributo previdenziale e marca da bollo (applicata alla quota esente oltre la soglia). In **Impostazioni → Fatturazione** si configurano le *spese di studio* (attivabili con importo e descrizione: vengono proposte come riga in ogni nuova fattura) e il *contributo previdenziale* (percentuale sull'imponibile con descrizione, es. contributo integrativo Cassa/INPS 4%, proposto e disattivabile fattura per fattura).
- **Prestazioni in visita e fattura dalla visita**: nella scheda visita (Motivo e anamnesi) si segnano le **prestazioni eseguite** (Select2 multipla dal listino); alla chiusura arriva la notifica "Visita da fatturare" e dal modulo Fatture il pulsante **Da visita** elenca le visite chiuse non ancora fatturate: un click e la fattura si compila da sola (paziente, righe, prezzi e IVA dal listino), senza riscrivere nulla. La fattura resta collegata alla visita (`fatture.visita_id`).
- **Prestazioni = tipi di appuntamento**: le due tabelle sono state fuse. Ogni prestazione ha **colore** e **durata** proposti in agenda (scegliendo la prestazione nella prenotazione, la durata si imposta da sola), oltre a prezzo, aliquota IVA e switch **Prenotabile online**. L'archivio "Tipi di appuntamento" non esiste più: all'aggiornamento i tipi esistenti confluiscono nelle prestazioni e gli appuntamenti vengono ricodificati automaticamente, senza perdere nulla.
- **Istruzioni pre-visita**: su ogni prestazione uno switch attiva le istruzioni da inviare a chi prenota — titolo, testo (con l'editor DRF.rich e i campi {paziente}, {prestazione}, {data}, {ora}, {medico}, {studio}) e quando inviarle (alla prenotazione, 24 o 48 ore prima). Alla prenotazione in agenda un avviso ricorda l'invio previsto; l'invio vero e proprio arriverà con i canali di comunicazione.
- **Sistema modulare (hook)**: il cuore della piattaforma. `core/Hooks.php` (server) e `DRF.hooks` (client) sono i punti di aggancio; le estensioni vivono in `estensioni/<codice>/` (`estensione.php` + js/css caricati solo se attive), possono aggiungere ruoli, voci di Procedure, pannelli in visita, app della Scrivania (def `estensione: codice`) ed endpoint propri. Versioni gestite su due piani (catalogo `store_moduli.versione` + installazioni `estensioni.versione`, allineate a ogni avvio con l'hook `estensione.aggiornata`); abbonamenti con **scadenza** (`Estensioni::attiva()` si spegne da sola a scadenza; attivazioni/proroghe via `strumenti/estensione.php`, richiamato dal portale dopo il pagamento — flusso Stripe documentato). Manuale completo in `docs/sviluppo-estensioni.md`; l'estensione **BMI in visita** nel Negozio è l'esempio guida funzionante.
- **Visite specialistiche come estensioni**: la colonna `visite.dati` dà a ogni estensione il suo spazio strutturato per visita (chiavi per codice, fuse — più moduli convivono), `ctx.getDati/setDati` lo fa viaggiare con l'autosave della bozza, e l'hook `referto.sezioni` porta i campi nel referto alla chiusura. L'esempio completo è l'estensione **Visita ginecologica** (Negozio): UM, ciclo, G·P·A, contraccezione, pap test, ecografia → sezione «Valutazione ginecologica» nel referto, dopo l'esame obiettivo.
- **Store** (icona nella Scrivania): estensioni e moduli con ricerca, categorie, voti a stelle, filtro Tutte/Installate/Aggiornamenti. Due origini: i pacchetti **distribuiti con il programma** e quelli del **repository** (`store.repository` in config: URL HTTPS o cartella locale con `catalogo.json` + `pacchetti/*.zip`), scaricati e installati con verifica sha256, requisiti (versione DRFacile/PHP), dipendenze e conflitti; aggiornamenti segnalati e applicati con un click; disattivazione (i dati restano) e rimozione dei file. Ogni pacchetto dichiara `stato` di **approvazione**: gli studi vedono gli approvati, un'installazione con `store.revisore = true` anche quelli in revisione, per provarli prima di pubblicarli. Strumenti: `strumenti/pacchetto.php` (crea lo ZIP da `estensioni/<codice>/` + `manifest.json`), `strumenti/repository.php` (genera il catalogo; `approva`/`respingi`/`voti`). Endpoint delle estensioni via `ajax/ext.php?ext=<codice>` (`DRF.api.ext`), app della Scrivania anche dentro i pacchetti (`estensioni/<codice>/modules/`). Tutto nel manuale `docs/sviluppo-estensioni.md` § 7-bis.
- **Negozio (storico)**: lo store dei moduli, **comune a tutti gli studi** (catalogo nella tabella condivisa `store_moduli`), con schede in stile app store — descrizione, "schermate", prezzo **gratis / a pagamento / in abbonamento**. Le gratuite si installano con un click (installazioni nella tabella dedicata `estensioni`, gate `Estensioni::attiva('codice')`); quelle a pagamento si attivano dal portale e compaiono già attive. Nel catalogo: **Commercialista** e **Sala d'attesa** (gratuite, installabili), più Magazzino, Refertazione vocale e Promemoria WhatsApp in arrivo.
- **Estensione Commercialista** (gratuita): aggiunge il ruolo **Commercialista** fra gli utenti dello studio e la voce **Procedure → Contabilità** con l'esportazione delle fatture del periodo: un archivio **ZIP** (scritto da `core/ZipSemplice.php`, senza dipendenze) con un **XML in formato elettronico per ogni fattura** — righe, IVA, bollo virtuale, pagamento, opposizione al Sistema TS in causale — più il riepilogo CSV.
- **Estensione Firma sul tablet** (gratuita): dal menu del paziente → Stampa documento, il pulsante **Firma sul tablet** apre il pad dove il paziente firma con il dito; il documento viene generato e archiviato **con la firma incorporata** (data-URL: l'archivio resta autosufficiente), il PNG della firma è conservato in `docs/archivio/firma/`, e il consenso si registra con la nota "firmato sul tablet". Il catalogo del Negozio ora si aggiorna per-voce: le estensioni nuove compaiono anche sulle installazioni esistenti.
- **Estensione Sala d'attesa** (gratuita): `attesa.php?t=<token>` — la pagina per la **TV dello studio**: coda di oggi con le sole **iniziali**, colori delle prestazioni, evidenza di chi è **in visita** e del **prossimo**, orologio, aggiornamento automatico ogni 30 secondi. Il collegamento segreto nasce all'installazione ed è revocabile.
- **Architettura SaaS: comune + dedicato**. Le tabelle vivono su due piani. Nel database **comune** (config `db.common` su MySQL — es. `drfacile_comune`, condiviso da tutte le installazioni; su SQLite convivono nello stesso file): gli **studi** con il loro **abbonamento**, gli **utenti** (più utenti per studio, ruolo medico/segreteria, credenziali e recapiti per il recupero) e gli archivi di supporto condivisi — **comuni** italiani, e le tabelle predisposte **icd9** e **farmaci_aifa**. Nel database **dedicato** dello studio: pazienti, visite, referti, fatture, agenda, documenti, impostazioni. Le tabelle comuni si raggiungono sempre con `Database::comune('tabella')`.
- **Utenti e accesso**: il login legge la tabella `utenti` (con ripiego automatico sulle vecchie credenziali di config per le installazioni non migrate: al primo avvio la migrazione crea studio e primo utente da sola). La pagina di accesso è **neutra** (niente nome né foto: più utenti per studio); il recupero password chiede il **nome utente** e manda il codice ai recapiti di quell'account. Le estensioni possono aggiungere **pannelli propri in Impostazioni** (hook `impostazioni.pannelli`, vedi `docs/sviluppo-estensioni.md` § 5-ter). In Impostazioni → **Utenti dello studio** si aggiungono, modificano e disattivano gli account (almeno uno resta attivo, non puoi disattivare te stesso). L'**avatar è personale** (`data/avatar-u<id>.png`) e compare sul pulsante della Scrivania. L'abbonamento è **dello studio** (`strumenti/abbonamento.php` aggiorna la riga in comune).
- **Foto del profilo**: in Impostazioni → Profilo si carica l'avatar del medico (click o drag&drop) con **ritaglio quadrato** al volo — trascini per inquadrare, cursore per lo zoom. La foto compare sul pulsante della Scrivania e nella pagina di accesso; si rimuove con un click e vive in `data/avatar.png`, fuori dai pacchetti di aggiornamento.
- **Assistente F2 (percorsi guidati "anti sbadati")**: un pannello flottante, non invasivo, con la lista delle cose da fare. Si apre da solo al nuovo paziente (anagrafica → privacy → vademecum → prima prenotazione) o con **F2**; i passi **automatici** (⚡) si spuntano da soli interrogando l'archivio (consenso registrato, appuntamento presente…), quelli manuali con un click; cliccando un passo si va alla sezione giusta. I percorsi sono preprogrammati in `core/percorsi.php` (incluso "Chiusura della giornata": bozze, referti da firmare, visite da fatturare, backup) e se ne aggiungono a piacere; interruttore in Impostazioni → Preferenze, API `DRF.assistente.apri()`.
- **Prenotazione con paziente al volo**: nella prenotazione lo switch "Paziente non ancora in archivio" chiede solo cognome, nome e **telefono obbligatorio** (email facoltativa) e crea la scheda; all'avvio della visita, se l'anagrafica è incompleta (CF, nascita, indirizzo), il programma avvisa e propone di completarla.
- **Opposizione al Sistema TS**: switch sulla fattura; in stampa la dicitura diventa la dichiarazione di opposizione (art. 3 DM 31/07/2015) e in elenco compare il badge.
- **Archivi ripuliti**: un solo pulsante Aggiungi (quello in alto); su Documenti il pulsante **Richiedi** è allineato a destra. Il **registro comunicazioni** è visibile da Impostazioni → Comunicazioni (driver per canale + tutte le uscite email/SMS/WhatsApp con stato).
- **Abbonamento attivo di default**: `abbonamento.attivo = true` nell'esempio di config; alla prima installazione in demo lo studio nasce con 30 giorni, e `strumenti/studio.php crea` dà 30 giorni se non si indica `--scadenza`. Per provarlo su un'installazione esistente: aggiungi il blocco `abbonamento` a `config/config.php` e lancia `php strumenti/abbonamento.php +30` (o `+3` per vedere il banner, `2020-01-01` per vedere la sospensione).
- **Gestione abbonamento**: `php strumenti/abbonamento.php --studio=ID +30 mensile` (o una data) aggiorna scadenza e periodo della riga dello studio nella tabella comune `studi` (con un solo studio `--studio` si può omettere; senza argomenti elenca gli studi); il backend di fatturazione deve solo scrivere `abbonamento_scadenza`/`abbonamento_periodo` su quella riga. `Auth::abbonamento()` legge **sempre lo studio della sessione** (o quello passato), mai "il primo studio": con più studi ognuno vede solo il proprio. Sul login il controllo avviene **dopo** aver verificato le credenziali, perché solo allora si sa a quale studio appartiene chi entra; se l'abbonamento è scaduto la sessione non viene creata e compare la pagina di rinnovo.
- **Accesso e SaaS**: sul login c'è **Password dimenticata?** → pagina di recupero nello stesso stile, con codice a 6 cifre via **email o SMS** (endpoint Comunicazioni; con il driver `log` della demo il codice compare in pagina). Le richieste vivono nella tabella comune `password_reset` (una riga per richiesta: più utenti insieme senza sovrascriversi; codice in hash, 15 minuti, 5 tentativi, al massimo 3 codici ogni 15 minuti per utente); la nuova password finisce sull'account in `utenti`. Le credenziali di `config/config.php` valgono solo finché la tabella `utenti` è vuota. L'**abbonamento** (mensile/bimestrale/semestrale/annuale) ha la scadenza nelle impostazioni: X giorni prima (config `abbonamento.avviso_giorni`) compare il banner "sta per scadere" con il link di rinnovo, e a scadenza superata **il login viene sospeso** con la pagina di rinnovo (i dati restano). Card riassuntiva in Impostazioni.
- **Endpoint Comunicazioni** (`core/Comunicazioni.php`): un punto solo per **email, SMS e WhatsApp** — `Comunicazioni::invia(canale, a, oggetto, testo)`. Ogni invio finisce nel registro (tabella `comunicazioni`); il driver per canale si sceglie in config (`log` = demo, `mail` = mail() di PHP, `smtp`/`gateway` predisposti e documentati nel file). Già usato da recupero password e richiesta documenti; pronto per promemoria e pre-visita.
- **Richiedi documento**: in Archivi → Documenti il pulsante **Richiedi** apre il catalogo comune (privacy, consenso all'operazione, certificati…), con note libere; la richiesta parte via email all'assistenza (config `assistenza.email_richieste`) e il modello viene poi inserito da remoto nell'archivio dello studio.
- **Documenti intestati come si deve**: studio in alto a sinistra, **intestatario in alto a destra** (nome e cognome, indirizzo, CAP città e provincia, codice fiscale) su fatture, referti e documenti generati; sotto, la riga con numero e data. In Impostazioni → Studio la **riga aggiuntiva sui documenti** (telefono, email…) viene stampata in fondo a tutti.
- **Aiuto con sottosezioni**: le voci F1 possono avere sotto-pagine (numerazione fatture, pagamenti e scadenzario, editor, documenti) e **link nel testo** che saltano alla pagina giusta.
- **Bug sistemati**: i tasti rapidi 1–9/0 e le frecce non scattano più mentre scrivi nell'editor (o con una modale aperta); il chip selezionato di "Tipo di sintomo" usa il colore del programma; la **stessa visita non può produrre due fatture** (guardia sul server, la notifica "Visita da fatturare" sparisce a fattura emessa e riaprendo il collegamento si va in modifica della fattura esistente).
- **Dizionari in prospettiva**: Diagnosi frequenti è un dizionario ICD-9-CM predisposto per l'aggancio all'archivio ICD9 completo (poi ICD10); il Prontuario si collegherà alle liste AIFA.
- **Agenda**: switch **Urgente** sulle prenotazioni (triangolo rosso pulsante in vista giorno) e stato **Non presentato** dal tasto destro (appuntamento barrato). Il selettore lette/non lette del centro notifiche è stato corretto.
- **Pazienti col tasto destro**: inizia visita, prenota, **Stampa documento…**, **Firma privacy**, modifica, oblio GDPR (in arrivo), elimina. Lo scudo giallo e lo sfondo tenue segnalano chi non ha la **privacy firmata** (o l'ha scaduta); l'eliminazione è bloccata se esistono visite chiuse o fatture.
- **Editor in visita**: Anamnesi ed Esame obiettivo usano DRF.rich; grassetti, elenchi e titoletti passano nel referto (anteprima, modifica della bozza e stampa comprese).
- **Aiuto in linea**: **F1** apre la guida sulla sezione in cui ti trovi — indice a sinistra, contenuto a destra, undici voci.
- **Archivio Documenti**: modelli di privacy, consensi e comunicazioni scritti con l'editor e i campi {paziente}, {cf}, {data}, {scadenza}… Dal tasto destro sul paziente si stampano con i **campi compilati**; i consensi con **validità in giorni** registrano da soli la firma nel registro consensi e la scadenza nello scadenzario. Tre modelli pronti nella demo (PRIV01, CONS01, MAIL01).
- **Scadenzario universale senza cron**: pagamenti con giorni di incasso, consensi in scadenza e visite di controllo programmate generano scadenze; al primo accesso di ogni giornata quelle mature diventano notifiche (una volta sola, su qualsiasi installazione, nessun cron da configurare). Il modulo **Scadenze** della Scrivania mostra i prossimi 30 giorni con chiusura al volo, e `Scadenzario::aggiungi()` è a disposizione di qualunque modulo.
- **Editor DRF.rich** (`assets/core/rich.js`): editor di testo fatto in casa nello stile del programma — grassetto/corsivo/sottolineato, titoletto, elenchi, link, annulla/ripeti, contatore caratteri, incolla ripulito. I **campi {segnaposto}** sono entità atomiche (chip su sfondo scuro: si eliminano in blocco, viaggiano come `{campo}` nel valore salvato) e il controllo si estende con **moduli** (`DRF.rich.use({...})`, `DRF.rich.allow('IMG')`). Nelle form del FormBuilder basta `'type' => 'rich'`; in HTML `<textarea class="rich" data-campi="paziente,data">` viene montata da sola e resta sincronizzata. La pagina **Procedure → Voce 4** lo mostra dal vivo con il codice. In Impostazioni → Preferenze si sceglie se mostrare i prezzi nella tendina "Prestazioni eseguite" della visita (in fattura si vedono sempre).
- **Gestione delle fatture emesse**: tasto destro su una fattura per aprirla, incassarla, **modificarla** o **eliminarla**. La prima stampa (apertura del documento) blocca definitivamente modifica ed eliminazione; l'eliminazione libera il numero (riusato se era l'ultimo) e riporta l'eventuale visita collegata tra quelle da fatturare.
- **Numerazione configurabile**: in Impostazioni → Fatturazione si imposta il **formato del numero** ({n} progressivo, {nnn} a tre cifre, {aaaa}/{aa} anno: es. `{aaaa}/{nnn}` → 2026/001, `{n}/{aa}` → 120/26, `{n}DR` → 120DR, con anteprima dal vivo) e — dopo lo sblocco — il **prossimo progressivo**, per adottare DRFacile a numerazione già avviata (es. partire dalla fattura 120).
- **Metodi di pagamento**: l'archivio ha ora **giorni per l'incasso** (0 = incasso immediato; con un valore la fattura nasce "in attesa" con scadenza calcolata — il vecchio "Da incassare 30 gg" è diventato un metodo modificabile), **conto**, **codice SDI** (modalità di pagamento per la fatturazione elettronica / Sistema TS), switch **non esportare** e switch **predefinito** (proposto nelle nuove fatture, uno solo alla volta).

## Aggiornamenti

Lo schema si aggiorna da solo: quando cambia `Installer::SCHEMA` l'Installer confronta `core/schema.sql` con il database e aggiunge tabelle e colonne mancanti senza toccare i dati (SQLite e MySQL). Le tabelle **comuni** (studi, utenti, password_reset, negozio) seguono `Installer::SCHEMA_COMUNE`: il bootstrap le riallinea una volta per sessione e per versione del programma, non a ogni richiesta. Per aggiornare basta sovrascrivere i file e ricaricare la pagina: `config/config.php` non viene mai toccato dagli aggiornamenti.

Prima di creare lo ZIP di distribuzione lanciare `php strumenti/impronte.php`, che rigenera `docs/impronte.json` (le impronte dei file usate da `diagnosi.php` per riconoscere un aggiornamento applicato a metà); `php strumenti/impronte.php verifica` controlla un'installazione.

## Architettura SaaS (ambienti isolati + tabelle comuni)

Il modello a più studi è operativo:

- **Database base** = quello di `config/config.php`. Ospita le **tabelle comuni** (`studi`, `utenti`, `store_moduli`, `comuni`, poi AIFA/ICD…) e lo **studio predefinito** (installazione monostudio, o il primo studio migrato dal monoutente). Con MySQL e `db.common = 'drfacile_comune'` le tabelle comuni vivono in un database a parte, sempre referenziate con `Database::comune('nome')`.
- **Studio con database dedicato**: la riga `studi.database` (JSON: `{"driver":"sqlite","sqlite":"data/studi/rossi.sqlite"}` oppure `{"driver":"mysql","mysql":{"dsn":"…","user":"…","pass":"…"}}`) indica il suo database. Isolamento reale: pazienti, visite, referti, fatture, agenda, documenti, impostazioni ed estensioni installate stanno solo lì; backup, esportazione e cancellazione (GDPR) sono un file/database alla volta.
- **Tenant resolver** (`core/Tenant.php`): a ogni richiesta il bootstrap apre il base, crea/aggiorna le tabelli comuni, poi legge lo studio dell'utente in sessione e, se ha un database dedicato, passa la connessione a quello con `Database::tenant()` — su MySQL una nuova connessione (le comuni restano `dbcomune.tabella`), su SQLite il file dello studio con `ATTACH` del base come `comune`. Solo dopo girano installer, estensioni e scadenzario. Il codice applicativo non cambia: tutte le query passano da `Database`.
- **Provisioning**: `php strumenti/studio.php crea "Studio Rossi" --sqlite=data/studi/rossi.sqlite --utente=rossi --password=… --cognome=Rossi` crea lo studio in comune, il suo amministratore e il database dedicato già installato (senza demo). Altri comandi: `database`, `utente`, `attiva`/`disattiva` (sospende il login dello studio), `elenco`. Gli strumenti CLI che lavorano sui dati dello studio (`estensione.php`) scelgono lo studio con `DRF_STUDIO=ID`: è il **contratto con il portale** — con più studi nella stessa installazione la variabile è obbligatoria e lo script si ferma (exit 1) se manca.
- **Pagina di sala d'attesa** (`attesa.php`): il link generato dal Negozio porta anche `&s=ID` dello studio, il token resta l'unica chiave.
- `Utente::migra()` resta solo per il passaggio monoutente → utenti (gira una volta, quando la tabella `utenti` è vuota): non è il provisioning.

Ogni visita registra il **professionista** che l'ha eseguita (`visite.utente_id`, l'utente collegato all'avvio): compare nell'elenco fatture sotto il paziente ("visitata da …"), nella scelta "Fattura da visita" e serve alle statistiche per operatore. Le visite precedenti al multiutente, senza utente, mostrano il nome del profilo dello studio.

## Documenti: PDF, link firmati, archivio e spazio per studio

- I documenti (referti, ricette, fatture, modelli, tipi delle estensioni) escono in **PDF** (`vendor/dompdf`, incluso, nessun composer) e in PDF vengono archiviati; `&html=1` dà ancora l'HTML stampabile.
- **Nessun id nell'URL apre nulla**: il client chiede a `documenti/link` un URL firmato (HMAC per studio e utente) valido 15 minuti, e lo apre (`DRF.doc.apri(tipo, id)`, `DRF.doc.file(rel)`, o `<button data-doc="referto" data-id="…">`). Il permesso dipende dal tipo (`referti.leggi`, `fatture.leggi`…): la segreteria non vede i referti. Ogni apertura finisce nel registro attività.
- **Archivio per studio** (`core/Spazio.php`): `docs/archivio` per lo studio base, `data/studi/<id>/archivio` per gli studi con database dedicato; tutto ciò che scrive un file passa da `Spazio::scrivi()`.
- **Quota di spazio**: per studio (`studi.quota_mb` nel comune; predefinita `archivio.quota_mb` in config, 2 GB); conta file e database. Barra in Impostazioni e nello Store; superata la quota le scritture si fermano con un messaggio chiaro; si amplia con `php strumenti/studio.php quota <id> +5120` (il portale lo chiama dopo l'acquisto del pacchetto "Spazio aggiuntivo" dello Store).

## Stampa dei documenti (Impostazioni → Stampa)

Pannello laterale con: modelli di pagina (normale, stretto, medio, largo, carta intestata, personalizzato) con anteprima dei margini e margini in mm; formato A4/A5/Letter e orientamento; carattere e dimensione del testo; **mittente** dell'intestazione separato per fatture (predefinito: nome dello studio, com'è giusto nel multiutente) e per referti/ricette (predefinito: il professionista che ha visitato); **logo** (PNG/JPG/SVG/WebP, trascinabile) con posizione, altezza, documenti su cui compare e modalità "solo logo" per la carta intestata; riga colorata e colore degli accenti; **piè di pagina** sempre in fondo a ogni pagina con riga dello studio, testo libero, "Pagina X di Y". Tutti i template passano da `_testata.php` e `_piede.php` (anche per le estensioni: `Documenti::mittente()`, `$stampa`). "Prova di stampa" genera un referto di esempio con le impostazioni correnti.

## Multilingua (gettext)

`.po`/`.mo` standard letti da `core/I18n.php` (loader PHP puro: nessuna dipendenza dall'estensione gettext), `locale/<lingua>/LC_MESSAGES/drfacile.mo` per il core e `estensioni/<codice>/locale/…/<codice>.mo` per le estensioni (dominio = codice, regola dello Store). Funzioni `__()`, `_p()` (contesto), `_n()`/`_np()` (plurali, anche le regole complesse) e le omonime `DRF.__` ecc. in JavaScript con i cataloghi generati dai `.mo`. Lingua per utente (Impostazioni → Lingua, `utenti.lingua`), predefinita `app.locale`. Strumento `php strumenti/i18n.php estrai|compila|nuova` (xgettext/msgfmt in PHP). Stringhe sorgente in italiano. Dalla 1.27 **tutto il core passa da gettext**: viste, form, moduli JavaScript, toast, messaggi degli endpoint, date relative e saluti (oltre 1.100 stringhe in `locale/drfacile.pot`); `locale/en_US` è una traduzione inglese completa. Le date seguono la lingua dell'utente. Regola per il codice nuovo: nessuna stringa visibile fuori da `__()` / `DRF.__()`; `php strumenti/i18n.php estrai` la mette nel `.pot`.

**Audit multiutente**: la tabella `attivita` registra `utente_id`, username fotografato e IP di chi ha fatto cosa; il widget Attività filtra per utente e cerca. **Permessi rifiniti**: `attivita.leggi`, `scadenzario.leggi/chiudi`, `assistente.usa`, app della Scrivania con `permesso:` nel `.def` (Store e Attività riservati). **Scrivania personale**: la disposizione dei widget è per utente (`scrivania_<id>`).

## Acquisti dentro DRFacile (Stripe)

`config stripe` (secret key, publishable key, webhook secret): i servizi e i pacchetti a pagamento dello Store si comprano con la carta tramite **Stripe Checkout** senza uscire dal programma (`core/Pagamenti.php`, REST senza SDK): ordine nel database comune (`ordini`), ritorno verificato, **webhook** `ajax/pagamenti.php?action=webhook` (firma verificata) per `checkout.session.completed` e `customer.subscription.deleted` (abbonamento disdetto → servizio disattivato). A pagamento confermato l'ordine viene **evaso**: estensione scaricata e attivata, spazio +5 GB, credito SMS, opzione attivata. Scheda **Acquisti** nello Store con lo storico. **Attivazione manuale** per l'amministratore di sistema (`sistema.amministratore = true`): bonifico, contanti, omaggio, prova, con nota — dallo Store o da CLI `php strumenti/studio.php acquisto <id> <codice> --metodo=bonifico`.

## Modelli di messaggio e invio email

Archivio **Modelli di messaggio** (email, SMS, WhatsApp) con segnaposto `{paziente} {nome} {medico} {studio} {studio_telefono} {data} {documento} {numero} {importo} {appuntamento}`, per uso (referto, fattura, ricetta, documento, file, promemoria, generico) e modello predefinito; seed iniziale. Ogni invio passa da una **finestra** con destinatario proposto dall'anagrafica ma **sempre modificabile**, scelta del modello, oggetto e testo ritoccabili, PDF in allegato: referto ("Invia via email", anche i reinvii), fatture (icona busta nell'elenco, verde se già inviata), file della documentale. Nome del mittente e "rispondi a" in Impostazioni → Email. Le **novità della versione** compaiono una volta per utente alla prima apertura (`docs/novita.json`, `DRF.novita`).

## Email e SMS

- **Email** (`config comunicazioni.email`): driver `log` (solo registro), `mail` (mail() di PHP) o `smtp` con **PHPMailer** incluso in `vendor/phpmailer` (host, porta, tls/ssl, utente, password, mittente, rispondi-a). "Invia" sul referto manda al paziente l'email con il **PDF allegato** (o lascia fare a un'estensione con `referto.invia`); `Comunicazioni::invia('email', …, ['allegati' => […]])` per tutto il resto.
- **SMS** (`config comunicazioni.sms`): driver `clickatell` con chiave API e mittente del provider. Il cliente **attiva il Servizio SMS** dallo Store (abbonamento) e compra **pacchetti** (500, 2.000): credito in `studi.sms_credito` (comune), scalato a ogni invio (1 ogni 160 caratteri), visibile in Impostazioni; `php strumenti/studio.php sms <id> +500` lo ricarica (lo chiama il portale). Senza servizio o credito l'invio si ferma con il motivo.
- **Firma del programma** sui documenti: "Documento generato con DRFacile" resta finché lo studio non attiva "Documenti senza firma DRFacile" dallo Store; poi l'interruttore in Impostazioni → Stampa si sblocca.

## Extension API 2.0

Le estensioni si agganciano a qualsiasi parte del programma: **struttura** (`moduli.elenco` aggiunge un modulo intero sulla costa; `menu.voci`, `search.comandi`, `scorciatoie`, `notifiche.tipi`, `scadenzario.controlli` job quotidiano senza cron, `cli.comandi` per `strumenti/drf.php`), **interfaccia** (slot JS con `ctx`: `paziente.scheda`, `agenda.appuntamento`, `fattura.editor`, `referto.editor`, `ricetta.editor`, `topbar.azioni`, `dashboard.widget`), **dati e documenti** (filtri `paziente.salva`, `appuntamento.salva`, `visita.chiudi`, `fattura.emetti`, `referto.invia`, `documento.dati/template/render`, `export.formati`, `backup.contenuto`; eventi `paziente.salvato`, `visita.chiusa`, `fattura.emessa/incassata`, `referto.firmato/inviato`, `ricetta.emessa`). Le **capabilities** del manifest sono applicate dal core (`core/Capabilities.php`): durante il codice di un'estensione i modelli, le comunicazioni, le notifiche, lo scadenzario, le impostazioni del core, i documenti e la rete (`Rete::get/post`) controllano cosa ha dichiarato. **Migrazioni** per le tabelle `ext_*` in `estensioni/<codice>/migrations/` (`core/Migrazioni.php`), eseguite da sole al ciclo di vita. Tutto in `docs/sviluppo-estensioni.md` § 7-ter.

Dalla 1.21 cadono gli ultimi muri: campi delle estensioni in **qualsiasi form** del core (`form.campi`, salvati da soli nella colonna JSON `dati`), filtri **prima/dopo ogni azione AJAX** (`api.prima`/`api.dopo`), **tipi di documento** registrabili (`documenti.tipi`, con archivio e stampa del core), `visita.salva`/`visita.avviata`, e la **sostituzione delle viste** (`views.override`).

**Rate limiting** su login e recupero password (`core/RateLimit.php`, tabella comune `tentativi`): per IP e per nome utente, 5 errori → 30 secondi, 10 → 5 minuti, 20 → 30 minuti, azzerato all'accesso riuscito; nessun blocco permanente.

## Utenti, ruoli e permessi

Ogni utente ha un **ruolo** (`medico`, `segreteria`, `commercialista` con l'estensione; altri via hook `utenti.ruoli`) e il flag **amministratore dello studio** (`utenti.admin`): il primo utente di ogni studio lo è, e almeno uno deve restarlo. Cosa può fare ciascun ruolo è in **`core/permessi.php`**:

| | Medico | Segreteria | Commercialista |
|---|---|---|---|
| Agenda, Pazienti | ✓ | ✓ (senza eliminare pazienti) | |
| Visita, Ricette, Referti, Archivi, Statistiche | ✓ | Archivi in lettura | Statistiche |
| Fatture | ✓ | emette e incassa | lettura |
| Contabilità (estensione) | ✓ | | ✓ |
| Impostazioni | ✓ | lettura | |
| Utenti e Negozio (installazioni) | solo amministratore | | |

L'applicazione è lato server: ogni endpoint AJAX dichiara il permesso di ogni azione nel secondo argomento di `Api::run([...], ['*' => 'agenda.leggi', 'save' => 'agenda.modifica'])` e riceve 403 chi non ce l'ha; `Auth::can('fatture.emetti')` risponde ovunque, `Auth::richiedi()` per i download fuori dal router. I moduli della costa hanno il loro `permesso` in `core/modules.php` (chi non lo ha non li vede né li carica), le voci di Procedure lo dichiarano in `core/procedure.php`. Lato client `DRF.can('…')` serve solo a nascondere i pulsanti inutili — i permessi effettivi arrivano in `DRF.config.utente.permessi`. Le estensioni ampliano la mappa con l'hook `auth.permessi`.

## Documenti e integrazioni

- I documenti (referti, promemoria ricetta, fatture) si aprono con `ajax/documenti.php?action=render&tipo=referto&id=…` e si stampano/salvano in PDF dal browser. Una copia HTML viene archiviata in `docs/archivio`.
  Per il PDF lato server si può agganciare dompdf in `core/Documenti.php`.
- `Ricetta::emetti()` e `Referto::invia()` sono i punti in cui collegare l'invio reale al Sistema TS (DEMA) e l'invio email/PEC, riusando i moduli già sviluppati per Igea.
- Il pulsante **Importa da Igea** in Impostazioni è predisposto per una procedura guidata di importazione dall'export di Igea.

## Sicurezza

Sessione con cookie HttpOnly/SameSite/Secure (`auth.cookie_secure`), permessi per ruolo su ogni endpoint (`core/permessi.php`), token CSRF su tutte le scritture, query con prepared statement, escape di tutto l'HTML generato (`e()` in PHP, `DRF.esc()` in JS), cartelle `config/`, `core/`, `form/`, `views/`, `data/`, `docs/archivio`, `docs/backup`, `temp/` negate via `.htaccess` (per Nginx replicare i `deny`).
