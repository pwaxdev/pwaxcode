<?php
/**
 * RETE per le estensioni: GET/POST verso servizi esterni con timeout, redirect limitati e la capability `rete_esterna`.
 * Un'estensione che usa Rete::get() invece di curl diretto viene verificata dal core e si legge meglio in revisione.
 *   $json = json_decode(Rete::get('https://api.example.com/x', ['Authorization: Bearer …']), true);
 *   Rete::post('https://api.example.com/y', json_encode($dati), ['Content-Type: application/json']);
 */
final class Rete
{
    public static function get(string $url, array $headers = [], int $timeout = 15): string { return self::chiama('GET', $url, null, $headers, $timeout); }
    public static function post(string $url, string $body, array $headers = [], int $timeout = 15): string { return self::chiama('POST', $url, $body, $headers, $timeout); }

    private static function chiama(string $metodo, string $url, ?string $body, array $headers, int $timeout): string
    {
        Capabilities::richiedi('rete_esterna');
        if (!preg_match('~^https?://~i', $url)) throw new RuntimeException('Rete: solo URL http(s)');
        if (function_exists('curl_init')) {
            $c = curl_init($url);
            curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_TIMEOUT => $timeout, CURLOPT_HTTPHEADER => $headers, CURLOPT_USERAGENT => 'DRFacile/' . Installer::VERSIONE]);
            if ($metodo === 'POST') curl_setopt_array($c, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => (string) $body]);
            $r = curl_exec($c); $code = (int) curl_getinfo($c, CURLINFO_RESPONSE_CODE); $err = curl_error($c); curl_close($c);
            if ($r === false) throw new RuntimeException("Rete: $err");
            if ($code >= 400) throw new RuntimeException("Rete: HTTP $code");
            return (string) $r;
        }
        $ctx = stream_context_create(['http' => ['method' => $metodo, 'timeout' => $timeout, 'header' => implode("\r\n", $headers), 'content' => $body ?? '', 'ignore_errors' => true]]);
        $r = @file_get_contents($url, false, $ctx);
        if ($r === false) throw new RuntimeException("Rete: $url non raggiungibile");
        return (string) $r;
    }
}
