/* Scrivania: piano di lavoro personale (click sull'avatar). Moduli in modules/<key>/: chiusi nel dock, aperti come finestre trascinabili.
   Layout (posizione, dimensione, stato) salvato nelle impostazioni e ripristinato al prossimo accesso. */
DRF.desk = (function ($) {
  'use strict';
  const st = { moduli: [], layout: {}, reg: {}, open: false, loaded: false, z: 10, clock: null };
  const salva = DRF.util.debounce(() => DRF.api.post('scrivania', 'salva', { layout: st.layout }), 700);

  function carica() {
    if (st.loaded) return $.Deferred().resolve().promise();
    return DRF.api.get('scrivania', 'moduli').then(r => {
      st.moduli = r.moduli; st.layout = (r.layout && !Array.isArray(r.layout)) ? r.layout : {}; st.prossimo = r.prossimo; st.nOggi = r.n_oggi;
      const v = encodeURIComponent(DRF.config.versione || '');   // stessa regola dei file del core: la versione nell'URL batte la cache del browser
      r.moduli.forEach(m => { if (m.css && !$(`link[href^="${m.css}"]`).length) $('<link rel="stylesheet">').attr('href', `${m.css}?v=${v}`).appendTo('head'); });
      const js = r.moduli.filter(m => m.js && !$(`script[src^="${m.js}"]`).length).map(m => $.getScript(`${m.js}?v=${v}`));
      return $.when.apply($, js).then(() => { st.loaded = true; render(); });
    });
  }
  function render() {
    const $d = $('#desk'), m = DRF.config.medico || {};
    $d.find('.desk-dock').html(st.moduli.map(mo => `<button type="button" class="dock-item" data-m="${mo.key}" title="${DRF.esc(mo.descrizione || mo.nome)}"><span class="dock-ico">${DRF.icons.html(mo.fi, mo.fa)}</span><span class="dock-lbl">${DRF.esc(mo.nome)}</span><i class="dock-dot"></i></button>`).join(''));
    $d.find('.desk-hello b').text(`${DRF.util.saluto()}, ${(m.nome || '').split(' ')[0]}`);
    const p = st.prossimo;
    $d.find('.desk-next').attr('data-go', 'agenda').attr('data-opts', JSON.stringify(p ? { date: p.data, select: +p.id } : { date: DRF.util.todayIso() })).addClass('desk-go').html(p ? `<span class="badge violet">${DRF.icons.html('clock', 'fa-regular fa-clock')} ${DRF.__('prossimo ·')} ${p.ora}</span><b>${DRF.esc(p.paziente)}</b><span class="muted small">${DRF.esc(p.tipo_label)}${p.note ? ' · ' + DRF.esc(p.note) : ''}</span>` : `<span class="badge mint">${DRF.icons.html('check', 'fa-solid fa-check')} agenda</span><b>${st.nOggi ? `${DRF._n('%d appuntamento', '%d appuntamenti', st.nOggi)} ${DRF.__('oggi')}` : DRF.__('Nessun appuntamento oggi')}</b>`);
    // widget delle estensioni nella scrivania (hook dashboard.widget): ctx.aggiungi(html) mette un riquadro sotto la testata
    $d.find('.desk-widgets').remove();
    const $w = $('<div class="desk-widgets"></div>').insertAfter($d.find('.desk-top'));
    DRF.hooks.run('dashboard.widget', { $root: $w, aggiungi: (html, titolo) => { const $b = $(`<div class="desk-widget">${titolo ? `<b>${DRF.esc(titolo)}</b>` : ''}<div class="desk-widget-body"></div></div>`); $b.find('.desk-widget-body').append(html); $w.append($b); DRF.icons.apply($b[0]); return $b; }, apri: k => D.apri(k), vai: (m, o) => DRF.nav.go(m, o) });
    if (!$w.children().length) $w.remove();
    // voci delle estensioni nel menu del pulsante utente (hook PHP menu.voci + filtro JS menu.voci): tasto destro sull'avatar
    DRF.icons.apply($d[0]);
    st.moduli.forEach(mo => { const l = st.layout[mo.key]; if (l && l.stato && l.stato !== 'chiuso') finestra(mo.key); });
    dock();
  }
  function dock() { $('#desk .dock-item').each(function () { const l = st.layout[this.dataset.m] || {}; $(this).toggleClass('open', l.stato === 'aperto').toggleClass('min', l.stato === 'ridotto'); }); }
  function mod(key) { return st.moduli.find(m => m.key === key); }
  /** Ricarica l'elenco dei moduli (dopo un'installazione dal Negozio: l'icona compare/sparisce subito) */
  function reloadModuli() { st.loaded = false; return carica(); }

  /** Crea (o riporta in primo piano) la finestra di un modulo */
  function finestra(key) {
    const mo = mod(key); if (!mo) return;
    let $w = $(`#desk .win[data-m="${key}"]`);
    const aperte = $('#desk .win').length;
    const l = st.layout[key] = Object.assign({ x: 60 + aperte * 70, y: 40 + aperte * 44, w: mo.larghezza, h: mo.altezza, stato: 'aperto' }, st.layout[key] || {});
    if (!mo.ridimensionabile) { l.w = mo.larghezza; l.h = mo.altezza; }   // misure sempre dal .def
    if (!$w.length) {
      $w = $(`<div class="win" data-m="${key}"><div class="win-bar"><span class="win-ico">${DRF.icons.html(mo.fi, mo.fa)}</span><b>${DRF.esc(mo.nome)}</b><div class="win-btns"><button type="button" data-w="min" title="${DRF.__('Riduci nel dock')}">${DRF.icons.html('minus-small', 'fa-solid fa-minus')}</button><button type="button" data-w="close" title="${DRF.__('Chiudi')}">${DRF.icons.html('cross-small', 'fa-solid fa-xmark')}</button></div></div><div class="win-body">${mo.html}</div>${mo.ridimensionabile ? '<span class="win-resize"></span>' : ''}</div>`).appendTo('#desk .desk-area');
      DRF.icons.apply($w[0]); DRF.ui.wire($w.find('.win-body')[0]);
      const reg = st.reg[key]; if (reg && reg.init) reg.init($w.find('.win-body'), { def: mo });
      $w.on('mousedown pointerdown', () => avanti($w));
      $w.find('.win-bar').on('pointerdown', e => trascina($w, e));
      $w.find('.win-resize').on('pointerdown', e => ridimensiona($w, mo, e));
      $w.find('[data-w=min]').on('click', () => riduci(key)); $w.find('[data-w=close]').on('click', () => chiudi(key));
    }
    l.stato = 'aperto'; applica($w, l); $w.removeClass('min').addClass('in'); avanti($w); dock(); salva();
    const reg = st.reg[key]; if (reg && reg.open) reg.open($w.find('.win-body'));
  }
  function applica($w, l) { const A = $('#desk .desk-area'), W = A.width() || window.innerWidth, H = A.height() || window.innerHeight; l.x = Math.max(0, Math.min(l.x, W - 80)); l.y = Math.max(0, Math.min(l.y, H - 60)); $w.css({ left: l.x, top: l.y, width: l.w, height: l.h }); }
  function avanti($w) { $w.css('zIndex', ++st.z); $('#desk .win').removeClass('focus'); $w.addClass('focus'); }
  function riduci(key) { const $w = $(`#desk .win[data-m="${key}"]`); st.layout[key].stato = 'ridotto'; $w.addClass('min'); setTimeout(() => $w.removeClass('in'), 200); dock(); salva(); }
  function chiudi(key) { const $w = $(`#desk .win[data-m="${key}"]`), reg = st.reg[key]; if (reg && reg.close) reg.close($w.find('.win-body')); st.layout[key].stato = 'chiuso'; $w.removeClass('in'); setTimeout(() => $w.remove(), 200); dock(); salva(); }
  function trascina($w, e) {
    if ($(e.target).closest('.win-btns').length || e.button) return;
    const key = $w.data('m'), l = st.layout[key], sx = e.clientX - l.x, sy = e.clientY - l.y;
    const move = ev => { l.x = ev.clientX - sx; l.y = ev.clientY - sy; applica($w, l); };
    const up = () => { $(document).off('pointermove', move).off('pointerup pointercancel', up); $w.removeClass('dragging'); salva(); };
    $w.addClass('dragging'); $(document).on('pointermove', move).on('pointerup pointercancel', up); e.preventDefault();
  }
  function ridimensiona($w, mo, e) {
    const l = st.layout[mo.key], x0 = e.clientX, y0 = e.clientY, w0 = l.w, h0 = l.h;
    const move = ev => { l.w = Math.max(240, w0 + ev.clientX - x0); l.h = Math.max(160, h0 + ev.clientY - y0); $w.css({ width: l.w, height: l.h }); };
    const up = () => { $(document).off('pointermove', move).off('pointerup pointercancel', up); salva(); };
    $(document).on('pointermove', move).on('pointerup pointercancel', up); e.preventDefault(); e.stopPropagation();
  }
  function orologio() { const d = new Date(); $('#desk .desk-clock').text(d.toLocaleTimeString(DRF.util.loc(), { hour: '2-digit', minute: '2-digit' })); $('#desk .desk-date').text(DRF.util.cap(d.toLocaleDateString(DRF.util.loc(), { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }))); }

  const D = {
    /** I moduli si registrano da modules/<key>/js/<key>.js */
    register(key, def) { st.reg[key] = def; },
    init() {
      $('#avatarBtn').on('click', () => D.toggle());
      $('#avatarBtn').on('contextmenu', function (e) {
        const voci = DRF.hooks.filter('menu.voci', (DRF.config.menu || []).map(v => ({ label: v.label, fi: v.fi, fa: v.fa, run: () => v.modulo ? DRF.nav.go(v.modulo, v.opts || {}) : v.url ? window.open(v.url, '_blank') : v.comando ? DRF.emit(v.comando) : null })));
        if (!voci.length) return;
        e.preventDefault(); DRF.menu.show(e.clientX, e.clientY, voci, { title: DRF.__('Estensioni') });
      });
      $('#desk').on('click', '.dock-item', function () { const key = this.dataset.m, l = st.layout[key]; if (l && l.stato === 'aperto') riduci(key); else finestra(key); })
        .on('click', '.desk-close', () => D.close())
        .on('click', '.desk-go', function () { D.close(); DRF.nav.go(this.dataset.go, this.dataset.opts ? JSON.parse(this.dataset.opts) : {}); });
      DRF.menu.bind($('#desk'), '.dock-item', el => { const key = el.dataset.m, l = st.layout[key] || {}; return [{ label: DRF.__('Apri'), fi: 'expand', fa: 'fa-solid fa-up-right-from-square', run: () => finestra(key), disabled: l.stato === 'aperto' }, { label: DRF.__('Riduci nel dock'), fi: 'minus-small', fa: 'fa-solid fa-minus', run: () => riduci(key), disabled: l.stato !== 'aperto' }, { label: DRF.__('Chiudi'), fi: 'cross-small', fa: 'fa-solid fa-xmark', run: () => chiudi(key), disabled: !l.stato || l.stato === 'chiuso' }, { sep: true }, { label: DRF.__('Riporta al centro'), fi: 'target', fa: 'fa-solid fa-crosshairs', run: () => { const m = mod(key); st.layout[key] = Object.assign(st.layout[key] || {}, { x: Math.max(20, ($('#desk .desk-area').width() - m.larghezza) / 2), y: 60 }); finestra(key); } }]; });
      $(document).on('keydown', e => { if (e.key === 'Escape' && st.open && !DRF.menu.isOpen() && !$('#modal').hasClass('open') && !$('#dialog').hasClass('open')) D.close(); });
    },
    toggle() { st.open ? D.close() : D.open(); },
    open() { st.open = true; $('#desk').addClass('open'); $('body').addClass('desk-open'); orologio(); st.clock = setInterval(orologio, 15000); carica(); },
    close() { st.open = false; $('#desk').removeClass('open'); $('body').removeClass('desk-open'); clearInterval(st.clock); },
    apri: finestra,
    reloadModuli
  };
  return D;
})(jQuery);
