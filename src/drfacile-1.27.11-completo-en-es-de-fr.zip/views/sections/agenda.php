<div class="agenda stagger">
  <div>
    <div class="wk-head">
      <b id="wkLabel">—</b>
      <div class="row" style="gap:6px">
        <div class="seg" id="agView"><button class="on" data-v="giorno"><?= __('Giorno') ?></button><button data-v="mese"><?= __('Mese') ?></button></div>
        <button class="icon-btn sm" id="wkPrev" title="<?= __('Settimana precedente') ?>"><i class="ico" data-fi="angle-left" data-fa="fa-solid fa-chevron-left"></i></button>
        <button class="btn ghost sm" id="wkToday"><?= __('Oggi') ?></button>
        <button class="icon-btn sm" id="wkNext" title="<?= __('Settimana successiva') ?>"><i class="ico" data-fi="angle-right" data-fa="fa-solid fa-chevron-right"></i></button>
      </div>
    </div>
    <div class="week" id="week"></div>
    <div class="timeline" id="timeline"></div>
    <div class="month" id="month" hidden></div>
  </div>
  <div class="side">
    <div class="next-card" id="nextCard"></div>
    <div class="card"><h3><i class="ico" data-fi="time-fast" data-fa="fa-regular fa-clock"></i><?= __('La giornata') ?></h3><div class="legend" id="legend"></div></div>
    <div class="card"><h3><i class="ico" data-fi="bolt" data-fa="fa-solid fa-bolt"></i><?= __('Azioni rapide') ?></h3>
      <div style="display:flex;flex-direction:column;gap:8px">
        <button class="btn ghost block left" id="qBook"><i class="ico" data-fi="calendar-plus" data-fa="fa-regular fa-calendar-plus"></i><?= __('Nuova prenotazione') ?></button>
        <button class="btn ghost block left" id="qPat"><i class="ico" data-fi="user-add" data-fa="fa-solid fa-user-plus"></i><?= __('Nuovo paziente') ?></button>
        <button class="btn ghost block left" id="qInv"><i class="ico" data-fi="receipt" data-fa="fa-solid fa-file-invoice"></i><?= __('Nuova fattura') ?></button>
      </div>
    </div>
  </div>
</div>
