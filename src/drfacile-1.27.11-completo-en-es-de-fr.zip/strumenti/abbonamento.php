<?php
/**
 * Gestione dell'abbonamento di uno STUDIO (da riga di comando o dal backend di fatturazione).
 * La scadenza vive nella tabella comune `studi` (abbonamento_scadenza, abbonamento_periodo), con copia
 * di ripiego nelle `impostazioni` del database dedicato per le installazioni legacy:
 * il portale di rinnovo, alla conferma del pagamento, deve solo aggiornare quelle chiavi —
 * via questo script, con una UPDATE diretta sul database, o con una chiamata applicativa.
 *
 *   php strumenti/abbonamento.php                          → elenco degli studi con stato
 *   php strumenti/abbonamento.php +30                      → proroga di 30 giorni (se c'è UN solo studio)
 *   php strumenti/abbonamento.php --studio=3 +30           → proroga lo studio 3
 *   php strumenti/abbonamento.php --studio=3 2027-03-01    → imposta la scadenza esatta
 *   php strumenti/abbonamento.php --studio=3 +365 annuale  → proroga e imposta il periodo
 *
 * Periodi ammessi: mensile, bimestrale, semestrale, annuale.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
require __DIR__ . '/../core/bootstrap.php';

$args = array_slice($argv, 1);
$sid = 0;
foreach ($args as $i => $a) {
    if (preg_match('/^--studio=(\d+)$/', $a, $m)) { $sid = (int) $m[1]; unset($args[$i]); }
}
$args = array_values($args);
$arg = $args[0] ?? null;
$periodo = $args[1] ?? null;

$studi = Database::all('SELECT id, nome, abbonamento_scadenza, abbonamento_periodo FROM ' . Database::comune('studi') . ' ORDER BY id');
if ($sid && !array_filter($studi, fn($s) => (int) $s['id'] === $sid)) exit("Studio $sid inesistente\n");
if (!$sid && count($studi) === 1) $sid = (int) $studi[0]['id'];
if (!$sid && count($studi) > 1 && $arg !== null) {
    echo "Più studi nel database comune: indica quale con --studio=ID\n";
    foreach ($studi as $s) printf("  %3d  %-30s scadenza %s · %s\n", $s['id'], $s['nome'], $s['abbonamento_scadenza'] ?: '—', $s['abbonamento_periodo'] ?: 'mensile');
    exit(1);
}
if ($periodo !== null) {
    if (!in_array($periodo, ['mensile', 'bimestrale', 'semestrale', 'annuale'], true)) exit("Periodo non valido: $periodo\n");
    if ($sid) Database::run('UPDATE ' . Database::comune('studi') . ' SET abbonamento_periodo = ? WHERE id = ?', [$periodo, $sid]);
    Impostazione::set('abbonamento_periodo', $periodo);
}
if ($arg !== null) {
    $attuale = $sid ? (string) Database::value('SELECT abbonamento_scadenza FROM ' . Database::comune('studi') . ' WHERE id = ?', [$sid]) : Impostazione::get('abbonamento_scadenza');
    if (preg_match('/^\+(\d+)$/', $arg, $m)) {
        $base = max(strtotime($attuale ?: 'today'), strtotime('today'));
        $nuova = date('Y-m-d', strtotime("+{$m[1]} days", $base));
    } elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $arg)) {
        $nuova = $arg;
    } else exit("Argomento non valido: $arg (usa +GIORNI oppure AAAA-MM-GG)\n");
    if ($sid) Database::run('UPDATE ' . Database::comune('studi') . ' SET abbonamento_scadenza = ? WHERE id = ?', [$nuova, $sid]);
    Impostazione::set('abbonamento_scadenza', $nuova);
}
if (!$sid && $studi) {   // solo elenco (più studi, nessuno indicato)
    foreach ($studi as $s) printf("  %3d  %-30s scadenza %s · %s\n", $s['id'], $s['nome'], $s['abbonamento_scadenza'] ?: '—', $s['abbonamento_periodo'] ?: 'mensile');
    exit(0);
}
$a = Auth::abbonamento($sid ?: null);   // 0 = installazione legacy non ancora migrata: ripiego sulle impostazioni
echo ($sid ? "Studio $sid · " : '') . "Abbonamento: stato {$a['stato']} · scadenza " . ($a['scadenza'] ?: '—') . ($a['giorni'] !== null ? " (fra {$a['giorni']} gg)" : '') . " · periodo {$a['periodo']}\n";
echo "Avviso a partire da " . ((int) (Config::get('abbonamento.avviso_giorni') ?? 7)) . " giorni prima · rinnovo: " . $a['url'] . "\n";
