<?php
/**
 * HOOK: i punti di aggancio del sistema modulare.
 * Le estensioni (estensioni/<codice>/estensione.php) registrano qui le loro funzioni:
 *
 *   Hooks::add('utenti.ruoli', fn(array $ruoli) => [...$ruoli, 'dietista']);      // filtro: trasforma un valore
 *   Hooks::add('visita.chiusa', function (int $visitaId) { ... });                // evento: fa qualcosa
 *
 * Il core li invoca con Hooks::filter('punto', $valore, ...$extra) per i filtri
 * e Hooks::run('punto', ...$argomenti) per gli eventi. I punti disponibili sono
 * documentati in docs/sviluppo-estensioni.md.
 */
final class Hooks
{
    private static array $reg = [];

    public static function add(string $punto, callable $fn, int $priorita = 10): void
    {
        // chi registra (l'estensione in caricamento, o null = core): il callback girerà sempre "a suo nome" (Capabilities)
        self::$reg[$punto][] = ['fn' => $fn, 'p' => $priorita, 'ext' => class_exists('Capabilities') ? Capabilities::corrente() : null];
        usort(self::$reg[$punto], fn($a, $b) => $a['p'] <=> $b['p']);
    }

    /** Filtro: ogni hook riceve il valore (più eventuali extra) e ritorna il valore trasformato (gli errori di un'estensione non fermano il programma) */
    public static function filter(string $punto, mixed $valore, mixed ...$extra): mixed
    {
        foreach (self::$reg[$punto] ?? [] as $h) {
            // un'estensione che sbaglia non deve far saltare la pagina: si logga e il valore resta quello di prima
            try { $valore = Capabilities::come($h['ext'], $h['fn'], $valore, ...$extra); } catch (Throwable $e) { error_log("Hook $punto: " . $e->getMessage()); }
        }
        return $valore;
    }

    /** Evento: esegue tutti gli hook registrati (gli errori di un'estensione non fermano il programma) */
    public static function run(string $punto, mixed ...$args): void
    {
        foreach (self::$reg[$punto] ?? [] as $h) {
            try { Capabilities::come($h['ext'], $h['fn'], ...$args); } catch (Throwable $e) { error_log("Hook $punto: " . $e->getMessage()); }
        }
    }

    public static function has(string $punto): bool { return !empty(self::$reg[$punto]); }

    /** Tutti i punti registrati (per la diagnosi e il manuale) */
    public static function punti(): array { return array_keys(self::$reg); }
}
