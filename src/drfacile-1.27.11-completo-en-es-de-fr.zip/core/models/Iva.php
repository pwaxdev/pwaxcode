<?php
/** Aliquote IVA (archivio): esente art. 10 per le prestazioni sanitarie, 22% per medicina estetica, ecc. */
final class Iva extends Model
{
    protected static string $table = 'iva';
    protected static array $fillable = ['nome', 'aliquota', 'nota', 'predefinita', 'attiva'];

    public static function attive(): array { return self::all('attiva = 1', [], 'aliquota, id'); }

    /** L'aliquota proposta per le nuove prestazioni e le righe libere */
    public static function predefinita(): ?array
    {
        return Database::one('SELECT * FROM iva WHERE attiva = 1 AND predefinita = 1 ORDER BY id LIMIT 1')
            ?: Database::one('SELECT * FROM iva WHERE attiva = 1 ORDER BY aliquota, id LIMIT 1');
    }

    public static function optionsMap(): array
    {
        $m = [];
        foreach (self::attive() as $r) $m[$r['id']] = $r['nome'] . ' · ' . rtrim(rtrim(number_format((float) $r['aliquota'], 2, ',', ''), '0'), ',') . '%';
        return $m;
    }

    /** [id => riga] per risolvere l'aliquota delle righe di fattura */
    public static function mappa(): array
    {
        $m = [];
        foreach (self::all('1=1', [], 'id') as $r) $m[(int) $r['id']] = $r;
        return $m;
    }
}
