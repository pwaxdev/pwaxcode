<?php
/** Cartella per problemi · la lista dei problemi (per paziente) e le note S·O·A·P di ogni visita */
return function () {
    Migrazioni::tabella('ext_soap_problemi', "
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        paziente_id INTEGER NOT NULL,
        titolo VARCHAR(160) NOT NULL,
        stato VARCHAR(10) DEFAULT 'attivo',
        aperto_il VARCHAR(10), chiuso_il VARCHAR(10),
        ultima_il VARCHAR(10), ultimo_piano TEXT,
        creato_il VARCHAR(19)");
    Migrazioni::indice('ext_soap_problemi', 'paziente_id');
    Migrazioni::tabella('ext_soap_note', "
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        problema_id INTEGER NOT NULL,
        visita_id INTEGER, referto_id INTEGER,
        data VARCHAR(10) NOT NULL,
        s TEXT, o TEXT, a TEXT, p TEXT,
        creato_il VARCHAR(19)");
    Migrazioni::indice('ext_soap_note', 'problema_id');
};
