<?php
/** Modulo Scrivania: Calcolatrice (contenuto della finestra; la cornice la disegna la Scrivania) */
if (!function_exists('module_calc_render')) {
    function module_calc_render(array $ctx): string
    {
        $rows = [
            [['C', 'clear', 'fn'], ['±', 'neg', 'fn'], ['%', 'pct', 'fn'], ['÷', 'div', 'op']],
            [['7', '7', ''], ['8', '8', ''], ['9', '9', ''], ['×', 'mul', 'op']],
            [['4', '4', ''], ['5', '5', ''], ['6', '6', ''], ['−', 'sub', 'op']],
            [['1', '1', ''], ['2', '2', ''], ['3', '3', ''], ['+', 'add', 'op']],
            [['0', '0', 'zero'], [',', 'dot', ''], ['=', 'eq', 'eq']],
        ];
        $h = '<div class="calc"><div class="calc-display" tabindex="0" aria-label="Display"><div class="calc-expr">&nbsp;</div><div class="calc-cur">0</div></div><div class="calc-hist" title="Storico"></div><div class="calc-keys">';
        foreach ($rows as $row) {
            $h .= '<div class="calc-row">';
            foreach ($row as [$label, $k, $role]) $h .= '<button type="button" class="calc-btn' . ($role ? ' k-' . $role : '') . '" data-k="' . $k . '">' . $label . '</button>';
            $h .= '</div>';
        }
        return $h . '</div><div class="calc-hint muted small">' . __('Digita da tastiera · Invio = · Esc C · Backspace ⌫') . '</div></div>';
    }
}
