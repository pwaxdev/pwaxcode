<?php
/**
 * Lo Store di DRFacile: catalogo (app + repository), installazione dei pacchetti, aggiornamenti, voti.
 * Lettura per tutti (store.leggi); installare/aggiornare/rimuovere è dell'amministratore dello studio (store.gestisci).
 */
require __DIR__ . '/../core/bootstrap.php';
$urlAttesa = fn() => 'attesa.php?t=' . Impostazione::get('salaattesa_token') . (Database::tenantId() ? '&s=' . Database::tenantId() : '');   // SaaS: il link porta anche lo studio
$cerca = function (string $codice): array {
    foreach (Estensioni::catalogo(true) as $x) if ($x['codice'] === $codice) return $x;
    throw new ApiException(__('Estensione non trovata nel catalogo'));
};
$esito = function (string $codice, string $messaggio) use ($urlAttesa): array {
    return ['messaggio' => $messaggio,
        'salaattesa_url' => $codice === 'salaattesa' ? $urlAttesa() : null,
        'icona' => (bool) array_filter(Scrivania::moduli(), fn($m) => ($m['estensione'] ?? null) === $codice),
        'ricarica' => (bool) glob(Store::dir($codice) . '/js/*.js')];
};

Api::run([
    'catalogo' => function () use ($urlAttesa) {
        $sync = Store::attivo() ? Store::sincronizza() : null;   // con la cache: costa una lettura di file
        $moduli = Estensioni::catalogo(true);
        $categorie = array_values(array_unique(array_merge(Store::CATEGORIE, array_filter(array_column($moduli, 'categoria')))));
        return ['moduli' => $moduli, 'categorie' => $categorie, 'salaattesa_url' => Estensioni::attiva('salaattesa') ? $urlAttesa() : null,
            'repository' => ['attivo' => Store::attivo(), 'url' => Store::repository(), 'revisore' => Store::revisore(), 'sync' => $sync],
            'gestisci' => Auth::can('store.gestisci'), 'zip' => class_exists('ZipArchive'), 'spazio' => Spazio::stato(),
            'pagamenti' => ['stripe' => Pagamenti::stripeAttivo(), 'amministratore' => Pagamenti::amministratore()]];
    },
    'sincronizza' => fn() => ['sync' => Store::sincronizza(true)],

    // Installa: scarica i file se servono (repository), poi attiva nello studio
    'installa' => function (array $in) use ($cerca, $esito) {
        $codice = Api::str($in, 'codice'); $m = $cerca($codice);
        if (!(int) $m['disponibile']) throw new ApiException(__('Questa estensione è in arrivo: sarà attivabile appena disponibile'));
        if ($m['prezzo_tipo'] !== 'gratis' && !$m['presente']) throw new ApiException(__('Le estensioni a pagamento si attivano dal portale DRFacile (acquisto o abbonamento): qui compariranno già attive'));
        if (!$m['presente']) Store::scarica($codice);   // dal repository: verifica sha256, requisiti, dipendenze
        elseif ($m['problemi']) throw new ApiException(implode(' · ', $m['problemi']));
        foreach ($m['dipendenze_mancanti'] as $d) { if (!Store::installato($d)) Store::scarica($d); Estensioni::installa($d); }
        Estensioni::installa($codice);
        Attivita::registra('estensione.installata', 'negozio', 0, $m['nome']);
        return $esito($codice, $m['nome'] . ' installata');
    },
    'aggiorna' => function (array $in) use ($cerca, $esito) {
        $codice = Api::str($in, 'codice'); $m = $cerca($codice);
        $r = Estensioni::aggiorna($codice);
        Attivita::registra('estensione.aggiornata', 'negozio', 0, $m['nome'] . ' ' . $r['da'] . ' → ' . $r['a']);
        return $esito($codice, $m['nome'] . ' aggiornata alla versione ' . $r['a']);
    },
    'attiva' => function (array $in) use ($cerca, $esito) {
        $codice = Api::str($in, 'codice'); $m = $cerca($codice);
        if (!$m['presente']) throw new ApiException('I file dell\'estensione non ci sono più: installala di nuovo');
        Estensioni::installa($codice);
        Attivita::registra('estensione.attivata', 'negozio', 0, $m['nome']);
        return $esito($codice, $m['nome'] . ' attivata');
    },
    'disinstalla' => function (array $in) use ($esito) {   // = disattiva (nome storico)
        $codice = Api::str($in, 'codice');
        $ricarica = (bool) glob(Store::dir($codice) . '/js/*.js');   // prima di spegnerla: i suoi js/css sono ancora in pagina
        Estensioni::disinstalla($codice);
        Attivita::registra('estensione.disattivata', 'negozio', 0, $codice);
        return ['messaggio' => __('Estensione disattivata'), 'ricarica' => $ricarica];
    },
    'rimuovi' => function (array $in) use ($cerca) {
        $codice = Api::str($in, 'codice'); $m = $cerca($codice);
        if ($m['origine'] !== 'repository') throw new ApiException(__('Questa estensione fa parte del programma: si può disattivare ma non rimuovere'));
        $ricarica = $m['installata'] && (bool) glob(Store::dir($codice) . '/js/*.js');
        Estensioni::rimuovi($codice);
        Attivita::registra('estensione.rimossa', 'negozio', 0, $m['nome']);
        return ['messaggio' => $m['nome'] . ' rimossa (i dati restano nel database)', 'ricarica' => $ricarica];
    },
    'vota' => fn(array $in) => ['voti' => Store::vota(Api::str($in, 'codice'), Api::int($in, 'voto'), Api::str($in, 'recensione'))],
], ['*' => 'store.leggi', 'installa' => 'store.gestisci', 'aggiorna' => 'store.gestisci', 'attiva' => 'store.gestisci', 'disinstalla' => 'store.gestisci', 'rimuovi' => 'store.gestisci', 'sincronizza' => 'store.gestisci']);
