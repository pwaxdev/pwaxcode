<?php
return [
    'title' => __('Nuova prestazione'), 'title_edit' => __('Modifica prestazione'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Aggiungi al listino'),
    'table' => 'prestazioni', 'wide' => true,
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'prestazioni'],
        ['name' => 'nome', 'label' => __('Nome'), 'type' => 'text', 'required' => true],
        ['name' => 'prezzo', 'label' => __('Prezzo'), 'type' => 'text', 'mask' => 'euros', 'row' => 1],
        ['name' => 'durata', 'label' => __('Durata (min)'), 'type' => 'text', 'mask' => 'numero', 'default' => 30, 'row' => 1, 'help' => __('Proposta alla prenotazione in agenda')],
        ['name' => 'iva_id', 'label' => __('Aliquota IVA'), 'type' => 'select', 'options' => fn() => Iva::optionsMap(), 'default' => fn() => (string) ((Iva::predefinita()['id'] ?? '')), 'row' => 2, 'help' => __('Le aliquote si gestiscono in Archivi → Aliquote IVA')],
        ['name' => 'colore', 'label' => __('Colore in agenda'), 'type' => 'color', 'default' => '#6B6FE6', 'row' => 2],
        ['name' => 'prenotabile', 'label' => __('Prenotabile online'), 'type' => 'switch', 'default' => 0, 'help' => __('Se attiva, in futuro la prestazione sarà prenotabile via internet dai pazienti')],
        ['name' => 'previsita', 'label' => __('Istruzioni pre-visita'), 'type' => 'switch', 'default' => 0, 'help' => __('Prepara le istruzioni da inviare al paziente che prenota questa prestazione')],
        ['name' => 'previsita_titolo', 'label' => __('Titolo delle istruzioni'), 'type' => 'text', 'placeholder' => __('Es. Preparazione all\'ecografia'), 'show_if' => 'previsita'],
        ['name' => 'previsita_testo', 'label' => __('Testo delle istruzioni'), 'type' => 'rich', 'height' => 170, 'show_if' => 'previsita',
            'campi' => ['paziente', 'prestazione', 'data', 'ora', 'medico', 'studio'],
            'placeholder' => __('Gentile {paziente}, per la {prestazione} del {data}…')],
        ['name' => 'previsita_quando', 'label' => __('Quando inviarle'), 'type' => 'seg', 'show_if' => 'previsita', 'default' => 'prenotazione',
            'options' => ['prenotazione' => __('Alla prenotazione'), '24h' => __('24 h prima'), '48h' => __('48 h prima')]],
        ['name' => 'attiva', 'label' => __('Attiva'), 'type' => 'switch', 'default' => 1],
    ],
];
