<?php
/**
 * Scadenzario interno, universale e senza cron: il controllo gira al primo accesso di ogni giornata
 * (bootstrap → Scadenzario::controlla), quindi funziona uguale per tutte le installazioni.
 * Le scadenze si creano con Scadenzario::aggiungi() da qualsiasi punto del programma
 * (pagamenti in attesa, consensi con validità, prossimi controlli…) e alla data prevista
 * diventano una notifica; il modulo "Scadenze" della Scrivania le mostra in anticipo.
 */
final class Scadenzario extends Model
{
    protected static string $table = 'scadenze';
    protected static array $fillable = ['tipo', 'data', 'titolo', 'testo', 'link', 'rif_tabella', 'rif_id', 'stato'];
    protected static array $json = ['link'];

    public const TIPI = ['pagamento' => 'Pagamento', 'consenso' => 'Consenso', 'controllo' => 'Controllo', 'documento' => 'Documento', 'promemoria' => 'Promemoria'];

    /** Crea (o aggiorna, se esiste già per lo stesso riferimento) una scadenza aperta */
    public static function aggiungi(string $tipo, string $data, string $titolo, string $testo = '', array $link = [], ?string $rifTabella = null, ?int $rifId = null): int
    {
        Capabilities::richiedi('scadenzario.crea');
        if ($rifTabella && $rifId) {
            $ex = Database::one('SELECT id FROM scadenze WHERE rif_tabella = ? AND rif_id = ? AND tipo = ?', [$rifTabella, $rifId, $tipo]);
            if ($ex) { self::save(['id' => (int) $ex['id'], 'data' => $data, 'titolo' => $titolo, 'testo' => $testo, 'link' => $link, 'stato' => 'aperta']); return (int) $ex['id']; }
        }
        return self::save(['tipo' => $tipo, 'data' => $data, 'titolo' => mb_substr($titolo, 0, 160), 'testo' => mb_substr($testo, 0, 300), 'link' => $link, 'rif_tabella' => $rifTabella, 'rif_id' => $rifId, 'stato' => 'aperta']);
    }

    /** Chiude la scadenza legata a un riferimento (es. fattura incassata) */
    public static function chiudi(string $rifTabella, int $rifId, ?string $tipo = null): void
    {
        Database::run('UPDATE scadenze SET stato = ? WHERE rif_tabella = ? AND rif_id = ?' . ($tipo ? ' AND tipo = ?' : ''), array_merge(['chiusa', $rifTabella, $rifId], $tipo ? [$tipo] : []));
    }

    /** Le prossime scadenze aperte (per il modulo della Scrivania) */
    public static function prossime(int $giorni = 30, int $limit = 50): array
    {
        return self::all("stato IN ('aperta', 'notificata') AND data <= ?", [date('Y-m-d', strtotime("+$giorni days"))], 'data, id', $limit);
    }

    /** Il motore: una volta al giorno trasforma in notifica le scadenze arrivate a maturazione */
    public static function controlla(): void
    {
        if (!Database::tableExists('scadenze')) return;
        if (Impostazione::get('scadenze_controllo') === oggi()) return;   // già fatto oggi
        Impostazione::set('scadenze_controllo', oggi());
        Hooks::run('scadenzario.controlli', oggi());   // i controlli quotidiani delle estensioni (job senza cron): scorte, scadenze, sincronizzazioni…
        foreach (self::all("stato = 'aperta' AND data <= ?", [oggi()], 'data, id', 200) as $s) {
            Notifica::aggiungi('warn', $s['titolo'], trim(($s['testo'] ? $s['testo'] . ' · ' : '') . 'scadenza ' . data_it($s['data'])), $s['link'] ?: null);
            self::save(['id' => (int) $s['id'], 'stato' => 'notificata']);
        }
    }
}
