<?php
/**
 * UTENTI e STUDI nel database COMUNE (SaaS).
 * Ruoli (medico, segreteria, commercialista + hook utenti.ruoli) e flag `admin` (amministratore dello studio):
 * cosa può fare ciascuno è in core/permessi.php, applicato da Auth::can().
 * `studi.database` (JSON, opzionale) indica il database dedicato dello studio: vedi core/Tenant.php.
 *
 * Architettura dei dati:
 *   · COMUNE (config db.common su MySQL; nello stesso file su SQLite):
 *     `studi` (con l'abbonamento), `utenti` (più utenti per studio), archivi di supporto
 *     condivisi fra tutte le installazioni: `comuni`, e in prospettiva `icd9` e `farmaci_aifa`.
 *   · DEDICATO (il database dell'installazione): tutto ciò che è dello studio —
 *     pazienti, visite, referti, fatture, agenda, documenti, impostazioni…
 *
 * Le tabelle comuni si raggiungono SEMPRE con Database::comune('tabella').
 */
final class Utente
{
    private static ?array $cache = null;

    public static function tabelle(): void
    {
        $u = Database::comune('utenti'); $s = Database::comune('studi');
        $id = Database::driver() === 'mysql' ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
        Database::run("CREATE TABLE IF NOT EXISTS $s (
            id $id, nome VARCHAR(160) NOT NULL, citta VARCHAR(120),
            abbonamento_scadenza VARCHAR(10), abbonamento_periodo VARCHAR(20) DEFAULT 'mensile',
            attivo INTEGER DEFAULT 1, creato_il VARCHAR(19))");
        Database::run("CREATE TABLE IF NOT EXISTS $u (
            id $id, studio_id INTEGER NOT NULL, username VARCHAR(60) NOT NULL,
            password_hash VARCHAR(255) NOT NULL, nome VARCHAR(80), cognome VARCHAR(80),
            sesso VARCHAR(1) DEFAULT 'F', ruolo VARCHAR(20) DEFAULT 'medico',
            email VARCHAR(160), telefono VARCHAR(40), attivo INTEGER DEFAULT 1, creato_il VARCHAR(19), admin INTEGER DEFAULT 0)");
        // recupero password: una riga per richiesta (più utenti possono chiederlo insieme), codice in hash, scadenza e tentativi
        Database::run('CREATE TABLE IF NOT EXISTS ' . Database::comune('password_reset') . " (
            id $id, utente_id INTEGER NOT NULL, codice_hash VARCHAR(255) NOT NULL, canale VARCHAR(10),
            scadenza VARCHAR(19) NOT NULL, tentativi INTEGER DEFAULT 0, usato INTEGER DEFAULT 0, ip VARCHAR(45), creato_il VARCHAR(19))");
        RateLimit::tabelle();
        // colonne aggiunte dopo la prima versione (idempotente: se esistono l'ALTER fallisce in silenzio)
        foreach (["$u" => ['admin' => 'INTEGER DEFAULT 0', 'lingua' => 'VARCHAR(8)'], "$s" => ['`database`' => 'TEXT', 'quota_mb' => 'INTEGER', 'sms_credito' => 'INTEGER DEFAULT 0']] as $tab => $cols) {
            foreach ($cols as $col => $tipo) { try { Database::run("ALTER TABLE $tab ADD COLUMN $col $tipo"); } catch (Throwable $e) { /* già presente */ } }
        }
        // archivi di supporto condivisi, predisposti per ICD9→ICD10 e liste AIFA
        Database::run('CREATE TABLE IF NOT EXISTS ' . Database::comune('icd9') . " (
            id $id, codice VARCHAR(10) NOT NULL, descrizione VARCHAR(255) NOT NULL, sistema VARCHAR(10) DEFAULT 'ICD9')");
        Database::run('CREATE TABLE IF NOT EXISTS ' . Database::comune('farmaci_aifa') . " (
            id $id, aic VARCHAR(12), nome VARCHAR(200) NOT NULL, principio VARCHAR(200), confezione VARCHAR(200), ditta VARCHAR(160))");
    }

    /** Migrazione dal monoutente: crea lo studio e il primo utente dalle vecchie impostazioni/config */
    public static function migra(): void
    {
        if (Database::value('SELECT COUNT(*) FROM ' . Database::comune('utenti'))) return;
        $p = Impostazione::profilo();
        $sid = (int) (Database::value('SELECT id FROM ' . Database::comune('studi') . ' LIMIT 1') ?: 0);
        if (!$sid) {
            // scadenza: quella già nelle impostazioni (legacy); in demo, 30 giorni da oggi per provare avvisi e sospensione
            $scad = Impostazione::get('abbonamento_scadenza') ?: (Config::get('app.demo') ? date('Y-m-d', strtotime('+30 days')) : null);
            Database::run('INSERT INTO ' . Database::comune('studi') . ' (nome, abbonamento_scadenza, abbonamento_periodo, attivo, creato_il) VALUES (?, ?, ?, 1, ?)',
                [$p['studio'] ?: 'Studio medico', $scad, Impostazione::get('abbonamento_periodo', 'mensile'), date('Y-m-d H:i:s')]);
            $sid = (int) Database::pdo()->lastInsertId();
        }
        $hash = Impostazione::get('auth_password_hash') ?: (string) Config::get('auth.password_hash');
        // il vecchio profilo ha nome e cognome in un campo unico: l'ultima parola diventa il cognome
        $pieno = trim((string) ($p['nome'] ?? ''));
        $parti = $pieno === '' ? [] : preg_split('/\s+/', $pieno);
        $cognome = count($parti) > 1 ? array_pop($parti) : ($parti[0] ?? '');
        $nome = implode(' ', $parti);
        Database::run('INSERT INTO ' . Database::comune('utenti') . ' (studio_id, username, password_hash, nome, cognome, sesso, ruolo, email, telefono, attivo, creato_il, admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 1)',
            [$sid, (string) Config::get('auth.username'), $hash, $nome, $cognome, $p['sesso'] ?? 'F', 'medico', $p['email'] ?? '', $p['telefono'] ?? '', date('Y-m-d H:i:s')]);
    }

    public static function perUsername(string $username): ?array
    {
        return Database::one('SELECT * FROM ' . Database::comune('utenti') . ' WHERE username = ? AND attivo = 1', [$username]) ?: null;
    }

    public static function trova(int $id): ?array
    {
        return Database::one('SELECT * FROM ' . Database::comune('utenti') . ' WHERE id = ?', [$id]) ?: null;
    }

    /** Gli utenti dello studio corrente */
    public static function delloStudio(int $studioId): array
    {
        Capabilities::richiedi('utenti.leggi');
        return Database::all('SELECT id, studio_id, username, nome, cognome, sesso, ruolo, email, telefono, attivo, creato_il, admin FROM ' . Database::comune('utenti') . ' WHERE studio_id = ? ORDER BY cognome, nome', [$studioId]);
    }

    public static function salva(array $in, int $studioId): int
    {
        $id = (int) ($in['id'] ?? 0);
        $username = strtolower(trim((string) ($in['username'] ?? '')));
        if ($username === '' || !preg_match('/^[a-z0-9._-]{3,60}$/', $username)) throw new ApiException(__('Nome utente non valido (minimo 3 caratteri, lettere/numeri/punti)'));
        $ex = Database::one('SELECT id FROM ' . Database::comune('utenti') . ' WHERE username = ?', [$username]);
        if ($ex && (int) $ex['id'] !== $id) throw new ApiException(__('Nome utente già in uso'));
        $dati = ['nome' => trim((string) ($in['nome'] ?? '')), 'cognome' => trim((string) ($in['cognome'] ?? '')),
            'sesso' => in_array($in['sesso'] ?? '', ['M', 'F'], true) ? $in['sesso'] : 'F',
            'ruolo' => in_array($in['ruolo'] ?? '', self::ruoli(), true) ? $in['ruolo'] : 'medico',
            'email' => trim((string) ($in['email'] ?? '')), 'telefono' => trim((string) ($in['telefono'] ?? ''))];
        if ($dati['cognome'] === '') throw new ApiException(__('Il cognome è obbligatorio'));
        $pwd = (string) ($in['password'] ?? '');
        // flag amministratore: solo un amministratore può assegnarlo o toglierlo; non a se stesso; ne resta sempre almeno uno
        $admin = array_key_exists('admin', $in) ? (int) (bool) $in['admin'] : null;
        if ($admin !== null) {
            if (!Auth::admin()) $admin = null;   // ignorato in silenzio: il campo non è modificabile da chi non è amministratore
            elseif ($id && $admin === 0) {
                if ($id === (int) (Auth::utente()['id'] ?? 0)) throw new ApiException(__('Non puoi togliere a te stesso il ruolo di amministratore'));
                $altri = (int) Database::value('SELECT COUNT(*) FROM ' . Database::comune('utenti') . ' WHERE studio_id = ? AND admin = 1 AND attivo = 1 AND id <> ?', [$studioId, $id]);
                if ($altri === 0) throw new ApiException(__('Deve restare almeno un amministratore nello studio'));
            }
        }
        if ($id) {
            $set = 'username = ?, nome = ?, cognome = ?, sesso = ?, ruolo = ?, email = ?, telefono = ?';
            $par = [$username, $dati['nome'], $dati['cognome'], $dati['sesso'], $dati['ruolo'], $dati['email'], $dati['telefono']];
            if ($admin !== null) { $set .= ', admin = ?'; $par[] = $admin; }
            if ($pwd !== '') { if (strlen($pwd) < 8) throw new ApiException(__('La password deve avere almeno 8 caratteri')); $set .= ', password_hash = ?'; $par[] = password_hash($pwd, PASSWORD_DEFAULT); }
            $par[] = $id; $par[] = $studioId;
            Database::run('UPDATE ' . Database::comune('utenti') . " SET $set WHERE id = ? AND studio_id = ?", $par);
            return $id;
        }
        if (strlen($pwd) < 8) throw new ApiException(__('La password deve avere almeno 8 caratteri'));
        Database::run('INSERT INTO ' . Database::comune('utenti') . ' (studio_id, username, password_hash, nome, cognome, sesso, ruolo, email, telefono, attivo, creato_il, admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)',
            [$studioId, $username, password_hash($pwd, PASSWORD_DEFAULT), $dati['nome'], $dati['cognome'], $dati['sesso'], $dati['ruolo'], $dati['email'], $dati['telefono'], date('Y-m-d H:i:s'), $admin ?? 0]);
        return (int) Database::pdo()->lastInsertId();
    }

    /** Ogni studio ha almeno un amministratore: se manca, lo diventa il primo medico attivo (poi il primo utente attivo) */
    public static function assicuraAdmin(int $studioId): void
    {
        $t = Database::comune('utenti');
        if (Database::value("SELECT COUNT(*) FROM $t WHERE studio_id = ? AND admin = 1 AND attivo = 1", [$studioId])) return;
        $id = Database::value("SELECT id FROM $t WHERE studio_id = ? AND attivo = 1 AND ruolo = 'medico' ORDER BY id LIMIT 1", [$studioId])
            ?: Database::value("SELECT id FROM $t WHERE studio_id = ? AND attivo = 1 ORDER BY id LIMIT 1", [$studioId]);
        if ($id) Database::run("UPDATE $t SET admin = 1 WHERE id = ?", [(int) $id]);
    }

    /** I ruoli disponibili: il commercialista arriva con l'estensione dal Negozio */
    public static function ruoli(): array
    {
        $r = ['medico', 'segreteria'];
        if (class_exists('Estensioni') && Estensioni::attiva('commercialista')) $r[] = 'commercialista';
        return class_exists('Hooks') ? array_values(array_unique(Hooks::filter('utenti.ruoli', $r))) : $r;   // hook per le estensioni
    }

    public static function studio(int $id): ?array
    {
        return Database::one('SELECT * FROM ' . Database::comune('studi') . ' WHERE id = ?', [$id]) ?: null;
    }
}
