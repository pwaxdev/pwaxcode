<?php
return [
    'title' => __('Nuovo farmaco'), 'title_edit' => __('Modifica farmaco'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Aggiungi al prontuario'),
    'table' => 'farmaci',
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'farmaci'],
        ['name' => 'nome', 'label' => __('Nome commerciale e dosaggio'), 'type' => 'text', 'required' => true],
        ['name' => 'principio', 'label' => __('Principio attivo'), 'type' => 'text'],
        ['name' => 'confezione', 'label' => __('Confezione'), 'type' => 'text', 'row' => 1],
        ['name' => 'posologia', 'label' => __('Posologia abituale'), 'type' => 'text', 'row' => 1],
        ['name' => 'preferito', 'label' => __('Tra i più usati'), 'type' => 'switch', 'default' => 0],
    ],
];
