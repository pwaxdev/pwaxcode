/* Notifiche: pannello sotto la campanella (ultime, con tempo relativo), centro notifiche in modale, badge non lette.
   Da qualsiasi modulo: DRF.notify.add({ tipo:'success', titolo, testo, link:{ modulo:'referti', opts:{ select: 12 } } }) */
DRF.notify = (function ($) {
  'use strict';
  const ICON = { info: ['info', 'fa-solid fa-circle-info'], success: ['check', 'fa-solid fa-check'], warn: ['exclamation', 'fa-solid fa-triangle-exclamation'], error: ['cross-circle', 'fa-solid fa-circle-xmark'] };
  const icone = () => (DRF.hooks ? DRF.hooks.filter('notifiche.tipi', ICON) : ICON);   // tipi delle estensioni: { dieta: ['salad', 'fa-solid fa-bowl-food'] }
  const st = { lista: [], nonLette: 0, dt: null };

  function rel(ts) {
    const d = new Date(String(ts).replace(' ', 'T')); if (isNaN(d)) return '';
    const s = Math.round((Date.now() - d) / 1000), m = Math.round(s / 60), h = Math.round(m / 60), g = Math.round(h / 24);
    if (s < 45) return DRF.__('poco fa'); if (m < 60) return DRF._n('%d minuto fa', '%d minuti fa', m); if (h < 24) return DRF._n('%d ora fa', '%d ore fa', h);
    if (g === 1) return DRF.__('ieri'); if (g < 7) return DRF._n('%d giorno fa', '%d giorni fa', g); if (g < 30) return DRF._n('%d settimana fa', '%d settimane fa', Math.round(g / 7)); return DRF.__('molto tempo fa');
  }
  function badge(n) { st.nonLette = n; $('#bellCount').text(n).prop('hidden', !n); $('#bellBtn').toggleClass('has', n > 0); }
  function riga(n, compatta) {
    const [fi, fa] = icone()[n.tipo] || ICON.info;
    return `<div class="ntf ${+n.letta ? '' : 'unread'} ${n.tipo}" data-id="${n.id}"><span class="ntf-ico">${DRF.icons.html(fi, fa)}</span><div class="ntf-body"><b>${DRF.esc(n.titolo)}</b>${n.testo ? `<span>${DRF.esc(n.testo)}</span>` : ''}<small>${rel(n.creato_il)}${compatta ? '' : ' · ' + DRF.util.fmtDateTime(n.creato_il)}</small></div>${+n.letta ? '' : '<i class="ntf-dot"></i>'}</div>`;
  }
  function apri(n) {
    if (!+n.letta) DRF.api.post('notifiche', 'letta', { id: n.id, letta: 1 }).then(r => badge(r.non_lette));
    n.letta = 1; chiudi(); DRF.ui.closeModal();
    if (n.link && n.link.modulo) DRF.nav.go(n.link.modulo, n.link.opts || {});
  }
  function pannello() {
    const $p = $('#notifPanel');
    $p.find('.ntf-list').html(st.lista.length ? st.lista.map(n => riga(n, true)).join('') : '<div class="empty">' + DRF.__('Nessuna notifica.') + '</div>');
    $p.find('[data-ntf-all]').prop('disabled', !st.nonLette);
    DRF.icons.apply($p[0]);
  }
  function chiudi() { $('#notifPanel').removeClass('open'); $(document).off('.ntf'); }

  const N = {
    init() {
      $('#bellBtn').on('click', e => { e.stopPropagation(); const $p = $('#notifPanel'); if ($p.hasClass('open')) return chiudi(); N.refresh().then(() => { $p.addClass('open'); setTimeout(() => $(document).on('mousedown.ntf', ev => { if (!$(ev.target).closest('#notifPanel, #bellBtn').length) chiudi(); }).on('keydown.ntf', ev => { if (ev.key === 'Escape') chiudi(); }), 0); }); });
      $('#notifPanel').on('click', '.ntf', function () { const n = st.lista.find(x => +x.id === +this.dataset.id); if (n) apri(n); })
        .on('click', '[data-ntf-all]', () => DRF.api.post('notifiche', 'tutte_lette').then(r => { badge(0); st.lista.forEach(n => n.letta = 1); pannello(); }))
        .on('click', '[data-ntf-centro]', () => { chiudi(); N.centro(); });
      N.refresh(); setInterval(() => N.refresh(), 60000);
    },
    refresh() { return DRF.api.get('notifiche', 'recenti', { n: 8 }).then(r => { st.lista = r.notifiche; badge(r.non_lette); pannello(); }); },
    /** Crea una notifica (anche da un modulo) e la mostra come toast */
    add(o) { return DRF.api.post('notifiche', 'aggiungi', o).then(r => { badge(r.non_lette); N.refresh(); DRF.ui.toast(o.titolo, o.tipo === 'error' ? 'error' : o.tipo === 'warn' ? 'warn' : o.tipo === 'success' ? 'success' : 'info'); return r; }); },
    /** Centro notifiche: modale con tutte le notifiche in DataTable */
    centro() {
      DRF.api.get('notifiche', 'tutte').then(r => {
        DRF.ui.modal({ title: DRF.__('Centro notifiche'), size: 'lg', ok: false, cancel: DRF.__('Chiudi'),
          html: `<div class="row" style="gap:8px;margin-bottom:12px;flex-wrap:wrap"><div class="seg" id="ntfFilter"><button type="button" class="on" data-v="tutte">${DRF.__('Tutte')}</button><button type="button" data-v="0">${DRF.__('Non lette')}</button><button type="button" data-v="1">${DRF.__('Lette')}</button></div><span class="muted small" id="ntfCount" style="margin-left:auto"></span><button class="btn ghost sm" type="button" data-ntf-seg-tutte>${DRF.icons.html('check-double', 'fa-solid fa-check-double')}${DRF.__('Segna tutte lette')}</button><button class="btn ghost sm" type="button" data-ntf-del-lette>${DRF.icons.html('trash', 'fa-solid fa-trash')}${DRF.__('Elimina le lette')}</button></div><table id="ntfTable" class="dt" style="width:100%"><thead><tr><th></th><th>${DRF.__('Notifica')}</th><th>${DRF.__('Quando')}</th><th>${DRF.__('Stato')}</th></tr></thead><tbody></tbody></table>`,
          onOpen($b) {
            const dati = r.notifiche;
            const dt = DRF.ui.datatable($b.find('#ntfTable'), { pageLength: 10, order: [[2, 'desc']], columns: [
              { data: 'id', orderable: false, searchable: false, className: 'dt-actions', render: (id, t, n) => `<button class="icon-btn sm accent" type="button" data-ntf-open="${id}" title="${DRF.__('Apri')}">${DRF.icons.html('arrow-small-right', 'fa-solid fa-arrow-right')}</button><button class="icon-btn sm" type="button" data-ntf-toggle="${id}" title="${+n.letta ? DRF.__('Segna non letta') : DRF.__('Segna letta')}">${DRF.icons.html(+n.letta ? 'envelope' : 'envelope-open', +n.letta ? 'fa-regular fa-envelope' : 'fa-regular fa-envelope-open')}</button><button class="icon-btn sm danger" type="button" data-ntf-del="${id}" title="${DRF.__('Elimina')}">${DRF.icons.html('trash', 'fa-solid fa-trash')}</button>` },
              { data: 'titolo', render: (v, t, n) => { const [fi, fa] = icone()[n.tipo] || ICON.info; return `<div class="row" style="gap:10px"><span class="ntf-ico ${n.tipo}">${DRF.icons.html(fi, fa)}</span><div><b>${DRF.esc(v)}</b>${n.testo ? `<div class="small muted">${DRF.esc(n.testo)}</div>` : ''}</div></div>`; } },
              { data: 'creato_il', render: (v, t) => t === 'display' ? `<span class="num">${rel(v)}</span><div class="small muted">${DRF.util.fmtDateTime(v)}</div>` : v },
              { data: 'letta', render: v => +v ? DRF.ui.badge('gray', DRF.__('Letta')) : DRF.ui.badge('violet', DRF.__('Non letta')) },
            ] });
            const draw = () => { const f = String(DRF.ui.segValue($b.find('#ntfFilter'))); const rows = f === 'tutte' ? dati : dati.filter(n => String(+n.letta) === f); dt.clear().rows.add(rows).draw(); $b.find('#ntfCount').text(`${DRF._n('%d notifica', '%d notifiche', rows.length)}`); };
            $b.find('#ntfFilter').on('seg:change', draw);
            $b.on('click', '[data-ntf-open]', function () { const n = dati.find(x => +x.id === +this.dataset.ntfOpen); if (n) apri(n); })
              .on('click', '[data-ntf-toggle]', function () { const n = dati.find(x => +x.id === +this.dataset.ntfToggle); n.letta = +n.letta ? 0 : 1; DRF.api.post('notifiche', 'letta', { id: n.id, letta: n.letta }).then(x => { badge(x.non_lette); N.refresh(); draw(); }); })
              .on('click', '[data-ntf-del]', function () { const id = +this.dataset.ntfDel; DRF.api.post('notifiche', 'elimina', { id }).then(x => { const i = dati.findIndex(n => +n.id === id); if (i >= 0) dati.splice(i, 1); badge(x.non_lette); N.refresh(); draw(); }); })
              .on('click', '[data-ntf-seg-tutte]', () => DRF.api.post('notifiche', 'tutte_lette').then(() => { dati.forEach(n => n.letta = 1); badge(0); N.refresh(); draw(); }))
              .on('click', '[data-ntf-del-lette]', () => DRF.ui.confirm(DRF.__('Eliminare le notifiche lette?'), DRF.__('Le notifiche non lette restano.'), DRF.__('Elimina')).then(ok => { if (ok) DRF.api.post('notifiche', 'elimina_lette').then(x => { for (let i = dati.length - 1; i >= 0; i--) if (+dati[i].letta) dati.splice(i, 1); badge(x.non_lette); N.refresh(); draw(); }); }));
            draw();
          } });
      });
    },
    rel
  };
  return N;
})(jQuery);
