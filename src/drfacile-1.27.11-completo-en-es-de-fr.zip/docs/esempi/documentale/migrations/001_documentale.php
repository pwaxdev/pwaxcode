<?php
/** Gestione documentale · cartelle (per paziente; sistema = referti|fatture|ricette|esami|documenti) e file (indice dell'archivio) */
return function () {
    Migrazioni::tabella('ext_documentale_cartelle', "
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        paziente_id INTEGER NOT NULL,
        parent_id INTEGER,
        nome VARCHAR(120) NOT NULL,
        sistema VARCHAR(20),
        creato_il VARCHAR(19)");
    Migrazioni::indice('ext_documentale_cartelle', 'paziente_id');
    Migrazioni::tabella('ext_documentale_file', "
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        paziente_id INTEGER NOT NULL,
        cartella_id INTEGER,
        nome VARCHAR(200) NOT NULL,
        mime VARCHAR(100),
        dimensione INTEGER DEFAULT 0,
        percorso VARCHAR(255) NOT NULL,
        origine VARCHAR(20) DEFAULT 'upload',
        rif_tabella VARCHAR(30), rif_id INTEGER,
        utente_id INTEGER, note VARCHAR(255),
        creato_il VARCHAR(19)");
    Migrazioni::indice('ext_documentale_file', 'paziente_id');
    Migrazioni::indice('ext_documentale_file', 'percorso');
};
