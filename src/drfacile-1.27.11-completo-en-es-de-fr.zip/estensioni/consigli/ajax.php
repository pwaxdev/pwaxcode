<?php
/** Estensione Consigli · endpoint AJAX (ajax/ext.php?ext=consigli): le impostazioni dello studio per la card in visita.
    Ritorna le azioni (chiusure) e i permessi, come un file di ajax/ del core; il router verifica che l'estensione sia attiva. */
return [
    'azioni' => [
        'config' => fn() => [
            'testo' => Impostazione::get('consigli_testo'),
            'frasi' => array_values(array_filter(array_map('trim', preg_split('/\r?\n/', Impostazione::get('consigli_frasi'))))),
            'auto' => Impostazione::get('consigli_auto') === '1',
        ],
    ],
    'permessi' => 'visita.leggi',
];
