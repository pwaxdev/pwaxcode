<?php
/**
 * Elenco dei moduli del gestionale, nell'ordine in cui compaiono sulla costa (rail).
 * Ogni modulo ha: etichetta, icona UIcons (fi) con equivalente Font Awesome (fa), foglio CSS e script propri,
 * e il permesso (core/permessi.php) che serve per vederlo: chi non ce l'ha non trova l'icona sulla costa.
 * Per aggiungere un modulo: una riga qui + views/sections/<key>.php + assets/css/<key>.css + assets/js/<key>.js
 */
return [
    ['key' => 'agenda',       'label' => __('Agenda'),       'fi' => 'calendar',        'fa' => 'fa-regular fa-calendar', 'permesso' => 'agenda.leggi'],
    ['key' => 'pazienti',     'label' => __('Pazienti'),     'fi' => 'users',           'fa' => 'fa-solid fa-user-group', 'permesso' => 'pazienti.leggi'],
    ['key' => 'visita',       'label' => __('Visita'),       'fi' => 'stethoscope',     'fa' => 'fa-solid fa-stethoscope', 'permesso' => 'visita.leggi'],
    ['key' => 'ricette',      'label' => __('Ricette'),      'fi' => 'prescription',    'fa' => 'fa-solid fa-prescription', 'permesso' => 'ricette.leggi'],
    ['key' => 'referti',      'label' => __('Referti'),      'fi' => 'document',        'fa' => 'fa-regular fa-file-lines', 'permesso' => 'referti.leggi'],
    ['key' => 'fatture',      'label' => __('Fatturazione'), 'fi' => 'receipt',         'fa' => 'fa-solid fa-file-invoice', 'permesso' => 'fatture.leggi'],
    ['key' => 'statistiche',  'label' => __('Statistiche'),  'fi' => 'chart-histogram', 'fa' => 'fa-solid fa-chart-simple', 'permesso' => 'statistiche.leggi'],
    ['key' => 'archivi',      'label' => __('Archivi'),      'fi' => 'folder-open',     'fa' => 'fa-regular fa-folder-open', 'permesso' => 'archivi.leggi'],
    ['key' => 'procedure',    'label' => __('Procedure'),    'fi' => 'list-check',      'fa' => 'fa-solid fa-list-check', 'permesso' => 'procedure.leggi'],
    ['key' => 'impostazioni', 'label' => __('Impostazioni'), 'fi' => 'settings',        'fa' => 'fa-solid fa-gear', 'permesso' => 'impostazioni.leggi'],
];
