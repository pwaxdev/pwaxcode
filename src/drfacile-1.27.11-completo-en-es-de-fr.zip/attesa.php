<?php
/** SALA D'ATTESA (estensione dal Negozio): pagina pubblica per la TV dello studio, protetta da token.
    Mostra la coda di oggi con le sole iniziali (privacy), evidenzia chi è in visita e il prossimo,
    e si aggiorna da sola ogni 30 secondi. Nessun login: il collegamento segreto è revocabile. */
require __DIR__ . '/core/bootstrap.php';
if (!empty($_GET['s'])) { Tenant::attiva((int) $_GET['s']); if (!Tenant::base() && !Database::tableExists('pazienti')) { http_response_code(404); exit('Pagina non trovata'); } }   // SaaS: lo studio è nel link (il token resta l'unica chiave)
$token = Impostazione::get('salaattesa_token');
if (!Estensioni::attiva('salaattesa') || !$token || !hash_equals($token, (string) ($_GET['t'] ?? ''))) { http_response_code(404); exit('Pagina non trovata'); }

$dati = function (): array {
    $oggi = oggi();
    $rows = Database::all("SELECT a.id, a.ora, a.durata, a.tipo, a.stato, a.urgente, p.nome, p.cognome, p.id pid FROM appuntamenti a JOIN pazienti p ON p.id = a.paziente_id WHERE a.data = ? AND a.stato IN ('prenotato', 'completato') ORDER BY a.ora", [$oggi]);
    $inVisita = array_column(Database::all("SELECT paziente_id FROM visite WHERE stato = 'bozza'"), 'paziente_id');
    $tipi = Appuntamento::tipi();
    $out = []; $prossimoTrovato = false;
    foreach ($rows as $r) {
        $stato = in_array($r['pid'], $inVisita) ? 'in_visita' : ($r['stato'] === 'completato' ? 'fatto' : 'attesa');
        if ($stato === 'attesa' && !$prossimoTrovato) { $stato = 'prossimo'; $prossimoTrovato = true; }
        $out[] = ['iniziali' => mb_strtoupper(mb_substr($r['nome'], 0, 1)) . '. ' . mb_strtoupper(mb_substr($r['cognome'], 0, 1)) . '.',
            'ora' => substr($r['ora'], 0, 5), 'colore' => $tipi[$r['tipo']]['colore'] ?? '#6B6FE6',
            'prestazione' => $tipi[$r['tipo']]['nome'] ?? '', 'stato' => $stato];
    }
    return $out;
};
if (isset($_GET['json'])) { header('Content-Type: application/json'); echo json_encode(['coda' => $dati(), 'ora' => date('H:i')], JSON_UNESCAPED_UNICODE); exit; }
$medico = Impostazione::profilo();
$coda = $dati();
?>
<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sala d'attesa · <?= e($medico['studio']) ?></title>
<link rel="stylesheet" href="assets/vendor/fonts/fonts.css">
<style>
:root{--bg:#14161F;--panel:#1D2029;--ink:#F2F3F8;--ink2:#9AA0B3;--line:#2A2E3C;--ok:#4FC3A1;--warn:#F0B64A}
*{box-sizing:border-box;margin:0}
body{background:var(--bg);color:var(--ink);font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex;flex-direction:column;padding:4vmin 5vmin}
header{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4vmin}
header h1{font-size:3.4vmin;font-weight:800}
header p{color:var(--ink2);font-size:1.9vmin;margin-top:.6vmin}
#clock{font-size:6vmin;font-weight:800;font-variant-numeric:tabular-nums;letter-spacing:.02em}
.coda{flex:1;display:flex;flex-direction:column;gap:1.6vmin;max-width:1100px;width:100%;margin:0 auto}
.riga{display:flex;align-items:center;gap:2.4vmin;background:var(--panel);border:1px solid var(--line);border-radius:2vmin;padding:2vmin 2.8vmin;transition:.3s}
.pallino{width:1.6vmin;height:1.6vmin;border-radius:50%;flex:none}
.chi{font-size:3vmin;font-weight:800;letter-spacing:.04em;min-width:14vmin}
.che{color:var(--ink2);font-size:2vmin;flex:1}
.quando{font-size:2.4vmin;font-weight:700;font-variant-numeric:tabular-nums;color:var(--ink2)}
.tag{font-size:1.7vmin;font-weight:800;border-radius:99px;padding:.5vmin 1.6vmin;text-transform:uppercase;letter-spacing:.06em}
.riga.in_visita{border-color:var(--ok);box-shadow:0 0 0 .4vmin rgba(79,195,161,.15)}
.riga.in_visita .tag{background:rgba(79,195,161,.15);color:var(--ok)}
.riga.prossimo .tag{background:rgba(240,182,74,.15);color:var(--warn)}
.riga.attesa .tag{background:var(--line);color:var(--ink2)}
.riga.fatto{opacity:.35}
.riga.fatto .tag{background:var(--line);color:var(--ink2)}
.vuoto{text-align:center;color:var(--ink2);font-size:2.4vmin;margin-top:8vmin}
footer{text-align:center;color:var(--ink2);font-size:1.6vmin;margin-top:3vmin}
</style></head>
<body>
<header><div><h1><?= e($medico['studio']) ?></h1><p><?= e($medico['nome_completo']) ?> · sala d'attesa</p></div><div id="clock"><?= date('H:i') ?></div></header>
<div class="coda" id="coda"></div>
<footer><?= __('Per riservatezza sono mostrate solo le iniziali · la pagina si aggiorna da sola') ?></footer>
<script>
const ETI = { in_visita: 'In visita', prossimo: 'Prossimo', attesa: 'In attesa', fatto: 'Fatto' };
function render(coda) {
  const el = document.getElementById('coda');
  el.innerHTML = coda.length ? coda.map(r => `<div class="riga ${r.stato}"><span class="pallino" style="background:${r.colore}"></span><span class="chi">${r.iniziali}</span><span class="che">${r.prestazione}</span><span class="quando">${r.ora}</span><span class="tag">${ETI[r.stato]}</span></div>`).join(\'\')
    : \'<div class="vuoto"><?= __('Nessun appuntamento in programma oggi') ?></div>';
}
render(<?= json_encode($coda, JSON_UNESCAPED_UNICODE) ?>);
setInterval(() => fetch(location.pathname + location.search + '&json=1').then(r => r.json()).then(d => { render(d.coda); document.getElementById('clock').textContent = d.ora; }).catch(() => {}), 30000);
setInterval(() => { const d = new Date(); document.getElementById('clock').textContent = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }, 15000);
</script>
</body></html>
