/* Sentinella · il MODULO sulla costa (hook PHP moduli.elenco): registrato come un modulo del core */
DRF.register('sentinella', (function ($) {
  'use strict';
  const I = DRF.icons.html, U = DRF.util;
  const st = { lista: [], tipi: {}, filtro: '' };
  const GRAV = g => g >= 2 ? ['rose', 'alta'] : ['amber', 'media'];
  function render() {
    const l = st.lista.filter(s => !st.filtro || s.tipo === st.filtro);
    const n = t => st.lista.filter(s => s.tipo === t).length;
    $('#sentKpi').html(`
      <div class="kpi">${I('eye', 'fa-regular fa-eye', 'rose')}<div><span>Segnalazioni aperte</span><b class="num">${st.lista.length}</b><small>${st.lista.filter(s => +s.gravita >= 2).length} ad alta priorità</small></div></div>
      <div class="kpi">${I('user-time', 'fa-solid fa-user-clock', 'amber')}<div><span>Non visti da tempo</span><b class="num">${n('assente')}</b><small>${n('controllo')} controlli saltati</small></div></div>
      <div class="kpi">${I('receipt', 'fa-solid fa-file-invoice', 'violet')}<div><span>Fatture scadute</span><b class="num">${n('fattura')}</b><small>${n('anagrafica')} anagrafiche incomplete</small></div></div>`);
    $('#sentLista').html(l.length ? l.map(s => { const [col, lbl] = GRAV(+s.gravita); return `
      <div class="sent-row" data-id="${s.id}">
        <span class="sent-dot ${col}"></span>
        <div class="sent-mid"><b>${DRF.esc(s.titolo)}</b><span>${DRF.esc(st.tipi[s.tipo] || s.tipo)} · priorità ${lbl}${s.testo ? ' · ' + DRF.esc(s.testo) : ''} · ${U.fmtIso(String(s.creato_il).slice(0, 10))}</span></div>
        ${s.paziente_id ? `<button class="btn ghost sm" data-paz="${s.paziente_id}">${I('user', 'fa-solid fa-user')}Scheda</button>` : ''}
        ${s.tipo === 'fattura' ? `<button class="btn ghost sm" data-fat="${s.rif_id}">${I('receipt', 'fa-solid fa-file-invoice')}Fattura</button>` : ''}
        ${s.paziente_id && s.tipo !== 'fattura' ? `<button class="btn soft sm" data-pren="${s.paziente_id}">${I('calendar', 'fa-regular fa-calendar')}Prenota</button>` : ''}
        <button class="icon-btn sm" data-chiudi="${s.id}" title="Segna come gestita">${I('check', 'fa-solid fa-check')}</button>
      </div>`; }).join('') : `<div class="empty">${st.filtro ? 'Nessuna segnalazione di questo tipo.' : 'Tutto sotto controllo: nessuna segnalazione aperta.'}</div>`);
    DRF.icons.apply($('[data-panel="sentinella"]')[0]);
  }
  function load() { return DRF.api.ext('sentinella', 'aperte').then(d => { st.lista = d.segnalazioni; st.tipi = d.tipi; render(); }); }
  return {
    title: 'Sentinella', sub: () => `Vigilanza clinica · ${st.lista.length} ${U.plural(st.lista.length, 'segnalazione aperta', 'segnalazioni aperte')}`,
    action: { label: 'Scansiona ora', fi: 'refresh', fa: 'fa-solid fa-rotate', run: () => DRF.api.ext('sentinella', 'scansione', {}).then(r => { DRF.ui.toast(r.messaggio, r.totale ? 'warn' : 'success'); load().then(() => DRF.nav.updateTopbar()); DRF.notify.refresh(); }) },
    init() {
      const $p = $('[data-panel="sentinella"]');
      $p.on('click', '#sentFiltro button', function () { $('#sentFiltro button').removeClass('on'); this.classList.add('on'); st.filtro = this.dataset.t; render(); });
      $p.on('click', '[data-paz]', function () { DRF.nav.go('pazienti', { select: +this.dataset.paz }); });
      $p.on('click', '[data-fat]', function () { DRF.nav.go('fatture', { select: +this.dataset.fat }); });
      $p.on('click', '[data-pren]', function () { DRF.module('agenda').prenota({ paziente_id: +this.dataset.pren }); });
      $p.on('click', '[data-chiudi]', function () { DRF.api.ext('sentinella', 'chiudi', { id: +this.dataset.chiudi }).then(() => { DRF.ui.toast('Segnalazione gestita'); load().then(() => DRF.nav.updateTopbar()); }); });
    },
    show(opts) { load().then(() => { DRF.nav.updateTopbar(); if (opts && opts.tipo) $(`#sentFiltro [data-t="${opts.tipo}"]`).trigger('click'); }); }
  };
})(jQuery));
