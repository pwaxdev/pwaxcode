<?php
/**
 * Micro-router per gli endpoint in ajax/: ogni file dichiara un elenco di azioni (closure)
 * e Api::run si occupa di autenticazione, CSRF, parsing dell'input e risposta JSON.
 *
 *   Api::run(['list' => fn(array $in) => [...], 'save' => fn(array $in) => [...]], ['*' => 'agenda.leggi', 'save' => 'agenda.modifica']);
 *
 * Risposta: {ok:true, data:...}  oppure  {ok:false, error:"..."}
 */
class ApiException extends RuntimeException {}

final class Api
{
    /**
     * $permessi (core/permessi.php): il permesso richiesto per ogni azione.
     *   stringa           → lo stesso permesso per tutte le azioni
     *   ['*' => 'agenda.leggi', 'save' => 'agenda.modifica']  → predefinito + eccezioni per azione
     *   null / assente    → nessun permesso oltre all'autenticazione (es. notifiche, aiuto)
     * Chi non ha il permesso riceve 403.
     */
    public static function run(array $actions, array|string|null $permessi = null): void
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        Auth::requireAjax();

        $action = (string) ($_GET['action'] ?? $_POST['action'] ?? '');
        if (!isset($actions[$action])) self::fail("Azione non valida: $action", 400);
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !Auth::verifyCsrf()) self::fail('Sessione non valida: ricarica la pagina', 419);
        // null esplicito per un'azione = nessun permesso oltre al login (array_key_exists: con ?? il null cadrebbe sul predefinito '*')
        $p = is_array($permessi) ? (array_key_exists($action, $permessi) ? $permessi[$action] : ($permessi['*'] ?? null)) : $permessi;
        if ($p && !Auth::can($p)) self::fail('Non hai il permesso per questa operazione', 403);

        // sezione = nome del file in ajax/ (pazienti, visita…) oppure ext:<codice> per gli endpoint delle estensioni
        $sezione = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''), '.php');
        if ($sezione === 'ext') $sezione = 'ext:' . preg_replace('/[^a-z0-9_]/', '', (string) ($_GET['ext'] ?? ''));
        try {
            // Un endpoint Api::run deve emettere ESCLUSIVAMENTE JSON. Durante installazione/aggiornamento
            // un'estensione appena caricata (o una sua migrazione) può produrre accidentalmente BOM,
            // spazi, echo di debug o warning: l'operazione può essere già riuscita ma jQuery non riesce
            // più a decodificare la risposta e mostra "Errore di comunicazione". Li sopprimiamo e logghiamo.
            $out = OutputGuard::run("API $sezione/$action", function () use ($actions, $action, $sezione) {
                $in = Hooks::filter('api.prima', self::input(), $sezione, $action);      // le estensioni possono trasformare/validare l'input di QUALSIASI azione
                $out = $actions[$action]($in);
                return Hooks::filter('api.dopo', $out, $sezione, $action, $in);         // …e arricchire/trasformare la risposta (es. allegare i propri dati)
            });
            self::ok($out);
        } catch (ApiException $e) {
            self::fail($e->getMessage(), $e->getCode() ?: 400);
        } catch (Throwable $e) {
            error_log('[DRFacile] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
            self::fail(Config::get('app.debug') ? $e->getMessage() : 'Errore interno del server', 500);
        }
    }

    /** Unisce querystring, POST classico e body JSON */
    public static function input(): array
    {
        static $in = null;
        if ($in !== null) return $in;
        $in = $_GET + $_POST;
        $raw = file_get_contents('php://input');
        if ($raw && str_contains($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')) {
            $j = json_decode($raw, true);
            if (is_array($j)) $in = $j + $in;
        }
        return $in;
    }

    public static function ok(mixed $data): never
    {
        echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    public static function fail(string $msg, int $code = 400): never
    {
        http_response_code($code >= 400 && $code < 600 ? $code : 400);
        echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
        exit;
    }

    /** Verifica che i campi obbligatori siano presenti e non vuoti */
    public static function require(array $in, array $keys, array $labels = []): void
    {
        foreach ($keys as $k) {
            $v = $in[$k] ?? null;
            if ($v === null || $v === '' || $v === []) throw new ApiException('Campo obbligatorio: ' . ($labels[$k] ?? $k));
        }
    }

    public static function int(array $in, string $k, int $default = 0): int { return isset($in[$k]) && $in[$k] !== '' ? (int) $in[$k] : $default; }
    public static function str(array $in, string $k, string $default = ''): string { return isset($in[$k]) ? trim((string) $in[$k]) : $default; }
    public static function float(array $in, string $k, float $default = 0): float { return isset($in[$k]) && $in[$k] !== '' ? numero($in[$k]) : $default; }
}
