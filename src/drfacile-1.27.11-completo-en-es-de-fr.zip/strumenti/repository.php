<?php
/**
 * REPOSITORY: genera/aggiorna catalogo.json di una cartella di pacchetti (quella pubblicata via HTTP, o locale).
 *
 *   php strumenti/repository.php /percorso/repository                    → legge pacchetti/*.zip, scrive catalogo.json
 *   php strumenti/repository.php /percorso/repository approva consigli   → stato approvato (dopo la revisione)
 *   php strumenti/repository.php /percorso/repository revisione consigli → torna in revisione
 *   php strumenti/repository.php /percorso/repository respingi consigli  → respinto (sparisce dagli store)
 *   php strumenti/repository.php /percorso/repository voti consigli 4.6 12 → media e numero voti mostrati nel catalogo
 *
 * Per ogni ZIP legge manifest.json e calcola sha256 e dimensione; di un codice tiene SOLO la versione più alta.
 * Stato, novità, ordine e voti si conservano fra una generazione e l'altra; un pacchetto nuovo nasce "in_revisione"
 * (gli studi non lo vedono finché un revisore non lo approva: prima lo si prova con store.revisore = true in config.php).
 * Autori terzi: mandano lo ZIP, il revisore lo mette in pacchetti/, rigenera, prova, approva.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
require __DIR__ . '/../core/bootstrap.php';
if (!class_exists('ZipArchive')) exit("Serve l'estensione PHP zip\n");

$repo = rtrim((string) ($argv[1] ?? ''), '/');
if ($repo === '' || !is_dir($repo)) exit("Uso: php strumenti/repository.php <cartella repository> [approva|revisione|respingi|voti <codice> …]\n");
$cat = is_file("$repo/catalogo.json") ? (json_decode((string) file_get_contents("$repo/catalogo.json"), true) ?: []) : [];
$prec = [];
foreach ((array) ($cat['pacchetti'] ?? []) as $p) if (!empty($p['codice'])) $prec[$p['codice']] = $p;

$cmd = $argv[2] ?? null; $cod = $argv[3] ?? null;
if ($cmd !== null) {
    if (!$cod || !isset($prec[$cod])) exit("Pacchetto sconosciuto: " . ($cod ?? '—') . " (prima genera il catalogo)\n");
    $mappa = ['approva' => 'approvato', 'revisione' => 'in_revisione', 'respingi' => 'respinto'];
    if (isset($mappa[$cmd])) { $prec[$cod]['stato'] = $mappa[$cmd]; echo "$cod → {$mappa[$cmd]}\n"; }
    elseif ($cmd === 'voti') { $prec[$cod]['voti'] = ['media' => round((float) ($argv[4] ?? 0), 1), 'n' => (int) ($argv[5] ?? 0)]; echo "$cod → voti {$prec[$cod]['voti']['media']} ({$prec[$cod]['voti']['n']})\n"; }
    else exit("Comando sconosciuto: $cmd\n");
}

$migliori = [];
foreach (glob("$repo/pacchetti/*.zip") ?: [] as $f) {
    $zip = new ZipArchive();
    if ($zip->open($f) !== true) { echo "  SALTATO (zip illeggibile): " . basename($f) . "\n"; continue; }
    $m = json_decode((string) $zip->getFromName('manifest.json'), true); $zip->close();
    $n = is_array($m) ? Store::normalizza($m) : null;
    if (!$n) { echo "  SALTATO (manifest mancante o non valido, o text_domain diverso dal codice): " . basename($f) . "\n"; continue; }
    if (isset($migliori[$n['codice']]) && version_compare($migliori[$n['codice']]['versione'], $n['versione'], '>=')) continue;
    $n['file'] = basename($f); $n['sha256'] = hash_file('sha256', $f); $n['dimensione'] = filesize($f); $n['conflitti'] = array_values((array) ($m['conflitti'] ?? []));
    $migliori[$n['codice']] = $n;
}
$out = [];
foreach ($migliori as $c => $n) {
    $p = $prec[$c] ?? [];
    $out[] = [
        'codice' => $c, 'nome' => $n['nome'], 'sottotitolo' => $n['sottotitolo'], 'descrizione' => $n['descrizione'], 'categoria' => $n['categoria'],
        'prezzo_tipo' => $n['prezzo_tipo'], 'prezzo' => $n['prezzo'], 'fi' => $n['fi'], 'fa' => $n['fa'], 'tinta' => $n['tinta'], 'schermate' => $n['schermate'],
        'disponibile' => $n['disponibile'], 'versione' => $n['versione'], 'autore' => $n['autore'], 'autore_url' => $n['autore_url'],
        'richiede' => $n['richiede'], 'dipendenze' => $n['dipendenze'], 'conflitti' => $n['conflitti'], 'capabilities' => $n['capabilities'],
        'file' => $n['file'], 'sha256' => $n['sha256'], 'dimensione' => $n['dimensione'],
        // conservati fra le generazioni (decisi dal revisore, non dall'autore)
        'stato' => $p['stato'] ?? 'in_revisione', 'novita' => (int) ($p['novita'] ?? 1), 'ordine' => (int) ($p['ordine'] ?? $n['ordine']),
        'voti' => (array) ($p['voti'] ?? ['media' => 0, 'n' => 0]), 'pubblicato_il' => $p['pubblicato_il'] ?? date('Y-m-d'),
    ];
}
usort($out, fn($a, $b) => [$a['ordine'], $a['nome']] <=> [$b['ordine'], $b['nome']]);
file_put_contents("$repo/catalogo.json", json_encode(['generato' => date('c'), 'drfacile_min' => Installer::VERSIONE, 'pacchetti' => $out], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n");
echo "catalogo.json: " . count($out) . " pacchetti\n";
foreach ($out as $p) printf("  %-16s v%-6s %-13s %s\n", $p['codice'], $p['versione'], $p['stato'], $p['file']);
