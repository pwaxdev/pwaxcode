/* Modulo Statistiche: visite per mese, tipologie, incassi, prestazioni più richieste (dati reali dal database) */
DRF.register('statistiche', (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;

  function render(d) {
    const root = $('#statsRoot')[0]; root.classList.remove('go');
    const k = d.kpi, varTxt = (v, base) => v == null ? base : `${v >= 0 ? '+' : ''}${v}${DRF.__('% sull\'anno precedente')}`;
    $('#sKpis').html(`<div class="kpi">${I('stethoscope', 'fa-solid fa-stethoscope', 'violet')}<div><span>${DRF.__('Visite in 12 mesi')}</span><b class="num">${k.visite}</b><small class="${k.visite_var == null ? '' : k.visite_var >= 0 ? 'up' : 'down'}">${varTxt(k.visite_var, DRF.__('primo anno di attività'))}</small></div></div>
      <div class="kpi">${I('user-add', 'fa-solid fa-user-plus', 'rose')}<div><span>${DRF.__('Nuovi pazienti')}</span><b class="num">${k.nuovi_pazienti}</b><small>${(k.nuovi_pazienti / 12).toFixed(1).replace('.', ',')} ${DRF.__('al mese in media')}</small></div></div>
      <div class="kpi">${I('euro', 'fa-solid fa-euro-sign', 'mint')}<div><span>${DRF.__('Incasso in 12 mesi')}</span><b class="num">${U.eur(k.incasso)}</b><small class="${k.incasso_var == null ? '' : k.incasso_var >= 0 ? 'up' : 'down'}">${varTxt(k.incasso_var, DRF.__('primo anno di attività'))}</small></div></div>
      <div class="kpi">${I('time-fast', 'fa-regular fa-clock', 'sky')}<div><span>${DRF.__('Durata media visita')}</span><b class="num">${k.durata_media} min</b><small>${DRF.__('obiettivo 30 min')}</small></div></div>`);
    const max = Math.max(1, ...d.mesi.map(m => m.visite));
    $('#bars').html(d.mesi.map((m, i) => `<div class="bar ${i === 11 ? 'hi' : ''}"><i style="--h:${Math.round(m.visite / max * 100)}%;transition-delay:${i * 45}ms" data-v="${m.visite}"></i><span>${DRF.esc(m.label)}</span></div>`).join(''));
    $('#donutTot').text(k.visite);
    let acc = 0; const stops = d.tipi.map(t => { const s = `${t.colore} ${acc}% ${acc + t.perc}%`; acc += t.perc; return s; });
    $('#donut').css('background', d.tipi.length ? `conic-gradient(${stops.join(',')}${acc < 100 ? `,var(--soft-2) ${acc}% 100%` : ''})` : 'var(--soft-2)');
    $('#sLegend').html(d.tipi.map(t => `<div><i style="background:${t.colore}"></i>${DRF.esc(t.label)}<b>${t.perc}%</b></div>`).join('') || '<span class="muted small">' + DRF.__('Nessun dato.') + '</span>');
    const cols = ['var(--accent)', 'var(--rose)', 'var(--mint)', 'var(--amber)', 'var(--sky)'], top0 = d.top[0] ? d.top[0].n : 1;
    $('#prog').html(d.top.map((t, i) => `<div><span>${DRF.esc(t.label)}<b class="num">${t.n}</b></span><i style="--w:${Math.round(t.n / top0 * 100)}%;--c:${cols[i % cols.length]}"></i></div>`).join('') || '<span class="muted small">' + DRF.__('Nessuna fattura negli ultimi 12 mesi.') + '</span>');
    const W = 320, H = 100, vals = d.mesi.map(m => m.incasso), mn = Math.min(...vals), mx = Math.max(...vals, mn + 1);
    const pts = vals.map((v, i) => [10 + i / 11 * (W - 20), 88 - (v - mn) / (mx - mn) * 66]);
    const line = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    $('#sparkWrap').html(`<div class="row" style="justify-content:space-between;font-size:12px"><span class="muted">${DRF.esc(d.mesi[0].label)} → ${DRF.esc(d.mesi[11].label)}</span><b class="num">${U.eur(vals[11])} <span class="muted" style="font-weight:600">${DRF.__('questo mese')}</span></b></div>
      <svg class="spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="sg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" style="stop-color:var(--accent);stop-opacity:.35"/><stop offset="1" style="stop-color:var(--accent);stop-opacity:0"/></linearGradient></defs><path class="area" d="${line} L${pts[11][0].toFixed(1)} ${H} L${pts[0][0].toFixed(1)} ${H} Z" fill="url(#sg)"/><path class="line" d="${line}"/></svg>`);
    DRF.icons.apply(root);
    void root.offsetWidth; requestAnimationFrame(() => root.classList.add('go'));
  }

  return {
    title: DRF.__('Statistiche'), sub: DRF.__('Andamento degli ultimi 12 mesi'), action: null,
    init() {},
    show() { DRF.api.get('statistiche', 'riepilogo').then(render); }
  };
})(jQuery));
