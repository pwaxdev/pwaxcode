<?php
/**
 * PERMESSI per ruolo: cosa può fare ciascun ruolo dello studio. Il backend li applica in Api::run()
 * (ogni endpoint AJAX dichiara il permesso di ogni azione) e Auth::can('permesso') li interroga ovunque.
 *
 * Sintassi: 'agenda.*' copre agenda.leggi, agenda.modifica…; '*' copre tutto tranne i permessi
 * riservati all'AMMINISTRATORE dello studio (flag utenti.admin, indipendente dal ruolo):
 * chi è amministratore può tutto, compresi quelli in 'solo_admin'.
 *
 * Le estensioni possono ampliare la mappa con Hooks::add('auth.permessi', fn(array $mappa) => …):
 * per esempio un ruolo nuovo (vedi anche l'hook utenti.ruoli) o un permesso nuovo per un ruolo esistente.
 *
 * Catalogo dei permessi usati dal core:
 *   agenda.leggi/.modifica            pazienti.leggi/.modifica/.elimina     visita.leggi/.modifica
 *   ricette.leggi/.emetti             referti.leggi/.modifica/.invia         fatture.leggi/.emetti/.modifica/.incassa
 *   documenti.leggi/.modifica         comunicazioni.leggi/.invia             archivi.leggi/.modifica
 *   procedure.leggi/.esegui           statistiche.leggi                      contabilita.leggi (estensione Commercialista)
 *   impostazioni.leggi/.modifica/.backup                                     store.leggi
 *   attivita.leggi (registro delle attività)     scrivania.* (app della Scrivania)
 *   solo admin: utenti.gestisci, store.gestisci
 */
return [
    'solo_admin' => ['utenti.gestisci', 'store.gestisci'],

    'medico' => ['*'],

    'segreteria' => [
        'agenda.*', 'pazienti.leggi', 'pazienti.modifica',
        'fatture.leggi', 'fatture.emetti', 'fatture.incassa',
        'documenti.*', 'comunicazioni.*', 'archivi.leggi', 'procedure.leggi',
        'impostazioni.leggi', 'store.leggi', 'scadenzario.leggi', 'scadenzario.chiudi', 'assistente.usa',
    ],

    'commercialista' => [
        'fatture.leggi', 'contabilita.*', 'procedure.leggi', 'statistiche.leggi', 'scadenzario.leggi',
    ],
];
