<?php
/**
 * ESTENSIONE "Visita ginecologica" (codice: gineco) — v1.3
 * Il referto viene RICOSTRUITO con le sezioni specialistiche. Restano dal core:
 * i Parametri vitali (peso, altezza, PA… — la card è adottata nel percorso ginecologico)
 * e le prestazioni/diagnosi che alimentano fatturazione e archivi come sempre.
 */
Hooks::add('referto.sezioni', function (array $sezioni, array $v): array {
    $g = $v['dati']['gineco'] ?? null;
    if (!$g || !array_filter($g)) return $sezioni;   // visita non ginecologica: referto standard

    $riga = fn(array $coppie) => implode("\n", array_map(fn($x) => '• ' . $x, array_filter($coppie)));
    $si = fn(string $k) => ($g[$k] ?? '') === '1';
    $out = [];
    if (!empty($sezioni['Parametri vitali']) && $sezioni['Parametri vitali'] !== 'Non rilevati') {
        $out['Parametri vitali'] = $sezioni['Parametri vitali'];   // peso, altezza, PA… rilevati nel percorso
    }
    $fattori = array_filter([$si('gravidanza') ? 'gravidanza in corso' : null, $si('fumo') ? 'fumatrice' : null, $si('alcol') ? 'consumo di alcol' : null, $si('diabete') ? 'diabete' : null]);
    $out['Anamnesi ginecologica'] = $riga([
        !empty($g['motivo']) ? 'Motivo della visita: ' . $g['motivo'] : null,
        !empty($g['menarca']) ? 'Menarca: ' . $g['menarca'] . ' anni' : null,
        !empty($g['um']) ? 'Ultima mestruazione: ' . data_it($g['um']) : null,
        !empty($g['ciclo']) ? 'Ciclo: ' . $g['ciclo'] : null,
        ($gpa = array_filter(['G' => $g['g'] ?? '', 'P' => $g['p'] ?? '', 'A' => $g['a'] ?? ''], fn($x) => $x !== ''))
            ? 'Anamnesi ostetrica: ' . implode(' ', array_map(fn($k, $x) => "$k$x", array_keys($gpa), $gpa)) : null,
        !empty($g['contraccezione']) ? 'Contraccezione: ' . $g['contraccezione'] : null,
        $fattori ? 'Fattori di rischio: ' . implode(', ', $fattori) : null,
        !empty($g['familiarita']) ? 'Familiarità oncologica: ' . $g['familiarita'] : null,
    ]) ?: '—';
    $eo = $riga([
        !empty($g['esterni']) ? 'Genitali esterni: ' . $g['esterni'] : null,
        !empty($g['speculum']) ? 'Esame con speculum: ' . $g['speculum'] : null,
        !empty($g['collo']) ? 'Collo uterino: ' . $g['collo'] : null,
        !empty($g['annessi']) ? 'Utero e annessi: ' . $g['annessi'] : null,
        !empty($g['seno']) ? 'Esame del seno: ' . $g['seno'] : null,
    ]);
    if ($eo) $out['Esame ginecologico'] = $eo;
    $acc = $riga([
        (!empty($g['pap_data']) || !empty($g['pap_esito'])) ? 'Pap test' . (!empty($g['pap_data']) ? ' del ' . data_it($g['pap_data']) : '') . (!empty($g['pap_esito']) ? ': ' . $g['pap_esito'] : '') : null,
        !empty($g['tamponi']) ? 'Tamponi: ' . $g['tamponi'] : null,
        !empty($g['eco']) ? 'Ecografia transvaginale: ' . $g['eco'] : null,
    ]);
    if ($acc) $out['Accertamenti'] = $acc;
    $out['Conclusioni'] = !empty($g['conclusione']) ? $g['conclusione'] : ($sezioni['Diagnosi'] ?? '—');
    $ind = trim(($g['indicazioni'] ?? '') . (!empty($g['controllo']) ? "\nProssimo controllo: " . data_it($g['controllo']) : ''));
    if ($ind) $out['Indicazioni e follow-up'] = $ind;
    if (!empty($sezioni['Esami'])) $out['Esami'] = $sezioni['Esami'];
    return $out;
});
