<?php
/**
 * Dati iniziali: impostazioni dello studio e, in modalità demo, un archivio dimostrativo
 * coerente con la data odierna (agenda della settimana, 12 mesi di storico per le statistiche).
 */
final class Seed
{
    public static function impostazioni(): void
    {
        $def = [
            'profilo_titolo' => 'Dr.ssa', 'profilo_nome' => 'Elena Conti', 'profilo_sesso' => 'F', 'profilo_specializzazione' => 'Medicina generale',
            'profilo_email' => 'elena.conti@drfacile.it', 'profilo_telefono' => '02 1234567',
            'studio_nome' => 'Studio medico Conti', 'studio_indirizzo' => 'Via Roma 12, 20121 Milano', 'studio_piva' => 'IT01234567890', 'studio_ordine' => 'MI-12345',
            'pref_tema' => 'light', 'pref_sms' => '1', 'pref_firma_auto' => '0', 'pref_durata' => '30', 'pref_suoni' => '1', 'assistente_attivo' => '1',
            'fattura_spese_attive' => '0', 'fattura_spese_importo' => '', 'fattura_spese_desc' => 'Spese di studio',
            'fattura_contributi_perc' => '', 'fattura_contributi_desc' => '',
            'fattura_formato' => '{aaaa}/{nnn}', 'fattura_prossimo' => '', 'pref_prezzi_visita' => '1',
            'backup_ultimo' => '',
        ];
        foreach ($def as $k => $v) {
            if (Database::value('SELECT COUNT(*) FROM impostazioni WHERE chiave = ?', [$k]) == 0) Database::insert('impostazioni', ['chiave' => $k, 'valore' => $v]);
        }
    }

    /** Comuni: campione iniziale (capoluoghi). In produzione si importa la tabella completa di Igea / ISTAT. */
    public static function comuni(): void
    {
        $t = Database::comune('comuni');
        if (Database::value("SELECT COUNT(*) FROM $t") > 0) return;
        $lista = [
            ['A271', 'Ancona', 'AN', '60121', 'Marche'], ['A662', 'Bari', 'BA', '70121', 'Puglia'], ['A794', 'Bergamo', 'BG', '24121', 'Lombardia'], ['A944', 'Bologna', 'BO', '40121', 'Emilia-Romagna'],
            ['B157', 'Brescia', 'BS', '25121', 'Lombardia'], ['B354', 'Cagliari', 'CA', '09121', 'Sardegna'], ['C351', 'Catania', 'CT', '95121', 'Sicilia'], ['C933', 'Como', 'CO', '22100', 'Lombardia'],
            ['D612', 'Firenze', 'FI', '50121', 'Toscana'], ['D969', 'Genova', 'GE', '16121', 'Liguria'], ['E506', 'Lecce', 'LE', '73100', 'Puglia'], ['E625', 'Livorno', 'LI', '57121', 'Toscana'],
            ['F205', 'Milano', 'MI', '20121', 'Lombardia'], ['F257', 'Modena', 'MO', '41121', 'Emilia-Romagna'], ['F704', 'Monza', 'MB', '20900', 'Lombardia'], ['F839', 'Napoli', 'NA', '80121', 'Campania'],
            ['G224', 'Padova', 'PD', '35121', 'Veneto'], ['G273', 'Palermo', 'PA', '90121', 'Sicilia'], ['G337', 'Parma', 'PR', '43121', 'Emilia-Romagna'], ['G478', 'Perugia', 'PG', '06121', 'Umbria'],
            ['G702', 'Pisa', 'PI', '56121', 'Toscana'], ['H223', 'Reggio Emilia', 'RE', '42121', 'Emilia-Romagna'], ['H501', 'Roma', 'RM', '00118', 'Lazio'], ['I452', 'Salerno', 'SA', '84121', 'Campania'],
            ['L219', 'Torino', 'TO', '10121', 'Piemonte'], ['L378', 'Trento', 'TN', '38121', 'Trentino-Alto Adige'], ['L424', 'Trieste', 'TS', '34121', 'Friuli-Venezia Giulia'], ['L736', 'Venezia', 'VE', '30121', 'Veneto'],
            ['L781', 'Verona', 'VR', '37121', 'Veneto'], ['L840', 'Vicenza', 'VI', '36100', 'Veneto'], ['L500', 'Udine', 'UD', '33100', 'Friuli-Venezia Giulia'], ['A952', 'Bolzano', 'BZ', '39100', 'Trentino-Alto Adige'],
            ['E463', 'Latina', 'LT', '04100', 'Lazio'], ['F158', 'Messina', 'ME', '98121', 'Sicilia'], ['G337', 'Parma', 'PR', '43121', 'Emilia-Romagna'], ['H703', 'Salò', 'BS', '25087', 'Lombardia'],
            ['D086', 'Cremona', 'CR', '26100', 'Lombardia'], ['F952', 'Novara', 'NO', '28100', 'Piemonte'], ['G388', 'Pavia', 'PV', '27100', 'Lombardia'], ['L682', 'Varese', 'VA', '21100', 'Lombardia'],
        ];
        $visti = [];
        foreach ($lista as $c) { if (isset($visti[$c[0]])) continue; $visti[$c[0]] = 1; Database::insert($t, ['cod_catastale' => $c[0], 'nome' => $c[1], 'provincia' => $c[2], 'cap' => $c[3], 'regione' => $c[4]]); }
    }

    /** Archivi di base (idempotente: inserisce solo se la tabella è vuota) */
    public static function archivi(): void
    {
        // (i tipi di appuntamento sono confluiti nelle prestazioni: la tabella resta solo per i dati storici)
        if (Database::value('SELECT COUNT(*) FROM diagnosi') == 0) {
            foreach ([['401.9', 'Ipertensione arteriosa essenziale'], ['724.2', 'Lombalgia acuta'], ['462', 'Faringite acuta'], ['477.9', 'Rinite allergica'], ['250.00', 'Diabete mellito tipo 2'], ['723.1', 'Cervicalgia'], ['535.50', 'Gastrite'], ['487.1', 'Sindrome influenzale'], ['719.46', 'Gonalgia'], ['845.00', 'Distorsione della caviglia']] as $d)
                Database::insert('diagnosi', ['codice' => $d[0], 'descrizione' => $d[1]]);
        }
        if (Database::value('SELECT COUNT(*) FROM esenzioni') == 0) {
            foreach ([['E01', 'Età < 6 o > 65 anni con reddito familiare < 36.151,98 €'], ['E02', 'Disoccupati e familiari a carico'], ['E03', 'Titolari di assegno sociale e familiari a carico'], ['E04', 'Titolari di pensione al minimo con più di 60 anni'], ['013', 'Diabete mellito'], ['031', 'Ipertensione arteriosa'], ['048', 'Patologia neoplastica'], ['C01', 'Invalidità civile > 2/3']] as $e)
                Database::insert('esenzioni', ['codice' => $e[0], 'descrizione' => $e[1]]);
        }
        if (Database::value('SELECT COUNT(*) FROM metodi_pagamento') == 0) {
            foreach ([['Contanti', 0, 'MP01', 1], ['Carta', 0, 'MP08', 0], ['Bonifico', 0, 'MP05', 0], ['Assegno', 0, 'MP02', 0], ['Da incassare', 30, '', 0]] as $m)
                Database::insert('metodi_pagamento', ['nome' => $m[0], 'giorni' => $m[1], 'sdi' => $m[2] ?: null, 'non_esporta' => 0, 'predefinito' => $m[3], 'attivo' => 1]);
        }
        // aggiornamento da versioni precedenti: "Da incassare" sostituisce l'opzione fissa a 30 giorni, un metodo diventa predefinito
        if (Database::value("SELECT COUNT(*) FROM metodi_pagamento WHERE giorni > 0") == 0 && Database::value("SELECT COUNT(*) FROM metodi_pagamento WHERE nome = 'Da incassare'") == 0)
            Database::insert('metodi_pagamento', ['nome' => __('Da incassare'), 'giorni' => 30, 'non_esporta' => 0, 'predefinito' => 0, 'attivo' => 1]);
        Database::run('UPDATE metodi_pagamento SET giorni = 0 WHERE giorni IS NULL');
        Database::run('UPDATE metodi_pagamento SET non_esporta = 0 WHERE non_esporta IS NULL');
        Database::run('UPDATE metodi_pagamento SET predefinito = 0 WHERE predefinito IS NULL');
        if (Database::value('SELECT COUNT(*) FROM metodi_pagamento WHERE predefinito = 1 AND attivo = 1') == 0) {
            // niente subquery sulla stessa tabella: MySQL non lo permette (errore 1093)
            $predefId = Database::value('SELECT id FROM metodi_pagamento WHERE attivo = 1 AND giorni = 0 ORDER BY id LIMIT 1')
                ?: Database::value('SELECT id FROM metodi_pagamento WHERE attivo = 1 ORDER BY id LIMIT 1');
            if ($predefId) Database::run('UPDATE metodi_pagamento SET predefinito = 1 WHERE id = ?', [$predefId]);
        }
        if (Database::value('SELECT COUNT(*) FROM esami') == 0) {
            foreach ([['Emocromo completo', 'Laboratorio'], ['Glicemia', 'Laboratorio'], ['Emoglobina glicata', 'Laboratorio'], ['Profilo lipidico', 'Laboratorio'], ['Creatinina', 'Laboratorio'], ['Transaminasi', 'Laboratorio'], ['TSH', 'Laboratorio'], ['Esame urine', 'Laboratorio'],
                      ['ECG', 'Strumentale'], ['Ecografia addome', 'Strumentale'], ['Ecografia tiroide', 'Strumentale'], ['RX torace', 'Radiologia'], ['RM ginocchio', 'Radiologia'], ['Spirometria', 'Strumentale'], ['Holter pressorio', 'Strumentale']] as $e)
                Database::insert('esami', ['nome' => $e[0], 'categoria' => $e[1]]);
        }
        if (Database::tableExists('consensi') && Database::value('SELECT COUNT(*) FROM consensi') == 0 && Database::value('SELECT COUNT(*) FROM pazienti') > 0) {
            foreach (Database::all('SELECT id FROM pazienti ORDER BY id LIMIT 4') as $i => $p)
                Database::insert('consensi', ['paziente_id' => $p['id'], 'tipo' => $i % 2 ? 'Consenso informato' : 'Privacy', 'data' => date('Y-m-d', strtotime('-' . (30 + $i * 17) . ' days')), 'scadenza' => $i % 2 ? null : date('Y-m-d', strtotime('+' . (335 - $i * 17) . ' days')), 'firmato' => 1, 'creato_il' => date('Y-m-d H:i:s')]);
        }
        if (Database::tableExists('iva') && Database::value('SELECT COUNT(*) FROM iva') == 0) {
            foreach ([
                ['Esente art. 10', 0, 'Operazione esente IVA art. 10 n. 18 DPR 633/72', 1],
                ['IVA 22%', 22, 'IVA 22%', 0],
                ['IVA 10%', 10, 'IVA 10%', 0],
                ['IVA 4%', 4, 'IVA 4%', 0],
            ] as $i) Database::insert('iva', ['nome' => $i[0], 'aliquota' => $i[1], 'nota' => $i[2], 'predefinita' => $i[3], 'attiva' => 1]);
        }
        if (Database::value('SELECT COUNT(*) FROM prestazioni') == 0) {
            $esente = (int) Database::value('SELECT id FROM iva WHERE aliquota = 0 ORDER BY id LIMIT 1');
            $iva22 = (int) Database::value('SELECT id FROM iva WHERE aliquota = 22 ORDER BY id LIMIT 1');
            foreach ([['Visita specialistica', 120, 30, $esente, 1, '#6B6FE6'], ['Visita di controllo', 80, 30, $esente, 1, '#4FC3A1'], ['Ecografia', 90, 45, $esente, 1, '#E79A9D'], ['Pap test', 60, 20, $esente, 1, '#9B7EDE'], ['Certificato', 50, 15, $esente, 0, '#F0B64A'], ['Medicazione', 40, 15, $esente, 0, '#5AA9E6'], ['Medicina estetica · filler', 250, 45, $iva22, 0, '#E6A45A']] as $p)
                Database::insert('prestazioni', ['nome' => $p[0], 'prezzo' => $p[1], 'durata' => $p[2], 'iva_id' => $p[3] ?: null, 'prenotabile' => $p[4], 'colore' => $p[5], 'attiva' => 1]);
            Database::update('prestazioni', ['previsita' => 1, 'previsita_titolo' => 'Preparazione all\'ecografia', 'previsita_quando' => '24h',
                'previsita_testo' => '<p>Gentile {paziente},</p><p>le ricordiamo l\'appuntamento per <b>{prestazione}</b> del <b>{data}</b> alle <b>{ora}</b>.</p><h3>Come prepararsi</h3><ul><li>Digiuno da almeno 6 ore</li><li>Bere 1 litro d\'acqua nell\'ora precedente, senza urinare</li><li>Portare gli esami precedenti</li></ul><p>A presto,<br>{medico} · {studio}</p>'], 'nome = :n', ['n' => 'Ecografia']);
        }
        // fusione tipi di appuntamento → prestazioni (aggiornamento da versioni precedenti, idempotente):
        // ogni tipo diventa/ritrova una prestazione e gli appuntamenti vengono ricodificati sul suo id
        if (Database::tableExists('tipi_appuntamento')) {
            $daMigrare = array_values(array_filter(array_column(Database::all('SELECT DISTINCT tipo FROM appuntamenti'), 'tipo'), fn($t) => $t !== null && $t !== '' && !ctype_digit((string) $t)));
            if ($daMigrare) {
                $mappaNomi = ['visita' => 'Visita specialistica', 'controllo' => 'Visita di controllo', 'eco' => 'Ecografia', 'certificato' => 'Certificato'];
                foreach ($daMigrare as $codice) {
                    $t = Database::one('SELECT * FROM tipi_appuntamento WHERE codice = ?', [$codice]) ?: ['nome' => ucfirst($codice), 'colore' => null, 'durata' => 30];
                    $pid = Database::value('SELECT id FROM prestazioni WHERE nome = ?', [$mappaNomi[$codice] ?? ''])
                        ?: Database::value('SELECT id FROM prestazioni WHERE nome = ?', [$t['nome']]);
                    if (!$pid) {
                        $simili = Database::all('SELECT id FROM prestazioni WHERE LOWER(nome) LIKE ?', ['%' . mb_strtolower($t['nome']) . '%']);
                        $pid = count($simili) === 1 ? $simili[0]['id'] : null;
                    }
                    if (!$pid) $pid = Database::insert('prestazioni', ['nome' => $t['nome'], 'prezzo' => 0, 'durata' => (int) ($t['durata'] ?: 30), 'colore' => $t['colore'] ?: null, 'attiva' => 1]);
                    if ($t['colore'] && !Database::value('SELECT colore FROM prestazioni WHERE id = ?', [$pid])) Database::update('prestazioni', ['colore' => $t['colore']], 'id = :id', ['id' => (int) $pid]);
                    Database::run('UPDATE appuntamenti SET tipo = ? WHERE tipo = ?', [(string) $pid, $codice]);
                }
            }
        }
        // ogni prestazione ha un colore (tavolozza a rotazione per quelle che ne sono prive)
        $tavolozza = ['#6B6FE6', '#4FC3A1', '#E79A9D', '#F0B64A', '#5AA9E6', '#9B7EDE', '#E6A45A', '#63C7C9'];
        foreach (Database::all("SELECT id FROM prestazioni WHERE colore IS NULL OR colore = '' ORDER BY id") as $i => $p)
            Database::update('prestazioni', ['colore' => $tavolozza[$i % count($tavolozza)]], 'id = :id', ['id' => (int) $p['id']]);
        Database::run("UPDATE prestazioni SET previsita = 0 WHERE previsita IS NULL");

        // aggiornamento da versioni precedenti: le prestazioni senza aliquota diventano esenti (l'aliquota predefinita)
        if (Database::tableExists('iva') && ($predef = Database::value('SELECT id FROM iva WHERE attiva = 1 AND predefinita = 1 ORDER BY id LIMIT 1'))) {
            Database::run('UPDATE prestazioni SET iva_id = ? WHERE iva_id IS NULL', [$predef]);
            Database::run('UPDATE prestazioni SET prenotabile = 0 WHERE prenotabile IS NULL');
        }
        self::messaggi();
        if (Database::tableExists('documenti') && Database::value('SELECT COUNT(*) FROM documenti') == 0) {
            $doc = [
                ['PRIV01', 'Informativa privacy e consenso al trattamento', 'consensi', 365,
                 '<p>Il sottoscritto <b>{paziente}</b> (CF {cf}), nato il {nascita}, residente in {indirizzo},</p><p>dichiara di aver ricevuto l\'informativa ai sensi del Reg. UE 2016/679 (GDPR) da parte di <b>{medico}</b> · {studio}, e</p><h3>Acconsente</h3><ul><li>al trattamento dei dati personali e sanitari per finalità di diagnosi e cura;</li><li>alla conservazione della documentazione clinica nei termini di legge;</li><li>alla trasmissione dei dati al Sistema Tessera Sanitaria, salvo opposizione.</li></ul><p>Il consenso è valido fino al <b>{scadenza}</b> e può essere revocato in ogni momento.</p><p>{studio_indirizzo}, {data}</p>'],
                ['CONS01', 'Consenso informato alla prestazione', 'consensi', 0,
                 '<p>Il sottoscritto <b>{paziente}</b> dichiara di essere stato informato in modo chiaro e comprensibile da <b>{medico}</b> su natura, finalità, benefici, alternative e possibili complicanze della prestazione proposta, e di aver avuto la possibilità di porre domande.</p><h3>Esprime pertanto</h3><p>il proprio <b>consenso informato</b> all\'esecuzione della prestazione.</p><p>{studio}, {data}</p>'],
                ['MAIL01', 'Promemoria appuntamento (email)', 'email', 0,
                 '<p>Gentile {paziente},</p><p>le ricordiamo l\'appuntamento presso <b>{studio}</b> ({studio_indirizzo}).</p><p>In caso di impedimento la preghiamo di avvisarci con anticipo.</p><p>Cordiali saluti,<br>{medico}</p>'],
            ];
            foreach ($doc as $d2) Database::insert('documenti', ['codice' => $d2[0], 'descrizione' => $d2[1], 'categoria' => $d2[2], 'durata' => $d2[3], 'contenuto' => $d2[4], 'abilitato' => 1, 'creato_il' => date('Y-m-d H:i:s')]);
        }
        if (Database::value('SELECT COUNT(*) FROM farmaci') == 0) {
            foreach ([
                ['Tachipirina 1000 mg', 'Paracetamolo', '16 compresse', '1 cp al bisogno, max 3/die', 1],
                ['Brufen 600 mg', 'Ibuprofene', '30 compresse', '1 cp x 2/die dopo i pasti', 1],
                ['Triatec 5 mg', 'Ramipril', '28 compresse', '1 cp/die al mattino', 1],
                ['Glucophage 500 mg', 'Metformina', '30 compresse', '1 cp x 2/die ai pasti', 1],
                ['Augmentin 875/125 mg', 'Amoxicillina + ac. clavulanico', '12 compresse', '1 cp x 2/die per 6 gg', 1],
                ['Zirtec 10 mg', 'Cetirizina', '7 compresse', '1 cp/die alla sera', 0],
                ['Pantorc 20 mg', 'Pantoprazolo', '14 compresse', '1 cp/die a digiuno', 0],
                ['Ventolin 100 mcg', 'Salbutamolo', 'spray 200 dosi', '2 puff al bisogno', 0],
            ] as $f) Database::insert('farmaci', ['nome' => $f[0], 'principio' => $f[1], 'confezione' => $f[2], 'posologia' => $f[3], 'preferito' => $f[4]]);
        }
    }

    /**
     * Carica il dataset dimostrativo una sola volta.
     * Serve anche a recuperare installazioni rimaste a metà: in quel caso aggiorna()
     * ricrea lo schema, ma non deve essere necessario cancellare il database per riavere il demo.
     */
    public static function demoSeNecessario(): void
    {
        if (!Config::get('app.demo') || !Database::tableExists('pazienti') || !Database::tableExists('impostazioni')) return;
        if (Impostazione::get('demo_seed_eseguito') === '1') return;

        // Installazioni demo precedenti alla 1.27.8 possono avere già dati ma non il marcatore:
        // in quel caso li consideriamo già inizializzati e NON inseriamo duplicati.
        if ((int) Database::value('SELECT COUNT(*) FROM pazienti') > 0) {
            Impostazione::set('demo_seed_eseguito', '1');
            return;
        }

        self::demo();
    }

    public static function demo(): void
    {
        $d = fn(int $off) => date('Y-m-d', strtotime("$off days"));
        $now = date('Y-m-d H:i:s');

        $paz = [
            ['Giulia', 'Ferrari', '1988-04-12', 'F', 'FRRGLI88D52F205X', '333 120 4455', 'giulia.ferrari@mail.it', ['Penicillina'], -120],
            ['Marco', 'Bianchi', '1975-09-03', 'M', 'BNCMRC75P03F205Y', '347 882 1190', 'm.bianchi@mail.it', [], -2],
            ['Anna', 'Russo', '1992-01-21', 'F', 'RSSNNA92A61H501Z', '320 455 7788', 'anna.russo@mail.it', ['Lattice'], -15],
            ['Luca', 'Romano', '1969-06-30', 'M', 'RMNLCU69H30F205K', '339 210 6677', 'luca.romano@mail.it', [], -60],
            ['Sara', 'Colombo', '2001-11-08', 'F', 'CLMSRA01S48F205W', '328 991 3344', 'sara.colombo@mail.it', ['Nichel', 'Acari'], -7],
            ['Paolo', 'Greco', '1958-02-14', 'M', 'GRCPLA58B14F205Q', '335 600 2211', 'p.greco@mail.it', [], -30],
            ['Elisa', 'Marino', '1984-07-19', 'F', 'MRNLSE84L59F205J', '340 118 9900', 'elisa.marino@mail.it', [], -200],
            ['Davide', 'Conti', '1996-03-05', 'M', 'CNTDVD96C05F205P', '331 774 5566', 'd.conti@mail.it', ['Aspirina'], -90],
        ];
        $ids = [];
        foreach ($paz as $p) {
            $cod = substr($p[4], 11, 4); $comune = Comune::daCodice($cod);
            $ids[] = Database::insert('pazienti', ['nome' => $p[0], 'cognome' => $p[1], 'nascita' => $p[2], 'sesso' => $p[3], 'cf' => CodiceFiscale::calcola($p[1], $p[0], $p[2], $p[3], $cod), 'cellulare' => $p[5], 'email' => $p[6], 'allergie' => json_txt($p[7]), 'ultima_visita' => $d($p[8]), 'citta' => 'Milano', 'provincia' => 'MI', 'cap' => '20121', 'indirizzo' => 'Via ' . $p[1] . ' ' . (10 + $p[8] % 7), 'comune_nascita' => $comune['nome'] ?? 'Milano', 'cod_nascita' => $cod, 'provenienza' => 'Passaparola', 'creato_il' => $now]);
        }
        $storico = [
            [1, -120, 'Visita', 'Cervicalgia, terapia con FANS'], [1, -300, 'Controllo', 'Esami ematochimici nella norma'],
            [2, -2, 'Controllo', 'Buona risposta alla terapia antipertensiva'], [2, -40, 'Visita', 'Ipertensione lieve, avviato ramipril'],
            [3, -15, 'Ecografia', 'Ecografia addome completo, nella norma'], [4, -60, 'Visita', 'Gonalgia destra, prescritta RM'],
            [5, -7, 'Visita', 'Rinite allergica stagionale'], [6, -30, 'Controllo', 'Diabete tipo 2, HbA1c 6,8%'], [6, -120, 'Controllo', 'Aggiustamento terapia'],
            [7, -200, 'Visita', 'Certificato di idoneità sportiva'], [8, -90, 'Visita', 'Distorsione caviglia sinistra'],
        ];
        foreach ($storico as $s) Database::insert('storico', ['paziente_id' => $ids[$s[0] - 1], 'data' => $d($s[1]), 'tipo' => $s[2], 'descrizione' => $s[3], 'creato_il' => $now]);

        // Agenda della settimana (come nel prototipo) · i tipi sono gli id delle prestazioni
        $pidDi = fn(string $nome) => (string) Database::value('SELECT id FROM prestazioni WHERE nome = ?', [$nome]);
        $pid = ['visita' => $pidDi('Visita specialistica'), 'controllo' => $pidDi('Visita di controllo'), 'eco' => $pidDi('Ecografia')];
        $app = [
            [0, '08:30', 30, 1, 'visita', 'Prima visita, dolore lombare'], [0, '09:15', 45, 2, 'controllo', 'Pressione e terapia'],
            [0, '10:30', 30, 3, 'eco', 'Ecografia tiroide'], [0, '11:30', 30, 4, 'visita', 'Esiti RM ginocchio'],
            [0, '14:00', 60, 5, 'eco', 'Ecografia addome'], [0, '15:30', 30, 6, 'controllo', 'Controllo glicemie'], [0, '16:30', 30, 7, 'visita', 'Rinnovo certificato'],
            [1, '09:00', 30, 8, 'controllo', 'Controllo caviglia'], [1, '11:00', 45, 3, 'visita', ''], [2, '10:00', 30, 6, 'controllo', ''],
            [3, '15:00', 60, 1, 'eco', ''], [-1, '09:30', 30, 2, 'controllo', ''], [-2, '16:00', 30, 4, 'visita', ''],
        ];
        foreach ($app as $a) Database::insert('appuntamenti', ['paziente_id' => $ids[$a[3] - 1], 'data' => $d($a[0]), 'ora' => $a[1], 'durata' => $a[2], 'tipo' => $pid[$a[4]], 'note' => $a[5], 'stato' => $a[0] < 0 ? 'completato' : 'prenotato', 'creato_il' => $now]);

        // Referti + visite chiuse
        $ref = [
            [2, 'Referto di controllo', -2, 'firmato', ['Parametri vitali' => 'PA 135/85 mmHg · FC 72 bpm · Peso 84 kg', 'Anamnesi ed esame obiettivo' => 'Paziente in buone condizioni generali. Riferisce buona tolleranza alla terapia antipertensiva, nessun effetto collaterale. Obiettività cardio-toracica nella norma.', 'Diagnosi' => 'Ipertensione arteriosa essenziale, grado 1, in buon compenso', 'Terapia e indicazioni' => "• Prosegue ramipril 5 mg 1 cp/die\n• Automisurazione pressoria settimanale\n• Controllo tra 3 mesi con esami ematochimici"]],
            [3, 'Referto ecografico', -15, 'inviato', ['Esame' => 'Ecografia addome completo', 'Descrizione' => 'Fegato di dimensioni regolari, ecostruttura omogenea. Colecisti alitiasica. Reni in sede, di normali dimensioni, senza dilatazioni delle vie escretrici. Milza nei limiti.', 'Conclusioni' => 'Quadro ecografico addominale nei limiti della norma.']],
            [5, 'Referto di visita', -7, 'bozza', ['Parametri vitali' => 'PA 115/75 mmHg · FC 68 bpm', 'Anamnesi ed esame obiettivo' => 'Riferisce rinorrea, starnuti e prurito oculare da circa due settimane. Mucosa nasale pallida ed edematosa.', 'Diagnosi' => 'Rinite allergica stagionale', 'Terapia e indicazioni' => "• Antistaminico 1 cp/die per 15 gg\n• Lavaggi nasali con soluzione salina\n• Valutare prick test"]],
            [6, 'Referto di controllo', -30, 'firmato', ['Parametri vitali' => 'Peso 91 kg · Glicemia 128 mg/dl · PA 140/85 mmHg', 'Anamnesi ed esame obiettivo' => 'Buon compenso glicemico, HbA1c 6,8%. Riferisce attività fisica regolare.', 'Diagnosi' => 'Diabete mellito tipo 2 in buon compenso', 'Terapia e indicazioni' => "• Prosegue metformina 500 mg x 2/die\n• Controllo HbA1c tra 3 mesi\n• Visita oculistica annuale"]],
        ];
        $prestVisita = [2 => 'Visita specialistica', 3 => 'Ecografia', 5 => 'Visita specialistica', 6 => 'Visita di controllo'];
        foreach ($ref as $r) {
            $pv = Database::one('SELECT id, nome FROM prestazioni WHERE nome = ?', [$prestVisita[$r[0]] ?? '']);
            $vid = Database::insert('visite', ['paziente_id' => $ids[$r[0] - 1], 'data' => $d($r[2]), 'ora' => '10:00', 'motivo' => $r[1], 'anamnesi' => $r[4]['Anamnesi ed esame obiettivo'] ?? ($r[4]['Descrizione'] ?? ''), 'diagnosi' => json_txt([$r[4]['Diagnosi'] ?? ($r[4]['Conclusioni'] ?? '')]), 'terapia' => json_txt([]), 'prestazioni' => json_txt($pv ? [['id' => (int) $pv['id'], 'nome' => $pv['nome']]] : []), 'stato' => 'chiusa', 'creato_il' => $now]);
            $rid = Database::insert('referti', ['paziente_id' => $ids[$r[0] - 1], 'visita_id' => $vid, 'tipo' => $r[1], 'data' => $d($r[2]), 'stato' => $r[3], 'sezioni' => json_txt($r[4]), 'firmato_il' => $r[3] !== 'bozza' ? $d($r[2]) . ' 10:30:00' : null, 'inviato_il' => $r[3] === 'inviato' ? $d($r[2]) . ' 11:00:00' : null, 'creato_il' => $now]);
            Database::update('visite', ['referto_id' => $rid], 'id = :id', ['id' => $vid]);
        }

        foreach ([[6, -30, 'ssn', 'Glucophage 500 mg', 'Metformina', 2], [2, -2, 'bianca', 'Triatec 5 mg', 'Ramipril', 2], [5, -7, 'bianca', 'Zirtec 10 mg', 'Cetirizina', 1]] as $r) {
            Database::insert('ricette', ['paziente_id' => $ids[$r[0] - 1], 'data' => $d($r[1]), 'tipo' => $r[2], 'righe' => json_txt([['farmaco' => $r[3], 'principio' => $r[4], 'quantita' => $r[5], 'posologia' => '']]), 'nre' => Ricetta::generaNre(), 'stato' => 'inviata', 'creato_il' => $now]);
        }

        // Fatture recenti (come nel prototipo)
        $fat = [[-1, 2, 'Visita di controllo', 80, 'pagata', 'Carta'], [-3, 5, 'Visita specialistica', 120, 'attesa', ''], [-7, 3, 'Ecografia', 90, 'pagata', 'Contanti'], [-12, 1, 'Visita specialistica', 120, 'pagata', 'Bonifico'], [-21, 4, 'Visita specialistica', 120, 'scaduta', ''], [-25, 6, 'Visita di controllo', 80, 'pagata', 'Carta'], [-40, 7, 'Certificato', 50, 'pagata', 'Contanti']];

        // Storico di 12 mesi (appuntamenti completati + fatture pagate) per le statistiche, generato in modo deterministico
        mt_srand(2026);
        $tipi = ['visita', 'visita', 'visita', 'controllo', 'controllo', 'eco', 'visita'];
        $prest = ['visita' => ['Visita specialistica', 120], 'controllo' => ['Visita di controllo', 80], 'eco' => ['Ecografia', 90]];
        $fatStorico = [];
        for ($off = -365; $off < -6; $off++) {
            $ts = strtotime("$off days");
            $w = (int) date('N', $ts);
            if ($w >= 6) continue;
            $n = mt_rand(0, 2) + (mt_rand(0, 9) < 6 ? 1 : 0);
            for ($i = 0; $i < $n; $i++) {
                $t = $tipi[mt_rand(0, count($tipi) - 1)];
                $pz = $ids[mt_rand(0, count($ids) - 1)];
                Database::insert('appuntamenti', ['paziente_id' => $pz, 'data' => date('Y-m-d', $ts), 'ora' => sprintf('%02d:%02d', mt_rand(8, 17), mt_rand(0, 1) * 30), 'durata' => $t === 'eco' ? 45 : 30, 'tipo' => $pid[$t], 'note' => '', 'stato' => 'completato', 'creato_il' => $now]);
                if (mt_rand(0, 9) < 9) $fatStorico[] = [date('Y-m-d', $ts), $pz, $prest[$t][0], $prest[$t][1]];
            }
        }
        $prog = [];
        foreach ($fatStorico as $f) {
            $anno = (int) substr($f[0], 0, 4);
            $prog[$anno] = ($prog[$anno] ?? 0) + 1;
            self::fattura($f[0], $anno, $prog[$anno], $f[1], $f[2], $f[3], 'pagata', mt_rand(0, 1) ? 'Carta' : 'Contanti', $now);
        }
        foreach (array_reverse($fat) as $f) {
            $data = $d($f[0]); $anno = (int) substr($data, 0, 4);
            $prog[$anno] = ($prog[$anno] ?? 0) + 1;
            self::fattura($data, $anno, $prog[$anno], $ids[$f[1] - 1], $f[2], $f[3], $f[4], $f[5], $now);
        }
        // abbonamento dimostrativo: piano mensile, prossimo rinnovo fra 25 giorni (sullo studio, nel comune)
        Impostazione::set('abbonamento_scadenza', $d(25));
        Impostazione::set('abbonamento_periodo', 'mensile');
        try { Database::run('UPDATE ' . Database::comune('studi') . ' SET abbonamento_scadenza = ? WHERE 1=1', [$d(25)]); } catch (Throwable $e) {}

        // scadenzario dimostrativo: un pagamento in arrivo, un consenso in scadenza, un controllo programmato
        $fatAttesa = Database::one("SELECT id, numero, totale, paziente_id FROM fatture WHERE stato = 'attesa' ORDER BY id DESC LIMIT 1");
        if ($fatAttesa) Scadenzario::aggiungi('pagamento', $d(27), __('Pagamento in scadenza: fattura ') . $fatAttesa['numero'], nome_completo(Paziente::find((int) $fatAttesa['paziente_id']) ?? []) . ' · ' . euro($fatAttesa['totale']), ['modulo' => 'fatture', 'opts' => ['select' => (int) $fatAttesa['id']]], 'fatture', (int) $fatAttesa['id']);
        Scadenzario::aggiungi('consenso', $d(12), __('Consenso in scadenza: Privacy'), 'Giulia Ferrari · firmato un anno fa', ['modulo' => 'pazienti', 'opts' => ['select' => $ids[0]]], 'consensi', 1);
        Scadenzario::aggiungi('controllo', $d(21), __('Visita di controllo: Marco Bianchi'), 'Programmata alla chiusura della visita', ['modulo' => 'agenda', 'opts' => []], 'visite', 1);

        // impostazioni di fatturazione dimostrative: spese di studio e contributo cassa
        Impostazione::set('fattura_spese_attive', '1'); Impostazione::set('fattura_spese_importo', '15'); Impostazione::set('fattura_spese_desc', 'Spese di studio');
        Impostazione::set('fattura_contributi_perc', '4'); Impostazione::set('fattura_contributi_desc', 'Contributo integrativo Cassa Previdenza 4%');
        self::archivi();   // voci che dipendono dai pazienti (es. consensi)
        foreach ([
            ['info', 'Ti diamo il benvenuto in DRFacile', 'Le notifiche di sistema compaiono qui: referti da firmare, fatture scadute, backup, ricette inviate.', null, '-3 days'],
            ['warn', 'Referto in bozza da firmare', 'Sara Colombo · referto di visita', ['modulo' => 'referti'], '-7 days'],
            ['error', 'Fattura 2026/040 scaduta', 'Luca Romano · € 122,00 non incassati', ['modulo' => 'fatture', 'opts' => ['select' => 0]], '-1 day'],
            ['success', 'Backup completato', 'drfacile-' . date('Ymd') . '-0730.sqlite · 128 KB', ['modulo' => 'impostazioni'], '-9 hours'],
        ] as $n) Database::insert('notifiche', ['tipo' => $n[0], 'titolo' => $n[1], 'testo' => $n[2], 'link' => json_txt($n[3] ?? []), 'letta' => $n[0] === 'info' ? 1 : 0, 'creato_il' => date('Y-m-d H:i:s', strtotime($n[4]))]);

        // Marcatore persistente: evita che un archivio demo svuotato manualmente venga ripopolato al bootstrap.
        Impostazione::set('demo_seed_eseguito', '1');
    }

    private static function fattura(string $data, int $anno, int $prog, int $pid, string $prest, float $imp, string $stato, string $metodo, string $now): void
    {
        $bollo = $imp > (float) Config::get('fattura.bollo_soglia') ? (float) Config::get('fattura.bollo_importo') : 0;
        $righe = [['tipo' => 'riga', 'descrizione' => $prest, 'quantita' => 1, 'prezzo' => $imp, 'aliquota' => 0, 'importo' => $imp]];
        Database::insert('fatture', ['numero' => sprintf('%d/%03d', $anno, $prog), 'anno' => $anno, 'progressivo' => $prog, 'data' => $data, 'paziente_id' => $pid, 'prestazione' => $prest, 'righe' => json_txt($righe), 'importo' => $imp, 'iva' => 0, 'contributi' => 0, 'bollo' => $bollo, 'totale' => $imp + $bollo, 'metodo' => $metodo ?: null, 'stato' => $stato, 'scadenza' => date('Y-m-d', strtotime($data . ' +30 days')), 'pagata_il' => $stato === 'pagata' ? $data : null, 'creato_il' => $now]);
    }

    /** Modelli di messaggio predefiniti (email/SMS): solo se la tabella è vuota, anche sugli aggiornamenti */
    public static function messaggi(): void
    {
        if (!Database::tableExists('messaggi') || Database::value('SELECT COUNT(*) FROM messaggi')) return;
        $ora = date('Y-m-d H:i:s');
        $m = [
            ['REF-EMAIL', 'Referto in allegato', 'email', 'referto', 'Referto della visita del {data} · {studio}', '<p>Gentile {paziente},</p><p>in allegato trova il referto della visita del {data}.</p><p>Restiamo a disposizione per qualsiasi chiarimento.</p><p>Cordiali saluti,<br>{medico}<br>{studio} · {studio_telefono}</p>'],
            ['FAT-EMAIL', 'Fattura in allegato', 'email', 'fattura', 'Fattura n. {numero} del {data} · {studio}', '<p>Gentile {paziente},</p><p>in allegato trova la fattura n. <b>{numero}</b> del {data} di {importo}.</p><p>Cordiali saluti,<br>{studio}</p>'],
            ['RIC-EMAIL', 'Promemoria ricetta', 'email', 'ricetta', 'Promemoria ricetta del {data}', '<p>Gentile {paziente},</p><p>in allegato il promemoria della ricetta del {data}.</p><p>Cordiali saluti,<br>{medico}</p>'],
            ['DOC-EMAIL', 'Documento in allegato', 'email', 'documento', '{documento} · {studio}', '<p>Gentile {paziente},</p><p>in allegato trova il documento <b>{documento}</b>.</p><p>Cordiali saluti,<br>{studio}</p>'],
            ['FILE-EMAIL', 'File dalla documentale', 'email', 'file', '{documento} · {studio}', '<p>Gentile {paziente},</p><p>le inviamo in allegato: <b>{documento}</b>.</p><p>Cordiali saluti,<br>{studio}</p>'],
            ['GEN-EMAIL', 'Comunicazione generica', 'email', 'generico', 'Comunicazione da {studio}', '<p>Gentile {paziente},</p><p></p><p>Cordiali saluti,<br>{studio}</p>'],
            ['PROM-SMS', 'Promemoria appuntamento', 'sms', 'promemoria', '', 'Gentile {paziente}, le ricordiamo l\'appuntamento del {appuntamento} presso {studio}. Per disdire: {studio_telefono}'],
            ['PROM-EMAIL', 'Promemoria appuntamento', 'email', 'promemoria', 'Promemoria appuntamento del {appuntamento}', '<p>Gentile {paziente},</p><p>le ricordiamo l\'appuntamento del <b>{appuntamento}</b> presso {studio}.</p><p>Per spostarlo o disdirlo: {studio_telefono}.</p>'],
        ];
        foreach ($m as $r) Database::insert('messaggi', ['codice' => $r[0], 'descrizione' => $r[1], 'canale' => $r[2], 'per_tipo' => $r[3], 'oggetto' => $r[4], 'contenuto' => $r[5], 'predefinito' => 1, 'abilitato' => 1, 'creato_il' => $ora]);
    }
}
