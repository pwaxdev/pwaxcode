<?php
/** Cartella per problemi · endpoint (ajax/ext.php?ext=soap) */
return [
    'azioni' => [
        'problemi' => fn(array $in) => ['problemi' => Soap::problemi(Api::int($in, 'paziente_id'), !empty($in['tutti']))],
        'apri' => fn(array $in) => ['id' => Soap::apri(Api::int($in, 'paziente_id'), Api::str($in, 'titolo')), 'messaggio' => 'Problema aperto'],
        'stato' => function (array $in) { Soap::stato(Api::int($in, 'id'), Api::str($in, 'stato')); return ['messaggio' => Api::str($in, 'stato') === 'risolto' ? 'Problema segnato come risolto' : 'Problema riaperto']; },
        'cronologia' => fn(array $in) => ['note' => Database::all('SELECT n.*, r.stato rstato FROM ' . Soap::N . ' n LEFT JOIN referti r ON r.id = n.referto_id WHERE n.problema_id = ? ORDER BY n.data DESC, n.id DESC', [Api::int($in, 'id')])],
    ],
    'permessi' => ['*' => 'visita.leggi', 'apri' => 'visita.modifica', 'stato' => 'visita.modifica'],
];
