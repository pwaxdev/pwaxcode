<?php
return [
    'title' => __('Nuovo esame'), 'title_edit' => __('Modifica esame'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Aggiungi'),
    'table' => 'esami',
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'esami'],
        ['name' => 'nome', 'label' => __('Nome'), 'type' => 'text', 'required' => true],
        ['name' => 'categoria', 'label' => __('Categoria'), 'type' => 'select', 'empty' => __('Seleziona…'), 'options' => ['Laboratorio' => __('Laboratorio'), 'Strumentale' => __('Strumentale'), 'Radiologia' => __('Radiologia'), 'Specialistica' => __('Specialistica'), 'Altro' => __('Altro')]],
    ],
];
