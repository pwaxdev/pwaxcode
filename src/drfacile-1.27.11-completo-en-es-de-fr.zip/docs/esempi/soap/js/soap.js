/* Cartella per problemi · la visita S·O·A·P (sostituisce il corpo della visita) + scheda paziente + referto */
(function ($) {
  'use strict';
  const I = (fi, fa) => DRF.icons.html(fi, fa);
  const LET = { s: ['S', 'Soggettivo', 'Cosa riferisce il paziente: sintomi, decorso, come sta'], o: ['O', 'Oggettivo', 'Cosa rilevi: esame obiettivo, parametri, esami'], a: ['A', 'Valutazione', 'Cosa concludi: diagnosi o ipotesi (la prima riga diventa diagnosi)'], p: ['P', 'Piano', 'Cosa fai: terapia, esami richiesti, controllo'] };
  let st = { problemi: [], sel: null, dati: { problemi: {}, piano: '' }, ctx: null };

  DRF.hooks.add('visita.pannello', function (ctx) {
    st.ctx = ctx;
    let $ext = ctx.$root.find('.visita-ext');
    if (!$ext.find('.soap').length) {
      $ext = ctx.sostituisci($(`
        <div class="soap">
          <div class="soap-side">
            <div class="card soap-lista"><h3>${I('list-check', 'fa-solid fa-list-check')}Problemi del paziente</h3>
              <div class="soap-items"></div>
              <div class="row soap-nuovo"><input class="input sm" placeholder="Nuovo problema…"><button class="btn primary sm" type="button" data-soap="apri">${I('plus', 'fa-solid fa-plus')}</button></div>
              <label class="small muted soap-risolti"><input type="checkbox" data-soap="risolti"> mostra i risolti</label>
            </div>
          </div>
          <div class="soap-main">
            <div class="soap-slot-vitali"></div>
            <div class="card soap-editor"><div class="soap-vuoto empty">Scegli un problema a sinistra (o aprine uno) e scrivi le note S·O·A·P.</div></div>
            <div class="card"><h3>${I('clipboard-list', 'fa-solid fa-clipboard-list')}Piano complessivo della visita</h3><textarea class="input" rows="2" data-soap="piano" placeholder="Indicazioni generali, prossimo controllo…"></textarea></div>
            <div class="soap-slot-prestazioni"></div>
            <div class="soap-slot-storico"></div>
          </div>
        </div>`));
      // blocchi VIVI del core adottati: parametri (→ referto), prestazioni (→ fattura), storico
      $ext.find('.soap-slot-vitali').append(ctx.adotta('#vitals'));
      $ext.find('.soap-slot-prestazioni').append(ctx.adotta('#vPrest').closest('.field'));
      $ext.find('.soap-slot-storico').append(ctx.adotta('#vStorico').closest('.card'));
      $ext.on('click', '[data-soap="apri"]', apriProblema).on('keydown', '.soap-nuovo input', e => { if (e.key === 'Enter') { e.preventDefault(); apriProblema(); } });
      $ext.on('click', '.soap-item', function () { if ($(this).hasClass('risolto')) return; st.sel = +this.dataset.id; lista(); editor(); });
      $ext.on('click', '[data-soap="risolvi"]', function (e) { e.stopPropagation(); const id = +this.dataset.id; DRF.api.ext('soap', 'stato', { id, stato: 'risolto' }).then(r => { DRF.ui.toast(r.messaggio); if (st.sel === id) st.sel = null; carica(); }); });
      $ext.on('click', '[data-soap="riapri"]', function (e) { e.stopPropagation(); DRF.api.ext('soap', 'stato', { id: +this.dataset.id, stato: 'attivo' }).then(r => { DRF.ui.toast(r.messaggio); carica(); }); });
      $ext.on('click', '[data-soap="cronologia"]', function (e) { e.stopPropagation(); cronologia(+this.dataset.id, this.dataset.titolo); });
      $ext.on('change', '[data-soap="risolti"]', lista);
      $ext.on('input', '.soap-editor textarea', DRF.util.debounce(function () { const n = st.dati.problemi[st.sel] = st.dati.problemi[st.sel] || {}; n[this.dataset.k] = this.value; salva(); }, 250));
      $ext.on('input', '[data-soap="piano"]', DRF.util.debounce(function () { st.dati.piano = this.value; salva(); }, 250));
      DRF.icons.apply($ext[0]);
    }
    const d = ctx.getDati('soap');
    st.dati = d && d.problemi ? { problemi: d.problemi, piano: d.piano || '' } : { problemi: {}, piano: '' };
    $ext.find('[data-soap="piano"]').val(st.dati.piano).prop('disabled', !ctx.visita);
    $ext.find('.soap-nuovo input, .soap-nuovo button').prop('disabled', !ctx.visita);
    if (ctx.paziente) carica(); else { st.problemi = []; lista(); editor(); }
  });

  function carica() { return DRF.api.ext('soap', 'problemi', { paziente_id: st.ctx.paziente.id, tutti: 1 }).then(d => { st.problemi = d.problemi; if (!st.sel || !st.problemi.some(p => +p.id === st.sel && p.stato === 'attivo')) st.sel = (st.problemi.find(p => p.stato === 'attivo') || {}).id || null; lista(); editor(); }); }
  function apriProblema() {
    const $in = st.ctx.$root.find('.soap-nuovo input'), t = $in.val().trim(); if (!t) return;
    DRF.api.ext('soap', 'apri', { paziente_id: st.ctx.paziente.id, titolo: t }).then(r => { $in.val(''); st.sel = r.id; DRF.ui.toast(r.messaggio, 'success'); carica(); });
  }
  function lista() {
    const $l = st.ctx.$root.find('.soap-items'), tutti = st.ctx.$root.find('[data-soap="risolti"]').is(':checked');
    const items = st.problemi.filter(p => tutti || p.stato === 'attivo');
    $l.html(items.length ? items.map(p => { const n = st.dati.problemi[p.id] || {}; const scritto = ['s', 'o', 'a', 'p'].filter(k => n[k]).map(k => k.toUpperCase()).join(''); return `
      <div class="soap-item ${+p.id === st.sel ? 'on' : ''} ${p.stato === 'risolto' ? 'risolto' : ''}" data-id="${p.id}">
        <div class="soap-item-t"><b>${DRF.esc(p.titolo)}</b><span>${p.stato === 'risolto' ? 'risolto il ' + DRF.util.fmtIso(p.chiuso_il) : (p.ultima_il ? 'visto il ' + DRF.util.fmtIso(p.ultima_il) : 'aperto il ' + DRF.util.fmtIso(p.aperto_il))}${scritto ? ` · <b class="soap-scritto">${scritto}</b>` : ''}</span></div>
        <div class="soap-item-b"><button class="icon-btn sm" type="button" data-soap="cronologia" data-id="${p.id}" data-titolo="${DRF.esc(p.titolo)}" title="Cronologia">${I('time-past', 'fa-solid fa-clock-rotate-left')}</button>${p.stato === 'risolto' ? `<button class="icon-btn sm" type="button" data-soap="riapri" data-id="${p.id}" title="Riapri">${I('undo', 'fa-solid fa-rotate-left')}</button>` : `<button class="icon-btn sm" type="button" data-soap="risolvi" data-id="${p.id}" title="Segna risolto">${I('check', 'fa-solid fa-check')}</button>`}</div>
      </div>`; }).join('') : '<div class="small muted" style="padding:6px 2px">Nessun problema aperto: scrivilo qui sotto.</div>');
    DRF.icons.apply($l[0]);
  }
  function editor() {
    const $e = st.ctx.$root.find('.soap-editor'), p = st.problemi.find(x => +x.id === st.sel);
    if (!p) { $e.html('<div class="soap-vuoto empty">Scegli un problema a sinistra (o aprine uno) e scrivi le note S·O·A·P.</div>'); return; }
    const n = st.dati.problemi[p.id] || {};
    $e.html(`<h3>${I('list-check', 'fa-solid fa-list-check')}${DRF.esc(p.titolo)}<span class="muted small" style="margin-left:auto;font-weight:500">aperto il ${DRF.util.fmtIso(p.aperto_il)}</span></h3>
      <div class="soap-grid">${Object.entries(LET).map(([k, [l, nome, hint]]) => `<div class="soap-cella"><label><b class="soap-let">${l}</b>${nome}<span>${hint}</span></label><textarea class="input" rows="3" data-k="${k}" ${st.ctx.visita ? '' : 'disabled'}>${DRF.esc(n[k] || '')}</textarea></div>`).join('')}</div>`);
    DRF.icons.apply($e[0]);
  }
  function salva() {
    if (!st.ctx.visita) return;
    st.ctx.setDati('soap', st.dati);
    const dx = [];
    Object.entries(st.dati.problemi).forEach(([pid, n]) => { if (n && n.a) dx.push(n.a.split('\n')[0].trim()); });
    st.ctx.setDiagnosi(dx);
    lista();
  }
  function cronologia(id, titolo) {
    DRF.api.ext('soap', 'cronologia', { id }).then(d => DRF.ui.modal({ title: `Cronologia · ${titolo}`, size: 'lg', ok: false, cancel: 'Chiudi',
      html: d.note.length ? `<div class="soap-cron">${d.note.map(n => `<div class="soap-cron-it"><b>${DRF.util.fmtIso(n.data)}</b>${['s', 'o', 'a', 'p'].filter(k => n[k]).map(k => `<div><i class="soap-let">${k.toUpperCase()}</i>${DRF.esc(n[k])}</div>`).join('')}${n.referto_id ? `<a href="#" data-doc="referto" data-id="${n.referto_id}" class="small">referto</a>` : ''}</div>`).join('')}</div>` : '<div class="empty">Nessuna nota ancora: la prima arriva chiudendo una visita.</div>' }));
  }

  // scheda paziente: i problemi (allegati da api.dopo a pazienti/get: nessuna chiamata in più) + Piano di cura
  DRF.hooks.add('paziente.scheda', ctx => {
    const lista = ctx.risposta.soap || [], attivi = lista.filter(p => p.stato === 'attivo');
    ctx.aggiungi(`<div class="card soap-scheda"><h3>${I('list-check', 'fa-solid fa-list-check')}Problemi ${attivi.length ? `<span class="badge mint">${attivi.length} attivi</span>` : ''}</h3>${attivi.length ? `<ul>${attivi.map(p => `<li><b>${DRF.esc(p.titolo)}</b>${p.ultimo_piano ? `<span>${DRF.esc(p.ultimo_piano)}</span>` : ''}</li>`).join('')}</ul>` : '<span class="muted small">Nessun problema aperto</span>'}${lista.length > attivi.length ? `<div class="small muted" style="margin-top:6px">${lista.length - attivi.length} risolti</div>` : ''}</div>`, 'prima');
    ctx.azione('Piano di cura', () => DRF.doc.apri('soap_piano', ctx.paziente.id), { fi: 'clipboard-list', fa: 'fa-solid fa-clipboard-list' });
  });
  DRF.hooks.add('referto.editor', ctx => ctx.azione('Piano di cura', () => DRF.doc.apri('soap_piano', ctx.paziente.id), { fi: 'clipboard-list', fa: 'fa-solid fa-clipboard-list' }));
  DRF.hooks.add('search.comandi', ctx => ctx.comando({ label: 'Cartella per problemi: apri un problema', fi: 'list-check', fa: 'fa-solid fa-list-check', kw: 'soap problema visita', run: () => DRF.nav.go('visita') }));
})(jQuery);
