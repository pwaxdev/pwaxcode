<?php
/** Calcolo, verifica e decodifica del codice fiscale italiano */
final class CodiceFiscale
{
    private const MESI = ['A', 'B', 'C', 'D', 'E', 'H', 'L', 'M', 'P', 'R', 'S', 'T'];
    private const DISPARI = ['0' => 1, '1' => 0, '2' => 5, '3' => 7, '4' => 9, '5' => 13, '6' => 15, '7' => 17, '8' => 19, '9' => 21, 'A' => 1, 'B' => 0, 'C' => 5, 'D' => 7, 'E' => 9, 'F' => 13, 'G' => 15, 'H' => 17, 'I' => 19, 'J' => 21, 'K' => 2, 'L' => 4, 'M' => 18, 'N' => 20, 'O' => 11, 'P' => 3, 'Q' => 6, 'R' => 8, 'S' => 12, 'T' => 14, 'U' => 16, 'V' => 10, 'W' => 22, 'X' => 25, 'Y' => 24, 'Z' => 23];
    private const OMOCODIA = ['L' => 0, 'M' => 1, 'N' => 2, 'P' => 3, 'Q' => 4, 'R' => 5, 'S' => 6, 'T' => 7, 'U' => 8, 'V' => 9];

    public static function calcola(string $cognome, string $nome, string $nascita, string $sesso, string $codCatastale): string
    {
        $ts = strtotime($nascita);
        if (!$ts || strlen($codCatastale) !== 4) return '';
        $cf = self::consonantiCognome($cognome) . self::consonantiNome($nome) . substr(date('Y', $ts), 2) . self::MESI[(int) date('n', $ts) - 1]
            . str_pad((string) ((int) date('j', $ts) + (strtoupper($sesso) === 'F' ? 40 : 0)), 2, '0', STR_PAD_LEFT) . strtoupper($codCatastale);
        return $cf . self::controllo($cf);
    }

    public static function valida(?string $cf): bool
    {
        $cf = strtoupper(trim((string) $cf));
        if (!preg_match('/^[A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]$/', $cf)) return false;
        return self::controllo(substr($cf, 0, 15)) === $cf[15];
    }

    /** Estrae data di nascita, sesso e codice catastale del comune (gestisce l'omocodia) */
    public static function decodifica(?string $cf): ?array
    {
        $cf = strtoupper(trim((string) $cf));
        if (!self::valida($cf)) return null;
        $num = fn(string $s) => implode('', array_map(fn($c) => ctype_digit($c) ? $c : (string) self::OMOCODIA[$c], str_split($s)));
        $aa = (int) $num(substr($cf, 6, 2)); $mese = array_search($cf[8], self::MESI, true) + 1; $gg = (int) $num(substr($cf, 9, 2));
        $sesso = $gg > 40 ? 'F' : 'M'; if ($gg > 40) $gg -= 40;
        $anno = $aa + ((int) date('y') >= $aa ? 2000 : 1900);
        if ($anno > (int) date('Y')) $anno -= 100;
        return ['nascita' => sprintf('%04d-%02d-%02d', $anno, $mese, $gg), 'sesso' => $sesso, 'cod_catastale' => $cf[11] . $num(substr($cf, 12, 3))];
    }

    private static function pulisci(string $s): string
    {
        $s = strtoupper(iconv('UTF-8', 'ASCII//TRANSLIT', $s) ?: $s);
        return preg_replace('/[^A-Z]/', '', $s);
    }
    private static function consonanti(string $s): string { return preg_replace('/[AEIOU]/', '', $s); }
    private static function vocali(string $s): string { return preg_replace('/[^AEIOU]/', '', $s); }

    private static function consonantiCognome(string $s): string
    {
        $s = self::pulisci($s);
        return substr(self::consonanti($s) . self::vocali($s) . 'XXX', 0, 3);
    }
    private static function consonantiNome(string $s): string
    {
        $s = self::pulisci($s); $c = self::consonanti($s);
        if (strlen($c) >= 4) $c = $c[0] . $c[2] . $c[3];
        return substr($c . self::vocali($s) . 'XXX', 0, 3);
    }
    private static function controllo(string $cf15): string
    {
        $somma = 0;
        for ($i = 0; $i < 15; $i++) { $c = $cf15[$i]; $somma += $i % 2 === 0 ? self::DISPARI[$c] : (ctype_digit($c) ? (int) $c : ord($c) - 65); }
        return chr(65 + $somma % 26);
    }
}
