/* Form generate dal FormBuilder (form/definitions/*.php), aperte nella sheet e inviate via AJAX.
   DRF.form.open('paziente', { id, values, onOpen($body), onSaved(data) }) */
DRF.form = (function ($) {
  'use strict';
  return {
    init() {},
    open(name, opt = {}) {
      return DRF.api.get('form', 'render', { name, id: opt.id || '', values: opt.values || {} }).then(f => {
        $('#sheet').toggleClass('wide', !!f.wide);
        DRF.ui.openSheet(f.title, f.html, () => {
          const $b = $('#sheetBody');
          let ok = true;
          $b.find('[required]').each(function () { const bad = !$(this).val(); $(this).toggleClass('err', bad); if (bad) ok = false; });
          if (!ok) { DRF.ui.toast(DRF.__('Compila i campi obbligatori'), 'warn'); return false; }
          const data = Object.assign(DRF.ui.formData($b), opt.extra || {});
          DRF.ui.sheetBusy(true);
          DRF.api.post(f.endpoint, f.action, data).then(res => {
            DRF.ui.closeSheet();
            if (res && res.messaggio) DRF.ui.toast(res.messaggio);
            if (opt.onSaved) opt.onSaved(res, data);
          }).always(() => DRF.ui.sheetBusy(false));
          return false; // la chiusura avviene al termine della chiamata
        }, f.submit);
        if (opt.values) Object.keys(opt.values).forEach(k => {
          const $i = $('#sheetBody').find(`[name="${k}"]`); if (!$i.length) return;
          DRF.ui.setVal($i, opt.values[k]); if ($i.is('select')) $i.trigger('change');
          const $seg = $i.prev('.seg'); if ($seg.length) { $seg.find('button').removeClass('on').filter(function () { return String($(this).data('v')) === String(opt.values[k]); }).addClass('on'); }
        });
        if (opt.onOpen) opt.onOpen($('#sheetBody'), f);
        // slot per le estensioni su QUALSIASI form del core: logica sui campi aggiunti con form.campi
        DRF.hooks.run('form.aperta', { $root: $('#sheetBody'), name, id: opt.id || null, form: f, val: n => DRF.ui.val($('#sheetBody').find(`[name="${n}"]`)), setVal: (n, v) => DRF.ui.setVal($('#sheetBody').find(`[name="${n}"]`), v) });
        return f;
      });
    }
  };
})(jQuery);
