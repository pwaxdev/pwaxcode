<?php
/**
 * PERCORSI GUIDATI dell'assistente (F2): le liste di cose da fare "anti sbadati".
 *
 * Ogni percorso ha i suoi passi. Un passo può essere:
 *   - AUTOMATICO: 'auto' => fn(int $rifId): bool — verificato dal vivo a ogni aggiornamento
 *     (es. "privacy firmata" si spunta da sola quando il consenso è nel registro)
 *   - MANUALE: senza 'auto' — lo spunta il medico con un click (resta memorizzato)
 * 'link' => ['modulo' => …, 'opts' => …] apre la sezione giusta cliccando il passo.
 *
 * I percorsi si aprono da codice (Percorso::apri) o si presentano da soli: 'trigger' documenta quando.
 * Per aggiungerne uno basta una voce qui sotto: l'assistente fa il resto.
 */
return [
    'nuovo_paziente' => [
        'titolo' => __('Nuovo paziente'),
        'trigger' => 'Alla creazione di un paziente (anche al volo dalla prenotazione)',
        'rif' => 'pazienti',
        'passi' => [
            'anagrafica' => ['label' => 'Completa l\'anagrafica (CF, nascita, contatti)',
                'auto' => fn(int $id) => ($p = Paziente::find($id)) && !empty($p['cf']) && !empty($p['nascita']) && (!empty($p['telefono']) || !empty($p['cellulare'])),
                'link' => fn(int $id) => ['modulo' => 'pazienti', 'opts' => ['select' => $id, 'modifica' => 1]]],
            'privacy' => ['label' => __('Stampa e registra la privacy firmata'),
                'auto' => fn(int $id) => (bool) Database::value("SELECT COUNT(*) FROM consensi WHERE paziente_id = ? AND tipo = 'Privacy' AND firmato = 1 AND (scadenza IS NULL OR scadenza = '' OR scadenza >= ?)", [$id, oggi()]),
                'link' => fn(int $id) => ['modulo' => 'pazienti', 'opts' => ['select' => $id]]],
            'promemoria' => ['label' => __('Consegna il vademecum dello studio (orari, recapiti)')],
            'prenotazione' => ['label' => __('Prenota la prima visita'),
                'auto' => fn(int $id) => (bool) Database::value('SELECT COUNT(*) FROM appuntamenti WHERE paziente_id = ?', [$id]),
                'link' => fn(int $id) => ['modulo' => 'agenda', 'opts' => []]],
        ],
    ],
    'chiusura_giornata' => [
        'titolo' => __('Chiusura della giornata'),
        'trigger' => 'Manuale: dal pulsante dell\'assistente o con F2',
        'rif' => null,
        'passi' => [
            'visite' => ['label' => __('Nessuna visita rimasta in bozza'),
                'auto' => fn(int $id) => Database::value("SELECT COUNT(*) FROM visite WHERE stato = 'bozza'") == 0,
                'link' => fn(int $id) => ['modulo' => 'visita', 'opts' => []]],
            'referti' => ['label' => __('Firma i referti in bozza'),
                'auto' => fn(int $id) => Database::value("SELECT COUNT(*) FROM referti WHERE stato = 'bozza'") == 0,
                'link' => fn(int $id) => ['modulo' => 'referti', 'opts' => []]],
            'fatture' => ['label' => __('Fattura le visite chiuse di oggi'),
                'auto' => fn(int $id) => count(Visita::daFatturare(5)) === 0,
                'link' => fn(int $id) => ['modulo' => 'fatture', 'opts' => []]],
            'assenti' => ['label' => __('Segna i non presentati in agenda'),
                'link' => fn(int $id) => ['modulo' => 'agenda', 'opts' => []]],
            'backup' => ['label' => __('Fai il backup (Impostazioni → Dati)'),
                'link' => fn(int $id) => ['modulo' => 'impostazioni', 'opts' => []]],
        ],
    ],
];
