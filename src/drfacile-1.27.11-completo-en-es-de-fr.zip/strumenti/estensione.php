<?php
/**
 * Gestione delle estensioni dal backend (il portale DRFacile, dopo un pagamento Stripe/PayPal,
 * chiama questo script sull'installazione dello studio — o esegue le stesse query).
 *
 *   php strumenti/estensione.php                          → elenco con stato e scadenze
 *   php strumenti/estensione.php attiva vocale +30        → attiva con scadenza fra 30 giorni (abbonamento)
 *   php strumenti/estensione.php attiva magazzino         → attiva senza scadenza (una tantum)
 *   php strumenti/estensione.php proroga vocale +365      → proroga (rinnovo abbonamento)
 *   php strumenti/estensione.php disattiva vocale         → disattiva
 *   php strumenti/estensione.php migra consigli           → esegue le migrazioni non ancora eseguite (estensioni/<codice>/migrations/)
 *   DRF_STUDIO=3 php strumenti/estensione.php attiva …     → SaaS: opera sullo studio 3 (le installazioni sono dello studio, vedi core/Tenant.php)
 *
 * CONTRATTO CON IL PORTALE: ogni chiamata porta lo studio nell'ambiente, DRF_STUDIO=<id studio>
 * (obbligatorio quando l'installazione ospita più studi; con uno solo si può omettere). Exit code 0 = fatto, 1 = errore.
 *
 * Flusso pagamenti (predisposto, vedi docs/sviluppo-estensioni.md § Pagamenti):
 * il portale incassa (Stripe Checkout / webhook payment_intent.succeeded) e attiva qui.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
require __DIR__ . '/../core/bootstrap.php';

// SaaS: le installazioni sono dello STUDIO. Con più studi il portale deve dire quale (DRF_STUDIO=ID), altrimenti si fermerebbe sul base.
$nStudi = (int) Database::value('SELECT COUNT(*) FROM ' . Database::comune('studi'));
if ($nStudi > 1 && !getenv('DRF_STUDIO')) {
    echo "Più studi in questa installazione: indica quello su cui operare con DRF_STUDIO=ID (elenco: php strumenti/studio.php)\n";
    exit(1);
}
echo 'Studio ' . (getenv('DRF_STUDIO') ?: (Database::value('SELECT id FROM ' . Database::comune('studi') . ' ORDER BY id LIMIT 1') ?: '—')) . (Database::tenantId() ? ' (database dedicato)' : ' (database base)') . "\n";
$cmd = $argv[1] ?? 'elenco'; $codice = $argv[2] ?? null; $arg = $argv[3] ?? null;
$scadenza = null;
if ($arg !== null) {
    if (preg_match('/^\+(\d+)$/', $arg, $m)) $scadenza = date('Y-m-d', strtotime("+{$m[1]} days"));
    elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $arg)) $scadenza = $arg;
    else exit("Scadenza non valida: $arg (usa +GIORNI oppure AAAA-MM-GG)\n");
}
$nomi = array_column(Estensioni::catalogo(), 'codice');
if ($cmd === 'migra') {
    if (!$codice || !in_array($codice, $nomi, true)) exit("Estensione sconosciuta: " . ($codice ?? '—') . "\n");
    $fatte = Migrazioni::esegui($codice);
    echo $fatte ? "Eseguite: " . implode(', ', $fatte) . "\n" : "Nessuna migrazione da eseguire (" . count(Migrazioni::eseguite($codice)) . " già fatte)\n";
    exit(0);
}
if (in_array($cmd, ['attiva', 'proroga', 'disattiva'], true)) {
    if (!$codice || !in_array($codice, $nomi, true)) exit("Estensione sconosciuta: " . ($codice ?? '—') . "\n");
    if ($cmd === 'disattiva') Estensioni::disinstalla($codice);
    else {
        Estensioni::installa($codice);
        if ($cmd === 'proroga') {
            $att = Database::one('SELECT scadenza FROM estensioni WHERE codice = ?', [$codice]);
            $base = max(strtotime($att['scadenza'] ?: 'today'), strtotime('today'));
            if (preg_match('/^\+(\d+)$/', (string) $arg, $m)) $scadenza = date('Y-m-d', strtotime("+{$m[1]} days", $base));
        }
        Database::run('UPDATE estensioni SET scadenza = ? WHERE codice = ?', [$scadenza, $codice]);
    }
}
echo "Estensioni dello studio:\n";
$inst = [];
foreach (Database::all('SELECT * FROM estensioni') as $e) $inst[$e['codice']] = $e;
foreach (Estensioni::catalogo() as $m) {
    $e = $inst[$m['codice']] ?? null;
    $stato = !$e || !$e['attiva'] ? 'non installata' : (($e['scadenza'] && $e['scadenza'] < oggi()) ? "SCADUTA il {$e['scadenza']}" : 'attiva' . ($e['scadenza'] ? " fino al {$e['scadenza']}" : ''));
    printf("  %-16s %-12s v%-5s %s\n", $m['codice'], $m['prezzo_tipo'], $e['versione'] ?? $m['versione'], $stato);
}
