<div class="stagger" id="statsRoot">
  <div class="kpis four" id="sKpis"></div>
  <div class="stats">
    <div class="card"><h3><i class="ico" data-fi="chart-histogram" data-fa="fa-solid fa-chart-simple"></i><?= __('Visite per mese') ?></h3><div class="bars" id="bars"></div></div>
    <div class="card"><h3><i class="ico" data-fi="chart-pie-alt" data-fa="fa-solid fa-chart-pie"></i><?= __('Tipo di prestazione') ?></h3><div class="donut-wrap"><div class="donut" id="donut"><b id="donutTot">—</b><small><?= __('ultimi 12 mesi') ?></small></div><div class="legend" id="sLegend"></div></div></div>
    <div class="card"><h3><i class="ico" data-fi="euro" data-fa="fa-solid fa-euro-sign"></i><?= __('Incassi mensili') ?></h3><div id="sparkWrap"></div></div>
    <div class="card"><h3><i class="ico" data-fi="star" data-fa="fa-regular fa-star"></i><?= __('Prestazioni più richieste') ?></h3><div class="prog" id="prog"></div></div>
  </div>
</div>
