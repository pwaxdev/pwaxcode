/* Aiuto in linea: F1 apre la guida sulla sezione corrente; indice a sinistra, contenuto a destra. */
DRF.help = (function ($) {
  'use strict';
  let voci = null;
  function open(key) {
    const show = () => {
      const k = voci[key] ? key : 'generale';
      const nav = () => Object.entries(voci).map(([id, v]) => `<button type="button" data-help="${id}">${DRF.icons.html(v.fi, v.fa)}<span>${DRF.esc(v.titolo)}</span></button>${Object.entries(v.sotto || {}).map(([sid, s]) => `<button type="button" class="help-sub" data-help="${id}/${sid}"><span>${DRF.esc(s.titolo)}</span></button>`).join('')}`).join('');
      DRF.ui.modal({ title: DRF.__('Aiuto in linea'), size: 'xl', ok: false, cancel: DRF.__('Chiudi (Esc)'),
        html: `<div class="hlp"><nav class="help-nav">${nav()}</nav><div class="help-body"><div class="help-tools"><button type="button" class="icon-btn sm" data-help="generale" title="${DRF.__('Indice e basi')}">${DRF.icons.html('home', 'fa-solid fa-house')}</button><span class="muted small">${DRF.__('F1 apre l\'aiuto della sezione in cui ti trovi · i link nel testo saltano alla pagina giusta')}</span></div><div class="help-content"></div></div></div>`,
        onOpen($b) {
          const go = id => {
            const [vk, sk] = String(id).split('/');
            const v = voci[vk] || voci.generale;
            const s = sk && v.sotto && v.sotto[sk] ? v.sotto[sk] : null;
            const attivo = s ? `${vk}/${sk}` : (voci[vk] ? vk : 'generale');
            $b.find('.help-nav button').removeClass('on').filter(`[data-help="${attivo}"]`).addClass('on');
            $b.find('.help-content').html(s
              ? `<h2>${DRF.icons.html(v.fi, v.fa)}${DRF.esc(v.titolo)} <i class="help-sep">›</i> ${DRF.esc(s.titolo)}</h2>${s.html}`
              : `<h2>${DRF.icons.html(v.fi, v.fa)}${DRF.esc(v.titolo)}</h2>${v.html}`).scrollTop(0);
            DRF.icons.apply($b[0]);
          };
          $b.on('click', '[data-help]', function () { go(this.dataset.help); });
          $b.on('click', 'a[data-go]', function (e) { e.preventDefault(); go(this.dataset.go); });
          go(k);
        } });
    };
    if (voci) return show();
    DRF.api.get('aiuto', 'voci').then(r => { voci = r.voci; show(); });
  }
  $(document).on('keydown', e => {
    if (e.key !== 'F1') return;
    e.preventDefault();
    if ($('#modal').hasClass('open')) return;
    open((DRF.state && DRF.state.current) || 'generale');
  });
  return { open };
})(jQuery);
