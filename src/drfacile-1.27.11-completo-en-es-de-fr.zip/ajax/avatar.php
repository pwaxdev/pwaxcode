<?php
/** Avatar personale dell'utente collegato: data/avatar-u<ID>.png (fuori dai pacchetti di aggiornamento). */
require __DIR__ . '/../core/bootstrap.php';
$uid = (int) (Auth::utente()['id'] ?? 0);
$file = DRF_ROOT . '/data/avatar-u' . $uid . '.png';

if (($_GET['action'] ?? '') === 'img') {
    if (!Auth::check() || !is_file($file)) { http_response_code(404); exit; }
    header('Content-Type: image/png');
    header('Cache-Control: private, max-age=86400');
    readfile($file); exit;
}
Api::run([
    'salva' => function (array $in) use ($file) {
        $data = (string) ($in['img'] ?? '');
        if (!preg_match('#^data:image/png;base64,#', $data)) throw new ApiException(__('Immagine non valida'));
        $bin = base64_decode(substr($data, strlen('data:image/png;base64,')), true);
        if ($bin === false || strlen($bin) > 1_500_000) throw new ApiException(__('Immagine troppo grande o corrotta'));
        if (substr($bin, 0, 8) !== "\x89PNG\r\n\x1a\n") throw new ApiException(__('Formato non riconosciuto'));
        file_put_contents($file, $bin);
        Attivita::registra('profilo.avatar', 'impostazioni', 0, 'Avatar aggiornato');
        return ['url' => 'ajax/avatar.php?action=img&v=' . filemtime($file)];
    },
    'rimuovi' => function () use ($file) { if (is_file($file)) unlink($file); return ['rimosso' => true]; },
]);
