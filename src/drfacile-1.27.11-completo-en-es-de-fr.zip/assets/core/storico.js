/* Storico del paziente come linea del tempo (usato in Pazienti e in Visita) */
DRF.storico = (function () {
  'use strict';
  const TIPI = { Visita: ['stethoscope', 'fa-solid fa-stethoscope', 'var(--accent)'], Controllo: ['stethoscope', 'fa-solid fa-stethoscope', 'var(--mint)'], Ecografia: ['pulse', 'fa-solid fa-wave-square', 'var(--rose)'], Ricetta: ['prescription', 'fa-solid fa-prescription', 'var(--sky)'], Anagrafica: ['user', 'fa-solid fa-user', 'var(--ink-3)'], Certificato: ['document-signed', 'fa-solid fa-file-signature', 'var(--amber)'] };
  return {
    /** Trasforma le righe della tabella storico in voci per DRF.ui.timeline */
    voci(storico) {
      return (storico || []).map(s => { const [fi, fa, c] = TIPI[s.tipo] || ['circle-small', 'fa-solid fa-circle', 'var(--ink-3)'];
        return { data: s.data, tipo: s.tipo, titolo: s.descrizione || s.tipo, fi, fa, colore: c, run: s.rif_tabella === 'referti' && s.rif_id ? () => DRF.nav.go('referti', { select: +s.rif_id }) : (s.rif_tabella === 'ricette' ? () => DRF.nav.go('ricette') : null) }; });
    },
    render($el, storico, compatta) { return DRF.ui.timeline($el.removeClass('hist'), DRF.storico.voci(storico), { compatta: compatta !== false, anni: true }); }
  };
})();
