/* Modulo Scrivania: Scadenze — le prossime scadenze dello scadenzario (pagamenti, consensi, controlli), con chiusura al volo */
DRF.desk.register('scadenze', {
  init($win) {
    const ICO = { pagamento: ['euro', 'fa-solid fa-euro-sign'], consenso: ['shield-check', 'fa-solid fa-shield-halved'], controllo: ['stethoscope', 'fa-solid fa-stethoscope'], documento: ['document', 'fa-regular fa-file-lines'], promemoria: ['bell', 'fa-regular fa-bell'] };
    const load = () => DRF.api.get('scadenzario', 'prossime').then(d => {
      const oggi = DRF.util.todayIso();
      $win.find('.scad-list').html(d.scadenze.map(s => {
        const diff = Math.round((new Date(s.data) - new Date(oggi)) / 86400000);
        const [fi, fa] = ICO[s.tipo] || ICO.promemoria;
        return `<div class="scad-it ${diff < 0 ? 'tardi' : diff === 0 ? 'oggi' : ''}" data-id="${s.id}" data-link='${DRF.esc(JSON.stringify(s.link || null))}'>
          <span class="scad-ico">${DRF.icons.html(fi, fa)}</span>
          <div class="scad-mid"><b>${DRF.esc(s.titolo)}</b>${s.testo ? `<span>${DRF.esc(s.testo)}</span>` : ''}</div>
          <div class="scad-data"><b>${DRF.util.fmtIso(s.data)}</b><small>${diff < 0 ? Math.abs(diff) + ' ' + DRF.__('gg fa') : diff === 0 ? DRF.__('oggi') : diff === 1 ? DRF.__('domani') : DRF.__('fra') + ' ' + diff + ' ' + DRF.__('gg')}</small></div>
          <button type="button" class="scad-done" data-done="${s.id}" title="${DRF.__('Segna come gestita')}">${DRF.icons.html('check', 'fa-solid fa-check')}</button></div>`;
      }).join('') || '<div class="scad-empty">' + DRF.__('Nessuna scadenza nei prossimi 30 giorni.') + '<br>' + DRF.__('Qui arrivano pagamenti da incassare, consensi in scadenza e visite di controllo programmate.') + '</div>');
      DRF.icons.apply($win[0]);
    });
    $win.on('click', '[data-done]', function (e) { e.stopPropagation(); const id = +this.dataset.done; DRF.api.post('scadenzario', 'chiudi', { id }).then(() => { DRF.ui.toast(DRF.__('Scadenza gestita')); load(); }); });
    $win.on('click', '.scad-it', function () { try { const l = JSON.parse(this.dataset.link); if (l && l.modulo) DRF.nav.go(l.modulo, l.opts || {}); } catch (e) {} });
    $win.data('reload', load); load();
  },
  open($win) { const r = $win.data('reload'); if (r) r(); }
});
