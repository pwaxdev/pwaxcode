/* Modulo Archivi: tabelle di base (core/archivi.php) gestite con il CRUD standard (assets/core/crud.js) */
DRF.register('archivi', (function ($) {
  'use strict';
  const I = DRF.icons.html;
  const st = { elenco: [], sel: 'prestazioni', crud: null };

  function loadElenco() {
    return DRF.api.get('archivi', 'elenco').then(e => {
      st.elenco = e;
      $('#archList').html(e.map(a => `<div class="arow ${a.nome === st.sel ? 'on' : ''}" data-a="${a.nome}"><span class="ib">${I(a.fi, a.fa)}</span><div><b>${DRF.esc(a.label)}</b><span>${DRF.esc(a.desc)}</span></div>${DRF.ui.badge('gray', a.n)}</div>`).join(''));
      DRF.icons.apply($('#archList')[0]);
      DRF.nav.refreshSub();
    });
  }
  function apri() {
    if (st.crud) st.crud.destroy();
    const extra = st.sel === 'documenti' ? [{ label: DRF.__('Richiedi'), fi: 'paper-plane', fa: 'fa-regular fa-paper-plane', primary: true, run: () => M.richiedi() }] : [];
    st.crud = DRF.crud.mount({ head: $('#archHead'), table: $('#archTable'), archivio: st.sel, onChange: loadElenco, extra, senzaNuovo: true });
  }

  const M = {
    title: DRF.__('Archivi'),
    sub() { const n = st.elenco.reduce((s, a) => s + a.n, 0); return `${st.elenco.length} ${DRF.__('archivi di base ·')} ${n} ${DRF.__('voci')}`; },
    action: { label: DRF.__('Aggiungi voce'), fi: 'plus', fa: 'fa-solid fa-plus', run: () => st.crud && st.crud.nuovo() },
    /** Richiesta di un nuovo modello all'assistenza (archivio Documenti) */
    richiedi() {
      DRF.api.get('documenti_modelli', 'catalogo').then(d => {
        DRF.ui.modal({ title: DRF.__('Richiedi un documento'), ok: DRF.__('Invia la richiesta'), cancel: DRF.__('Annulla'),
          html: `<p class="small muted" style="margin-bottom:12px">${DRF.__('Scegli dal catalogo comune: prepariamo il modello con i campi {…} e lo inseriamo nel tuo archivio, pronto da stampare.')}</p>
            <div class="field"><label>${DRF.__('Documento')}</label><select class="select" id="rqVoce"><option value="">${DRF.__('Seleziona…')}</option>${Object.entries(d.voci).map(([k, v]) => `<option value="${k}">${DRF.esc(v)}</option>`).join('')}</select></div>
            <div class="field"><label>${DRF.__('Note per chi lo prepara')}</label><textarea class="textarea" id="rqNote" style="min-height:90px" placeholder="${DRF.__('Specialità, passaggi particolari, riferimenti normativi…')}"></textarea></div>`,
          onOk($b) {
            const voce = $b.find('#rqVoce').val();
            if (!voce) { DRF.ui.toast(DRF.__('Scegli il documento'), 'warn'); return false; }
            DRF.api.post('documenti_modelli', 'richiedi', { voce, note: $b.find('#rqNote').val() }).then(r => { DRF.ui.toast(r.messaggio, 'success'); DRF.ui.closeModal(); });
            return false;
          } });
      });
    },
    init() {
      $('#archList').on('click', '.arow', function () { st.sel = this.dataset.a; $('#archList .arow').removeClass('on'); $(this).addClass('on'); apri(); });
    },
    show(opts) { if (opts && opts.archivio) st.sel = opts.archivio; loadElenco().then(apri); }
  };
  return M;
})(jQuery));
