# Creare estensioni per DRFacile

DRFacile è un sistema **modulare**: tutto ciò che non è il nucleo (agenda, pazienti, visite,
fatture) può arrivare come **estensione** dal Negozio. Questo documento spiega, punto per punto,
come costruirne una — dalla cartella al catalogo, fino ai pagamenti.

---

## 1. L'architettura in due minuti

Un'estensione è fatta di **tre pezzi**, tutti facoltativi tranne il primo:

| Pezzo | Dove vive | A che serve |
|---|---|---|
| **Scheda di catalogo** | tabella `store_moduli` nel database **comune** | La scheda nel Negozio: nome, descrizione, prezzo, screenshot, versione, autore |
| **Codice server** | `estensioni/<codice>/estensione.php` | Registra gli hook PHP (nuovi ruoli, voci di procedura, logiche) |
| **Codice client** | `estensioni/<codice>/js/*.js` e `css/*.css` | Si aggancia all'interfaccia (pannelli in visita, grafici, pulsanti) |

Lo **stato di installazione** è dello studio (tabella dedicata `estensioni`: `codice`,
`attiva`, `versione`, `scadenza`). Il **gate** è una riga:

```php
if (Estensioni::attiva('mia_estensione')) { ... }
```

Il bootstrap fa il resto: se l'estensione è attiva include il suo `estensione.php`,
la pagina carica i suoi js/css, e `Estensioni::attiva()` risponde `true`
(tenendo conto della scadenza, per gli abbonamenti).

## 2. Passo 1 — la cartella

```
estensioni/
└── mia_estensione/
    ├── estensione.php      ← hook server (può essere vuoto)
    ├── js/
    │   └── mia_estensione.js
    └── css/
        └── mia_estensione.css
```

Il codice (`mia_estensione`) è l'identificatore: minuscolo, senza spazi.
I file js/css vengono inclusi **solo** se l'estensione è attiva, con `?v=<versione app>`
per il cache-busting.

## 3. Passo 2 — la scheda di catalogo

In sviluppo si aggiunge una voce a `Estensioni::catalogoSeed()` (core/models/Estensioni.php);
in produzione la riga la scrive il **portale** nella tabella comune `store_moduli`
(il catalogo è lo stesso per tutti gli studi). I campi:

| Campo | Esempio | Note |
|---|---|---|
| `codice` | `mia_estensione` | = nome della cartella |
| `nome`, `sottotitolo` | | La scheda del Negozio |
| `descrizione` | HTML | Paragrafi `<p>`, grassetti |
| `categoria` | `Clinica` | Libera |
| `prezzo_tipo` | `gratis` / `pagamento` / `abbonamento` | |
| `prezzo` | `9` | € (al mese per gli abbonamenti) |
| `fi`, `fa` | icone Flaticon / Font Awesome | |
| `tinta` | `#F0B64A` | Colore dell'icona |
| `schermate` | JSON | `[{"img":"assets/images/store/x-1.svg","t":"Didascalia"}]` — una o più; senza `img` diventa una card a gradiente `{t, s}` |
| `disponibile` | `1` | `0` = "In arrivo" (non installabile) |
| `versione` | `1.0` | Vedi § Aggiornamenti |
| `autore` | `NASTech` | Mostrato nel Negozio |
| `novita` | `1` | Badge **NUOVO** |

Il seed è **idempotente per codice e versione**: alzando la `versione` nel seed, la scheda
si aggiorna da sola su tutte le installazioni al primo avvio.

## 4. Passo 3 — gli hook server (estensione.php)

`estensione.php` viene incluso dal bootstrap a ogni richiesta, solo se attiva.
Qui si registrano gli hook con `Hooks::add(punto, funzione)`:

```php
<?php
// nuovo ruolo utente
Hooks::add('utenti.ruoli', fn(array $ruoli) => [...$ruoli, 'dietista']);

// nuova voce in Procedure (con una vista tutta tua)
Hooks::add('procedure.voci', function (array $voci) {
    $voci['dieta'] = ['label' => 'Piani alimentari', 'desc' => 'I piani dei pazienti',
        'fi' => 'salad', 'fa' => 'fa-solid fa-bowl-food', 'tipo' => 'vista', 'vista' => 'dieta'];
    return $voci;
});

// reagire a un aggiornamento di versione (migrazioni dell'estensione)
Hooks::add('estensione.aggiornata', function (string $codice, ?string $da, string $a) {
    if ($codice !== 'mia_estensione') return;
    // es. Database::run('ALTER TABLE ...') o Seed dei propri archivi
});
```

**Punti server disponibili oggi** (`Hooks::filter` trasforma un valore, `Hooks::run` è un evento):

| Punto | Tipo | Riceve |
|---|---|---|
| `utenti.ruoli` | filter | `array $ruoli` |
| `procedure.voci` | filter | `array $voci` (label, desc, fi/fa, tipo archivio/vista) |
| `referto.sezioni` | filter | `array $sezioni, array $visita` — le sezioni del referto alla chiusura; la visita include `dati` (§ 5-bis) |
| `estensione.aggiornata` | run | `$codice, $versionePrima, $versioneDopo` |
| `impostazioni.pannelli` | filter | `array $pannelli` — una card tua in Impostazioni (§ 5-ter) |
| `impostazioni.chiavi` | filter | `array $chiavi` — altre chiavi salvabili da `ajax/impostazioni.php` (oltre a quelle dei pannelli) |
| `auth.permessi` | filter | `array $mappa` — i permessi per ruolo (`core/permessi.php`): aggiungi un ruolo tuo o un permesso a un ruolo esistente |
| `auth.can` | filter | `bool $ok, string $permesso, array $utente` — l'ultima parola su un permesso (usalo con parsimonia) |

**Permessi.** Dalla 1.17 ogni endpoint dichiara cosa serve per ogni azione: `Api::run([...], ['*' => 'dieta.leggi', 'salva' => 'dieta.modifica'])`.
Inventa i tuoi permessi con il prefisso dell'estensione e assegnali ai ruoli con `auth.permessi`; l'amministratore dello studio li ha tutti:

```php
Hooks::add('auth.permessi', function (array $m) {
    $m['medico'][] = 'dieta.*';            // il medico fa tutto sulla dieta ('*' lo copre già, è solo un esempio)
    $m['segreteria'][] = 'dieta.leggi';    // la segreteria la consulta
    $m['dietista'] = ['agenda.leggi', 'pazienti.leggi', 'dieta.*'];   // il ruolo nuovo (vedi utenti.ruoli)
    return $m;
});
```
Le voci di Procedure possono dichiarare `'permesso' => 'dieta.leggi'`; in JavaScript `DRF.can('dieta.modifica')` nasconde i pulsanti a chi non può.

Le estensioni possono creare **le proprie tabelle** (conviene prefissarle: `ext_dieta_piani`)
dentro l'hook `estensione.aggiornata` o al primo uso, con `Database::run('CREATE TABLE IF NOT EXISTS …')`.
Un endpoint AJAX proprio si dichiara in `estensioni/<codice>/ajax.php` (ritorna le azioni, vedi § 7-bis) e si chiama con `DRF.api.ext('codice', 'azione')`; il vecchio schema `ajax/<nome>.php` con `Estensioni::attiva()` in testa resta valido solo per le estensioni distribuite con il programma. Nel SaaS le tue tabelle nascono nel database **dello studio**
(quello attivo quando gira il tuo codice: `core/Tenant.php` ha già scelto la connessione giusta), mai in quello comune.

## 5. Passo 4 — gli hook client (js)

Il file js si aggancia con `DRF.hooks`:

```js
(function ($) {
  'use strict';
  DRF.hooks.add('visita.pannello', function (ctx) {
    // ctx.$root    → il contenitore della sezione Visita
    // ctx.visita   → la visita corrente (null se nessuna in corso)
    // ctx.paziente → il paziente corrente
    // ctx.setNota(testo) → aggiunge un paragrafo all'anamnesi
    const $box = $('<div class="mia-box">…</div>').appendTo(ctx.$root.find('#vNote').closest('.field'));
  });
})(jQuery);
```

**Punti client disponibili oggi:**

| Punto | Tipo | Contesto |
|---|---|---|
| `visita.pannello` | run | `{ $root, visita, paziente, getDati, setDati, setDiagnosi, sostituisci, ripristina, setNota }` — a ogni render della visita |

E in più tutto il **bus eventi** già esistente (`DRF.on('visita:avviata')`,
`DRF.on('modulo:aperto')`, …) e le API pubbliche (`DRF.ui`, `DRF.rich.use()` per i moduli
dell'editor, `DRF.form`, `DRF.api`). Con questi strumenti un'estensione può **aggiungere un
pannello alla visita** (il grafico BMI), **precompilare o trasformare i campi** al cambio di
prestazione (una visita diabetologica che aggiunge le sue sezioni quando la prestazione è
"Visita diabetologica"), o **portare voci nuove** in Procedure e ruoli nuovi fra gli utenti.
Servisse un punto che ancora non c'è, aggiungerlo al core è una riga
(`Hooks::run`/`DRF.hooks.run` nel posto giusto): il contratto resta stabile per tutte le estensioni.

## 5-bis. Dati propri nella visita e sezioni nel referto (il ciclo completo)

Ogni estensione ha il suo **spazio dati strutturato sulla visita**: la colonna `visite.dati`
(JSON, una chiave per estensione, fusa per codice — più moduli convivono). Dal client:

```js
DRF.hooks.add('visita.pannello', function (ctx) {
  const salvati = ctx.getDati('mia_estensione') || {};      // ripristino a ogni render
  // ... disegna i campi, e a ogni modifica:
  ctx.setDati('mia_estensione', { um: '2026-08-14', ciclo: 'Regolare' });
  // → il core li fa viaggiare nell'AUTOSAVE della bozza, insieme a tutto il resto
});
```

E alla chiusura della visita, l'hook server `referto.sezioni` li porta **nel referto**:

```php
Hooks::add('referto.sezioni', function (array $sezioni, array $v): array {
    $miei = $v['dati']['mia_estensione'] ?? null;
    if ($miei) $sezioni['La mia sezione'] = '• ...';
    return $sezioni;   // ordine libero: puoi anche ricostruire l'array per inserirla dove vuoi
});
```

Con questi due pezzi una **visita specialistica completa** è un'estensione normale:
l'esempio funzionante è **Visita ginecologica** nel Negozio (`estensioni/gineco/`):
il js disegna la scheda (UM, ciclo, G·P·A, contraccezione, pap test, ecografia, note),
`setDati` la salva con la bozza, e `estensione.php` compone la sezione
«Valutazione ginecologica» del referto, inserita dopo l'esame obiettivo.
Per la trasformazione radicale c'è il primitivo dedicato: **`ctx.sostituisci($contenuto)`**
nasconde lo stepper e i tab standard e consegna un contenitore a tutta colonna dove montare
la propria visita (testata paziente, storico e «Chiudi e genera referto» restano del core);
`ctx.ripristina()` torna alla visita standard, `ctx.setDiagnosi([...])` scrive la diagnosi
della visita (così elenchi, fatturazione e storico continuano a funzionare). La versione 1.1
di **Visita ginecologica** fa esattamente questo: sostituzione completa — anamnesi ginecologica,
esame ginecologico, accertamenti, conclusioni — e referto ricostruito da zero dall'hook
`referto.sezioni` (che può ignorare le sezioni standard e restituire le proprie).

## 5-ter. Un pannello tuo in Impostazioni

Le Impostazioni sono estendibili: una card con i tuoi campi, caricata e salvata dal core come quelle standard.
Lato PHP dichiari il pannello (titolo, icona, HTML dei campi, chiavi):

```php
Hooks::add('impostazioni.pannelli', function (array $p) {
    $p['dieta'] = [
        'titolo' => 'Piani alimentari', 'fi' => 'salad', 'fa' => 'fa-solid fa-bowl-food',
        'html' => '<p class="small muted" style="margin-bottom:10px">Valori predefiniti dei nuovi piani.</p>
                   <div class="grid2">
                     <div class="field"><label>Kcal giornaliere</label><input class="input" name="dieta_kcal" inputmode="numeric"></div>
                     <div class="field"><label>Pasti al giorno</label><select class="select" name="dieta_pasti"><option>3</option><option>5</option></select></div>
                   </div>
                   <div class="pref"><div><b>Allegare il piano al referto</b></div><button class="switch" type="button" data-name="dieta_allega" aria-label="Allega"></button><input type="hidden" name="dieta_allega"></div>',
        'chiavi' => ['dieta_kcal', 'dieta_pasti', 'dieta_allega'],   // solo queste vengono salvate
        'salva' => 'Salva dieta',                                     // etichetta del pulsante (omesso = "Salva")
        'permesso' => 'impostazioni.modifica',                        // chi vede la card (omesso = impostazioni.leggi)
    ];
    return $p;
});
```

**Chi vede il pannello**: la chiave `'permesso'` decide (predefinito `impostazioni.leggi`, che la segreteria ha in sola lettura). Per un pannello riservato usa `'permesso' => 'impostazioni.modifica'` (medico e amministratore) o `'utenti.gestisci'` (solo amministratore); per uno personale, che ogni utente vede, `'permesso' => null` e salva le chiavi con il prefisso `<codice>_u<id utente>_…`. Regole: la chiave del pannello e i `name` dei campi usano il **prefisso della tua estensione** (`dieta_…`), così non collidono con le impostazioni del core o di altre estensioni; ogni campo con `name` uguale a una chiave viene **riempito da solo** all'apertura e **salvato** dal pulsante della card (`Impostazione::get('dieta_kcal')` per leggerlo lato PHP); gli switch seguono il pattern `data-name` + input nascosto, come nel core. Nel SaaS le impostazioni sono dello studio (database dedicato), quindi ogni studio ha i suoi valori.

Lato JavaScript, se ti serve reagire (anteprime, pulsanti, validazioni), c'è l'hook `impostazioni.pronto`, che gira ogni volta che il pannello Impostazioni viene aperto e riempito:

```javascript
DRF.hooks.add('impostazioni.pronto', ctx => {
    const $card = ctx.pannello('dieta');            // la tua card (jQuery); ctx.impostazioni = tutte le chiavi
    $card.find('[name=dieta_kcal]').off('input.dieta').on('input.dieta', function () { /* anteprima */ });
});
```

Se preferisci salvare per conto tuo (endpoint AJAX dedicato) ometti `chiavi`: la card non avrà il pulsante del core e ci metti i tuoi.

**L'esempio completo è nello Store: "Consigli di fine visita"** (`estensioni/consigli/`, codice `consigli`): `estensione.php` registra il pannello in Impostazioni (testo predefinito, frasi rapide, switch "sempre nel referto") e la sezione "Consigli" del referto; `js/consigli.js` aggiunge la card in visita — legge le impostazioni da `ajax/consigli.php`, le frasi rapide sono chip, il testo va in `dati.consigli` con `ctx.setDati()` — e con `impostazioni.pronto` mostra il conteggio delle frasi nel pannello. Installala e leggi i quattro file: sono meno di cento righe.

## 6. Passo 5 — un'app per la Scrivania (icona sul desktop)

Le estensioni possono portare una **finestra della Scrivania**: cartella `modules/<key>/`
con `key.def`, `key.php`, `js/key.js` come i moduli di serie, più una riga nel `.def`:

```
estensione: mia_estensione
```

L'icona compare nel dock **solo se l'estensione è installata** (è così che funziona il gioco
Ritmo): all'installazione dal Negozio il dock si ricarica da solo.

## 7. L'esempio completo: "BMI in visita"

L'estensione `bmi` distribuita nel Negozio è l'esempio guida, in due file:

**`estensioni/bmi/estensione.php`** — vuoto (nessun hook server necessario), con i commenti sulla forma.

**`estensioni/bmi/js/bmi.js`** — si aggancia a `visita.pannello`, disegna il calcolatore
(peso × altezza → BMI + categoria) e con `ctx.setNota()` scrive il risultato in anamnesi.
Leggilo: sono ~30 righe e coprono l'intero ciclo (hook, UI, interazione con la visita).

## 7-bis. Lo Store: pacchetti, repository, approvazione, voti

Dalla 1.19 un'estensione non si copia più a mano: è un **pacchetto** (ZIP) che sta in un **repository**, e lo Store lo scarica, lo verifica e lo installa. Il flusso completo:

```
estensioni/<codice>/ + manifest.json
        │  php strumenti/pacchetto.php <codice> <repository>
        ▼
<repository>/pacchetti/<codice>-<versione>.zip
        │  php strumenti/repository.php <repository>      (rigenera catalogo.json: sha256, dimensione, stato)
        ▼
<repository>/catalogo.json   ──►  stato: in_revisione ──(revisore prova e approva)──► approvato
        │
        ▼  config store.repository = URL o cartella
Store (Scrivania) → Scarica e installa → verifica sha256, requisiti, dipendenze → estensioni/<codice>/ → attiva
```

### manifest.json (obbligatorio, alla radice del pacchetto)

```json
{
  "codice": "dieta",                       // immutabile dopo la pubblicazione: lettere minuscole, numeri, _ (max 40)
  "nome": "Piani alimentari",
  "sottotitolo": "Una riga sotto il nome",
  "descrizione": "<p>HTML: la scheda nello Store.</p>",
  "versione": "1.2",                       // confrontata con version_compare: 1.2 < 1.10
  "autore": "MedSoft Italia", "autore_url": "https://medsoft.example",
  "categoria": "Clinica",                  // Clinica, Documenti (privacy, consensi, modelli…), Amministrazione, Accoglienza, Comunicazione, Produttività, Gestione, Integrazioni, Svago
  "prezzo_tipo": "gratis", "prezzo": 0,    // gratis | pagamento | abbonamento (i pagamenti passano dal portale)
  "fi": "salad", "fa": "fa-solid fa-bowl-food", "tinta": "#4FC3A1",
  "schermate": [{ "img": "assets/shot-1.svg", "t": "Didascalia" }],   // immagini nella tua cartella (assets/…)
  "richiede": { "drfacile": "1.19", "php": "8.1", "estensioni_php": ["zip"], "drfacile_max": "1.99" },
  "dipendenze": ["bmi"],                   // altre estensioni: si installano insieme, prima della tua
  "conflitti": ["gineco"],                 // se una di queste è attiva l'installazione si ferma
  "capabilities": ["visite.dati", "referto.sezioni", "comunicazioni.invia", "rete_esterna"],   // cosa usa: lo Store lo mostra
  "novita": 1, "ordine": 50
}
```

`capabilities` è **dichiarativo**: dice all'utente (e al revisore) cosa tocca l'estensione — dati delle visite, referti, invio di comunicazioni, rete esterna. Un'estensione che fa cose non dichiarate non passa la revisione.

### Contenuto del pacchetto

```
manifest.json          la scheda (sopra)
estensione.php         hook server (incluso a ogni richiesta se attiva)
ajax.php               endpoint proprio: ritorna ['azioni' => [...], 'permessi' => ...] — raggiunto da ajax/ext.php?ext=<codice>
js/*.js  css/*.css     caricati con l'app se attiva
modules/<key>/         app della Scrivania (key.def, key.php, js/, css/): scoperte da sole, icona solo se attiva
assets/                immagini, font, dati
```

Niente file in `ajax/` o `modules/` del core: un pacchetto vive tutto dentro `estensioni/<codice>/`. L'endpoint si chiama dal client con `DRF.api.ext('dieta', 'salva', {...})` (POST con dati, GET senza); il router verifica che l'estensione sia attiva e passa ad `Api::run` (login, CSRF, permessi). La cartella `estensioni/` è protetta: PHP, JSON e SQL non sono raggiungibili dal browser, `js/`, `css/` e `assets/` sì.

### Repository

Una cartella con `catalogo.json` e `pacchetti/*.zip`, pubblicata via HTTPS (o locale per sviluppare). `strumenti/repository.php` legge i manifest dentro gli ZIP, calcola sha256 e dimensione, tiene **una sola versione per codice** (la più alta) e conserva stato, novità, ordine e voti fra una generazione e l'altra. Lo Store legge `catalogo.json` (cache `store.cache` secondi), scarica lo ZIP e **rifiuta** il pacchetto se sha256 non coincide, se il codice o la versione nel manifest interno non coincidono con il catalogo, se i requisiti non sono soddisfatti, o se un percorso nello ZIP esce dalla cartella.

### Approvazione (autori terzi)

Ogni pacchetto ha `stato` nel catalogo: **in_revisione** (default per un pacchetto nuovo), **approvato**, **respinto**. Gli studi vedono solo gli approvati. Chi revisiona mette in `config.php` `store.revisore = true`: nello Store compare "modalità revisore", i pacchetti in revisione hanno il badge e si possono installare per provarli. Approvazione: `php strumenti/repository.php <repo> approva <codice>`; `respingi` lo toglie dagli store (resta attivo dove già installato).

Percorso per un autore terzo: manda lo ZIP → il revisore lo mette in `pacchetti/`, rigenera il catalogo, lo prova con il flag revisore, legge il codice (non c'è sandbox: `estensione.php` gira dentro DRFacile, con accesso ai dati sanitari), controlla che faccia solo ciò che dichiara in `capabilities` → approva.

### Ciclo di vita

| Hook | Quando | Argomenti |
|---|---|---|
| `estensione.installata` | prima attivazione nello studio | `$codice, $versione` — crea qui le tue tabelle (`ext_<codice>_…`) |
| `estensione.attivata` | riattivata dopo una disattivazione | `$codice` |
| `estensione.aggiornata` | i file sono passati a una versione nuova | `$codice, $da, $a` — migrazioni |
| `estensione.disattivata` | spenta | `$codice` — non cancellare nulla |
| `estensione.rimossa` | file cancellati dal disco | `$codice` — i dati restano comunque |

Gli hook di ciclo di vita si registrano in `estensione.php`, che viene incluso anche al momento dell'installazione.

### Voti e recensioni

Chi ha installato un'estensione può votarla (1-5 stelle) dalla scheda. Il voto vive nel database comune (`store_voti`, uno per studio) e, se il repository lo prevede (`store.voti_url`), viene inviato anche lì con un identificativo anonimo dell'installazione; la media mostrata è quella del catalogo se presente, altrimenti quella locale. La colonna `recensione` è già predisposta per le recensioni scritte.

## 7-ter. Extension API 2.0: agganciarsi a qualsiasi parte del programma

Dalla 1.20 un'estensione può aggiungere o modificare praticamente tutto. Tre famiglie di punti di aggancio.

### A. Struttura (hook PHP, `Hooks::add` in estensione.php)

| Hook | Tipo | Cosa fa |
|---|---|---|
| `moduli.elenco` | filter `array $moduli` | **Un modulo intero sulla costa**: `$m[] = ['key' => 'dieta', 'label' => 'Dieta', 'fi' => 'salad', 'fa' => 'fa-solid fa-bowl-food', 'permesso' => 'dieta.leggi', 'vista' => Store::dir('dieta') . '/views/dieta.php', 'css' => ['estensioni/dieta/css/dieta.css'], 'js' => ['estensioni/dieta/js/dieta.js']]`. La vista è un file PHP con il pannello; il js fa `DRF.register('dieta', { title, init(), show(opts) })` come un modulo del core. Tasti 1-0, ricerca e menu funzionano da soli |
| `menu.voci` | filter `array $voci` | Voci nel menu dell'utente (tasto destro sull'avatar): `['label', 'fi', 'fa', 'modulo' => 'dieta', 'opts' => [...]]` oppure `'url'` o `'comando'` (evento `DRF.emit`) |
| `scorciatoie` | filter `array $s` | Scorciatoie dichiarate (`['label', 'tasti' => 'Ctrl+Shift+D']`) mostrate nell'aiuto `?`; quelle vere si registrano in JS con `DRF.tasti.add('ctrl+shift+d', fn, 'Etichetta')` |
| `notifiche.tipi` | filter `array $tipi` | Tipi di notifica in più (`dieta`); l'icona lato client con l'hook JS omonimo |
| `notifiche.tipo` | filter `$tipo, $titolo, $testo, $link` | Cambia il tipo di una notifica prima che venga creata |
| `scadenzario.controlli` | run `$oggi` | **Job quotidiano senza cron**: gira al primo accesso del giorno, nello studio. Scorte, scadenze, sincronizzazioni; crea scadenze con `Scadenzario::aggiungi()` o notifiche |
| `cli.comandi` | filter `array $c` | Comandi per `php strumenti/drf.php nome:comando --opz=…` (vedi l'intestazione dello script) |
| `impostazioni.pannelli` / `impostazioni.chiavi` | filter | Pannello proprio in Impostazioni (§ 5-ter) |
| `procedure.voci`, `utenti.ruoli`, `auth.permessi`, `referto.sezioni` | filter | Come prima |
| `estensione.installata/attivata/aggiornata/disattivata/rimossa` | run | Ciclo di vita (§ 7-bis) |

### B. Interfaccia (slot JS, `DRF.hooks.add` nei tuoi js/)

Tutti seguono il pattern di `visita.pannello`: ricevono un `ctx` con il **record**, il **container** (`$root`) e le **azioni del core** per non ricostruire nulla.

| Slot | Quando gira | `ctx` |
|---|---|---|
| `visita.pannello` | apertura/aggiornamento della visita | `$root, visita, paziente, sostituisci(), adotta(), ripristina(), getDati(), setDati(), setDiagnosi(), setNota(), chiudi()` |
| `paziente.scheda` | scheda del paziente renderizzata | `$root, paziente, storico, risposta (tutta la risposta di pazienti/get, con ciò che hai allegato via api.dopo), aggiungi(html, 'prima'|'dopo'|'fondo'), azione(label, fn, {fi, fa}), ricarica(), avviaVisita(), prenota()` |
| `agenda.appuntamento` | form di prenotazione aperta | `$root, valori, tipi, campo(html) (inviato con la form), val(name), setVal(name, v)` — lato server il filtro `appuntamento.salva` riceve anche i tuoi campi |
| `fattura.editor` | editor fattura aperto | `$root, editor, dati (listino, iva, metodi…), fattura (se in modifica), righe(), aggiungiRiga({descrizione, quantita, prezzo, iva_id}), ricalcola(), campo(html)` |
| `referto.editor` | referto aperto (bozza o firmato) | `$root, $paper, $azioni, referto, paziente, medico, bozza, azione(label, fn, {fi, fa})` |
| `ricetta.editor` | righe della ricetta ridisegnate | `$root, righe, farmaci, aggiungi(farmaco), rendi(), paziente()` |
| `topbar.azioni` (filter) | cambio modulo | ritorna `[{ label, fi, fa, run, primario }]` per il modulo `key` ricevuto: pulsanti nella barra del titolo |
| `dashboard.widget` | Scrivania aperta | `$root, aggiungi(html, titolo), apri(app), vai(modulo, opts)`: riquadri sotto la testata |
| `search.comandi` | avvio | `comando({ label, fi, fa, kw, run })`: voci nella ricerca ⌘K |
| `menu.voci` (filter) | menu dell'avatar | trasforma/aggiunge voci `{ label, fi, fa, run }` |
| `notifiche.tipi` (filter) | rendering notifiche | `{ tipo: [fi, fa] }` per i tipi tuoi |
| `impostazioni.pronto` | pannello Impostazioni riempito | `$root, impostazioni, pannello(key)` |

Esempio, un pannello nella scheda paziente con un pulsante nella barra:

```javascript
DRF.hooks.add('paziente.scheda', ctx => {
  DRF.api.ext('dieta', 'piano', { paziente_id: ctx.paziente.id }).then(p => {
    ctx.aggiungi(`<div class="card dieta-card"><h3>Piano alimentare</h3>${p ? DRF.esc(p.titolo) : '<span class="muted">Nessun piano</span>'}</div>`, 'prima');
    ctx.azione(p ? 'Apri il piano' : 'Nuovo piano', () => DRF.nav.go('dieta', { paziente: ctx.paziente.id }), { fi: 'salad', fa: 'fa-solid fa-bowl-food' });
  });
});
DRF.hooks.add('topbar.azioni', (azioni, modulo) => modulo === 'pazienti' ? [...azioni, { label: 'Diete', fi: 'salad', fa: 'fa-solid fa-bowl-food', run: () => DRF.nav.go('dieta') }] : azioni);
DRF.tasti.add('ctrl+shift+d', () => DRF.nav.go('dieta'), 'Apri Dieta');
```

### C. Dati e documenti (hook PHP)

| Hook | Tipo | Argomenti |
|---|---|---|
| `paziente.salva` | filter | `array $dati, array $in` — prima del salvataggio: completa, normalizza, valida (lancia `ApiException` per rifiutare) |
| `paziente.salvato` / `paziente.eliminato` | run | `$id, $dati, $nuovo` / `$id` |
| `appuntamento.salva` / `appuntamento.salvato` | filter / run | `$in` (con i campi aggiunti da `agenda.appuntamento`) / `$id, $risultato` |
| `visita.chiudi` | filter | `array $in, int $id` — prima della chiusura e del referto |
| `visita.chiusa` | run | `$id, $refertoId, $visita` |
| `fattura.emetti` | filter | `array $in` — righe, note, metodo prima dell'emissione |
| `fattura.emessa` / `fattura.incassata` | run | `$id, $fattura` — fatturazione elettronica, contabilità esterna |
| `referto.firmato` / `referto.inviato` | run | `$id, $referto` / `$id` |
| `referto.invia` | filter | `bool $ok, $id, $referto` — **l'invio vero** (email, PEC, FSE): ritorna `false` per bloccare |
| `ricetta.emessa` | run | `$id, $ricetta` — invio al Sistema TS |
| `documento.dati` | filter | `array $dati, $tipo, $id` — arricchisce ciò che il template riceve (intestazioni, loghi, righe, sezioni) |
| `documento.template` | filter | `string $percorso, $tipo, $dati` — un template tuo al posto di `docs/templates/<tipo>.php` |
| `documento.render` | filter | `string $html, $tipo, $dati` — ultimo passaggio sull'HTML (piè di pagina, watermark, QR) |
| `export.formati` | filter | `array $formati` — `['csv_pazienti' => ['label', 'mime', 'ext', 'fn' => fn(array $tabelle): string]]`: compare nel menu "Esporta" delle Impostazioni |
| `backup.contenuto` | filter | `array $tabelle` — aggiungi le tue `ext_*` al backup e all'export |

### Le estensioni di riferimento

- **Sentinella** (pacchetto `sentinella-1.0.zip` nel repository di esempio, sorgenti in `docs/esempi/sentinella/`): usa tutte e tre le famiglie. `estensione.php` registra modulo sulla costa, voce nel menu, scorciatoia, tipo di notifica, job quotidiano, comandi CLI, pannello impostazioni, filtri e eventi su pazienti/visite/fatture, il promemoria sul referto e la tabella nel backup; `migrations/001_segnalazioni.php` crea la tabella; `ajax.php` l'endpoint; `js/sentinella.js` gli slot (scheda paziente, Scrivania, barra dell'agenda, ricerca, referto); `modulo/sentinella.js` + `views/sentinella.php` il modulo. Nota la cartella `modulo/`: `js/` e `css/` vengono caricati sempre, il modulo invece lo carica il layout con i percorsi dichiarati in `moduli.elenco`.
- **Bacheca personale** (pacchetto `bacheca-1.0.zip`, sorgenti in `docs/esempi/bacheca/`): il menu sull'avatar. Voci statiche in PHP (`menu.voci` → `DRF.config.menu`), voci dinamiche nel filtro JS omonimo (riceve la lista pronta e la trasforma: separatori con `{ sep: true }`, `danger`, `kbd`), endpoint proprio, impostazioni per utente con prefisso del codice.

### D. Dalla 1.21: i muri caduti

| Cosa | Come |
|---|---|
| **Campi nelle form del core** | `Hooks::add('form.campi', fn(array $def, string $form) => …)`: aggiungi voci a `$def['fields']` di `paziente`, `appuntamento`, `prestazione`, `documento`… (stessa sintassi di `form/definitions/`, `'row' => 90` per metterli in fondo). I campi chiamati **`<codice>_<campo>`** vengono **salvati da soli** nella colonna JSON `dati` di pazienti e appuntamenti (`$paziente['dati']['dieta']['kcal']`) e ricompaiono nella form in modifica. Lato client `DRF.hooks.add('form.aperta', ctx => …)` con `ctx.name, ctx.$root, ctx.val(), ctx.setVal()` per la logica sui campi. |
| **Endpoint del core** | `api.prima` (filter `$in, $sezione, $azione`) e `api.dopo` (filter `$out, $sezione, $azione, $in`): trasformi input e risposta di **qualsiasi** azione AJAX — `$sezione` è il file (`pazienti`, `visita`…) o `ext:<codice>`. Esempio: allegare i tuoi dati alla risposta di `pazienti/get`: `Hooks::add('api.dopo', fn($out, $s, $a) => $s === 'pazienti' && $a === 'get' ? $out + ['dieta' => Dieta::di($out['paziente']['id'])] : $out);` |
| **Tipi di documento** | `documenti.tipi` (filter): registri `'esame_lab' => ['label', 'template' => percorso, 'dati' => fn(int $id) => ['doc' => $riga, …]]`. Da lì `ajax/documenti.php?action=render&tipo=esame_lab&id=…`, `Documenti::archivia('esame_lab', $id)` (evento `documento.archiviato` per collegare il file al tuo record), archivio documentale, `documento.dati/template/render`: tutto come per referti e fatture. La riga `doc` deve avere `data` e, se c'è, `paziente_id`. |
| **Visita, lato server** | `visita.salva` (filter `$in, $visita` a ogni autosalvataggio, anche sui tuoi `dati`), `visita.avviata` (run `$id, $pazienteId, $appuntamentoId`), oltre a `visita.chiudi`/`visita.chiusa`. Un percorso con vita propria (esami richiesti oggi e refertati fra un mese) va nelle tue tabelle `ext_*`, agganciato alla visita da `visite.dati` e da questi eventi. |
| **Schema del core** | Non si estende: le colonne JSON `dati` di `pazienti`, `appuntamenti` e `visite` sono tue (sempre sotto il tuo codice), tutto il resto nelle `ext_*` con le migrazioni. |
| **Sostituire una vista** | `views.override` (filter `$percorso, $chiave`): `sections/<modulo>` per un pannello della costa, `procedure/<vista>` per una pagina di Procedure, `impostazioni/pannelli` per un blocco tuo prima dei pannelli. Ritorni il percorso di un tuo file PHP (stesse variabili). Il js del modulo resta quello del core: aggancia i tuoi elementi con gli slot o con `modulo:aperto`. |

### Documenti, archivio, quota (1.22)

- Non costruire mai URL di documenti a mano: `DRF.doc.apri(tipo, id, {html, stampa, scarica})`, `DRF.doc.file(rel)` oppure `<button data-doc="tipo" data-id="…" data-opts="html,stampa">`; lato PHP `Documenti::link('render', $tipo, $id)` / `Documenti::link('file', '', $rel)`. I link sono firmati e scadono; il tipo decide il permesso (`Documenti::permesso`).
- PDF: `Documenti::pdf($tipo, $id)` o `Documenti::pdfDaHtml($html)` (dompdf); i template restano HTML.
- File: `Spazio::scrivi($rel, $bytes)` (capability `spazio.scrivi`, controllo della quota), `Spazio::elimina($rel)`, `Spazio::base()`, `Spazio::stato()`. I file di un'estensione vanno sotto `<codice>/…`: il primo segmento del percorso decide il permesso per leggerli (i tipi non del core → `documenti.leggi`). `documento.archiviato` ora porta anche il paziente: `($tipo, $id, $rel, $pazienteId)`.
- Slot: `paziente.scheda` ha `ctx.azione(label, fn, { fi, fa, icona: true, dopo: '#pdEdit' })` (solo icona, posizione); filtro JS `pazienti.menu` (`(voci, paziente)`) per il tasto destro sul paziente; `DRF.module('visita').paziente()` per sapere chi è in visita (es. in `topbar.azioni`).
- `DRF.ui.prompt(titolo, etichetta, valore)` → promise con il testo; `DRF.api.ext(codice, azione, formData)` per gli upload (i file in `$_FILES`); pannello laterale senza pulsanti: `$('#sheet').addClass('wide nofoot')` dopo `DRF.ui.openSheet`.
- Template: includi `_stile.php` (parametrico su `$stampa`), poi `$destra = '<div class="destinatario">…</div>'; include _testata.php` e in fondo `include _piede.php` (con `$piede_extra` facoltativo): così il tuo documento eredita margini, logo, mittente e piè di pagina configurati dallo studio. `Documenti::stampa()` e `Documenti::mittente($tipo, $medico, $stampa)` sono pubblici.
- Invio email con finestra: `DRF.doc.invia({ tipo, id })` o `DRF.doc.invia({ file, paziente_id, documento })`; lato PHP `Documenti::inviaEmail(...)` e `Messaggi::compila(codice|per, canale, Messaggi::variabili($paziente, $ctx))`; segnaposto aggiuntivi con il filtro `messaggi.variabili`. Evento `documento.inviato` (`$tipo, $id, $email, $comunicazioneId`); acquisti: evento `store.acquisto` (`$codice, $ordineId, $metodo`).
- Esempio completo: **Gestione documentale** (`docs/esempi/documentale/`, pacchetto nel repository): cartelle di sistema riempite da `documento.archiviato`, upload nell'archivio con quota, anteprime PDF/immagini/Word (mammoth incluso nel pacchetto), menu contestuale, drag&drop.

### Traduzioni (gettext, dalla 1.26)

DRFacile è multilingua con **gettext standard** (`.po`/`.mo`, Poedit, `msgctxt`, plurali) letto da un loader in PHP puro (`core/I18n.php`): nessuna dipendenza dall'estensione gettext dell'hosting. Le stringhe sorgente sono in **italiano**; con l'italiano non serve alcun catalogo.

```php
__('Ultima mestruazione', 'ginecologia');                 // il dominio È il codice dell'estensione (regola dello Store)
_p('medical', 'Visita', 'ginecologia');                   // contesto per le stringhe ambigue (msgctxt)
_n('%d esame', '%d esami', $n, 'ginecologia');            // plurali (sprintf incluso)
```
```javascript
DRF.__('Ultima mestruazione', 'ginecologia');  DRF._p('medical', 'Visita', 'ginecologia');  DRF._n('%d esame', '%d esami', n, 'ginecologia');
```
I cataloghi JavaScript **non si scrivono**: il core li genera dai `.mo` (`DRF.config.i18n`, un dominio per estensione attiva). Il traduttore vede solo i `.po`.

Struttura dell'estensione:
```
estensioni/<codice>/locale/
  <codice>.pot                    template (php strumenti/i18n.php estrai <codice>)
  en_US.po  de_DE.po              traduzioni (Poedit)
  en_US/LC_MESSAGES/<codice>.mo   compilati (php strumenti/i18n.php compila <codice>, o Poedit)
```
Nel `manifest.json`: `"text_domain": "<codice>"` (deve coincidere con il codice: il repository rifiuta il pacchetto altrimenti) e `"languages": ["it_IT", "en_US"]` (mostrate nello Store). La lingua è **per utente** (Impostazioni → Lingua); il core registra il dominio dell'estensione da solo quando la carica. Esempio: `estensioni/consigli/locale/`.

### Capabilities applicate

Dalla 1.20 le capability del manifest **valgono davvero**. Il core sa sempre quale estensione sta girando (durante `estensione.php`, nei suoi hook, nel suo `ajax.php`, nelle migrazioni) e i servizi che toccano i dati o escono dal programma controllano il manifest: senza la capability l'operazione si ferma con un'eccezione, registrata nel log.

| Capability | Cosa sblocca |
|---|---|
| `pazienti.leggi` / `pazienti.scrivi` | `Paziente::find/all` / `save/delete` (e `Database::insert/update/delete` su `pazienti`) |
| `visite.leggi` / `visite.scrivi` | visite, referti e ricette in lettura / `Visita::save` |
| `referti.scrivi`, `ricette.scrivi`, `fatture.leggi`, `fatture.scrivi`, `agenda.scrivi` | i rispettivi modelli |
| `documenti.genera` | `Documenti::archivia` |
| `comunicazioni.invia` | `Comunicazioni::invia` |
| `notifiche.crea`, `scadenzario.crea` | `Notifica::aggiungi`, `Scadenzario::aggiungi` |
| `impostazioni.scrivi` | `Impostazione::set` su chiavi del core (le tue, `<codice>_…`, sono sempre libere) |
| `utenti.leggi` | `Utente::delloStudio` |
| `database.tabelle` | le migrazioni (`migrations/`) |
| `rete_esterna` | `Rete::get` / `Rete::post` (usa questi invece di curl: sono verificati e si leggono in revisione) |

Hook, slot di interfaccia e lettura delle proprie impostazioni **non** richiedono capability. Le tabelle `ext_*` sono libere. Non è un sandbox (PHP non lo permette): per il resto c'è la revisione, e un'estensione che aggira il core non viene approvata.

### Migrazioni

Le tabelle di un'estensione nascono in `migrations/NNN_nome.php` (§ intestazione di `core/Migrazioni.php`): ogni file gira una volta, in ordine, nel database dello studio, da solo all'installazione, alla riattivazione e all'aggiornamento (oppure `DRF_STUDIO=… php strumenti/estensione.php migra <codice>`). Si scrive in dialetto SQLite e su MySQL viene adattato: `Migrazioni::tabella('ext_dieta_piani', "id INTEGER PRIMARY KEY AUTOINCREMENT, paziente_id INTEGER NOT NULL, kcal INTEGER")`, `Migrazioni::colonna(...)`, `Migrazioni::indice(...)`. Richiede `database.tabelle`.

## 8. Versioni e aggiornamenti dei moduli

Il **codice** delle estensioni viaggia con gli aggiornamenti del programma (stesso zip).
Le **versioni** sono gestite su due piani:

1. **Catalogo** — la colonna `versione` in `store_moduli`. Alzandola (dal seed o dal portale)
   la scheda del Negozio si aggiorna ovunque.
2. **Installazioni** — la colonna `versione` nella tabella dedicata `estensioni`. A ogni avvio
   `Estensioni::aggiornamenti()` confronta con il catalogo: se diversa, aggiorna la riga e lancia
   l'hook **`estensione.aggiornata`** (lì l'estensione fa le sue migrazioni). Tutto automatico,
   nessun click richiesto al medico.

## 9. Prezzi, scadenze e pagamenti

- **gratis** → pulsante "Installa gratis" nel Negozio: `Estensioni::installa()` e via.
- **pagamento** (una tantum) → si attiva **dal portale DRFacile** dopo l'acquisto: nessuna scadenza.
- **abbonamento** → come sopra, ma con **scadenza**: `Estensioni::attiva()` ritorna `false`
  a scadenza superata (la funzione si spegne da sola, i dati restano); il rinnovo la riaccende.

L'attivazione remota usa lo strumento CLI (o le stesse query, dal backend):

```bash
php strumenti/estensione.php attiva magazzino          # una tantum: attiva senza scadenza
php strumenti/estensione.php attiva vocale +30         # abbonamento: 30 giorni
php strumenti/estensione.php proroga vocale +365       # rinnovo
php strumenti/estensione.php disattiva vocale
```

**Flusso Stripe (predisposto):** il portale crea una *Checkout Session* con
`metadata = { studio_id, estensione, periodo }`; al webhook `checkout.session.completed`
(o `invoice.paid` per i rinnovi ricorrenti) il backend risale allo studio e attiva/proroga
con i comandi qui sopra. Il programma non tocca mai carte o chiavi: i pagamenti vivono
tutti sul portale, e in `config/config.php` basta il blocco
`'portale' => ['url' => 'https://drfacile.it/portale']` per i pulsanti "Attiva dal portale".
Lo stesso identico flusso funziona con PayPal o un altro PSP: cambia solo il webhook.

## 10. Riepilogo: la checklist

1. Scegli il **codice** e crea `estensioni/<codice>/`.
2. Aggiungi la **scheda** al catalogo (seed in sviluppo, portale in produzione) con
   prezzo, screenshot (uno o più), versione `1.0`, autore.
3. Scrivi gli **hook server** in `estensione.php` (ruoli, voci, tabelle proprie).
4. Scrivi gli **hook client** in `js/` (+ `css/`) usando `DRF.hooks` e le API DRF.
5. Se serve un'**icona sulla Scrivania**, crea il modulo in `modules/` con `estensione: <codice>`.
6. Se serve un **endpoint**, crea `ajax/<nome>.php` con il gate in testa.
7. Proteggi ogni funzionalità con `Estensioni::attiva('<codice>')`.
8. Per gli aggiornamenti: alza la `versione` nel catalogo e migra nell'hook `estensione.aggiornata`.
