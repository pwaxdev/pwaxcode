/* Modulo Scrivania: Ritmo. Sequenza di colori e note (Web Audio) da ripetere; velocità crescente; record in localStorage; tasti 1-4. */
DRF.desk.register('ritmo', {
  init($win) {
    const K = 'drf_ritmo_record', NOTE = [329.63, 392.0, 466.16, 523.25];   // mi, sol, si♭, do
    const $r = $win.find('.ritmo'), $pads = $win.find('.ritmo-pad'), $msg = $win.find('.ritmo-msg'), $turno = $win.find('.ritmo-turno'), $rec = $win.find('.ritmo-record');
    let seq = [], pos = 0, stato = 'idle', ctx = null, record = +localStorage.getItem(K) || 0;
    $rec.text(record);
    const tono = (i, ms, tipo) => { try { ctx = ctx || new (window.AudioContext || window.webkitAudioContext)(); const o = ctx.createOscillator(), g = ctx.createGain(); o.type = tipo || 'sine'; o.frequency.value = NOTE[i] || 150; g.gain.setValueAtTime(0.0001, ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + ms / 1000); o.connect(g).connect(ctx.destination); o.start(); o.stop(ctx.currentTime + ms / 1000 + 0.05); } catch (e) { /* audio non disponibile */ } };
    const accendi = (i, ms) => new Promise(res => { const $p = $pads.eq(i).addClass('on'); tono(i, ms); setTimeout(() => { $p.removeClass('on'); setTimeout(res, 90); }, ms); });
    const velocita = () => Math.max(220, 520 - seq.length * 22);
    async function mostra() {
      stato = 'playing'; $r.removeClass('turn over').addClass('playing'); $msg.text(DRF.__('Osserva…'));
      await new Promise(r => setTimeout(r, 500));
      for (const i of seq) await accendi(i, velocita());
      stato = 'turn'; pos = 0; $r.removeClass('playing').addClass('turn'); $msg.text(DRF.__('Tocca a te: ripeti la sequenza.'));
    }
    function turno() { seq.push(Math.floor(Math.random() * 4)); $turno.text(seq.length); mostra(); }
    function gioca() { seq = []; $r.removeClass('over newrec'); $win.find('.ritmo-start').text(DRF.__('Ricomincia')); turno(); }
    function fine() {
      stato = 'over'; $r.removeClass('turn playing').addClass('over'); tono(-1, 500, 'sawtooth');
      const punti = seq.length - 1;
      if (punti > record) { record = punti; localStorage.setItem(K, record); $rec.text(record); $r.addClass('newrec'); $msg.text(`${DRF.__('Nuovo record:')} ${record}!`); DRF.ui.toast(`${DRF.__('Ritmo: nuovo record,')} ${record} ${record === 1 ? 'turno' : 'turni'}!`, 'success'); }
      else $msg.text(`${DRF.__('Sbagliato al turno')} ${seq.length}${DRF.__('. Record:')} ${record}.`);
      $win.find('.ritmo-start').text(DRF.__('Gioca ancora'));
    }
    async function premi(i) {
      if (stato !== 'turn') return;
      stato = 'busy'; await accendi(i, 180); stato = 'turn';
      if (seq[pos] !== i) return fine();
      if (++pos === seq.length) { $msg.text(seq.length >= 8 ? DRF.__('Impressionante!') : DRF.__('Bene!')); setTimeout(turno, 600); }
    }
    $win.on('click', '.ritmo-start', gioca).on('click', '.ritmo-pad', function () { premi(+this.dataset.p); });
    $win.on('keydown', e => { if (/^[1-4]$/.test(e.key)) { e.preventDefault(); premi(+e.key - 1); } });
    $win.attr('tabindex', 0);
  },
  open($win) { $win.trigger('focus'); }
});
