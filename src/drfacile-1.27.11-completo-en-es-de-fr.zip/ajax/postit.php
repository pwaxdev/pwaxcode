<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'list'   => fn(array $in) => ['postit' => Postit::delContesto(preg_replace('/[^a-z0-9_]/i', '', Api::str($in, 'sezione', 'main')), Api::int($in, 'record')), 'conteggi' => Postit::conteggi(preg_replace('/[^a-z0-9_]/i', '', Api::str($in, 'sezione', 'main')))],
    'save'   => fn(array $in) => Postit::salva($in),
    'delete' => function (array $in) { $ident = preg_replace('/[^a-z0-9_-]/i', '', Api::str($in, 'ident')); return ['eliminato' => Database::delete('postit', 'ident = ?', [$ident]) > 0]; },
]);
