<?php
/**
 * ESTENSIONE DI ESEMPIO: "BMI in visita" (codice: bmi)
 * Questo file viene incluso dal bootstrap SOLO se l'estensione è attiva (installata dal Negozio).
 * Qui si registrano gli hook lato server; questa estensione non ne ha bisogno,
 * ma il file mostra la forma. Esempi possibili:
 *
 *   Hooks::add('utenti.ruoli', fn(array $r) => [...$r, 'dietista']);
 *   Hooks::add('procedure.voci', function (array $voci) { $voci['dieta'] = [...]; return $voci; });
 *   Hooks::add('estensione.aggiornata', function (string $codice, $da, $a) { ... });
 */
