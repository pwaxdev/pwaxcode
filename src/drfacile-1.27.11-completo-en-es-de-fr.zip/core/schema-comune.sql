-- DRFacile · tabelle COMUNI a tutti gli ambienti (comuni, e in futuro AIFA, ICD9/ICD10…)
-- Vivono nel database indicato da db.common (se impostato) e sono referenziate con Database::comune('nome').

CREATE TABLE comuni (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cod_catastale VARCHAR(4) NOT NULL,
  nome VARCHAR(80) NOT NULL,
  provincia VARCHAR(2),
  cap VARCHAR(5),
  regione VARCHAR(40)
);
CREATE INDEX idx_comuni_nome ON comuni(nome);
