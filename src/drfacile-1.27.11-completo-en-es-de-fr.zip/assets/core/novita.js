/* Novità della versione: presentazione a schede alla prima apertura dopo un aggiornamento (docs/novita.json) */
DRF.novita = (function ($) {
  'use strict';
  let i = 0, n = null;
  function render() {
    const s = n.slides[i];
    $('#nvLeft').css('--tinta', s.tinta || 'var(--accent)').html(`<div class="nv-art"><span class="nv-ico">${DRF.icons.html(s.fi, s.fa)}</span><i class="nv-b1"></i><i class="nv-b2"></i><i class="nv-b3"></i></div>`);
    $('#nvTitolo').text(s.titolo); $('#nvTesto').text(s.testo);
    $('#nvDots').html(n.slides.map((_, k) => `<i class="${k === i ? 'on' : ''}" data-k="${k}"></i>`).join(''));
    $('#nvAvanti').html(i === n.slides.length - 1 ? DRF.__('Inizia') + ' <span>→</span>' : DRF.__('Avanti') + ' <span>→</span>');
    DRF.icons.apply($('#nvLeft')[0]);
  }
  function chiudi() { $('#novita').removeClass('in'); setTimeout(() => $('#novita').remove(), 350); DRF.api.post('impostazioni', 'novita_viste', {}); }
  return {
    mostra(dati) {
      n = dati; i = 0; if (!n || !n.slides || !n.slides.length) return;
      $('body').append(`<div class="novita" id="novita"><div class="nv-box"><button class="nv-skip" type="button" id="nvSkip">${DRF.__('Salta')}</button>
        <div class="nv-left" id="nvLeft"></div>
        <div class="nv-right"><div class="nv-vers">${DRF.esc(n.titolo || DRF.__('Novità'))}</div><h2 id="nvTitolo"></h2><p id="nvTesto"></p>
          <div class="nv-foot"><button class="btn primary" type="button" id="nvAvanti"></button><div class="nv-dots" id="nvDots"></div></div></div></div></div>`);
      render(); requestAnimationFrame(() => $('#novita').addClass('in'));
      $('#nvSkip').on('click', chiudi);
      $('#nvAvanti').on('click', () => { if (i < n.slides.length - 1) { i++; render(); } else chiudi(); });
      $('#nvDots').on('click', 'i', function () { i = +this.dataset.k; render(); });
      $(document).on('keydown.novita', e => { if (!$('#novita').length) { $(document).off('keydown.novita'); return; } if (e.key === 'Escape') chiudi(); if (e.key === 'ArrowRight') $('#nvAvanti').trigger('click'); if (e.key === 'ArrowLeft' && i > 0) { i--; render(); } });
    }
  };
})(jQuery);
