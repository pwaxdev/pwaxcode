<?php
/**
 * Gestione documentale: rende i template in docs/templates e archivia gli HTML in docs/archivio/<tipo>/<anno>/.
 * I documenti sono stampabili dal browser (Ctrl+P → PDF). Per generare PDF lato server è sufficiente
 * agganciare una libreria (es. dompdf) in Documenti::pdf().
 */
final class Documenti
{
    public const TIPI = ['referto', 'ricetta', 'fattura'];

    /**
     * I tipi di documento: quelli del core + quelli registrati dalle estensioni (hook documenti.tipi):
     *   $t['esame_lab'] = ['label' => __('Referto di laboratorio'), 'template' => Store::dir('esami') . '/templates/referto_lab.php',
     *                      'dati' => fn(int $id) => ['doc' => $riga (con 'data' e 'paziente_id'), 'valori' => …]];
     * Il documento si apre con ajax/documenti.php?action=render&tipo=esame_lab&id=…, si archivia con Documenti::archivia('esame_lab', $id)
     * e finisce nell'archivio documentale come quelli del core.
     */
    public static function tipi(): array
    {
        $core = [];
        foreach (self::TIPI as $t) $core[$t] = ['label' => ucfirst($t), 'template' => DRF_ROOT . "/docs/templates/$t.php", 'dati' => null];
        // la PROVA DI STAMPA: un referto finto per vedere margini, logo e intestazione (Impostazioni → Stampa)
        $core['prova'] = ['label' => __('Prova di stampa'), 'template' => DRF_ROOT . '/docs/templates/prova.php', 'dati' => fn(int $id) => ['doc' => ['id' => 0, 'data' => oggi(), 'tipo' => 'Prova di stampa', 'paziente_id' => 0],
            'paziente' => ['id' => 0, 'nome_completo' => 'Mario Rossi', 'indirizzo' => 'Via dei Platani 12', 'cap' => '20100', 'citta' => 'Milano', 'provincia' => 'MI', 'cf' => 'RSSMRA80A01F205X', 'eta' => 46, 'sesso' => 'M']]];
        $tutti = [];
        foreach ((array) Hooks::filter('documenti.tipi', $core) as $k => $d) if (preg_match('/^[a-z][a-z0-9_]*$/', (string) $k) && is_array($d)) $tutti[$k] = $d;
        return $tutti;
    }

    /* ------------------------------------------------------------------ impostazioni di STAMPA (Impostazioni → Stampa dei documenti) */

    public const PRESET = ['normale' => [20, 20, 20, 20], 'stretto' => [12, 12, 12, 12], 'medio' => [25, 20, 25, 20], 'largo' => [30, 30, 30, 30], 'intestazione' => [45, 20, 25, 20]];
    public const FONT = ['sans' => '"DejaVu Sans","Segoe UI",Helvetica,Arial,sans-serif', 'serif' => '"DejaVu Serif",Georgia,"Times New Roman",serif', 'mono' => '"DejaVu Sans Mono",Menlo,Consolas,monospace', 'helvetica' => 'Helvetica,Arial,sans-serif', 'times' => '"Times New Roman",Times,serif'];

    /** Le impostazioni di stampa complete (con i valori predefiniti): margini, formato, font, intestazione, logo, piè di pagina */
    public static function stampa(): array
    {
        $g = fn(string $k, string $d = '') => (string) (Impostazione::get('stampa_' . $k) ?: $d);
        $preset = $g('preset', 'normale');
        [$sup, $des, $inf, $sin] = $preset === 'personalizzato' ? [(float) $g('m_sup', '20'), (float) $g('m_des', '20'), (float) $g('m_inf', '20'), (float) $g('m_sin', '20')] : (self::PRESET[$preset] ?? self::PRESET['normale']);
        $logo = $g('logo');
        $logoData = null;
        if ($logo !== '') { $p = Spazio::percorso($logo); if ($p && is_file($p) && filesize($p) < 1500000) { $ext = strtolower(pathinfo($p, PATHINFO_EXTENSION)); $logoData = 'data:' . ($ext === 'svg' ? 'image/svg+xml' : ($ext === 'jpg' || $ext === 'jpeg' ? 'image/jpeg' : "image/$ext")) . ';base64,' . base64_encode((string) file_get_contents($p)); } }
        return [
            'formato' => in_array($g('formato'), ['A4', 'A5', 'Letter'], true) ? $g('formato') : 'A4', 'orientamento' => $g('orientamento') === 'landscape' ? 'landscape' : 'portrait',
            'font' => self::FONT[$g('font', 'sans')] ?? self::FONT['sans'], 'font_chiave' => $g('font', 'sans'), 'corpo' => max(9, min(16, (int) $g('corpo', '13'))),
            'preset' => $preset, 'm_sup' => $sup, 'm_des' => $des, 'm_inf' => $inf, 'm_sin' => $sin,
            'intestazione' => $g('intestazione', '1') === '1', 'piede' => $g('piede', '1') === '1', 'bordo' => $g('bordo', '1') === '1', 'colore' => preg_match('/^#[0-9a-f]{6}$/i', $g('colore')) ? $g('colore') : '#6B6FE6',
            'mittente_fattura' => in_array($g('mittente_fattura'), ['studio', 'professionista', 'entrambi'], true) ? $g('mittente_fattura') : 'studio',
            'mittente_clinico' => in_array($g('mittente_clinico'), ['studio', 'professionista', 'entrambi'], true) ? $g('mittente_clinico') : 'professionista',
            'logo' => $logo, 'logo_data' => $logoData, 'logo_posizione' => in_array($g('logo_posizione'), ['sinistra', 'centro', 'destra'], true) ? $g('logo_posizione') : 'sinistra',
            'logo_altezza' => max(8, min(60, (int) $g('logo_altezza', '18'))), 'logo_solo' => $g('logo_solo') === '1', 'logo_su' => array_filter(explode(',', $g('logo_su', 'referto,fattura,ricetta,documento'))),
            'piede_testo' => $g('piede_testo'), 'piede_pagine' => $g('piede_pagine', '1') === '1',
            // la firma del programma resta finché lo studio non attiva l'opzione "senza_marchio" (Store)
            'marchio_bloccato' => !Estensioni::attiva('senza_marchio'), 'piede_generato' => Estensioni::attiva('senza_marchio') ? $g('piede_generato', '1') === '1' : true,
        ];
    }

    /** Il blocco MITTENTE dell'intestazione per un tipo di documento: righe di testo (la prima in grassetto) */
    public static function mittente(string $tipo, array $medico, array $stampa): array
    {
        $modo = $tipo === 'fattura' ? $stampa['mittente_fattura'] : $stampa['mittente_clinico'];
        $studio = array_values(array_filter([$medico['studio'] ?? '', $medico['indirizzo'] ?? '', trim(($medico['piva'] ? 'P.IVA ' . $medico['piva'] : '') . ($medico['piva'] && $medico['email'] ? ' · ' : '') . ($medico['email'] ?? '')), $medico['telefono'] ?? '']));
        $prof = array_values(array_filter([$medico['nome_completo'] ?? '', $medico['specializzazione'] ?? '', $medico['ordine'] ? 'Ordine ' . $medico['ordine'] : '']));
        if ($modo === 'studio') return $studio ?: $prof;
        if ($modo === 'professionista') return array_values(array_filter(array_merge($prof, [$medico['studio'] ?? '', $medico['indirizzo'] ?? '', $medico['telefono'] ?? ''])));
        return array_values(array_filter(array_merge([$prof[0] ?? ''], array_slice($prof, 1), $studio)));   // entrambi
    }

    /* ------------------------------------------------------------------ invio via email (documenti generati o file dell'archivio) */

    /** Descrizione umana di un documento per {documento} e per l'oggetto */
    public static function etichetta(string $tipo, array $d): string
    {
        $doc = $d['doc'];
        return match ($tipo) { 'referto' => 'Referto del ' . data_it($doc['data']), 'fattura' => 'Fattura n. ' . ($doc['numero'] ?? $doc['id']) . ' del ' . data_it($doc['data']), 'ricetta' => 'Promemoria ricetta del ' . data_it($doc['data']),
            default => (string) (self::tipi()[$tipo]['label'] ?? ucfirst($tipo)) . (isset($doc['data']) ? ' del ' . data_it($doc['data']) : '') };
    }

    /**
     * Invia un documento (PDF generato) o un file dell'archivio via email, con un modello di messaggio.
     * $a = indirizzo (anche diverso da quello in anagrafica: il figlio, il commercialista…); $modello = codice o per_tipo;
     * $oggetto/$testo = versione modificata a mano nella finestra di invio (null = dal modello). Ritorna l'id nel registro comunicazioni.
     */
    public static function inviaEmail(string $a, ?string $tipo, ?int $id, ?string $file, string $modello = '', ?string $oggetto = null, ?string $testo = null, ?int $pazienteId = null): int
    {
        $a = trim($a);
        if (!filter_var($a, FILTER_VALIDATE_EMAIL)) throw new ApiException(__('Indirizzo email non valido'));
        if ($tipo !== null && $id !== null) {
            if (!Auth::can(self::permesso($tipo))) throw new ApiException(__('Non hai il permesso per questo documento'), 403);
            $d = self::dati($tipo, $id);
            $paz = $d['paziente'] ?? null; $etich = self::etichetta($tipo, $d);
            $ctx = ['documento' => $etich, 'data' => $d['doc']['data'] ?? oggi(), 'numero' => $d['doc']['numero'] ?? '', 'importo' => $d['doc']['totale'] ?? null, 'medico' => $d['medico']['nome_completo'] ?? null];
            $allegato = ['nome' => preg_replace('/[^a-z0-9]+/i', '-', mb_strtolower($etich)) . '.pdf', 'contenuto' => self::pdf($tipo, $id), 'mime' => 'application/pdf'];
            $per = in_array($tipo, ['referto', 'fattura', 'ricetta'], true) ? $tipo : 'documento'; $rif = "$tipo-$id";
        } elseif ($file !== null) {
            $p = Spazio::percorso($file);
            if (!$p || !is_file($p)) throw new ApiException(__('File non trovato'));
            if (!Auth::can(self::permesso(explode('/', $file)[0] ?? ''))) throw new ApiException(__('Permesso negato'), 403);
            $paz = $pazienteId ? Paziente::find($pazienteId) : null; $etich = basename($file);
            $ctx = ['documento' => $etich];
            $allegato = ['nome' => basename($file), 'contenuto' => (string) file_get_contents($p), 'mime' => mime_content_type($p) ?: 'application/octet-stream'];
            $per = 'file'; $rif = 'file';
        } else throw new ApiException(__('Niente da inviare'));
        $vars = Messaggi::variabili($paz, $ctx, $per);
        $msg = Messaggi::compila($modello !== '' ? $modello : $per, 'email', $vars, $oggetto, $testo);
        if (trim(strip_tags($msg['testo'])) === '') $msg['testo'] = '<p>Gentile ' . e($vars['paziente']) . ',</p><p>in allegato: ' . e($etich) . '.</p><p>Cordiali saluti,<br>' . e($vars['studio']) . '</p>';
        if ($msg['oggetto'] === '') $msg['oggetto'] = $etich . ' · ' . $vars['studio'];
        $cid = Comunicazioni::invia('email', $a, $msg['oggetto'], $msg['testo'], ['rif' => $rif, 'allegati' => [$allegato]]);
        $c = Database::one('SELECT stato, errore FROM comunicazioni WHERE id = ?', [$cid]);
        if ($c && $c['stato'] === 'errore') throw new ApiException('Invio non riuscito: ' . $c['errore']);
        if ($tipo === 'referto') Referto::save(['id' => $id, 'stato' => 'inviato', 'inviato_il' => date('Y-m-d H:i:s')]);
        if ($tipo === 'fattura') Database::update('fatture', ['inviata_il' => date('Y-m-d H:i:s')], 'id = :id', ['id' => $id]);
        Attivita::registra('documento.inviato', 'documenti', (int) ($id ?? 0), "$etich → $a");
        Hooks::run('documento.inviato', $tipo ?? 'file', $id ?? 0, $a, $cid);
        return $cid;
    }

    /** Il permesso per vedere un tipo di documento (i tipi delle estensioni: documenti.leggi) */
    public static function permesso(string $tipo): string
    {
        return ['referto' => 'referti.leggi', 'ricetta' => 'ricette.leggi', 'fattura' => 'fatture.leggi', 'prova' => 'impostazioni.leggi'][$tipo] ?? 'documenti.leggi';
    }

    /* ------------------------------------------------------------------ link firmati: l'id nell'URL non basta */

    private static function chiave(): string
    {
        $k = Impostazione::get('documenti_chiave');
        if ($k === '') { $k = bin2hex(random_bytes(24)); Capabilities::comeCore(fn() => Impostazione::set('documenti_chiave', $k)); }
        return $k;
    }

    /**
     * URL firmato e a scadenza (15 minuti) per aprire un documento: cambiare l'id o riusare il link dopo la scadenza non funziona.
     * Legato allo studio e all'utente collegato. $cosa = 'render' (documento da generare) o 'file' (archiviato).
     */
    public static function link(string $cosa, string $tipo, string $id, int $minuti = 15): string
    {
        $exp = time() + $minuti * 60;
        $t = self::firma($cosa, $tipo, $id, $exp);
        return 'ajax/documenti.php?action=' . $cosa . '&' . ($cosa === 'file' ? 'f=' : 'tipo=' . rawurlencode($tipo) . '&id=') . rawurlencode($id) . "&exp=$exp&t=$t";
    }

    public static function firma(string $cosa, string $tipo, string $id, int $exp): string
    {
        return hash_hmac('sha256', "$cosa|$tipo|$id|$exp|" . Auth::studioId() . '|' . (int) (Auth::utente()['id'] ?? 0), self::chiave());
    }

    public static function verifica(string $cosa, string $tipo, string $id, int $exp, string $t): bool
    {
        return $exp > time() && $t !== '' && hash_equals(self::firma($cosa, $tipo, $id, $exp), $t);
    }

    /* ------------------------------------------------------------------ PDF (dompdf, in vendor/dompdf) */

    public static function pdfDisponibile(): bool { return is_file(DRF_ROOT . '/vendor/dompdf/autoload.inc.php'); }

    /** L'HTML di un documento reso in PDF (bytes). Il template resta lo stesso: si tolgono barra e script, si adattano flex e colori. */
    public static function pdfDaHtml(string $html): string
    {
        if (!self::pdfDisponibile()) throw new ApiException(__('Generazione PDF non disponibile (manca vendor/dompdf)'));
        require_once DRF_ROOT . '/vendor/dompdf/autoload.inc.php';
        $html = preg_replace('~<div class="toolbar">.*?</div>~s', '', $html);
        $html = preg_replace('~<script\b[^>]*>.*?</script>~s', '', $html);
        $css = '<style>body{background:#fff;margin:0}.foglio{box-shadow:none;border-radius:0;max-width:none;margin:0;padding:0 0 22mm 0;min-height:0}
            header .riga{display:table;width:100%}header .riga>*{display:table-cell;vertical-align:top}header .destinatario,header .doc{text-align:right}
            .firma{display:table;width:100%}.firma>div{display:table-cell;text-align:right}table{page-break-inside:auto}tr{page-break-inside:avoid}
            footer{position:fixed;bottom:0;left:0;right:0}.pagine .n:before{content:counter(page)}.pagine .t:before{content:counter(pages)}</style>';
        $html = str_contains($html, '</head>') ? str_replace('</head>', $css . '</head>', $html) : $css . $html;
        $html = preg_replace('~<body([^>]*)>~i', '<body$1 class="pdf">', $html, 1);   // nel PDF la numerazione la scrive il canvas
        $opt = new \Dompdf\Options();
        $opt->set('isRemoteEnabled', false); $opt->set('isHtml5ParserEnabled', true); $opt->set('defaultFont', 'DejaVu Sans');
        $opt->set('chroot', DRF_ROOT); $opt->set('tempDir', sys_get_temp_dir()); $opt->set('fontCache', sys_get_temp_dir());
        $pdf = new \Dompdf\Dompdf($opt);
        $st = self::stampa();
        $pdf->setPaper($st['formato'], $st['orientamento']);
        $pdf->loadHtml($html, 'UTF-8');
        ob_start();   // dompdf a volte emette avvisi: non devono finire nel file
        try {
            $pdf->render();
            if ($st['piede'] && $st['piede_pagine']) {   // "Pagina X di Y" in basso a destra, dentro il margine, su ogni pagina
                $c = $pdf->getCanvas(); $fm = $pdf->getFontMetrics(); $font = $fm->getFont('DejaVu Sans');
                $x = $c->get_width() - $st['m_des'] * 2.8346 - 4; $y = $c->get_height() - $st['m_inf'] * 2.8346 + 4;
                $c->page_text($x - 60, $y, 'Pagina {PAGE_NUM} di {PAGE_COUNT}', $font, 7.5, [0.6, 0.63, 0.7]);
            }
            $out = (string) $pdf->output();
        } finally { ob_end_clean(); }
        return $out;
    }

    public static function pdf(string $tipo, int $id): string { return self::pdfDaHtml(self::render($tipo, $id)); }

    public static function dati(string $tipo, int $id): array
    {
        $tipi = self::tipi();
        if (!isset($tipi[$tipo])) throw new ApiException(__('Tipo documento non valido'));
        if (in_array($tipo, self::TIPI, true)) {
            $doc = match ($tipo) { 'referto' => Referto::find($id), 'ricetta' => Ricetta::find($id), 'fattura' => Fattura::find($id) };
            $extra = [];
        } else {
            $r = is_callable($tipi[$tipo]['dati'] ?? null) ? ($tipi[$tipo]['dati'])($id) : null;
            if (!is_array($r) || empty($r['doc'])) throw new ApiException(__('Documento non trovato'), 404);
            $doc = $r['doc']; unset($r['doc']); $extra = $r;
        }
        if (!$doc) throw new ApiException(__('Documento non trovato'), 404);
        // il professionista del documento: per i referti quello che ha fatto la visita (multiutente), altrimenti il profilo dello studio
        $medico = Impostazione::profilo();
        if ($tipo === 'referto' && !empty($doc['visita_id'])) {
            $v = Database::one('SELECT v.utente_id, u.nome unome, u.cognome ucognome, u.sesso usesso FROM visite v LEFT JOIN ' . Database::comune('utenti') . ' u ON u.id = v.utente_id WHERE v.id = ?', [(int) $doc['visita_id']]);
            if ($v && !empty($v['ucognome'])) { $medico['nome'] = trim($v['unome'] . ' ' . $v['ucognome']); $medico['titolo'] = ($v['usesso'] ?? 'F') === 'M' ? 'Dott.' : 'Dott.ssa'; $medico['nome_completo'] = $medico['titolo'] . ' ' . $medico['nome']; }
        }
        // le estensioni possono arricchire i dati (intestazioni, righe, sezioni, loghi…): hook documento.dati
        return Hooks::filter('documento.dati', $extra + ['tipo' => $tipo, 'doc' => $doc, 'paziente' => !empty($doc['paziente_id']) ? Paziente::find((int) $doc['paziente_id']) : null, 'medico' => $medico, 'config' => Config::get('fattura'), 'stampa' => self::stampa()], $tipo, $id);
    }

    /** Pagina HTML stampabile generica (per i modelli dell'archivio Documenti) */
    public static function pagina(string $titolo, string $corpoHtml, array $paziente, array $medico, ?string $firmaImg = null): string
    {
        ob_start(); $auto_print = false; $stampa = self::stampa(); $tipo = 'documento';
        $doc = ['titolo' => $titolo, 'corpo' => $corpoHtml, 'firma_img' => $firmaImg];
        include DRF_ROOT . '/docs/templates/documento.php';
        return (string) Hooks::filter('documento.render', ob_get_clean(), 'documento', ['doc' => $doc, 'paziente' => $paziente, 'medico' => $medico]);
    }

    /** Restituisce l'HTML del documento */
    public static function render(string $tipo, int $id, bool $stampa = false): string
    {
        $d = self::dati($tipo, $id);
        extract($d);
        $auto_print = $stampa;
        // template: quello del core, o quello che un'estensione indica con documento.template (percorso di un file PHP con le stesse variabili)
        $base = (string) (self::tipi()[$tipo]['template'] ?? (DRF_ROOT . "/docs/templates/$tipo.php"));
        $tpl = (string) Hooks::filter('documento.template', $base, $tipo, $d);
        if (!is_file($tpl)) $tpl = $base;
        if (!is_file($tpl)) throw new ApiException("Template del documento $tipo non trovato");
        ob_start();
        include $tpl;
        $html = ob_get_clean();
        return (string) Hooks::filter('documento.render', $html, $tipo, $d);   // ultimo passaggio sull'HTML (intestazioni, piè di pagina, watermark…)
    }

    /** Salva una copia HTML nell'archivio documentale e la collega al record. Restituisce il percorso relativo. */
    public static function archivia(string $tipo, int $id): string
    {
        Capabilities::richiedi('documenti.genera');
        $html = self::render($tipo, $id);
        $d = self::dati($tipo, $id);
        $anno = substr((string) ($d['doc']['data'] ?? oggi()), 0, 4);
        $pdf = self::pdfDisponibile();
        $nome = sprintf('%s-%05d-%s.%s', $tipo, $id, preg_replace('/[^a-z0-9]+/i', '-', mb_strtolower($d['paziente']['nome_completo'] ?? 'paziente')), $pdf ? 'pdf' : 'html');
        // nell'archivio dello studio (Spazio: cartella per studio, quota), in PDF quando dompdf c'è
        $rel = Capabilities::comeCore(fn() => Spazio::scrivi("$tipo/$anno/$nome", $pdf ? self::pdfDaHtml($html) : $html));
        if ($tipo === 'referto') Database::update('referti', ['file' => $rel], 'id = :id', ['id' => $id]);
        Hooks::run('documento.archiviato', $tipo, $id, $rel, (int) ($d['paziente']['id'] ?? 0));   // l'estensione collega il file al suo record / lo indicizza
        return $rel;
    }

    /** Elenco dei documenti archiviati (più recenti prima) */
    public static function archivio(int $limit = 100): array
    {
        $base = Spazio::base();
        $out = [];
        foreach (array_merge(glob("$base/*/*/*.html") ?: [], glob("$base/*/*/*.pdf") ?: []) as $f) {
            $out[] = ['file' => substr($f, strlen($base) + 1), 'tipo' => basename(dirname(dirname($f))), 'dimensione' => filesize($f), 'modificato' => date('Y-m-d H:i', filemtime($f))];
        }
        usort($out, fn($a, $b) => strcmp($b['modificato'], $a['modificato']));
        return array_slice($out, 0, $limit);
    }
}
