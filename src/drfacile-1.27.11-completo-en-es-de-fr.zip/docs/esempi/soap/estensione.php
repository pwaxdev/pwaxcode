<?php
/**
 * CARTELLA PER PROBLEMI (codice: soap) — la visita orientata ai problemi, metodo S·O·A·P.
 * Il corpo della visita è SOSTITUITO (js/soap.js, visita.pannello + ctx.sostituisci); i dati della visita stanno in
 * visite.dati['soap'] = { problemi: { <id problema>: {s, o, a, p} }, piano: '…' }; i problemi vivono in ext_soap_problemi
 * e alla chiusura ogni nota viene copiata in ext_soap_note (la cronologia). Referto ricostruito per problemi;
 * Piano di cura = tipo di documento registrato (documenti.tipi). api.dopo allega i problemi alla scheda del paziente.
 */
final class Soap
{
    public const P = 'ext_soap_problemi';
    public const N = 'ext_soap_note';

    public static function problemi(int $pazienteId, bool $anche_risolti = false): array
    {
        return Database::all('SELECT * FROM ' . self::P . ' WHERE paziente_id = ?' . ($anche_risolti ? '' : " AND stato = 'attivo'") . ' ORDER BY stato, aperto_il DESC, id DESC', [$pazienteId]);
    }

    public static function apri(int $pazienteId, string $titolo): int
    {
        $titolo = trim($titolo);
        if ($titolo === '') throw new ApiException('Scrivi il problema');
        return Database::insert(self::P, ['paziente_id' => $pazienteId, 'titolo' => mb_substr($titolo, 0, 160), 'stato' => 'attivo', 'aperto_il' => oggi(), 'creato_il' => date('Y-m-d H:i:s')]);
    }

    public static function stato(int $id, string $stato): void
    {
        Database::update(self::P, ['stato' => $stato === 'risolto' ? 'risolto' : 'attivo', 'chiuso_il' => $stato === 'risolto' ? oggi() : null], 'id = :id', ['id' => $id]);
    }

    /** Le sezioni del referto ricostruite per problema (i parametri vitali del core restano) */
    public static function sezioni(array $sezioni, array $v): array
    {
        $d = $v['dati']['soap'] ?? null;
        if (!$d || empty($d['problemi'])) return $sezioni;
        $out = [];
        if (!empty($sezioni['Parametri vitali']) && $sezioni['Parametri vitali'] !== 'Non rilevati') $out['Parametri vitali'] = $sezioni['Parametri vitali'];
        $titoli = [];
        foreach (Database::all('SELECT id, titolo FROM ' . self::P . ' WHERE paziente_id = ?', [(int) $v['paziente_id']]) as $p) $titoli[(int) $p['id']] = $p['titolo'];
        $n = 0;
        foreach ((array) $d['problemi'] as $pid => $nota) {
            $nota = (array) $nota;
            if (!array_filter($nota)) continue;
            $n++;
            $righe = array_filter([
                !empty($nota['s']) ? 'S · Soggettivo: ' . $nota['s'] : null, !empty($nota['o']) ? 'O · Oggettivo: ' . $nota['o'] : null,
                !empty($nota['a']) ? 'A · Valutazione: ' . $nota['a'] : null, !empty($nota['p']) ? 'P · Piano: ' . $nota['p'] : null]);
            $out["Problema $n: " . ($titoli[(int) $pid] ?? 'problema')] = implode("\n", $righe);
        }
        if (!empty($d['piano'])) $out['Piano complessivo'] = $d['piano'];
        if (!empty($sezioni['Esami'])) $out['Esami'] = $sezioni['Esami'];
        return $out ?: $sezioni;
    }

    /** Alla chiusura: le note finiscono nella cronologia dei problemi */
    public static function archivia(int $visitaId, int $refertoId, array $v): void
    {
        $d = $v['dati']['soap'] ?? null;
        if (!$d || empty($d['problemi'])) return;
        foreach ((array) $d['problemi'] as $pid => $nota) {
            $nota = (array) $nota;
            if (!array_filter($nota)) continue;
            Database::delete(self::N, 'visita_id = ? AND problema_id = ?', [$visitaId, (int) $pid]);
            Database::insert(self::N, ['problema_id' => (int) $pid, 'visita_id' => $visitaId, 'referto_id' => $refertoId, 'data' => $v['data'], 's' => $nota['s'] ?? '', 'o' => $nota['o'] ?? '', 'a' => $nota['a'] ?? '', 'p' => $nota['p'] ?? '', 'creato_il' => date('Y-m-d H:i:s')]);
            Database::update(self::P, ['ultima_il' => $v['data'], 'ultimo_piano' => (string) ($nota['p'] ?? '')], 'id = :id', ['id' => (int) $pid]);
        }
    }

    /** Il Piano di cura: i problemi attivi con l'ultimo piano (documento) */
    public static function piano(int $pazienteId): array
    {
        $problemi = self::problemi($pazienteId);
        foreach ($problemi as &$p) $p['note'] = Database::all('SELECT data, p FROM ' . self::N . " WHERE problema_id = ? AND p <> '' ORDER BY data DESC LIMIT 3", [(int) $p['id']]);
        return ['doc' => ['id' => $pazienteId, 'data' => oggi(), 'paziente_id' => $pazienteId, 'tipo' => 'Piano di cura'], 'problemi' => $problemi];
    }
}

Hooks::add('referto.sezioni', fn(array $s, array $v) => Soap::sezioni($s, $v));
Hooks::add('visita.chiusa', fn(int $id, int $rid, array $v) => Soap::archivia($id, $rid, $v));
// la valutazione (A) di ogni problema diventa diagnosi anche lato server (se il client non l'ha già fatto)
Hooks::add('visita.salva', function (array $in, array $v) {
    if (!isset($in['dati']['soap']['problemi']) || !empty($in['diagnosi'])) return $in;
    $dx = [];
    foreach ((array) $in['dati']['soap']['problemi'] as $n) if (!empty($n['a'])) $dx[] = trim(strtok((string) $n['a'], "\n"));
    if ($dx) $in['diagnosi'] = $dx;
    return $in;
});
// la scheda del paziente (pazienti/get) porta con sé i problemi: nessuna chiamata in più dal client
Hooks::add('api.dopo', function ($out, string $sezione, string $azione) {
    if ($sezione === 'pazienti' && $azione === 'get' && is_array($out) && !empty($out['paziente']['id'])) $out['soap'] = Soap::problemi((int) $out['paziente']['id'], true);
    return $out;
});
// il Piano di cura come documento del programma: stampa, archivio, filtri documento.*
Hooks::add('documenti.tipi', function (array $t) {
    $t['soap_piano'] = ['label' => 'Piano di cura', 'template' => Store::dir('soap') . '/templates/piano.php', 'dati' => fn(int $pazienteId) => Soap::piano($pazienteId)];
    return $t;
});
// un campo in più nella scheda paziente: il problema principale, salvato da solo in pazienti.dati.soap.principale
Hooks::add('form.campi', function (array $def, string $form) {
    if ($form === 'paziente') $def['fields'][] = ['name' => 'soap_principale', 'label' => 'Problema principale (cartella per problemi)', 'type' => 'text', 'row' => 90, 'placeholder' => 'Es. ipertensione arteriosa'];
    return $def;
});
Hooks::add('backup.contenuto', fn(array $t) => [...$t, Soap::P, Soap::N]);
Hooks::add('cli.comandi', function (array $c) {
    $c['soap:problemi'] = ['descrizione' => 'Conta i problemi attivi e risolti', 'fn' => function () {
        foreach (Database::all('SELECT stato, COUNT(*) n FROM ' . Soap::P . ' GROUP BY stato') as $r) printf("  %-8s %d\n", $r['stato'], $r['n']); return 0;
    }];
    return $c;
});
