<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'corrente'   => fn() => ['percorso' => Percorso::corrente(), 'attivo' => Impostazione::get('assistente_attivo', '1') === '1'],
    'stato'      => fn(array $in) => ['percorso' => Percorso::stato(Api::int($in, 'id'))],
    'apri'       => function (array $in) { $id = Percorso::apri(Api::str($in, 'percorso'), Api::int($in, 'rif_id') ?: null, Api::str($in, 'etichetta')); return ['percorso' => Percorso::stato($id)]; },
    'spunta'     => function (array $in) { Percorso::spunta(Api::int($in, 'id'), Api::str($in, 'chiave'), !empty($in['fatto'])); return ['percorso' => Percorso::stato(Api::int($in, 'id'))]; },
    'chiudi'     => function (array $in) { Percorso::save(['id' => Api::int($in, 'id'), 'stato' => 'chiuso']); return ['chiuso' => true]; },
    'definizioni' => fn() => ['percorsi' => array_map(fn($d) => ['titolo' => $d['titolo'], 'trigger' => $d['trigger']], Percorso::definizioni())],
], 'assistente.usa');
