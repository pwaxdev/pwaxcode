<?php
if (!function_exists('module_negozio_render')) {
    function module_negozio_render(array $ctx): string
    {
        return '<div class="store"><div class="store-body"><div class="muted small" style="padding:16px">' . __('Apertura dello store…') . '</div></div></div>';
    }
}
