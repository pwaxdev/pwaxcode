<?php
/** Modulo Scrivania: Ritmo (gioco di memoria alla "Simon") */
if (!function_exists('module_ritmo_render')) {
    function module_ritmo_render(array $ctx): string
    {
        return '<div class="ritmo"><div class="ritmo-top"><div><span class="muted small">' . __('Turno') . '</span><b class="ritmo-turno">0</b></div><div><span class="muted small">Record</span><b class="ritmo-record">0</b></div></div>
          <div class="ritmo-pads">' . implode('', array_map(fn($i) => '<button type="button" class="ritmo-pad p' . $i . '" data-p="' . $i . '" aria-label="Tasto ' . ($i + 1) . '"><span>' . ($i + 1) . '</span></button>', range(0, 3))) . '<div class="ritmo-core"><button type="button" class="btn primary sm ritmo-start">' . __('Gioca') . '</button></div></div>
          <div class="ritmo-msg muted small">' . __('Osserva la sequenza, poi ripetila.') . '</div></div>';
    }
}
