/* Post-it: appunti liberi incollati sull'area di lavoro, legati alla sezione corrente e al record aperto.
   Un modulo espone il record con record() → { sezione: 'paziente', record: id } (o solo l'id: la sezione è il modulo);
   così un post-it incollato su un paziente lo segue in Pazienti e in Visita, uno su un referto resta su quel referto.
   Trascinamento, ridimensionamento, rotazione, colori, dimensione testo, grassetto, primo piano; salvataggio automatico.
   Riscrittura leggera del componente "sticky" di Igea, senza jQuery UI / roundSlider / scrollbar. */
DRF.postit = (function ($) {
  'use strict';
  const COLORI = ['#FFF4A3', '#FFD6A5', '#FFB5B5', '#CDE7FF', '#D7F5DC', '#F3D1F9', '#E6E6E6', '#FFFFFF'];
  const TESTO = ['#1F2233', '#C9474E', '#2E9A78', '#2F7FC2', '#6B6FE6', '#B7811B', '#8A2BE2', '#777777'];
  const st = { ctx: { sezione: 'main', record: 0 }, note: {}, $layer: null, zmax: 1, req: 0 };

  function contesto() {
    const m = DRF.current(); if (!m) return { sezione: 'main', record: 0 };
    const r = typeof m.record === 'function' ? m.record() : null;
    if (r && typeof r === 'object') return { sezione: r.sezione || m.key, record: +r.record || 0 };
    return { sezione: m.key, record: r ? +r : 0 };
  }
  const uid = () => 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ---------- una nota ---------- */
  function Nota(d) {
    const self = this; this.d = d;
    const $n = this.$el = $(`<div class="postit" data-ident="${d.ident}">
      <div class="postit-bar">
        <span class="postit-tape"></span>
        <div class="postit-tools">
          <button type="button" data-t="colore" title="${DRF.__('Colore del foglio')}">${DRF.icons.html('palette', 'fa-solid fa-palette')}</button>
          <button type="button" data-t="testo" title="${DRF.__('Colore del testo')}">${DRF.icons.html('text', 'fa-solid fa-font')}</button>
          <button type="button" data-t="meno" title="${DRF.__('Testo più piccolo')}">A−</button><button type="button" data-t="piu" title="${DRF.__('Testo più grande')}">A+</button>
          <button type="button" data-t="bold" title="${DRF.__('Grassetto')}"><b>B</b></button>
          <button type="button" data-t="ruota" title="${DRF.__('Ruota')}">${DRF.icons.html('rotate-right', 'fa-solid fa-rotate-right')}</button>
          <button type="button" data-t="chiudi" title="${DRF.__('Elimina')}">${DRF.icons.html('cross-small', 'fa-solid fa-xmark')}</button>
        </div>
      </div>
      <textarea class="postit-text" spellcheck="false" placeholder="${DRF.__('Scrivi qui…')}"></textarea>
      <div class="postit-pop" hidden></div>
      <span class="postit-resize"></span></div>`);
    DRF.icons.apply($n[0]);
    $n.find('.postit-text').val(d.testo || '');
    this.applica();
    st.$layer.append($n);
    requestAnimationFrame(() => $n.addClass('in'));
    const save = DRF.util.debounce(() => self.salva(), 700);
    $n.on('mousedown pointerdown', () => self.avanti());
    $n.find('.postit-text').on('input', () => { d.testo = $n.find('.postit-text').val(); save(); });
    $n.find('.postit-tools').on('click', 'button', function (e) { e.stopPropagation(); self.tool(this.dataset.t); });
    $n.find('.postit-bar').on('pointerdown', e => self.drag(e));
    $n.find('.postit-resize').on('pointerdown', e => self.resize(e));
  }
  Nota.prototype.applica = function () {
    const d = this.d, $n = this.$el;
    $n.css({ left: d.posx, top: d.posy, width: d.width, height: d.height, zIndex: d.zindex, background: d.back, transform: `rotate(${d.rotation}deg)` });
    $n.find('.postit-text').css({ color: d.color, fontSize: d.fontsize + 'px', fontWeight: +d.bold ? 700 : 400 });
    $n.find('[data-t=bold]').toggleClass('on', !!+d.bold);
  };
  Nota.prototype.avanti = function () { if (+this.d.zindex >= st.zmax) return; this.d.zindex = ++st.zmax; this.$el.css('zIndex', this.d.zindex); this.salva(); };
  Nota.prototype.drag = function (e) {
    if ($(e.target).closest('.postit-tools').length || e.button) return;
    const self = this, d = this.d, sx = e.clientX - d.posx, sy = e.clientY - d.posy, W = st.$layer.width(), H = st.$layer.height();
    this.$el.addClass('dragging'); this.$el.find('.postit-pop').prop('hidden', true);
    const move = ev => { d.posx = clamp(ev.clientX - sx, -20, W - 60); d.posy = clamp(ev.clientY - sy, 0, H - 40); self.$el.css({ left: d.posx, top: d.posy }); };
    const up = () => { $(document).off('pointermove', move).off('pointerup pointercancel', up); self.$el.removeClass('dragging'); self.salva(); };
    $(document).on('pointermove', move).on('pointerup pointercancel', up); e.preventDefault();
  };
  Nota.prototype.resize = function (e) {
    const self = this, d = this.d, x0 = e.clientX, y0 = e.clientY, w0 = d.width, h0 = d.height;
    const move = ev => { d.width = clamp(w0 + ev.clientX - x0, 150, 600); d.height = clamp(h0 + ev.clientY - y0, 100, 600); self.$el.css({ width: d.width, height: d.height }); };
    const up = () => { $(document).off('pointermove', move).off('pointerup pointercancel', up); self.salva(); };
    $(document).on('pointermove', move).on('pointerup pointercancel', up); e.preventDefault(); e.stopPropagation();
  };
  Nota.prototype.pop = function (html) { const $p = this.$el.find('.postit-pop'); if (!$p.prop('hidden') && $p.data('k') === html) return $p.prop('hidden', true); $p.html(html).data('k', html).prop('hidden', false); };
  Nota.prototype.tool = function (t) {
    const d = this.d, self = this;
    if (t === 'chiudi') return self.elimina();
    if (t === 'meno' || t === 'piu') { d.fontsize = clamp(+d.fontsize + (t === 'piu' ? 2 : -2), 12, 40); this.applica(); return this.salva(); }
    if (t === 'bold') { d.bold = +d.bold ? 0 : 1; this.applica(); return this.salva(); }
    if (t === 'colore' || t === 'testo') {
      const lista = t === 'colore' ? COLORI : TESTO;
      this.pop(`<div class="postit-palette">${lista.map(c => `<button type="button" data-c="${c}" style="background:${c}" class="${(t === 'colore' ? d.back : d.color).toUpperCase() === c ? 'on' : ''}"></button>`).join('')}</div>`);
      this.$el.find('.postit-palette button').on('click', function () { d[t === 'colore' ? 'back' : 'color'] = this.dataset.c; self.applica(); self.salva(); self.$el.find('.postit-pop').prop('hidden', true); });
      return;
    }
    if (t === 'ruota') {
      this.pop(`<div class="postit-rot"><input type="range" min="-20" max="20" value="${d.rotation}"><span class="num">${d.rotation}°</span><button type="button" class="chip" data-reset>0°</button></div>`);
      const $r = this.$el.find('.postit-rot');
      $r.find('input').on('input', function () { d.rotation = +this.value; $r.find('span').text(d.rotation + '°'); self.applica(); }).on('change', () => self.salva());
      $r.find('[data-reset]').on('click', () => { d.rotation = 0; $r.find('input').val(0); $r.find('span').text('0°'); self.applica(); self.salva(); });
    }
  };
  Nota.prototype.salva = function () { const d = this.d; DRF.api.post('postit', 'save', d).then(r => { if (r && r.id) d.id = r.id; }); };
  Nota.prototype.elimina = function () { const self = this, d = Object.assign({}, this.d); DRF.api.post('postit', 'delete', { ident: this.d.ident }).then(() => { self.$el.removeClass('in'); setTimeout(() => self.$el.remove(), 250); delete st.note[self.d.ident]; badge(); DRF.ui.toast(DRF.__('Post-it eliminato'), 'info', { undo: () => { const n = st.note[d.ident] = new Nota(d); n.salva(); badge(); } }); }); };

  function badge() { const n = Object.keys(st.note).length; $('#postitCount').text(n).prop('hidden', !n); $('#postitBtn').toggleClass('has', n > 0); }
  function nascosti() { return localStorage.getItem('drf_postit_nascosti') === '1'; }
  function applicaVisibilita() { const h = nascosti(); st.$layer.toggleClass('nascosti', h); const i = $('#postitBtn i')[0]; i.dataset.fi = h ? 'eye-crossed' : 'note-sticky'; i.dataset.fa = h ? 'fa-regular fa-eye-slash' : 'fa-regular fa-note-sticky'; DRF.icons.apply(i); $('#postitBtn').attr('title', h ? DRF.__('Post-it nascosti: click per incollarne uno e mostrarli') : DRF.__('Incolla un post-it · tasto destro per le opzioni')); }

  const P = {
    init() {
      st.$layer = $('#postitLayer');
      $('#postitBtn').on('click', () => { if (nascosti()) P.mostra(true); P.nuovo(); });
      DRF.menu.bind($('#postitBtn').parent(), '#postitBtn', () => P.menu(), { title: DRF.__('Post-it') });
      applicaVisibilita();
      $(document).on('click', e => { if (!$(e.target).closest('.postit').length) $('.postit-pop').prop('hidden', true); });
    },
    /** Ricarica i post-it del contesto corrente (chiamato a ogni cambio di modulo o di record) */
    refresh() {
      const c = contesto(); st.ctx = c; const mine = ++st.req;
      DRF.api.get('postit', 'list', { sezione: c.sezione, record: c.record }).then(r => {
        if (mine !== st.req) return;
        st.$layer.empty(); st.note = {}; st.zmax = 1;
        r.postit.forEach(d => { st.note[d.ident] = new Nota(d); st.zmax = Math.max(st.zmax, +d.zindex || 1); });
        badge();
        const m = DRF.current(); if (m && typeof m.postitConteggi === 'function') m.postitConteggi(r.conteggi || {});
      });
    },
    /** Incolla un nuovo post-it nel contesto corrente */
    nuovo(testo) {
      const c = st.ctx, n = Object.keys(st.note).length;
      const d = { ident: uid(), sezione: c.sezione, record_id: c.record, testo: testo || '', posx: 40 + (n % 5) * 34, posy: 30 + (n % 5) * 26, width: 220, height: 190, rotation: [-3, 2, -1, 3, 0][n % 5], fontsize: +((DRF.config.postit || {}).font_size || 14), back: COLORI[n % 3], color: '#1F2233', bold: 0, zindex: ++st.zmax };
      const nota = st.note[d.ident] = new Nota(d); nota.salva(); badge();
      setTimeout(() => nota.$el.find('.postit-text').trigger('focus'), 120);
      DRF.sound.play('notify');
      return nota;
    },
    /** Voci del menu (tasto destro sull'icona) */
    menu() {
      const n = Object.keys(st.note).length, h = nascosti();
      return [
        { label: DRF.__('Nuovo post-it'), fi: 'plus', fa: 'fa-solid fa-plus', run: () => { if (h) P.mostra(true); P.nuovo(); } },
        { sep: true },
        { label: h ? DRF.__('Mostra i post-it') : DRF.__('Nascondi i post-it'), fi: h ? 'eye' : 'eye-crossed', fa: h ? 'fa-regular fa-eye' : 'fa-regular fa-eye-slash', run: () => P.mostra(h) },
        { label: DRF.__('Ordina in pila'), fi: 'layers', fa: 'fa-solid fa-layer-group', disabled: n < 2, run: () => P.ordina() },
        { sep: true },
        { label: DRF.__('Elimina tutti i post-it'), fi: 'trash', fa: 'fa-solid fa-trash', danger: true, disabled: !n, run: () => P.eliminaTutti() },
      ];
    },
    mostra(v) { localStorage.setItem('drf_postit_nascosti', v ? '0' : '1'); applicaVisibilita(); DRF.ui.toast(v ? DRF.__('Post-it visibili') : DRF.__('Post-it nascosti'), 'info'); },
    /** Impila i post-it uno sotto l'altro in alto a destra */
    ordina() {
      let y = 24; const W = st.$layer.width();
      Object.values(st.note).sort((a, b) => (+a.d.posy) - (+b.d.posy)).forEach((n, i) => { n.d.posx = Math.max(20, W - n.d.width - 30); n.d.posy = y; n.d.rotation = 0; n.d.zindex = i + 1; n.applica(); n.$el.addClass('moving'); setTimeout(() => n.$el.removeClass('moving'), 450); n.salva(); y += 46; });
      st.zmax = Object.keys(st.note).length; DRF.ui.toast(DRF.__('Post-it ordinati in pila'), 'info');
    },
    eliminaTutti() {
      const lista = Object.values(st.note); if (!lista.length) return;
      DRF.ui.confirm(`${DRF.__('Eliminare')} ${lista.length} ${DRF.__('post-it?')}`, DRF.__('Verranno rimossi tutti i post-it di questo contesto.'), DRF.__('Elimina tutti'), 'warn').then(ok => { if (!ok) return; $.when.apply($, lista.map(n => DRF.api.post('postit', 'delete', { ident: n.d.ident }))).then(() => { st.$layer.empty(); st.note = {}; badge(); DRF.ui.toast(DRF.__('Post-it eliminati'), 'info'); }); });
    },
    contesto
  };
  return P;
})(jQuery);
