/* Bacheca personale · il menu sull'avatar (tasto destro) con voci dinamiche, note personali, tema, blocco, uscita */
(function ($) {
  'use strict';
  const I = DRF.icons.html, U = DRF.util;
  let giornata = null;
  const carica = () => DRF.api.ext('bacheca', 'giornata').then(g => (giornata = g));
  carica(); setInterval(carica, 120000);   // i numeri del menu restano freschi

  // il filtro JS riceve le voci già pronte (quelle PHP di tutte le estensioni) e aggiunge le sue, dinamiche
  DRF.hooks.add('menu.voci', voci => {
    const g = giornata || {};
    return [
      { label: g.visite != null ? `La mia giornata · ${g.visite} ${U.plural(g.visite, 'visita', 'visite')}, ${U.eur(g.incassato || 0)}` : 'La mia giornata', fi: 'calendar-day', fa: 'fa-solid fa-calendar-day', run: mostraGiornata },
      { label: 'Note personali', fi: 'notebook', fa: 'fa-regular fa-note-sticky', run: note, kbd: '⌘⇧N' },
      { sep: true },
      ...voci,
      { sep: true },
      { label: document.documentElement.dataset.theme === 'dark' ? 'Tema chiaro' : 'Tema scuro', fi: document.documentElement.dataset.theme === 'dark' ? 'sun' : 'moon', fa: document.documentElement.dataset.theme === 'dark' ? 'fa-regular fa-sun' : 'fa-regular fa-moon', run: () => DRF.ui.setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark', true) },
      { label: 'Blocca lo schermo', fi: 'lock', fa: 'fa-solid fa-lock', run: blocca },
      { label: 'Esci', fi: 'sign-out-alt', fa: 'fa-solid fa-right-from-bracket', danger: true, run: () => DRF.ui.confirm('Uscire da DRFacile?', 'La visita in corso resta salvata come bozza.', 'Esci').then(ok => { if (ok) DRF.api.post('auth', 'logout').then(r => { location.href = (r && r.redirect) || 'login.php'; }); }) },
    ];
  });
  DRF.on('bacheca:scorciatoie', () => DRF.app.scorciatoie());   // la voce PHP "Scorciatoie da tastiera" emette questo comando
  DRF.tasti.add('ctrl+shift+n', note, 'Bacheca: note personali');
  DRF.hooks.add('search.comandi', ctx => ctx.comando({ label: 'La mia giornata', fi: 'calendar-day', fa: 'fa-solid fa-calendar-day', kw: 'bacheca giornata oggi riepilogo', run: mostraGiornata }));

  function mostraGiornata() {
    carica().then(g => DRF.ui.modal({ title: `La giornata di ${DRF.esc(g.utente || 'oggi')}`, ok: false, cancel: 'Chiudi', html: `
      <div class="bach-grid">
        <div class="kpi">${I('stethoscope', 'fa-solid fa-stethoscope', 'violet')}<div><span>Visite chiuse oggi</span><b class="num">${g.visite}</b><small>${g.aperte ? g.aperte + ' in corso' : 'nessuna in corso'}</small></div></div>
        <div class="kpi">${I('receipt', 'fa-solid fa-file-invoice', 'mint')}<div><span>Fatture emesse</span><b class="num">${g.fatture}</b><small>${U.eur(g.fatturato)} fatturato</small></div></div>
        <div class="kpi">${I('euro', 'fa-solid fa-euro-sign', 'amber')}<div><span>Incassato oggi</span><b class="num">${U.eur(g.incassato)}</b><small>fatture pagate oggi</small></div></div>
        <div class="kpi">${I('user-add', 'fa-solid fa-user-plus', 'rose')}<div><span>Pazienti nuovi</span><b class="num">${g.nuovi}</b><small>${g.prossimi} ${U.plural(g.prossimi, 'appuntamento ancora da fare', 'appuntamenti ancora da fare')}</small></div></div>
      </div>` }));
  }
  function note() {
    DRF.api.ext('bacheca', 'note').then(d => DRF.ui.modal({ title: 'Note personali', ok: 'Salva', cancel: 'Chiudi',
      html: `<p class="small muted" style="margin-bottom:8px">Solo tue: i colleghi non le vedono. Restano finché non le cancelli.</p><textarea class="input bach-note" rows="10" placeholder="Cose da ricordare, telefonate da fare, idee…">${DRF.esc(d.note || '')}</textarea>`,
      onOk($b) { DRF.api.ext('bacheca', 'salva_note', { note: $b.find('.bach-note').val() }).then(() => { DRF.ui.toast('Note salvate', 'success'); DRF.ui.closeModal(); }); return false; } }));
  }
  function blocca() {
    // velo a tutto schermo: si toglie con la password? no — semplice e onesto: torna al login (la sessione resta viva finché non scade)
    const $v = $(`<div class="bach-lock"><div><div class="bach-lock-ava">${DRF.esc((DRF.config.utente || {}).iniziali || '')}</div><b>${DRF.esc((DRF.config.utente || {}).nome_completo || '')}</b><span>Schermo bloccato · clicca per riprendere</span></div></div>`).appendTo('body');
    $v.on('click', () => $v.remove());
  }
})(jQuery);
