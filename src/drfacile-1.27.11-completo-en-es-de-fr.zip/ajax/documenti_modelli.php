<?php
/** Genera un documento dell'archivio Documenti per un paziente: campi {…} compilati, copia archiviata,
    per i consensi con durata registra la firma nel registro consensi e la scadenza nello scadenzario. */
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'catalogo' => fn() => ['voci' => require DRF_ROOT . '/core/catalogo_richieste.php'],
    'richiedi' => function (array $in) {
        $catalogo = require DRF_ROOT . '/core/catalogo_richieste.php';
        $voce = Api::str($in, 'voce');
        if (!isset($catalogo[$voce])) throw new ApiException(__('Scegli il documento da richiedere'));
        $medico = Impostazione::profilo();
        $email = Config::get('assistenza.email_richieste') ?: 'documenti@drfacile.it';
        $note = trim(Api::str($in, 'note'));
        $testo = '<p><b>Richiesta di un nuovo modello di documento</b></p>'
            . '<p>Documento: <b>' . e($catalogo[$voce]) . '</b> (' . e($voce) . ')</p>'
            . ($note !== '' ? '<p>Note dello studio:</p><blockquote>' . nl2br(e($note)) . '</blockquote>' : '')
            . '<p>Studio: ' . e($medico['studio']) . ' · ' . e($medico['nome_completo']) . '<br>Email: ' . e($medico['email']) . ' · Tel: ' . e($medico['telefono']) . '</p>';
        Comunicazioni::invia('email', $email, 'DRFacile · richiesta documento: ' . $catalogo[$voce], $testo, ['rif' => 'richiesta-documento']);
        Attivita::registra('documento.richiesto', 'documenti', 0, $catalogo[$voce]);
        return ['messaggio' => __('Richiesta inviata: il modello sarà inserito nel tuo archivio appena pronto')];
    },
    'genera' => function (array $in) {
        $doc = Database::one('SELECT * FROM documenti WHERE id = ? AND abilitato = 1', [Api::int($in, 'documento')]) ?? throw new ApiException(__('Documento non trovato'), 404);
        $p = Paziente::find(Api::int($in, 'paziente_id')) ?? throw new ApiException(__('Paziente non trovato'), 404);
        $medico = Impostazione::profilo();
        $durata = (int) $doc['durata'];
        $scad = $durata > 0 ? date('Y-m-d', strtotime('+' . $durata . ' days')) : null;
        $campi = [
            'paziente' => $p['nome_completo'], 'cf' => $p['cf'] ?: '—', 'nascita' => $p['nascita'] ? data_it($p['nascita']) : '—',
            'indirizzo' => trim(implode(', ', array_filter([$p['indirizzo'], trim(($p['cap'] ?? '') . ' ' . ($p['citta'] ?? ''))]))) ?: '—',
            'data' => data_it(oggi()), 'medico' => $medico['nome_completo'], 'studio' => $medico['studio'], 'studio_indirizzo' => $medico['indirizzo'],
            'scadenza' => $scad ? data_it($scad) : '—',
        ];
        $html = rich_txt($doc['contenuto']);
        foreach ($campi as $k => $v) $html = str_replace('{' . $k . '}', '<b>' . e($v) . '</b>', $html);
        // pagina stampabile con l'intestazione dello studio
        // estensione "Firma sul tablet": firma disegnata dal paziente, incorporata nel documento archiviato
        $firmaData = null;
        if (!empty($in['firma']) && Estensioni::attiva('firma')) {
            $raw = (string) $in['firma'];
            if (!preg_match('#^data:image/png;base64,#', $raw)) throw new ApiException(__('Firma non valida'));
            $bin = base64_decode(substr($raw, strlen('data:image/png;base64,')), true);
            if ($bin === false || strlen($bin) > 800_000 || substr($bin, 0, 8) !== "\x89PNG\r\n\x1a\n") throw new ApiException(__('Firma non valida o troppo pesante'));
            $fnome = sprintf('firma-%s-%s.png', date('Ymd-His'), preg_replace('/[^a-z0-9]+/i', '-', mb_strtolower($p['nome_completo'])));
            Spazio::scrivi('firma/' . date('Y') . "/$fnome", $bin);   // archivio dello studio, quota
            $firmaData = $raw;   // incorporata come data-URL: l'archivio resta autosufficiente
        }
        $pagina = Documenti::pagina($doc['descrizione'], $html, $p, $medico, $firmaData);
        $anno = date('Y');
        $pdf = Documenti::pdfDisponibile();
        $nome = sprintf('documento-%s-%s-%s.' . ($pdf ? 'pdf' : 'html'), mb_strtolower(preg_replace('/[^a-z0-9]+/i', '-', $doc['codice'])), date('Ymd-His'), preg_replace('/[^a-z0-9]+/i', '-', mb_strtolower($p['nome_completo'])));
        $rel = Spazio::scrivi("documento/$anno/$nome", $pdf ? Documenti::pdfDaHtml($pagina) : $pagina);
        Hooks::run('documento.archiviato', 'documento', (int) $doc['id'], $rel, (int) $p['id']);
        Attivita::registra('documento.generato', 'documenti', (int) $doc['id'], $doc['codice'] . ' · ' . $p['nome_completo']);
        $consenso = null;
        if ($doc['categoria'] === 'consensi') {
            $tipo = stripos($doc['descrizione'], 'privacy') !== false ? 'Privacy' : $doc['descrizione'];
            $cid = Database::insert('consensi', ['paziente_id' => (int) $p['id'], 'tipo' => mb_substr($tipo, 0, 80), 'data' => oggi(), 'scadenza' => $scad, 'firmato' => 1, 'note' => 'Da modello ' . $doc['codice'] . ($firmaData ? ' · firmato sul tablet' : ''), 'creato_il' => date('Y-m-d H:i:s')]);
            if ($scad) Scadenzario::aggiungi('consenso', $scad, __('Consenso in scadenza: ') . mb_substr($tipo, 0, 60), $p['nome_completo'] . ' · firmato il ' . data_it(oggi()), ['modulo' => 'pazienti', 'opts' => ['select' => (int) $p['id']]], 'consensi', $cid);
            $consenso = ['id' => $cid, 'scadenza' => $scad];
        }
        return ['file' => "documento/$anno/$nome", 'consenso' => $consenso];
    },
], ['*' => 'documenti.leggi', 'genera' => 'documenti.modifica']);
