<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'cerca'  => fn(array $in) => Comune::cerca(Api::str($in, 'q')),
    'codice' => fn(array $in) => Comune::daCodice(Api::str($in, 'cod')),
    // calcolo / verifica del codice fiscale lato server (stessa logica del JS, utile per validazioni e import)
    'cf'     => function (array $in) {
        $cf = CodiceFiscale::calcola(Api::str($in, 'cognome'), Api::str($in, 'nome'), Api::str($in, 'nascita'), Api::str($in, 'sesso'), Api::str($in, 'cod'));
        return ['cf' => $cf, 'valido' => CodiceFiscale::valida($cf)];
    },
]);
