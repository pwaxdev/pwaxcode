<?php
/**
 * Modello base: CRUD generico su una tabella.
 * Le sottoclassi dichiarano $table, $fillable (campi salvabili) e $json (campi serializzati).
 */
abstract class Model
{
    protected static string $table = '';
    protected static array $fillable = [];
    protected static array $json = [];

    public static function table(): string { return static::$table; }

    public static function find(int $id): ?array
    {
        Capabilities::tabella(static::$table, false);
        $r = Database::one('SELECT * FROM ' . static::$table . ' WHERE id = ?', [$id]);
        return $r ? static::decode($r) : null;
    }

    public static function all(string $where = '1=1', array $params = [], string $order = 'id DESC', int $limit = 0): array
    {
        Capabilities::tabella(static::$table, false);
        $sql = 'SELECT * FROM ' . static::$table . " WHERE $where ORDER BY $order" . ($limit ? " LIMIT $limit" : '');
        return array_map([static::class, 'decode'], Database::all($sql, $params));
    }

    public static function count(string $where = '1=1', array $params = []): int
    {
        return (int) Database::value('SELECT COUNT(*) FROM ' . static::$table . " WHERE $where", $params);
    }

    /** Inserisce (senza id) o aggiorna (con id). Restituisce l'id. */
    public static function save(array $data): int
    {
        Capabilities::tabella(static::$table, true);
        $row = [];
        foreach (static::$fillable as $f) {
            if (array_key_exists($f, $data)) $row[$f] = in_array($f, static::$json, true) ? json_txt($data[$f]) : $data[$f];
        }
        $id = (int) ($data['id'] ?? 0);
        if ($id > 0) {
            $row['aggiornato_il'] = date('Y-m-d H:i:s');
            Database::update(static::$table, $row, 'id = :id', ['id' => $id]);
            return $id;
        }
        $row['creato_il'] = date('Y-m-d H:i:s');
        return Database::insert(static::$table, $row);
    }

    /**
     * Campi aggiunti dalle estensioni alle form del core (hook form.campi): i campi che si chiamano <codice>_<campo>,
     * con <codice> un'estensione attiva, finiscono nella colonna JSON `dati` del record come dati[codice][campo].
     * $esistenti = i dati già salvati (le chiavi non presenti nella form restano).
     */
    public static function datiEstensioni(array $in, array $esistenti = []): array
    {
        $out = $esistenti;
        $attive = class_exists('Estensioni') ? Estensioni::tutteAttive() : [];
        foreach ($in as $k => $v) {
            if (!is_string($k) || !preg_match('/^([a-z][a-z0-9]*)_(.+)$/', $k, $m) || !isset($attive[$m[1]])) continue;
            $out[$m[1]][$m[2]] = is_array($v) ? $v : (string) $v;
        }
        return $out;
    }

    public static function delete(int $id): bool
    {
        Capabilities::tabella(static::$table, true);
        return Database::delete(static::$table, 'id = ?', [$id]) > 0;
    }

    /** Decodifica i campi JSON in array */
    public static function decode(array $row): array
    {
        foreach (static::$json as $f) if (array_key_exists($f, $row)) $row[$f] = json_arr($row[$f]);
        return $row;
    }
}
