<?php
if (!function_exists('module_oggi_render')) {
    function module_oggi_render(array $ctx): string
    {
        return '<div class="oggi"><div class="oggi-head"><b>' . e(ucfirst(data_lunga(oggi(), false))) . '</b><span class="badge violet oggi-n">…</span></div><div class="oggi-list"><div class="empty">' . __('Caricamento…') . '</div></div></div>';
    }
}
