# Moduli della Scrivania

La Scrivania (click sull'avatar) è un piano di lavoro con i moduli personali: chiusi stanno nel dock come icone, aperti sono finestre
trascinabili. Posizione, dimensione e stato (aperto / ridotto / chiuso) vengono salvati e ritrovati al prossimo accesso.

Sistema a *discovery*: per aggiungere un modulo basta creare la sua cartella in `modules/`. Nessun altro file da toccare.

```
modules/
  <key>/
    <key>.def          # definizione (obbligatorio): nome, descrizione, icona (fi + fa), larghezza, altezza, ridimensionabile
    <key>.php          # render della finestra (obbligatorio): function module_<key>_render(array $ctx): string
    css/<key>.css      # opzionale, caricato con la Scrivania
    js/<key>.js        # opzionale, caricato con la Scrivania; registra DRF.desk.register('<key>', { init($win, ctx), open($win), close($win) })
    ajax/<key>.php     # opzionale, endpoint del modulo (usa Api::run come gli altri)
```

`<key>` è il nome della cartella e la chiave con cui viene salvato il layout: non rinominarla dopo l'uso.

## Il file `.def`
```
nome: Calcolatrice
descrizione: Calcolatrice contabile con percentuale IVA
icona: calculator | fa-solid fa-calculator      # UIcons | Font Awesome (fallback)
larghezza: 300
altezza: 440
ridimensionabile: no
```

## Il render — `<key>.php`
```php
function module_calc_render(array $ctx): string   // $ctx: def, medico, config
{
    return '<div class="calc">…</div>';            // solo il contenuto: la finestra (titolo, pulsanti) la disegna la Scrivania
}
```

## Il JS — `js/<key>.js`
```js
DRF.desk.register('calc', {
  init($win, ctx) { /* una volta, quando la finestra viene creata: $win è il contenuto */ },
  open($win)      { /* ogni apertura (es. focus) */ },
  close($win)     { /* alla chiusura */ }
});
```
Stile: usa le classi di DRFacile (`.btn`, `.input`, `.card`, `.badge`…) e i token (`var(--accent)`, `var(--soft)`…) così il modulo segue anche il tema scuro.
