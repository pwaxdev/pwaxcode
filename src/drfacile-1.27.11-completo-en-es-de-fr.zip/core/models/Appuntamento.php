<?php
final class Appuntamento extends Model
{
    protected static string $table = 'appuntamenti';
    protected static array $fillable = ['paziente_id', 'data', 'ora', 'durata', 'tipo', 'urgente', 'note', 'dati', 'stato'];
    protected static array $json = ['dati'];

    public const TIPI = ['visita' => 'Visita', 'controllo' => 'Controllo', 'eco' => 'Ecografia'];
    private static ?array $tipiCache = null;
    private static ?array $legacyCache = null;

    /** I tipi dell'agenda SONO le prestazioni del listino: [id => [nome, colore, durata, previsita]] */
    public static function tipi(): array
    {
        if (self::$tipiCache !== null) return self::$tipiCache;
        $out = [];
        foreach (Database::all('SELECT id, nome, colore, durata, previsita FROM prestazioni WHERE attiva = 1 ORDER BY nome') as $p)
            $out[(string) $p['id']] = ['nome' => $p['nome'], 'colore' => $p['colore'] ?: '#6B6FE6', 'durata' => (int) ($p['durata'] ?: 30), 'previsita' => (int) ($p['previsita'] ?? 0)];
        if (!$out) foreach (self::TIPI as $k => $n) $out[$k] = ['nome' => $n, 'colore' => '#6B6FE6', 'durata' => 30, 'previsita' => 0];
        return self::$tipiCache = $out;
    }

    /** [id => nome] */
    public static function tipiNomi(): array { return array_map(fn($t) => $t['nome'], self::tipi()); }

    public static function tipoNome(?string $codice): string
    {
        $t = self::tipi()[$codice]['nome'] ?? null;
        if ($t !== null) return $t;
        // prestazione disattivata o codice storico (pre-fusione con i tipi di appuntamento)
        if (self::$legacyCache === null) {
            self::$legacyCache = [];
            foreach (Database::all('SELECT id, nome FROM prestazioni') as $p) self::$legacyCache[(string) $p['id']] = $p['nome'];
            if (Database::tableExists('tipi_appuntamento')) foreach (Database::all('SELECT codice, nome FROM tipi_appuntamento') as $r) self::$legacyCache[$r['codice']] = self::$legacyCache[$r['codice']] ?? $r['nome'];
        }
        return self::$legacyCache[$codice] ?? self::TIPI[$codice] ?? (string) $codice;
    }

    private const SELECT = 'SELECT a.*, p.nome, p.cognome FROM appuntamenti a JOIN pazienti p ON p.id = a.paziente_id';

    private static function riga(array $r): array
    {
        $r['paziente'] = nome_completo($r); $r['tipo_label'] = self::tipoNome($r['tipo']);
        unset($r['nome'], $r['cognome']);
        return $r;
    }

    public static function delGiorno(string $data): array
    {
        return array_map([self::class, 'riga'], Database::all(self::SELECT . " WHERE a.data = ? AND a.stato <> 'annullato' ORDER BY a.ora", [$data]));
    }

    public static function contaGiorno(string $data): int
    {
        return (int) Database::value("SELECT COUNT(*) FROM appuntamenti WHERE data = ? AND stato <> 'annullato'", [$data]);
    }

    /** Conteggio per ciascun giorno della settimana (lun-dom) che contiene $data */
    public static function contaSettimana(string $data): array
    {
        $ts = strtotime($data); $lun = strtotime('monday this week', $ts);
        if (date('N', $ts) == 1) $lun = $ts;
        $out = [];
        for ($i = 0; $i < 7; $i++) $out[date('Y-m-d', strtotime("+$i days", $lun))] = 0;
        $rows = Database::all("SELECT data, COUNT(*) n FROM appuntamenti WHERE data BETWEEN ? AND ? AND stato <> 'annullato' GROUP BY data", [array_key_first($out), array_key_last($out)]);
        foreach ($rows as $r) $out[$r['data']] = (int) $r['n'];
        return $out;
    }

    /** Appuntamenti del mese raggruppati per giorno: ['2026-08-03' => [...], ...] */
    public static function delMese(int $anno, int $mese): array
    {
        $da = sprintf('%04d-%02d-01', $anno, $mese); $a = date('Y-m-t', strtotime($da));
        $out = [];
        foreach (Database::all(self::SELECT . " WHERE a.data BETWEEN ? AND ? AND a.stato <> 'annullato' ORDER BY a.data, a.ora", [$da, $a]) as $r) $out[$r['data']][] = self::riga($r);
        return $out;
    }

    /** Il prossimo appuntamento di oggi non ancora concluso */
    public static function prossimo(): ?array
    {
        $ora = date('H:i');
        foreach (self::delGiorno(oggi()) as $a) {
            $fine = date('H:i', strtotime($a['data'] . ' ' . $a['ora']) + $a['durata'] * 60);
            if ($fine >= $ora && $a['stato'] === 'prenotato') return $a;
        }
        return null;
    }

    /** Ritorna l'appuntamento che si sovrappone (escluso $escludiId), oppure null */
    public static function sovrapposto(string $data, string $ora, int $durata, int $escludiId = 0): ?array
    {
        $inizio = strtotime("$data $ora"); $fine = $inizio + $durata * 60;
        foreach (self::delGiorno($data) as $a) {
            if ((int) $a['id'] === $escludiId) continue;
            $ai = strtotime($a['data'] . ' ' . $a['ora']); $af = $ai + $a['durata'] * 60;
            if ($ai < $fine && $inizio < $af) return $a;
        }
        return null;
    }

    public static function salvaDaForm(array $in): array
    {
        $in = Hooks::filter('appuntamento.salva', $in);
        Api::require($in, ['data', 'ora'], ['data' => 'Data', 'ora' => 'Ora']);
        if (!empty($in['nuovo_paziente'])) {
            // paziente creato al volo dalla prenotazione: dati minimi, anagrafica da completare prima della visita
            $cognome = trim((string) ($in['nuovo_cognome'] ?? '')); $nome = trim((string) ($in['nuovo_nome'] ?? ''));
            $tel = trim((string) ($in['nuovo_telefono'] ?? '')); $email = trim((string) ($in['nuovo_email'] ?? ''));
            if ($cognome === '' || $nome === '') throw new ApiException(__('Per il nuovo paziente servono cognome e nome'));
            if ($tel === '') throw new ApiException(__('Per il nuovo paziente il telefono o cellulare è obbligatorio'));
            $in['paziente_id'] = Paziente::save(['nome' => $nome, 'cognome' => $cognome, 'cellulare' => $tel, 'email' => $email ?: null, 'allergie' => []]);
            Attivita::registra('paziente.creato', 'pazienti', (int) $in['paziente_id'], "$cognome $nome (dalla prenotazione)");
            Storico::aggiungi((int) $in['paziente_id'], oggi(), 'Anagrafica', 'Paziente creato dalla prenotazione (da completare)');
            if (Impostazione::get('assistente_attivo', '1') === '1') Percorso::apri('nuovo_paziente', (int) $in['paziente_id'], "Nuovo paziente · $cognome $nome");
        }
        if (empty($in['paziente_id'])) throw new ApiException(__('Il campo "Paziente" è obbligatorio'));
        if (!Paziente::find((int) $in['paziente_id'])) throw new ApiException(__('Paziente non trovato'));
        $data = ['id' => (int) ($in['id'] ?? 0), 'paziente_id' => (int) $in['paziente_id'], 'data' => $in['data'], 'ora' => substr($in['ora'], 0, 5),
            'durata' => max(5, (int) ($in['durata'] ?: Config::get('agenda.durata_default'))), 'tipo' => isset(self::tipi()[$in['tipo'] ?? '']) ? $in['tipo'] : array_key_first(self::tipi()),
            'urgente' => (int) !empty($in['urgente']), 'note' => trim((string) ($in['note'] ?? '')) ?: null, 'stato' => $in['stato'] ?? 'prenotato'];
        $data['dati'] = Model::datiEstensioni($in, $data['id'] ? (array) ((self::find($data['id'])['dati'] ?? []) ?: []) : []);   // campi delle estensioni (form.campi)
        $sovr = self::sovrapposto($data['data'], $data['ora'], $data['durata'], $data['id']);
        $id = self::save($data);
        Attivita::registra(empty($in['id']) ? 'appuntamento.creato' : 'appuntamento.modificato', 'appuntamenti', $id, nome_completo(Paziente::find($data['paziente_id']) ?? []) . ' · ' . data_it($data['data']) . ' ' . $data['ora']);
        if ($sovr) Notifica::aggiungi('warn', 'Appuntamenti sovrapposti', data_it($data['data']) . ' alle ' . $data['ora'] . ': ' . nome_completo(Paziente::find($data['paziente_id']) ?? []) . ' e ' . $sovr['paziente'], ['modulo' => 'agenda', 'opts' => ['date' => $data['data'], 'select' => $id]]);
        $prev = null;
        if (empty($in['id'])) {
            $p = Database::one('SELECT nome, previsita, previsita_titolo, previsita_quando FROM prestazioni WHERE id = ?', [(int) $data['tipo']]);
            if ($p && (int) $p['previsita'] === 1) $prev = ['titolo' => $p['previsita_titolo'] ?: 'Istruzioni pre-visita', 'quando' => $p['previsita_quando'] ?: 'prenotazione',
                'quando_label' => ['prenotazione' => 'alla prenotazione', '24h' => '24 ore prima', '48h' => '48 ore prima'][$p['previsita_quando'] ?: 'prenotazione'] ?? 'alla prenotazione'];
        }
        return ['id' => $id, 'sovrapposizione' => $sovr ? ['paziente' => $sovr['paziente'], 'ora' => $sovr['ora']] : null, 'previsita' => $prev,
            'paziente_creato' => !empty($in['nuovo_paziente']) ? nome_completo(Paziente::find((int) $in['paziente_id']) ?? []) : null];
    }
}
