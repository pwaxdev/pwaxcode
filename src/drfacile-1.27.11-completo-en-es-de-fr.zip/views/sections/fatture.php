<div class="stagger">
  <div class="kpis" id="fKpis"></div>
  <div class="toolbar">
    <div class="seg" id="fFilter"><button class="on" data-f="tutte"><?= __('Tutte') ?></button><button data-f="pagata"><?= __('Pagate') ?></button><button data-f="attesa"><?= __('In attesa') ?></button><button data-f="scaduta"><?= __('Scadute') ?></button></div>
    <button class="btn ghost sm" id="fDaVisita" style="margin-left:auto"><i class="ico" data-fi="stethoscope" data-fa="fa-solid fa-stethoscope"></i><?= __('Da visita') ?></button>
    <button class="btn ghost sm" id="fListino"><i class="ico" data-fi="list" data-fa="fa-solid fa-list"></i><?= __('Listino prestazioni') ?></button>
  </div>
  <div class="card"><table id="fTable" class="dt" style="width:100%"><thead><tr><th></th><th><?= __('Numero') ?></th><th><?= __('Data') ?></th><th><?= __('Paziente') ?></th><th><?= __('Prestazione') ?></th><th><?= __('Totale') ?></th><th><?= __('Stato') ?></th></tr></thead><tbody id="fBody"></tbody></table></div>
</div>
