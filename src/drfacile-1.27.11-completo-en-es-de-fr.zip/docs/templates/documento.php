<?php /** @var array $doc @var array $paziente @var array $medico @var bool $auto_print */ ?>
<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8"><title><?= e($doc['titolo']) ?> · <?= e($paziente['nome_completo']) ?></title><?php include __DIR__ . '/_stile.php'; ?></head>
<body>
<div class="toolbar"><button class="ghost" onclick="window.close()">Chiudi</button><button onclick="window.print()">Stampa / salva PDF</button></div>
<div class="foglio">
  <?php $destra = '<div class="destinatario">' . (($tipo ?? '') === 'fattura' ? '<span class="dest-eyebrow">Spett.le</span>' : '') . '<b>' . e($paziente['nome_completo']) . '</b>'
  . (!empty($paziente['indirizzo']) ? '<span>' . e($paziente['indirizzo']) . '</span>' : '')
  . (($riga2 = trim(implode(' ', array_filter([$paziente['cap'] ?? '', $paziente['citta'] ?? '', !empty($paziente['provincia']) ? '(' . $paziente['provincia'] . ')' : ''])))) !== '' ? '<span>' . e($riga2) . '</span>' : '')
  . (!empty($paziente['cf']) ? '<span class="mono">CF ' . e($paziente['cf']) . '</span>' : '') . '</div>'; include __DIR__ . '/_testata.php'; ?>
  <div class="doc-riga"><b><?= e($doc['titolo']) ?></b> · <?= data_it(oggi()) ?></div>
  <div class="rich-out" style="margin-top:18px"><?= $doc['corpo'] ?></div>
  <div class="firma"><div><?php if (!empty($doc['firma_img'])): ?><img src="<?= $doc['firma_img'] ?>" alt="Firma" style="display:block;height:64px;margin-bottom:-14px"><span style="display:block;border-top:1px solid #C9CCDA;padding-top:8px;width:240px">Firma del paziente · apposta sul tablet il <?= e(data_it(oggi())) ?></span><?php else: ?><span style="display:block;border-top:1px solid #C9CCDA;margin-top:60px;padding-top:8px;width:240px">Firma del paziente</span><?php endif; ?></div></div>
  <?php include __DIR__ . '/_piede.php'; ?>
</div>
</body></html>
