/* Modulo Visita: schede Anamnesi → Visita → Esami → Terapia → Complicanze, bozza salvata in automatico,
   storico visite (DataTable con modifica/eliminazione), modifica di visite già chiuse, chiusura con referto */
DRF.register('visita', (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;
  const TABS = ['anamnesi', 'visita', 'esami', 'terapia', 'complicanze'];
  const VIT = ['pa_sys', 'pa_dia', 'fc', 'spo2', 'temp', 'peso', 'altezza', 'glicemia'];
  const TXT = ['motivo', 'anamnesi', 'esame_obiettivo', 'indicazioni', 'controllo', 'complicanze'];
  const STATO = { bozza: 'amber', firmato: 'mint', inviato: 'sky' };
  const st = { visita: null, paziente: null, dx: [], th: [], ex: [], prest: [], tab: 0, pazienti: [], storico: [], visite: [], dt: null, dtEx: null, bmS: null, bmR: null };
  const meta = () => st.paziente ? { sesso: st.paziente.sesso, nascita: st.paziente.nascita } : {};
  const modifica = () => !!(st.visita && st.visita.stato === 'chiusa');

  function load() { return DRF.api.get('visita', 'corrente').then(apply); }
  function apply(d) {
    st.visita = d.visita; st.paziente = d.paziente; st.pazienti = d.pazienti; st.appuntamento = d.appuntamento; st.tipi = d.tipi; st.storico = d.storico; st.visite = d.visite_precedenti || [];
    st.dx = d.visita ? d.visita.diagnosi || [] : []; st.th = d.visita ? d.visita.terapia || [] : []; st.ex = d.visita ? d.visita.esami || [] : [];
    st.prest = d.visita ? (d.visita.prestazioni || []).map(x => +x.id) : [];
    const $vp = $('#vPrest');
    const conPrezzi = !DRF.config.pref || DRF.config.pref.prezzi_visita !== false;
    $vp.empty().append((d.prestazioni_catalogo || []).map(p => `<option value="${p.id}">${DRF.esc(p.nome)}${conPrezzi ? ` · ${DRF.util.eur(p.prezzo)}${+p.aliquota ? ` ${DRF.__('(+IVA')} ${(+p.aliquota).toLocaleString(DRF.util.loc(), { maximumFractionDigits: 2 })}%)` : ''}` : ''}</option>`).join(''));
    $vp.val(st.prest.map(String)).trigger('change.select2');
    $('#dxList').html((d.diagnosi_frequenti || []).map(x => `<option value="${DRF.esc(x.descrizione)}">${DRF.esc(x.codice || '')}</option>`).join(''));
    $('#exList').html((d.esami_catalogo || []).map(x => `<option value="${DRF.esc(x.nome)}">${DRF.esc(x.categoria || '')}</option>`).join(''));
    fillForm(); render(); DRF.nav.refreshSub(); DRF.postit.refresh(); if (DRF.state.current === 'visita') DRF.nav.updateTopbar();
    DRF.nav.setDot('visita', !!(st.visita && st.visita.stato === 'bozza'), st.paziente ? DRF.__('Visita in corso: ') + st.paziente.nome_completo : '');
    st.bmS.reload().load(d.visita ? d.visita.sintomi || [] : []); st.bmR.reload().load(d.visita ? d.visita.reperti || [] : []);
    st.bmS.setReadonly(!d.visita); st.bmR.setReadonly(!d.visita);
    // punto di aggancio per le estensioni (docs/sviluppo-estensioni.md): possono aggiungere pannelli,
    // riempire campi, o trasformare la visita in una visita specialistica
    st.datiExt = (d.visita && d.visita.dati && !Array.isArray(d.visita.dati)) ? d.visita.dati : {};   // il PHP serializza l'insieme vuoto come [] — e JSON.stringify di un Array PERDE le chiavi con nome
    DRF.hooks.run('visita.pannello', { $root: $('[data-panel="visita"]'), visita: st.visita, paziente: st.paziente,
      // SOSTITUZIONE del corpo visita: nasconde stepper e tab standard e consegna un contenitore
      // a tutta colonna (testata paziente, storico e chiusura dalla topbar restano del core)
      sostituisci: $contenuto => {
        st.extBody = true;
        const $col = $('[data-panel="visita"] .visit > div').first();
        $col.find('#stepper, .vtab').prop('hidden', true);
        $('#vPrev, #vNext').closest('.row').prop('hidden', true);
        let $ext = $col.find('.visita-ext');
        if (!$ext.length) $ext = $('<div class="visita-ext"></div>').appendTo($col);
        if ($contenuto) $ext.empty().append($contenuto);
        return $ext;
      },
      // prende in prestito un blocco VIVO del core (es. la field di #vPrest, la card di #vitals,
      // la card di #vStorico): handler, select2 e datatable continuano a funzionare
      adotta: selettore => { const $b = $('[data-panel="visita"]').find(selettore).first(); if (!$b.length) return $b; if (!$b.prev('.ext-segnaposto').length) $('<span class="ext-segnaposto" hidden></span>').insertBefore($b); return $b; },
      ripristina: () => {
        st.extBody = false; const $col = $('[data-panel="visita"] .visit > div').first();
        $('[data-panel="visita"] .ext-segnaposto').each(function () { const $s = $(this); $s.after($col.find('.visita-ext').find($s.data('per') || null)); });
        $('[data-panel="visita"] .visita-ext .adottato').each(function () { /* riconsegna gestita dai segnaposto */ });
        $col.find('#stepper, .vtab').prop('hidden', false); $('#vPrev, #vNext').closest('.row').prop('hidden', false); $col.find('.visita-ext').remove(); setTab(st.tab);
      },
      setDiagnosi: lista => { st.dx = (lista || []).filter(Boolean); if (st.visita) autosave(); },
      chiudi: () => M.chiudi(),
      // dati strutturati per estensione: persistono sulla visita (colonna dati, fusi per codice) e viaggiano con l'autosave
      getDati: codice => (st.datiExt || {})[codice] || null,
      setDati: (codice, valori) => { if (!st.datiExt || Array.isArray(st.datiExt)) st.datiExt = {}; st.datiExt[codice] = valori; if (st.visita) autosave(); },
      setNota: txt => { const $n = $('#vNote'); const cur = DRF.ui.rich ? ($n[0]._drfRich ? $n[0]._drfRich.get() : $n.val()) : $n.val(); DRF.ui.setVal($n, (cur ? cur + '<p>' : '<p>') + DRF.esc(txt) + '</p>'); $n.trigger('input'); } });
  }
  function fillForm() {
    const v = st.visita || {};
    VIT.forEach(k => DRF.ui.setVal($(`#vitals [name="${k}"]`), v[k] || ''));
    TXT.forEach(k => DRF.ui.setVal($(`.visit [name="${k}"]`), v[k] || ''));
    const comp = !!(v.complicanze && String(v.complicanze).trim());
    $('#vCompSeg button').removeClass('on').filter(`[data-v="${comp ? 1 : 0}"]`).addClass('on'); $('.visit [name=complicanze]').prop('hidden', !comp);
    calcBmi(); $('#vSaved').text('');
  }
  function render() {
    const p = st.paziente, $vh = $('#vhead');
    if (!p) {
      $vh.html(`<div class="av" style="background:var(--soft-2);color:var(--ink-3)">?</div><div><b>${DRF.__('Nessuna visita in corso')}</b><div class="muted small">${DRF.__('Scegli un paziente per iniziare, oppure avviala dall\'agenda o con un doppio click in Pazienti')}</div></div><select class="select" id="vPick"><option value="">${DRF.__('Seleziona paziente…')}</option>${st.pazienti.map(x => `<option value="${x.id}">${DRF.esc(x.nome_completo)}</option>`).join('')}</select>`);
      DRF.ui.wire($vh[0]);
      $('#vPick').on('change', function () { if (this.value) M.avvia(+this.value); });
    } else if (modifica()) {
      $vh.html(`${DRF.ui.avatar(p.nome_completo)}<div><b style="font-size:15px">${DRF.esc(p.nome_completo)}</b><div class="muted small">${p.eta != null ? DRF._n('%d anno', '%d anni', p.eta) + ' · ' : ''}<span class="mono">${DRF.esc(p.cf || '')}</span></div></div><span class="badge amber" style="margin-left:auto">${I('pencil', 'fa-solid fa-pen')} ${DRF.__('modifica visita del')} ${U.fmtIso(st.visita.data)}</span><button class="btn ghost sm" id="vBack">${DRF.__('Esci dalla modifica')}</button>`);
      $('#vBack').on('click', () => load());
    } else {
      const a = st.appuntamento;
      $vh.html(`${DRF.ui.avatar(p.nome_completo)}<div><b style="font-size:15px">${DRF.esc(p.nome_completo)}</b><div class="muted small">${p.eta != null ? DRF._n('%d anno', '%d anni', p.eta) + ' · ' : ''}<span class="mono">${DRF.esc(p.cf || '')}</span>${a ? ' · ' + a.ora + ' ' + (st.tipi[a.tipo] || '') : ''}</div></div><span class="badge violet" style="margin-left:auto">${I('clock', 'fa-regular fa-clock')} ${DRF.__('in corso dalle')} ${st.visita.ora}</span><button class="btn ghost sm" id="vChange">${DRF.__('Cambia paziente')}</button>`);
      $('#vChange').on('click', () => M.annulla(true));
    }
    DRF.icons.apply($vh[0]);
    setTab(st.tab);
    $('.visit :input, #closeVisit, #draftVisit, #abortVisit').not('#vPick').prop('disabled', !p);
    $('.visit textarea.rich').each(function () { if (this._drfRich) this._drfRich.enable(!!p); });
    $('#closeVisit').html(modifica() ? `${I('check', 'fa-solid fa-check')}${DRF.__('Salva modifiche')}` : `${I('check', 'fa-solid fa-check')}${DRF.__('Chiudi visita e genera referto')}`); DRF.icons.apply($('#closeVisit')[0]);
    $('#draftVisit').toggle(!modifica()); $('#abortVisit').html(modifica() ? DRF.__('Annulla modifiche') : DRF.__('Annulla visita'));
    renderDx(); renderTh(); renderEx(); renderStorico();
    if (p) DRF.storico.render($('#vhist'), st.storico, true); else $('#vhist').removeClass('timeline compatta').html('<span class="muted small">' + DRF.__('Nessun paziente selezionato.') + '</span>');
    $('#vAlert').html(p ? (p.allergie.length ? p.allergie.map(a => `<div>${I('exclamation', 'fa-solid fa-triangle-exclamation')}<b>${DRF.__('Allergia:')}</b> ${DRF.esc(a)}</div>`).join('') : '<span class="muted small">' + DRF.__('Nessuna allergia o interazione segnalata.') + '</span>') : '<span class="muted small">—</span>');
    DRF.icons.apply($('#vAlert')[0]);
  }
  function setTab(i) {
    if (st.extBody) return;   // corpo sostituito da un'estensione: il percorso standard resta spento
    st.tab = Math.max(0, Math.min(TABS.length - 1, i));
    $('#stepper .step').each((j, s) => { s.classList.toggle('on', j === st.tab); s.classList.toggle('done', j < st.tab); });
    $('.vtab').each(function () { this.hidden = this.dataset.tab !== TABS[st.tab]; });
    $('#vPrev').prop('disabled', st.tab === 0 || !st.paziente);
    $('#vNext').html(st.tab === TABS.length - 1 ? `${I('check', 'fa-solid fa-check')}${modifica() ? DRF.__('Salva modifiche') : DRF.__('Chiudi visita e genera referto')}` : `${DRF.__('Avanti')}${I('angle-right', 'fa-solid fa-chevron-right')}`); DRF.icons.apply($('#vNext')[0]);
    if (st.tab === 1 && st.dt) st.dt.columns.adjust();
    if (st.tab === 2 && st.dtEx) st.dtEx.columns.adjust();
    $('#panels').scrollTop(0);
  }
  function renderDx() {
    const $box = $('#dxBox'), $inp = $('#dxInput'); $box.find('.tag').remove();
    st.dx.forEach((d, i) => $(`<span class="tag">${DRF.esc(d)}<button type="button" data-i="${i}" title="${DRF.__('Rimuovi')}">${I('cross-small', 'fa-solid fa-xmark')}</button></span>`).insertBefore($inp));
    DRF.icons.apply($box[0]);
  }
  function renderTh() {
    $('#therapy').html(st.th.map((t, i) => `<div>${I('capsules', 'fa-solid fa-pills')}<span>${DRF.esc(t)}</span><button type="button" data-i="${i}" title="${DRF.__('Rimuovi')}">${I('cross-small', 'fa-solid fa-xmark')}</button></div>`).join('') || '<p class="small muted" style="padding:4px 0 8px">' + DRF.__('Nessun farmaco prescritto.') + '</p>');
    DRF.icons.apply($('#therapy')[0]);
  }
  function renderEx() {
    if (!st.dtEx) st.dtEx = DRF.ui.datatable($('#exTable'), { pageLength: 10, lengthMenu: [10, 25], order: [], paging: false, searching: false, info: false, layout: { topStart: null, topEnd: null, bottomStart: null, bottomEnd: null }, language: { emptyTable: DRF.__('Nessun esame: aggiungilo dal campo qui sopra.') }, columns: [
      { data: null, orderable: false, className: 'dt-actions', render: (e, t, r, m) => `<button class="icon-btn sm accent" data-ex-toggle="${m.row}" type="button" title="${e.stato === 'eseguito' ? DRF.__('Riporta a richiesto') : DRF.__('Segna eseguito')}">${I(e.stato === 'eseguito' ? 'undo' : 'check', e.stato === 'eseguito' ? 'fa-solid fa-rotate-left' : 'fa-solid fa-check')}</button><button class="icon-btn sm danger" data-ex-del="${m.row}" type="button" title="${DRF.__('Rimuovi')}">${I('trash', 'fa-solid fa-trash')}</button>` },
      { data: 'nome', render: d => `<b>${DRF.esc(d)}</b>` },
      { data: 'stato', render: d => DRF.ui.badge(d === 'eseguito' ? 'mint' : 'amber', d === 'eseguito' ? DRF.__('Eseguito') : DRF.__('Richiesto')) },
      { data: 'data', render: (d, t, e, m) => `<input class="input sm-inline" type="date" data-ex-data="${m.row}" value="${DRF.esc(d || '')}" ${modifica() || st.visita ? '' : 'disabled'}>` },
      { data: 'esito', render: (d, t, e, m) => `<input class="input sm-inline" data-ex-esito="${m.row}" value="${DRF.esc(d || '')}" placeholder="${DRF.__('Esito, valori, note…')}">` },
    ], drawCallback() { DRF.ui.dates($('#exTable')[0]); } });
    st.dtEx.clear().rows.add(st.ex).draw();
  }
  function renderStorico() {
    if (!st.dt) st.dt = DRF.ui.datatable($('#vStorico'), { pageLength: 5, lengthMenu: [5, 10, 25], order: [[1, 'desc']], columns: [
      { data: 'id', orderable: false, searchable: false, className: 'dt-actions', render: (id, t, r) => `<button class="icon-btn sm" data-vis-edit="${id}" type="button" title="${DRF.__('Modifica visita')}">${I('pencil', 'fa-solid fa-pen')}</button><button class="icon-btn sm danger" data-vis-del="${id}" type="button" title="${DRF.__('Elimina visita')}" ${r.referto_stato && r.referto_stato !== 'bozza' ? 'disabled' : ''}>${I('trash', 'fa-solid fa-trash')}</button>${r.referto_id ? `<button class="icon-btn sm" data-ref="${r.referto_id}" type="button" title="${DRF.__('Apri referto')}">${I('document', 'fa-regular fa-file-lines')}</button>` : ''}` },
      { data: 'data', render: (d, t, r) => t === 'display' ? `<b class="num">${U.fmtIso(d)}</b><div class="small muted">${r.ora || ''}</div>` : d },
      { data: 'motivo', render: d => DRF.esc(d || '—') },
      { data: 'diagnosi', render: d => DRF.esc(d || '—') },
      { data: 'referto_stato', render: (d, t, r) => r.referto_id ? DRF.ui.badge(STATO[d] || 'gray', (r.referto_tipo || DRF.__('Referto')) + ' · ' + (d || '')) : '<span class="muted">—</span>' },
    ] });
    st.dt.clear().rows.add(st.visite).draw();
  }
  function calcBmi() {
    const kg = parseFloat(String(DRF.ui.val($('#vPeso')) || '').replace(',', '.')), cm = parseFloat(DRF.ui.val($('#vAlt')));
    // finché i valori non sono plausibili (si sta ancora digitando) il BMI resta —, sempre con 1 decimale
    if (!kg || !cm || kg < 10 || cm < 50 || cm > 260) { $('#vBmi').text('—'); $('#vBmiCat').text(''); return; }
    const b = kg / Math.pow(cm / 100, 2);
    $('#vBmi').text(b.toFixed(1).replace('.', ','));
    $('#vBmiCat').text(b < 18.5 ? DRF.__('sottopeso') : b < 25 ? DRF.__('normopeso') : b < 30 ? DRF.__('sovrappeso') : DRF.__('obesità'));
    calcGli();
  }
  /** Glicemia con categoria colorata (soglie ADA/SID a digiuno, uguali per sesso ed età; in gravidanza valgono criteri propri) */
  function calcGli() {
    const g = parseFloat(DRF.ui.val($('#vGli')));
    const $c = $('#vGliCat').removeClass('gli-ok gli-warn gli-bad');
    if (!g || g < 20) { $c.text(''); return; }
    const [txt, cls] = g < 54 ? [DRF.__('molto bassa'), 'gli-bad'] : g < 70 ? [DRF.__('bassa'), 'gli-warn'] : g < 100 ? [DRF.__('nella norma'), 'gli-ok'] : g < 126 ? [DRF.__('alterata'), 'gli-warn'] : [DRF.__('elevata'), 'gli-bad'];
    $c.text(txt).addClass(cls);
  }
  function payload() {
    const d = { id: st.visita.id, diagnosi: st.dx, terapia: st.th, esami: st.ex, prestazioni: st.prest, sintomi: st.bmS.getData(), reperti: st.bmR.getData(), dati: st.datiExt || {} };
    VIT.forEach(k => d[k] = DRF.ui.val($(`#vitals [name="${k}"]`)));
    TXT.forEach(k => d[k] = DRF.ui.val($(`.visit [name="${k}"]`)));
    if (DRF.ui.segValue($('#vCompSeg')) == 0) d.complicanze = '';
    return d;
  }
  const autosave = U.debounce(() => { if (!st.visita || modifica()) return; DRF.api.post('visita', 'salva', payload()).then(() => $('#vSaved').text(DRF.__('Bozza salvata alle ') + new Date().toLocaleTimeString(DRF.util.loc(), { hour: '2-digit', minute: '2-digit' }))); }, 900);
  function pulisci() { DRF.nav.setDot('visita', false); st.visita = null; st.paziente = null; st.datiExt = {}; st.dx = []; st.th = []; st.ex = []; st.prest = []; $('#vPrest').val([]).trigger('change.select2'); st.visite = []; st.tab = 0; fillForm(); render(); st.bmS.clear().setReadonly(true); st.bmR.clear().setReadonly(true); DRF.nav.refreshSub(); if (DRF.state.current === 'visita') DRF.nav.updateTopbar(); }

  const M = {
    title: DRF.__('Visita'),
    record() { return st.paziente ? { sezione: 'paziente', record: st.paziente.id } : null; },
    paziente() { return st.paziente; }, visita() { return st.visita; },   // per le estensioni (topbar.azioni, slot)
    sub() { const p = st.paziente; if (!p) return DRF.__('Nessuna visita in corso'); return `${p.nome_completo} · ${p.eta != null ? DRF._n('%d anno', '%d anni', p.eta) + ' · ' : ''}${modifica() ? DRF.__('modifica della visita del') + ' ' + U.fmtIso(st.visita.data) : DRF.__('visita in corso')}`; },
    get action() { return st.visita ? { label: modifica() ? DRF.__('Salva modifiche') : DRF.__('Chiudi e genera referto'), fi: 'check', fa: 'fa-solid fa-check', run: () => M.chiudi() } : null; },

    /** Avvia la visita per un paziente (eventualmente da un appuntamento) e apre il modulo */
    avvia(pazienteId, appuntamentoId) {
      const go = () => DRF.api.post('visita', 'avvia', { paziente_id: pazienteId, appuntamento_id: appuntamentoId || null }).then(d => {
        st.tab = 0; apply(d); DRF.emit('visita:avviata', d.paziente); DRF.nav.go('visita'); DRF.ui.toast(`${DRF.__('Visita avviata:')} ${d.paziente.nome_completo}`, { fi: 'stethoscope', fa: 'fa-solid fa-stethoscope' });
        if (d.anagrafica_incompleta) DRF.ui.confirm(DRF.__('Anagrafica da completare'), `${DRF.__('Nella scheda di')} ${d.paziente.nome_completo} ${DRF.__('mancano:')} ${d.anagrafica_incompleta}${DRF.__('. Completarla ora?')}`, DRF.__('Completa la scheda')).then(ok => { if (ok) DRF.form.open('paziente', { id: +d.paziente.id, onSaved: () => DRF.ui.toast(DRF.__('Scheda completata')) }); });
      });
      if (st.visita && !modifica() && +st.visita.paziente_id !== +pazienteId) DRF.ui.confirm(DRF.__('Visita già in corso'), `${DRF.__('C\'è una bozza aperta per')} ${st.paziente.nome_completo}${DRF.__('. Vuoi scartarla e iniziare la nuova visita?')}`, DRF.__('Scarta e inizia')).then(ok => { if (ok) go(); });
      else if (st.visita && !modifica()) { DRF.nav.go('visita'); }
      else go();
    },
    /** Apre in modifica una visita già chiusa */
    modifica(id) {
      DRF.api.get('visita', 'apri', { id }).then(d => { st.tab = 0; apply(d); DRF.nav.go('visita'); DRF.ui.toast(`${DRF.__('Modifica della visita del')} ${U.fmtIso(d.visita.data)}`, 'info'); });
    },
    annulla(silenzioso) {
      if (!st.visita) return;
      if (modifica()) return load();
      const run = () => DRF.api.post('visita', 'annulla', { id: st.visita.id }).then(() => { pulisci(); DRF.emit('visita:chiusa', {}); if (!silenzioso) DRF.ui.toast(DRF.__('Visita annullata'), 'info'); });
      if (silenzioso) run(); else DRF.ui.confirm(DRF.__('Annullare la visita?'), DRF.__('I dati inseriti in questa bozza andranno persi.'), DRF.__('Annulla visita')).then(ok => { if (ok) run(); });
    },
    chiudi() {
      if (!st.visita) return DRF.ui.toast(DRF.__('Seleziona prima un paziente'), 'warn');
      if (modifica()) {
        return DRF.api.post('visita', 'salva_chiusa', payload()).then(r => { DRF.ui.toast(r.referto_rigenerato ? DRF.__('Visita aggiornata e referto in bozza rigenerato') : DRF.__('Visita aggiornata')); load(); });
      }
      DRF.ui.confirm(DRF.__('Chiudere la visita?'), DRF.__('Verrà generato il referto e la visita entrerà nello storico del paziente.'), DRF.__('Chiudi e genera referto')).then(ok => {
        if (!ok) return;
        DRF.api.post('visita', 'chiudi', payload()).then(r => {
          const p = st.paziente; pulisci(); DRF.emit('visita:chiusa', { paziente: p, referto_id: r.referto_id });
          DRF.ui.toast(r.stato === 'firmato' ? DRF.__('Referto generato e firmato') : `${DRF.__('Referto in bozza per')} ${p.nome_completo}`, { fi: 'document', fa: 'fa-regular fa-file-lines' });
          DRF.app.aggiornaBadge();
          DRF.nav.go('referti', { select: r.referto_id });
        });
      });
    },

    init() {
      st.bmS = DRF.bodymap({ box: '#bmSintomi', mode: 'sintomi', getMeta: meta, onChange: () => { if (st.visita) autosave(); } });
      st.bmR = DRF.bodymap({ box: '#bmReperti', mode: 'esame', getMeta: meta, onChange: () => { if (st.visita) autosave(); } });
      $('#stepper').on('click', '.step', function () { setTab($(this).index()); });
      $('#vPrev').on('click', () => setTab(st.tab - 1));
      $('#vNext').on('click', () => st.tab === TABS.length - 1 ? M.chiudi() : setTab(st.tab + 1));
      $('#vitals').on('input keyup', 'input', () => { calcBmi(); autosave(); });
      $('#vPrest').on('change', function () { st.prest = ($(this).val() || []).map(Number); autosave(); });
      $('.visit').on('input change', '[name]', function () { if (!$(this).closest('#vitals').length) autosave(); });
      $('#vCompSeg').on('seg:change', (e, v) => { $('.visit [name=complicanze]').prop('hidden', v == 0); if (v == 0) $('.visit [name=complicanze]').val(''); autosave(); });
      $('#dxInput').on('keydown', function (e) { if (e.key === 'Enter' && this.value.trim()) { e.preventDefault(); st.dx.push(this.value.trim()); this.value = ''; renderDx(); autosave(); } });
      $('#dxInput').on('change', function () { if (this.value.trim() && $('#dxList option').filter((_, o) => o.value === this.value).length) { st.dx.push(this.value.trim()); this.value = ''; renderDx(); autosave(); } });
      $('#dxBox').on('click', '.tag button', function () { st.dx.splice(+this.dataset.i, 1); renderDx(); autosave(); });
      const addTh = () => { const v = $('#thInput').val().trim(); if (!v) return; st.th.push(v); $('#thInput').val(''); renderTh(); autosave(); };
      $('#thAdd').on('click', addTh);
      $('#thInput').on('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addTh(); } });
      $('#therapy').on('click', 'button', function () { st.th.splice(+this.dataset.i, 1); renderTh(); autosave(); });
      // esami
      const addEx = () => { const v = $('#exInput').val().trim(); if (!v) return; st.ex.push({ nome: v, stato: DRF.ui.segValue($('#exStato')) || 'richiesto', data: null, esito: '' }); $('#exInput').val(''); renderEx(); autosave(); };
      $('#exAdd').on('click', addEx);
      $('#exInput').on('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addEx(); } });
      $('#exTable').on('click', '[data-ex-del]', function () { st.ex.splice(+this.dataset.exDel, 1); renderEx(); autosave(); })
        .on('click', '[data-ex-toggle]', function () { const e = st.ex[+this.dataset.exToggle]; e.stato = e.stato === 'eseguito' ? 'richiesto' : 'eseguito'; if (e.stato === 'eseguito' && !e.data) e.data = U.todayIso(); renderEx(); autosave(); })
        .on('change', '[data-ex-data]', function () { st.ex[+this.dataset.exData].data = this.value || null; autosave(); })
        .on('input', '[data-ex-esito]', function () { st.ex[+this.dataset.exEsito].esito = this.value; autosave(); });
      // storico
      $('#vStorico').on('click', '[data-ref]', function () { DRF.nav.go('referti', { select: +this.dataset.ref }); })
        .on('click', '[data-vis-edit]', function () { M.modifica(+this.dataset.visEdit); })
        .on('click', '[data-vis-del]', function () { const id = +this.dataset.visDel; DRF.ui.confirm(DRF.__('Eliminare la visita?'), DRF.__('Verranno rimossi la visita e il referto in bozza collegato.'), DRF.__('Elimina')).then(ok => { if (ok) DRF.api.post('visita', 'elimina', { id }).then(r => { DRF.ui.toast(r.messaggio); load(); DRF.app.aggiornaBadge(); }); }); });
      $('#closeVisit').on('click', () => M.chiudi());
      $('#draftVisit').on('click', () => { if (!st.visita) return DRF.ui.toast(DRF.__('Seleziona prima un paziente'), 'warn'); DRF.api.post('visita', 'salva', payload()).then(() => DRF.ui.toast(DRF.__('Bozza della visita salvata'), { fi: 'disk', fa: 'fa-regular fa-floppy-disk' })); });
      $('#abortVisit').on('click', () => M.annulla(false));
      DRF.api.get('ricette', 'farmaci').then(f => $('#thList').html(f.map(x => `<option value="${DRF.esc(x.nome + (x.posologia ? ' — ' + x.posologia : ''))}">`).join('')));
    },
    show(opts) { if (opts && opts.modifica) return M.modifica(+opts.modifica); if (!modifica()) load(); else render(); }
  };
  return M;
})(jQuery));
