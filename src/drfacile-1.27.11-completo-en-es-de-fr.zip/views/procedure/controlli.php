<?php /** Pagina demo "Controlli di DRFacile": ogni riquadro lancia un controllo e mostra il codice per usarlo nei propri moduli. Logica in assets/js/procedure.js → viste.controlli */
$ctl = function (string $titolo, string $desc, string $bottoni, string $codice): string {
    return '<div class="ctl"><div class="ctl-head"><div><b>' . e($titolo) . '</b><span>' . e($desc) . '</span></div><button class="icon-btn sm" type="button" data-code title="Mostra il codice"><i class="ico" data-fi="brackets-curly" data-fa="fa-solid fa-code"></i></button></div><div class="ctl-btns">' . $bottoni . '</div><pre hidden>' . e($codice) . '</pre></div>';
};
$btn = fn(string $k, string $l, string $cls = 'ghost') => '<button class="btn ' . $cls . ' sm" type="button" data-ctl="' . $k . '">' . e($l) . '</button>';
?>
<div class="ctl-grid">
  <?= $ctl('Modali', 'Titolo in alto, contenuto libero, OK e Chiudi in basso a destra. onOk può bloccare la chiusura (validazione).',
      $btn('modal_sm', 'Modale piccola', 'primary') . $btn('modal_lg', 'Modale grande'),
      "DRF.ui.modal({\n  title: 'Titolo', size: 'sm' | 'lg' | 'xl',\n  html: '<p>…</p>',            // oppure una form del FormBuilder\n  ok: 'OK', cancel: 'Chiudi',\n  onOpen: (\$body) => {},        // es. montare una DataTable\n  onOk:   (\$body) => { /* return false per non chiudere */ }\n}).then(ok => { /* true = OK, false = chiusa */ });") ?>

  <?= $ctl('Messaggi', 'Conferma sì/no, sì/no/annulla, avviso con OK, oppure pulsanti a piacere. Restituiscono una promise.',
      $btn('conf2', 'Sei sicuro? (sì/no)', 'primary') . $btn('conf3', 'Sì / No / Annulla') . $btn('alert', 'Avviso') . $btn('dialog', 'Pulsanti liberi'),
      "DRF.ui.confirm('Sei sicuro?', 'Testo', 'Sì, procedi').then(ok => …);      // true/false\nDRF.ui.confirm3('Salvare?', 'Testo').then(k => …);                         // 'si' | 'no' | 'annulla'\nDRF.ui.alert('Fatto', 'Testo', 'success');                                  // kind: info | success | warn | error\nDRF.ui.dialog({ title, text, kind: 'warn',\n  buttons: [{ k: 'stampa', label: 'Stampa', cls: 'ghost' }, { k: 'invia', label: 'Invia', cls: 'primary' }]\n}).then(k => …);                                                            // chiave del pulsante premuto") ?>

  <?= $ctl('Toast', 'Notifiche in basso a destra, con suono. Quattro tipi più l\'icona personalizzata.',
      $btn('toast_ok', 'Successo', 'primary') . $btn('toast_warn', 'Attenzione') . $btn('toast_err', 'Errore', 'danger') . $btn('toast_info', 'Info') . $btn('toast_ico', 'Icona') . $btn('toast_undo', 'Con Annulla', 'soft'),
      "DRF.ui.toast('Salvato', 'success');   // 'success' | 'warn' | 'error' | 'info'\nDRF.ui.toast('Inviato', { fi: 'paper-plane', fa: 'fa-regular fa-paper-plane' });\nDRF.ui.toast('Eliminato', 'info', { undo: () => ripristina() });   // 8 secondi per annullare") ?>

  <?= $ctl('Pannello laterale e form', 'La sheet ospita HTML libero oppure una form generata dal FormBuilder (form/definitions).',
      $btn('sheet', 'Pannello con HTML', 'primary') . $btn('form', 'Form dal FormBuilder') . $btn('form_paz', 'Form paziente precompilata'),
      "DRF.ui.openSheet('Titolo', html, () => { const dati = DRF.ui.formData(\$('#sheetBody')); DRF.ui.closeSheet(); }, 'Salva');\nDRF.form.open('prestazione', { id: 3, values: {…}, onSaved: r => … });   // definizione in form/definitions/prestazione.php") ?>

  <?= $ctl('Barra dei passi', 'Stati di un processo: fatti, in corso, da fare, errore. Qui in una modale che simula l\'invio di una ricetta al Sistema TS.',
      $btn('steps_ok', 'Invio ricetta (simulazione)', 'primary') . $btn('steps_err', 'Con errore al passo 2', 'danger'),
      "const s = DRF.ui.steps(\$('#box'), { current: 0, steps: [\n  { label: 'Firma', fi: 'document-signed', fa: 'fa-solid fa-file-signature' },\n  { label: 'Invio', desc: 'Sistema TS', fi: 'paper-plane', fa: 'fa-regular fa-paper-plane' },\n  { label: 'NRE' }, { label: 'Promemoria' }\n]});\ns.set(2);                    // passo corrente (i precedenti diventano fatti)\ns.error(1, 'Timeout');       // passo in errore con messaggio\ns.done();                    // tutti completati") ?>

  <div class="ctl ctl-wide">
    <div class="ctl-head"><div><b><?= __('Linea del tempo') ?></b><span><?= __('Generata da un array: data, tipo, titolo, descrizione, icona, colore; cliccabile con run. Alternata a destra e sinistra con i separatori per anno, oppure compatta (come nello storico paziente).') ?></span></div><button class="icon-btn sm" type="button" data-code title="<?= __('Mostra il codice') ?>"><i class="ico" data-fi="brackets-curly" data-fa="fa-solid fa-code"></i></button></div>
    <div class="ctl-btns" style="margin-bottom:12px"><div class="seg" id="ctlTlMode"><button type="button" class="on" data-v="alterna"><?= __('Alternata') ?></button><button type="button" data-v="compatta"><?= __('Compatta') ?></button></div></div>
    <div id="ctlTimeline"></div>
    <pre hidden><?= e("DRF.ui.timeline(\$('#box'), [
  { data: '2026-06-29', tipo: 'Visita', titolo: 'Visita', testo: 'Peso 85 kg · PA 130/85', fi: 'stethoscope', fa: 'fa-solid fa-stethoscope', colore: 'var(--accent)', run: it => … },
  { data: '2026-06-29', tipo: 'Terapia', titolo: 'Piano terapeutico', testo: 'Cardioaspirin', fi: 'capsules', fa: 'fa-solid fa-pills', colore: '#8A2BE2' },
  …
], { compatta: false, anni: true });
// storico paziente già pronto: DRF.storico.render(\$el, righeStorico, true)") ?></pre>
  </div>

  <?= $ctl('Notifiche', 'Le notifiche restano nel pannello della campanella e nel centro notifiche, con tempo relativo. Ogni modulo può crearne una, anche con un link che apre un modulo.',
      $btn('ntf_ok', 'Notifica di successo', 'primary') . $btn('ntf_warn', 'Attenzione') . $btn('ntf_err', 'Errore con link', 'danger') . $btn('ntf_centro', 'Centro notifiche'),
      "DRF.notify.add({ tipo: 'warn', titolo: 'Referto da firmare', testo: 'Marco Bianchi',\n  link: { modulo: 'referti', opts: { select: 12 } } });     // tipo: info | success | warn | error\nDRF.notify.centro();                                         // apre il centro notifiche\n// lato PHP, da qualsiasi modello o endpoint:\nNotifica::aggiungi('success', 'Backup completato', 'file.sql', ['modulo' => 'impostazioni']);") ?>

  <div class="ctl" id="ctlMenu">
    <div class="ctl-head"><div><b><?= __('Menu contestuale') ?></b><span><?= __('Tasto destro su un elemento, oppure menu sotto un pulsante. Voci con icona, disabilitate, pericolose, separatori, scorciatoia; frecce e Invio da tastiera.') ?></span></div><button class="icon-btn sm" type="button" data-code title="<?= __('Mostra il codice') ?>"><i class="ico" data-fi="brackets-curly" data-fa="fa-solid fa-code"></i></button></div>
    <div class="ctl-btns"><button class="btn primary sm" type="button" data-ctl="menu_btn"><?= __('Menu sotto il pulsante') ?></button><div class="ctl-rclick" data-ctl-rc="1"><?= __('Tasto destro qui') ?></div><div class="ctl-rclick" data-ctl-rc="2"><?= __('…o qui (voci diverse)') ?></div></div>
    <pre hidden><?= e("DRF.menu.show(x, y, [
  { label: 'Modifica', fi: 'pencil', fa: 'fa-solid fa-pen', kbd: 'E', run: () => … },
  { label: 'Non disponibile', fi: 'lock', fa: 'fa-solid fa-lock', disabled: true },
  { sep: true },
  { label: 'Elimina', fi: 'trash', fa: 'fa-solid fa-trash', danger: true, run: () => … }
], { title: 'Titolo' });
DRF.menu.showAt(\$btn, voci);                                  // sotto un pulsante
DRF.menu.bind(\$('#timeline'), '.appt', el => [ …voci per el… ]);   // tasto destro (delegato)") ?></pre>
  </div>

  <?= $ctl('Post-it, Scrivania, comandi, eventi', 'Le funzioni di sistema che ogni modulo può usare. ⌘K trova anche i comandi (prova a scrivere "nuova" o "tema"); ? apre le scorciatoie; il bus di eventi collega i moduli senza dipendenze.',
      $btn('postit', 'Incolla un post-it', 'primary') . $btn('scrivania', 'Apri la Scrivania') . $btn('palette', 'Comandi (⌘K)') . $btn('keys', 'Scorciatoie (?)') . $btn('evento', 'Emetti un evento') . $btn('suono', 'Suoni') . $btn('vai', 'Vai a Pazienti (id 1)') . $btn('lettura', 'Chiamata API'),
      "DRF.postit.nuovo('Testo');                       // nel contesto corrente (sezione + record)\nDRF.desk.open(); DRF.desk.apri('calc');           // Scrivania e apertura di un modulo\nDRF.search.comando({ label: 'Chiudi cassa', fi: 'euro', fa: 'fa-solid fa-euro-sign', kw: 'incassi', run: () => … });   // comando in ⌘K\nDRF.on('visita:chiusa', d => …); DRF.emit('mio:evento', dati);   // bus di eventi (modulo:aperto, paziente:selezionato, visita:avviata, visita:chiusa)\nDRF.sound.play('success');                       // click | notify | success | error\nDRF.nav.go('pazienti', { select: 1 });           // apre un modulo passando opzioni a show()\nDRF.api.get('agenda', 'giorno', { data }).then(d => …);   // ajax/agenda.php?action=giorno\nDRF.api.post('pazienti', 'save', dati);          // POST JSON + token CSRF") ?>

  <div class="ctl">
    <div class="ctl-head"><div><b><?= __('Campi') ?></b><span>Select2, flatpickr, Inputmask, seg e switch si attivano da soli con DRF.ui.wire(root). Valori con DRF.ui.val / setVal.</span></div><button class="icon-btn sm" type="button" data-code title="<?= __('Mostra il codice') ?>"><i class="ico" data-fi="brackets-curly" data-fa="fa-solid fa-code"></i></button></div>
    <div class="grid12">
      <div class="field" style="grid-column:span 4"><label>Data (flatpickr)</label><input class="input" type="date" name="demo_data" value="<?= date('Y-m-d') ?>"></div>
      <div class="field" style="grid-column:span 4"><label>Importo (mask euros)</label><input class="input" name="demo_euro" data-mask="euros" value="1.234,50"></div>
      <div class="field" style="grid-column:span 4"><label>Select2</label><select class="select" name="demo_sel"><option value=""><?= __('Seleziona…') ?></option><option value="a"><?= __('Prima scelta') ?></option><option value="b"><?= __('Seconda scelta') ?></option></select></div>
      <div class="field" style="grid-column:span 4"><label><?= __('Segmentato') ?></label><div class="seg" id="demoSeg"><button type="button" class="on" data-v="uno">Uno</button><button type="button" data-v="due">Due</button><button type="button" data-v="tre">Tre</button></div></div>
      <div class="field field-inline" style="grid-column:span 4"><div class="row" style="gap:10px"><button type="button" class="switch on" data-switch="demo_sw"></button><input type="hidden" name="demo_sw" value="1"><span class="switch-label"><?= __('Interruttore') ?></span></div></div>
      <div class="field" style="grid-column:span 4;justify-content:flex-end"><button class="btn soft" id="ctlValori" type="button"><?= __('Leggi i valori') ?></button></div>
    </div>
    <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:12px"><span class="badge mint">badge mint</span><span class="badge amber">amber</span><span class="badge red">red</span><span class="badge sky">sky</span><span class="badge violet">violet</span><span class="badge gray">gray</span><button class="chip" type="button">chip</button><button class="chip on" type="button">chip attiva</button></div>
    <pre hidden><?= e("<input class=\"input\" type=\"date\" name=\"d\">                      // diventa flatpickr (valore Y-m-d)\n<input class=\"input\" name=\"i\" data-mask=\"euros\">                 // euros | numero | decimale | sconto | intero | decimale1 | cap\n<select class=\"select\" name=\"s\">…</select>                        // diventa Select2\n<div class=\"seg\" data-seg=\"t\"><button data-v=\"a\">A</button></div><input type=\"hidden\" name=\"t\">\n<button class=\"switch\" data-switch=\"f\"></button><input type=\"hidden\" name=\"f\" value=\"0\">\nDRF.ui.wire(root);   // attiva tutto dentro root (fatto in automatico per sheet, modali e pannelli)\nDRF.ui.val(\$el); DRF.ui.setVal(\$el, v); DRF.ui.formData(root); DRF.ui.segValue(\$seg)") ?></pre>
  </div>

  <div class="ctl ctl-log"><div class="ctl-head"><div><b><?= __('Risultato') ?></b><span><?= __('Cosa restituiscono le promise dei controlli lanciati qui sopra.') ?></span></div></div><div id="ctlLog" class="ctl-logbox"><div class="muted small"><?= __('Premi un pulsante…') ?></div></div></div>
</div>
