<?php
/**
 * MODELLI DI MESSAGGIO (archivio `messaggi`): email, SMS e WhatsApp personalizzati con segnaposto.
 *   Messaggi::compila('referto', 'email', $vars)          → il modello predefinito per l'uso (o il primo abilitato)
 *   Messaggi::compila('REF-EMAIL', 'email', $vars)        → per codice
 * Segnaposto: {paziente} {nome} {cognome} {medico} {studio} {studio_telefono} {studio_email} {data} {documento} {numero} {importo} {appuntamento}
 * Le estensioni possono aggiungere segnaposto con l'hook `messaggi.variabili` (filter: array $vars, string $per, array $contesto).
 */
final class Messaggi
{
    public static function elenco(string $canale = 'email', ?string $per = null): array
    {
        $w = 'abilitato = 1 AND canale = ?'; $p = [$canale];
        if ($per) { $w .= " AND (per_tipo = ? OR per_tipo = 'generico')"; $p[] = $per; }
        $rows = Database::all("SELECT id, codice, descrizione, canale, per_tipo, oggetto, contenuto, predefinito FROM messaggi WHERE $w ORDER BY (per_tipo = ?) DESC, predefinito DESC, codice", array_merge($p, [$per ?? '']));
        return $rows;
    }

    public static function trova(string $codiceOPer, string $canale): ?array
    {
        $r = Database::one('SELECT * FROM messaggi WHERE codice = ? AND canale = ? AND abilitato = 1', [$codiceOPer, $canale]);
        if ($r) return $r;
        return Database::one('SELECT * FROM messaggi WHERE per_tipo = ? AND canale = ? AND abilitato = 1 ORDER BY predefinito DESC, id LIMIT 1', [$codiceOPer, $canale]);
    }

    /** Le variabili standard per un paziente e un contesto ({documento}, {numero}, {data}, {importo}, {appuntamento}) */
    public static function variabili(?array $paziente, array $ctx = [], string $per = 'generico'): array
    {
        $m = Impostazione::profilo();
        $v = ['paziente' => $paziente['nome_completo'] ?? '', 'nome' => $paziente['nome'] ?? '', 'cognome' => $paziente['cognome'] ?? '',
            'medico' => $ctx['medico'] ?? $m['nome_completo'], 'studio' => $m['studio'] ?: $m['nome_completo'], 'studio_telefono' => $m['telefono'], 'studio_email' => $m['email'],
            'data' => isset($ctx['data']) ? data_it((string) $ctx['data']) : data_it(oggi()), 'documento' => $ctx['documento'] ?? '', 'numero' => $ctx['numero'] ?? '',
            'importo' => isset($ctx['importo']) ? euro((float) $ctx['importo']) : '', 'appuntamento' => $ctx['appuntamento'] ?? ''];
        return (array) Hooks::filter('messaggi.variabili', $v, $per, $ctx);
    }

    /** Sostituisce i segnaposto in oggetto e testo. Ritorna ['oggetto', 'testo', 'codice'] (testo HTML per email, semplice per sms/whatsapp) */
    public static function compila(string $codiceOPer, string $canale, array $vars, ?string $oggettoOverride = null, ?string $testoOverride = null): array
    {
        $mod = self::trova($codiceOPer, $canale);
        $ogg = $oggettoOverride ?? (string) ($mod['oggetto'] ?? '');
        $txt = $testoOverride ?? (string) ($mod['contenuto'] ?? '');
        $sost = function (string $s, bool $html) use ($vars): string {
            return preg_replace_callback('/\{([a-z_]+)\}/i', fn($m) => $html ? e((string) ($vars[strtolower($m[1])] ?? '')) : (string) ($vars[strtolower($m[1])] ?? ''), $s);
        };
        if ($canale !== 'email') $txt = trim(html_entity_decode(strip_tags(preg_replace('~<br\s*/?>|</p>~i', "\n", $txt))));
        return ['oggetto' => $sost($ogg, false), 'testo' => $sost($txt, $canale === 'email'), 'codice' => $mod['codice'] ?? null];
    }
}
