<?php
/** Estensione Commercialista: riepilogo ed esportazione delle fatture (XML elettronico + CSV, in ZIP). */
require __DIR__ . '/../core/bootstrap.php';
if (!Estensioni::attiva('commercialista')) { http_response_code(403); exit('Estensione non attiva'); }

$fatture = function (string $da, string $a): array {
    return Database::all('SELECT f.*, p.nome pnome, p.cognome pcognome, p.cf pcf, p.indirizzo pind, p.cap pcap, p.citta pcitta, p.provincia pprov FROM fatture f JOIN pazienti p ON p.id = f.paziente_id WHERE f.data BETWEEN ? AND ? ORDER BY f.anno, f.progressivo', [$da, $a]);
};

if (($_GET['action'] ?? '') === 'zip') {
    if (!Auth::check()) { http_response_code(401); exit; }
    Auth::richiedi('contabilita.leggi');
    $da = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['da'] ?? '') ? $_GET['da'] : date('Y-m-01');
    $a = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['a'] ?? '') ? $_GET['a'] : date('Y-m-d');
    $rows = $fatture($da, $a);
    if (!$rows) { http_response_code(404); exit('Nessuna fattura nel periodo'); }
    $medico = Impostazione::profilo();
    $zip = new ZipSemplice();
    $x = fn($v) => htmlspecialchars((string) $v, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    $csv = "Numero;Data;Paziente;Codice fiscale;Imponibile;IVA;Contributi;Bollo;Totale;Stato;Metodo;Opposizione TS\n";
    foreach ($rows as $f) {
        $righe = json_decode((string) $f['righe'], true) ?: [];
        $rx = '';
        $nl = 0;
        foreach ($righe as $r) {
            if (($r['tipo'] ?? 'riga') !== 'riga') continue;
            $nl++;
            $rx .= "\n      <DettaglioLinee><NumeroLinea>$nl</NumeroLinea><Descrizione>" . $x($r['descrizione'] ?? '') . '</Descrizione><Quantita>' . number_format((float) ($r['quantita'] ?? 1), 2, '.', '') . '</Quantita><PrezzoUnitario>' . number_format((float) ($r['prezzo'] ?? 0), 2, '.', '') . '</PrezzoUnitario><PrezzoTotale>' . number_format((float) ($r['prezzo'] ?? 0) * (float) ($r['quantita'] ?? 1), 2, '.', '') . '</PrezzoTotale><AliquotaIVA>' . number_format((float) ($r['aliquota'] ?? 0), 2, '.', '') . '</AliquotaIVA></DettaglioLinee>';
        }
        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" .
"<FatturaElettronica versione=\"FPR12\" xmlns=\"http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2\">
  <FatturaElettronicaHeader>
    <CedentePrestatore><DatiAnagrafici><IdFiscaleIVA><IdPaese>IT</IdPaese><IdCodice>" . $x($f['opposizione'] ? $medico['piva'] : $medico['piva']) . "</IdCodice></IdFiscaleIVA><Anagrafica><Denominazione>" . $x($medico['nome_completo'] . ' · ' . $medico['studio']) . "</Denominazione></Anagrafica></DatiAnagrafici><Sede><Indirizzo>" . $x($medico['indirizzo']) . "</Indirizzo></Sede></CedentePrestatore>
    <CessionarioCommittente><DatiAnagrafici><CodiceFiscale>" . $x($f['pcf']) . "</CodiceFiscale><Anagrafica><Nome>" . $x($f['pnome']) . "</Nome><Cognome>" . $x($f['pcognome']) . "</Cognome></Anagrafica></DatiAnagrafici><Sede><Indirizzo>" . $x($f['pind'] ?: '—') . "</Indirizzo><CAP>" . $x($f['pcap'] ?: '00000') . "</CAP><Comune>" . $x($f['pcitta'] ?: '—') . "</Comune><Provincia>" . $x($f['pprov'] ?: '') . "</Provincia></Sede></CessionarioCommittente>
  </FatturaElettronicaHeader>
  <FatturaElettronicaBody>
    <DatiGenerali><DatiGeneraliDocumento><TipoDocumento>TD01</TipoDocumento><Divisa>EUR</Divisa><Data>" . $x($f['data']) . "</Data><Numero>" . $x($f['numero']) . "</Numero>" . ($f['bollo'] > 0 ? '<DatiBollo><BolloVirtuale>SI</BolloVirtuale><ImportoBollo>' . number_format((float) $f['bollo'], 2, '.', '') . '</ImportoBollo></DatiBollo>' : '') . ($f['opposizione'] ? '<Causale>Il paziente si è opposto alla trasmissione al Sistema TS (art. 3 DM 31/07/2015)</Causale>' : '') . "</DatiGeneraliDocumento></DatiGenerali>
    <DatiBeniServizi>$rx
      <DatiRiepilogo><ImponibileImporto>" . number_format((float) $f['importo'], 2, '.', '') . '</ImponibileImporto><Imposta>' . number_format((float) $f['iva'], 2, '.', '') . "</Imposta></DatiRiepilogo>
    </DatiBeniServizi>
    <DatiPagamento><CondizioniPagamento>TP02</CondizioniPagamento><DettaglioPagamento><ModalitaPagamento>" . ($f['stato'] === 'pagata' ? 'MP01' : 'MP05') . '</ModalitaPagamento><ImportoPagamento>' . number_format((float) $f['totale'], 2, '.', '') . "</ImportoPagamento></DettaglioPagamento></DatiPagamento>
  </FatturaElettronicaBody>
</FatturaElettronica>";
        $zip->aggiungi('xml/fattura-' . preg_replace('/[^A-Za-z0-9]+/', '-', $f['numero']) . '.xml', $xml);
        $csv .= implode(';', [$f['numero'], data_it($f['data']), trim($f['pcognome'] . ' ' . $f['pnome']), $f['pcf'], numero_csv($f['importo']), numero_csv($f['iva']), numero_csv($f['contributi']), numero_csv($f['bollo']), numero_csv($f['totale']), $f['stato'], $f['metodo'] ?: '', $f['opposizione'] ? 'SI' : 'NO']) . "\n";
    }
    $zip->aggiungi('riepilogo.csv', "\xEF\xBB\xBF" . $csv);
    Attivita::registra('contabilita.export', 'procedure', 0, count($rows) . ' fatture · ' . data_it($da) . '–' . data_it($a));
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="contabilita-' . $da . '-' . $a . '.zip"');
    echo $zip->contenuto(); exit;
}
function numero_csv($v): string { return number_format((float) $v, 2, ',', ''); }
Api::run([
    'riepilogo' => function (array $in) use ($fatture) {
        $da = Api::str($in, 'da') ?: date('Y-m-01'); $a = Api::str($in, 'a') ?: date('Y-m-d');
        $rows = $fatture($da, $a);
        $aliquote = [];
        foreach ($rows as $f) foreach (json_decode((string) $f['righe'], true) ?: [] as $r) {
            if (($r['tipo'] ?? 'riga') !== 'riga') continue;
            $al = number_format((float) ($r['aliquota'] ?? 0), 2, '.', '');
            $imp = (float) ($r['prezzo'] ?? 0) * (float) ($r['quantita'] ?? 1);
            $aliquote[$al] = ['imponibile' => ($aliquote[$al]['imponibile'] ?? 0) + $imp, 'imposta' => ($aliquote[$al]['imposta'] ?? 0) + $imp * (float) $al / 100, 'n' => ($aliquote[$al]['n'] ?? 0) + 1];
        }
        ksort($aliquote, SORT_NUMERIC);
        $inAttesa = array_filter($rows, fn($f) => $f['stato'] === 'attesa');
        return ['n' => count($rows), 'imponibile' => array_sum(array_column($rows, 'importo')), 'iva' => array_sum(array_column($rows, 'iva')),
            'contributi' => array_sum(array_column($rows, 'contributi')), 'bollo' => array_sum(array_column($rows, 'bollo')), 'totale' => array_sum(array_column($rows, 'totale')),
            'incassato' => array_sum(array_column(array_filter($rows, fn($f) => $f['stato'] === 'pagata'), 'totale')),
            'attesa_n' => count($inAttesa), 'attesa_importo' => array_sum(array_column($inAttesa, 'totale')),
            'opposizioni' => count(array_filter($rows, fn($f) => (int) $f['opposizione'] === 1)),
            'aliquote' => array_map(fn($k, $v) => ['aliquota' => (float) $k, 'n' => $v['n'], 'imponibile' => round($v['imponibile'], 2), 'imposta' => round($v['imposta'], 2)], array_keys($aliquote), $aliquote)];
    },
], 'contabilita.leggi');
