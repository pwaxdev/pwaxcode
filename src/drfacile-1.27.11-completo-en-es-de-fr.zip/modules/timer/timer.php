<?php
if (!function_exists('module_timer_render')) {
    function module_timer_render(array $ctx): string { return '<div class="timer"><div class="timer-ring"><svg viewBox="0 0 120 120"><circle class="bg" cx="60" cy="60" r="52"/><circle class="fg" cx="60" cy="60" r="52"/></svg><div class="timer-time">00:00</div></div><div class="timer-who muted small">' . __('Nessuna visita in corso') . '</div><div class="row" style="gap:6px;justify-content:center"><button class="btn primary sm" type="button" data-t="start">' . __('Avvia') . '</button><button class="btn ghost sm" type="button" data-t="reset">' . __('Azzera') . '</button></div></div>'; }
}
