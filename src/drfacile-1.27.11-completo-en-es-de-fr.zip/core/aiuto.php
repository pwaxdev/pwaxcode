<?php
/** Aiuto in linea (F1): una voce per modulo + le basi. HTML semplice, reso nella modale dell'aiuto.
    Ogni voce può avere 'sotto' => [chiave => ['titolo' => …, 'html' => …]] (sottosezioni, nell'indice a sinistra).
    Nel testo, <a data-go="voce"> o <a data-go="voce/sottosezione"> porta dritti alla pagina giusta. */
return [
    'generale' => ['titolo' => __('Le basi di DRFacile'), 'fi' => 'interrogation', 'fa' => 'fa-solid fa-question', 'html' => '
        <p><b>F1</b> apre questo aiuto sulla sezione in cui ti trovi; <b>F2</b> mostra e nasconde l\'<b>assistente</b> — la lista "anti sbadati" che compare in basso a sinistra quando serve (es. al nuovo paziente: anagrafica, privacy, prima prenotazione). I passi con il fulmine si spuntano da soli; gli altri con un click; cliccando un passo si va nella sezione giusta. Si disattiva in Impostazioni → Preferenze e i percorsi si definiscono in <span class="mono">core/percorsi.php</span>.</p>
        <p> <b>⌘K / Ctrl+K</b> apre la ricerca globale (pazienti, referti, fatture e anche i <i>comandi</i>); <b>?</b> mostra tutte le scorciatoie; i tasti <b>1–9 e 0</b> saltano ai dieci moduli, <b>↑/↓</b> li scorrono, <b>Esc</b> chiude calendari, messaggi, modali e pannelli.</p>
        <ul><li><b>Scrivania</b> — click sull\'avatar in basso: calcolatrice, agenda del giorno, registro attività, cronometro, scadenze e Ritmo. Le finestre si trascinano e ricordano la posizione.</li>
        <li><b>Post-it</b> — l\'icona in alto incolla un post-it legato al contesto (es. a un paziente: lo ritrovi sulla sua scheda e in visita).</li>
        <li><b>Notifiche</b> — la campanella mostra le ultime; dal pannello si apre il <i>centro notifiche</i> con filtri lette/non lette.</li>
        <li><b>Scadenzario</b> — pagamenti da incassare, consensi in scadenza e controlli programmati generano scadenze: alla data giusta arriva una notifica e il modulo <i>Scadenze</i> della Scrivania le mostra in anticipo. Nessun cron da configurare.</li>
        <li><b>Tasto destro</b> — quasi ovunque: appuntamenti, giorni del mese, pazienti, fatture, post-it, dock della Scrivania.</li>
        <li><b>Negozio</b> — nella Scrivania: lo store delle estensioni (gratuite, a pagamento o in abbonamento), uguale per tutti gli studi. Con l\'estensione <i>Commercialista</i> arrivano il ruolo dedicato e <a data-go="procedure">Procedure → Contabilità</a> con l\'export XML/CSV; con <i>Sala d\'attesa</i> lo schermo per la TV dello studio.</li></ul>'],
    'agenda' => ['titolo' => 'Agenda', 'fi' => 'calendar', 'fa' => 'fa-regular fa-calendar', 'html' => '
        <p>Vista giorno con le corsie sovrapposte e vista mese. La <b>prestazione scelta</b> nella prenotazione porta con sé durata e colore dal listino; lo switch <b>Urgente</b> evidenzia l\'appuntamento con il triangolo rosso.</p>
        <ul><li><b>Tasto destro su un appuntamento</b>: inizia visita, scheda, ricetta, modifica, completato, <b>non presentato</b>, elimina (con Annulla nel toast).</li>
        <li><b>Tasto destro su uno spazio libero</b>: prenota a quell\'ora. Sul mese: tasto destro su un giorno.</li>
        <li>Le sovrapposizioni vengono segnalate ma non bloccate. Il promemoria SMS si attiva nelle Impostazioni.</li></ul>'],
    'pazienti' => ['titolo' => 'Pazienti', 'fi' => 'users', 'fa' => 'fa-solid fa-user-group', 'html' => '
        <p>Elenco con ricerca (nome, CF, telefono) e filtri. <b>Doppio click</b> avvia la visita. Lo scudo giallo segnala la <b>privacy non firmata</b> (o scaduta).</p>
        <ul><li><b>Tasto destro</b>: inizia visita, prenota, <b>Stampa documento…</b> (modelli dell\'archivio Documenti con i campi {…} compilati), <b>Firma privacy</b>, modifica, oblio (in arrivo), elimina.</li>
        <li>La scheda ha il codice fiscale con calcolo e verifica; il comune compila CAP e provincia.</li>
        <li>L\'eliminazione è protetta: con visite chiuse o fatture emesse il paziente non si può eliminare.</li></ul>'],
    'visita' => ['titolo' => 'Visita', 'fi' => 'stethoscope', 'fa' => 'fa-solid fa-stethoscope', 'html' => '
        <p>Cinque passi: Anamnesi → Visita → Esami → Terapia → Complicanze. La bozza si salva da sola; alla chiusura nasce il referto (firmato subito se l\'hai scelto nelle Impostazioni).</p>
        <ul><li><b>Anamnesi</b> ed <b>Esame obiettivo</b> usano l\'editor di testo: grassetto, elenchi, titoletti finiscono così anche nel referto.</li>
        <li>Le <b>prestazioni eseguite</b> (sotto il motivo) diventano la fattura: alla chiusura arriva la notifica "Visita da fatturare".</li>
        <li>La <b>data del prossimo controllo</b> (scheda Terapia) entra nello scadenzario.</li>
        <li>I modelli corporei registrano sintomi e reperti toccando le regioni; lo storico del paziente è sempre a destra.</li></ul>
        <p>Approfondimento: <a data-go="visita/editor">l\'editor di testo</a>.</p>',
        'sotto' => [
            'editor' => ['titolo' => 'L\'editor di testo', 'html' => '
                <p>Anamnesi ed esame obiettivo usano <b>DRF.rich</b>: ⌘B/I/U, titoletti, elenchi, link, annulla/ripeti e contatore caratteri. La formattazione attraversa referto, anteprima e stampa. Nei modelli dell\'<a data-go="archivi/documenti">archivio Documenti</a> lo stesso editor ha anche i <b>campi {segnaposto}</b>: entità atomiche che alla stampa diventano i dati veri del paziente. La pagina <a data-go="procedure">Procedure → Voce 4</a> mostra tutto dal vivo con il codice.</p>']],],
    'ricette' => ['titolo' => 'Ricette', 'fi' => 'prescription', 'fa' => 'fa-solid fa-prescription', 'html' => '
        <p>Ricetta bianca o SSN con i farmaci del prontuario (Archivi → Prontuario). L\'invio genera l\'NRE e il promemoria stampabile; il collegamento reale al Sistema TS è predisposto.</p>'],
    'referti' => ['titolo' => 'Referti', 'fi' => 'document', 'fa' => 'fa-regular fa-file-lines', 'html' => '
        <p>Le bozze si modificano (le sezioni scritte con l\'editor riaprono l\'editor), poi firma digitale e invio. Ogni referto firmato viene archiviato in HTML in <span class="mono">docs/archivio</span> e resta stampabile in PDF dal browser.</p>'],
    'fatture' => ['titolo' => 'Fatturazione', 'fi' => 'receipt', 'fa' => 'fa-solid fa-file-invoice', 'html' => '
        <p>Fattura a <b>righe</b>: prestazioni dal listino (con IVA), righe libere e descrittive; spese di studio e contributo cassa arrivano dalle Impostazioni e si tolgono fattura per fattura. Il riepilogo calcola imponibile, IVA per aliquota, bollo sulla quota esente e totale. Vedi anche la <a data-go="fatture/numerazione">numerazione</a> e i <a data-go="fatture/pagamenti">pagamenti e lo scadenzario</a>.</p>
        <ul><li><b>Da visita</b>: le visite chiuse con prestazioni si fatturano con un click; la stessa visita non può produrre due fatture.</li>
        <li><b>Tasto destro</b>: apri/stampa, incassa, <b>modifica</b> ed <b>elimina</b> — solo finché la fattura non è stata stampata.</li>
        <li>L\'intestatario è stampato in alto a destra: nome, indirizzo, CAP/città/provincia e codice fiscale. La <a data-go="impostazioni">riga aggiuntiva dello studio</a> chiude il documento.</li></ul>',
        'sotto' => [
            'numerazione' => ['titolo' => 'Numerazione', 'html' => '
                <p>In Impostazioni → Fatturazione scegli il <b>formato del numero</b> con i segnaposto <span class="mono">{n}</span>, <span class="mono">{nnn}</span>, <span class="mono">{aaaa}</span>, <span class="mono">{aa}</span> (predefinito <span class="mono">{aaaa}/{nnn}</span>) e, se serve, sblocchi il <b>prossimo progressivo</b> — utile arrivando da un altro gestionale a metà anno. Il progressivo riparte a ogni anno e i numeri delle fatture eliminate vengono riusati se sono gli ultimi.</p>'],
            'pagamenti' => ['titolo' => __('Pagamenti e scadenzario'), 'html' => '
                <p>Ogni <b>metodo di pagamento</b> (Archivi → Metodi di pagamento) può avere i <b>giorni per l\'incasso</b>: bonifico a 3 giorni, "da incassare" a 30… La fattura nasce <b>in attesa</b> con la scadenza calcolata, entra nello <a data-go="generale">scadenzario</a> e alla data giusta arriva la notifica. All\'incasso la scadenza si chiude da sola.</p>']],],
    'statistiche' => ['titolo' => 'Statistiche', 'fi' => 'stats', 'fa' => 'fa-solid fa-chart-simple', 'html' => '
        <p>Andamento degli incassi, composizione delle prestazioni e pazienti più assidui, calcolati sull\'archivio reale. I colori della torta sono quelli delle prestazioni.</p>'],
    'archivi' => ['titolo' => 'Archivi', 'fi' => 'boxes', 'fa' => 'fa-solid fa-box-archive', 'html' => '
        <p>Le tabelle di base: <b>Prestazioni</b> (prezzo, durata, colore in agenda, IVA, prenotabilità, istruzioni pre-visita), <b>Aliquote IVA</b>, i <a data-go="archivi/documenti">Documenti</a>, <b>Metodi di pagamento</b> (giorni di incasso, conto, SDI), farmaci, diagnosi, esami, esenzioni.</p>
        <p><b>Diagnosi frequenti</b> è un dizionario: oggi contiene le voci più usate con codifica ICD-9-CM, ed è predisposto per agganciarsi all\'archivio ICD9 completo (e ICD10 dal prossimo anno). Lo stesso vale per il <b>Prontuario</b>, che si collegherà alle liste AIFA.</p>
        <p>Per aggiungere un archivio: una riga in <span class="mono">core/archivi.php</span> più una definizione in <span class="mono">form/definitions</span>.</p>',
        'sotto' => [
            'documenti' => ['titolo' => 'Documenti', 'html' => '
                <p>I modelli (privacy, consensi, comunicazioni) si scrivono con <a data-go="visita/editor">l\'editor</a> e i campi {paziente}, {cf}, {data}, {scadenza}… Dal tasto destro sul paziente → <b>Stampa documento…</b> escono compilati, con copia in archivio; i <b>consensi con validità</b> registrano da soli la firma e la scadenza.</p>
                <p>Con <b>Richiedi</b> chiedi un modello dal catalogo comune (consenso all\'operazione, certificati…): la richiesta parte via email all\'assistenza e il documento compare nel tuo archivio appena pronto.</p>']],],
    'procedure' => ['titolo' => 'Procedure', 'fi' => 'magic-wand', 'fa' => 'fa-solid fa-wand-magic-sparkles', 'html' => '
        <p>Le voci configurabili dello studio: un archivio (CRUD standard), una procedura con parametri ed esecuzione, o una pagina libera. Le demo incluse: registro consensi, promemoria appuntamenti, la pagina dei <b>controlli</b> e quella dell\'<b>editor</b> — entrambe con il codice pronto da copiare.</p>'],
    'impostazioni' => ['titolo' => 'Impostazioni', 'fi' => 'settings-sliders', 'fa' => 'fa-solid fa-sliders', 'html' => '
        <p>Profilo (con il sesso per i saluti), studio, <b>Fatturazione</b> (spese di studio, contributo cassa, formato e numerazione delle fatture), preferenze (tema, suoni, firma automatica, prezzi in visita) e i dati: backup, esportazione JSON, ripristino demo, archivio documentale.</p>'],
];
