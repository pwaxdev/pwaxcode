<div class="reports stagger">
  <div>
    <div class="toolbar"><div class="seg" id="refFilter"><button class="on" data-f="tutti"><?= __('Tutti') ?></button><button data-f="bozza"><?= __('Bozze') ?></button><button data-f="firmato"><?= __('Firmati') ?></button><button data-f="inviato"><?= __('Inviati') ?></button></div></div>
    <div class="rlist" id="rlist"></div>
  </div>
  <div>
    <div class="doc-actions" id="docActions"></div>
    <div class="doc" id="doc"></div>
  </div>
</div>
