<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'prossime' => fn() => ['scadenze' => Scadenzario::prossime(30)],
    'chiudi'   => function (array $in) { Scadenzario::save(['id' => Api::int($in, 'id'), 'stato' => 'chiusa']); return ['chiusa' => true]; },
    'aggiungi' => fn(array $in) => ['id' => Scadenzario::aggiungi(Api::str($in, 'tipo', 'promemoria'), Api::str($in, 'data', oggi()), Api::str($in, 'titolo'), Api::str($in, 'testo'))],
], ['*' => 'scadenzario.leggi', 'chiudi' => 'scadenzario.chiudi', 'aggiungi' => 'agenda.modifica']);
