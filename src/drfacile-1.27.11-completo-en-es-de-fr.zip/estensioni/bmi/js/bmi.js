/* Estensione "BMI in visita": il calcolatore di indice di massa corporea nel pannello anamnesi.
   Caricato solo con l'estensione attiva. Si aggancia all'hook 'visita.pannello'. */
(function ($) {
  'use strict';
  DRF.hooks.add('visita.pannello', function (ctx) {
    const $anam = ctx.$root.find('#vNote').closest('.vcard, .card, .field').first();
    if (!$anam.length || $anam.find('.bmi-box').length) return;
    const $box = $(`
      <div class="bmi-box">
        <b>${DRF.icons.html('chart-line-up', 'fa-solid fa-weight-scale')} BMI</b>
        <input class="input sm" id="bmiPeso" inputmode="decimal" placeholder="kg" style="width:64px">
        <span class="muted">×</span>
        <input class="input sm" id="bmiAlt" inputmode="decimal" placeholder="cm" style="width:64px">
        <span class="bmi-out muted">—</span>
        <button class="btn ghost sm" type="button" id="bmiIns" disabled>In anamnesi</button>
      </div>`).appendTo($anam);
    const CAT = v => v < 18.5 ? ['Sottopeso', 'amber'] : v < 25 ? ['Normopeso', 'mint'] : v < 30 ? ['Sovrappeso', 'amber'] : ['Obesità', 'rose'];
    const calc = () => {
      const p = parseFloat(($box.find('#bmiPeso').val() || '').replace(',', '.'));
      const a = parseFloat(($box.find('#bmiAlt').val() || '').replace(',', '.')) / 100;
      if (!p || !a) { $box.find('.bmi-out').html('—'); $box.find('#bmiIns').prop('disabled', true); return; }
      const bmi = p / (a * a), [lbl, col] = CAT(bmi);
      $box.data('txt', `BMI ${bmi.toFixed(1)} (${lbl}) — peso ${p} kg, altezza ${Math.round(a * 100)} cm`);
      $box.find('.bmi-out').html(`<b>${bmi.toFixed(1)}</b> ${DRF.ui.badge(col, lbl)}`);
      $box.find('#bmiIns').prop('disabled', !ctx.visita);
    };
    $box.on('input', '#bmiPeso, #bmiAlt', calc);
    $box.on('click', '#bmiIns', () => { ctx.setNota($box.data('txt')); DRF.ui.toast('BMI inserito in anamnesi', 'success'); });
    DRF.icons.apply($box[0]);
  });
})(jQuery);
