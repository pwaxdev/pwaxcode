<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'riepilogo' => function () {
        $mesi = [];
        for ($i = 11; $i >= 0; $i--) {
            $ym = date('Y-m', strtotime("first day of -$i months"));
            $mesi[] = [
                'ym' => $ym, 'label' => mese_it((int) substr($ym, 5, 2), true),
                'visite' => (int) Database::value("SELECT COUNT(*) FROM appuntamenti WHERE substr(data,1,7) = ? AND stato <> 'annullato'", [$ym]),
                'incasso' => (float) Database::value("SELECT COALESCE(SUM(totale),0) FROM fatture WHERE stato = 'pagata' AND substr(data,1,7) = ?", [$ym]),
            ];
        }
        $da = date('Y-m-01', strtotime('first day of -11 months'));
        $tot = (int) Database::value("SELECT COUNT(*) FROM appuntamenti WHERE data >= ? AND stato <> 'annullato'", [$da]);
        $totPrec = (int) Database::value("SELECT COUNT(*) FROM appuntamenti WHERE data >= ? AND data < ? AND stato <> 'annullato'", [date('Y-m-01', strtotime('first day of -23 months')), $da]);
        $tipiArchivio = Appuntamento::tipi(); $tipi = [];
        foreach (Database::all("SELECT tipo, COUNT(*) n FROM appuntamenti WHERE data >= ? AND stato <> 'annullato' GROUP BY tipo ORDER BY n DESC", [$da]) as $r) {
            $tipi[] = ['tipo' => $r['tipo'], 'label' => Appuntamento::tipoNome($r['tipo']), 'n' => (int) $r['n'], 'perc' => $tot ? round($r['n'] / $tot * 100) : 0, 'colore' => $tipiArchivio[$r['tipo']]['colore'] ?? 'var(--amber)'];
        }
        $top = array_map(fn($r) => ['label' => $r['prestazione'], 'n' => (int) $r['n'], 'incasso' => (float) $r['t']], Database::all('SELECT prestazione, COUNT(*) n, SUM(totale) t FROM fatture WHERE data >= ? GROUP BY prestazione ORDER BY n DESC LIMIT 5', [$da]));
        $incasso = array_sum(array_column($mesi, 'incasso'));
        $incPrec = (float) Database::value("SELECT COALESCE(SUM(totale),0) FROM fatture WHERE stato='pagata' AND data >= ? AND data < ?", [date('Y-m-01', strtotime('first day of -23 months')), $da]);
        return [
            'mesi' => $mesi, 'tipi' => $tipi, 'top' => $top,
            'kpi' => [
                'visite' => $tot, 'visite_var' => $totPrec ? round(($tot - $totPrec) / $totPrec * 100) : null,
                'nuovi_pazienti' => Paziente::count('creato_il >= ?', [$da]),
                'incasso' => $incasso, 'incasso_var' => $incPrec ? round(($incasso - $incPrec) / $incPrec * 100) : null,
                'durata_media' => (int) round((float) Database::value("SELECT AVG(durata) FROM appuntamenti WHERE data >= ? AND stato <> 'annullato'", [$da])),
            ],
        ];
    },
], 'statistiche.leggi');
