<?php
/** Istanze dei percorsi guidati (assistente F2): stato dei passi manuali + calcolo dal vivo degli automatici */
final class Percorso extends Model
{
    protected static string $table = 'percorsi';
    protected static array $fillable = ['percorso', 'rif_id', 'etichetta', 'manuali', 'stato'];
    protected static array $json = ['manuali'];

    public static function definizioni(): array { return require DRF_ROOT . '/core/percorsi.php'; }

    /** Apre (o ritrova) l'istanza di un percorso per un riferimento */
    public static function apri(string $percorso, ?int $rifId = null, string $etichetta = ''): int
    {
        $def = self::definizioni()[$percorso] ?? throw new ApiException(__('Percorso sconosciuto'));
        $ex = Database::one("SELECT id FROM percorsi WHERE percorso = ? AND stato = 'aperto'" . ($rifId ? ' AND rif_id = ?' : ''), $rifId ? [$percorso, $rifId] : [$percorso]);
        if ($ex) return (int) $ex['id'];
        return self::save(['percorso' => $percorso, 'rif_id' => $rifId, 'etichetta' => mb_substr($etichetta ?: $def['titolo'], 0, 120), 'manuali' => [], 'stato' => 'aperto']);
    }

    /** L'istanza con i passi calcolati (auto dal vivo + manuali memorizzati) */
    public static function stato(int $id): ?array
    {
        $i = self::find($id); if (!$i) return null;
        $def = self::definizioni()[$i['percorso']] ?? null; if (!$def) return null;
        $passi = []; $fatti = 0;
        foreach ($def['passi'] as $k => $p) {
            $auto = isset($p['auto']);
            $fatto = $auto ? (bool) $p['auto']((int) $i['rif_id']) : in_array($k, $i['manuali'] ?: [], true);
            $link = isset($p['link']) ? $p['link']((int) $i['rif_id']) : null;
            $passi[] = ['chiave' => $k, 'label' => $p['label'], 'auto' => $auto, 'fatto' => $fatto, 'link' => $link];
            if ($fatto) $fatti++;
        }
        return ['id' => (int) $i['id'], 'percorso' => $i['percorso'], 'titolo' => $def['titolo'], 'etichetta' => $i['etichetta'],
            'passi' => $passi, 'fatti' => $fatti, 'totale' => count($passi), 'completo' => $fatti === count($passi)];
    }

    /** Spunta / togli la spunta a un passo manuale */
    public static function spunta(int $id, string $chiave, bool $fatto): void
    {
        $i = self::find($id) ?? throw new ApiException(__('Percorso non trovato'));
        $m = array_values(array_diff($i['manuali'] ?: [], [$chiave]));
        if ($fatto) $m[] = $chiave;
        self::save(['id' => $id, 'manuali' => $m]);
    }

    /** L'istanza aperta più recente (per il pannello flottante) */
    public static function corrente(): ?array
    {
        $i = Database::one("SELECT id FROM percorsi WHERE stato = 'aperto' ORDER BY id DESC LIMIT 1");
        return $i ? self::stato((int) $i['id']) : null;
    }
}
