<?php /** @var array $doc @var array $paziente @var array $medico @var array $config @var bool $auto_print */
// Righe della fattura: le versioni precedenti avevano una sola prestazione → percorso legacy
$righe = is_array($doc['righe'] ?? null) ? $doc['righe'] : [];
if (!$righe) $righe = [['tipo' => 'riga', 'descrizione' => $doc['prestazione'], 'quantita' => 1, 'prezzo' => (float) $doc['importo'], 'aliquota' => 0, 'importo' => (float) $doc['importo']]];
$sole = array_values(array_filter($righe, fn($r) => ($r['tipo'] ?? 'riga') === 'riga'));
$multiQta = (bool) array_filter($sole, fn($r) => (float) ($r['quantita'] ?? 1) != 1.0);
$conIva = (bool) array_filter($sole, fn($r) => (float) ($r['aliquota'] ?? 0) > 0);
// IVA per aliquota + note delle aliquote (dall'archivio)
$perAli = [];
foreach ($sole as $r) { $a = (string) (float) ($r['aliquota'] ?? 0); $perAli[$a] = ($perAli[$a] ?? 0) + (float) $r['importo']; }
$noteIva = [];
foreach (Database::all('SELECT aliquota, nota FROM iva') as $i) if (trim((string) $i['nota']) !== '') $noteIva[(string) (float) $i['aliquota']] = $i['nota'];
$notaEsente = $noteIva['0'] ?? $config['esenzione_iva'];
$fmtQ = fn($q) => rtrim(rtrim(number_format((float) $q, 2, ',', '.'), '0'), ',');
$fmtA = fn($a) => rtrim(rtrim(number_format((float) $a, 2, ',', ''), '0'), ',') . '%';
$tuttoEsente = !$conIva;
?>
<!DOCTYPE html>
<html lang="it"><head><meta charset="utf-8"><title>Fattura <?= e($doc['numero']) ?> · <?= e($paziente['nome_completo']) ?></title><?php include __DIR__ . '/_stile.php'; ?></head>
<body>
<div class="toolbar"><button class="ghost" onclick="window.close()">Chiudi</button><button onclick="window.print()">Stampa / salva PDF</button></div>
<div class="foglio">
  <?php $destra = '<div class="destinatario">' . (($tipo ?? '') === 'fattura' ? '<span class="dest-eyebrow">Spett.le</span>' : '') . '<b>' . e($paziente['nome_completo']) . '</b>'
  . (!empty($paziente['indirizzo']) ? '<span>' . e($paziente['indirizzo']) . '</span>' : '')
  . (($riga2 = trim(implode(' ', array_filter([$paziente['cap'] ?? '', $paziente['citta'] ?? '', !empty($paziente['provincia']) ? '(' . $paziente['provincia'] . ')' : ''])))) !== '' ? '<span>' . e($riga2) . '</span>' : '')
  . (!empty($paziente['cf']) ? '<span class="mono">CF ' . e($paziente['cf']) . '</span>' : '') . '</div>'; include __DIR__ . '/_testata.php'; ?>
  <div class="doc-riga"><b>Fattura n. <?= e($doc['numero']) ?></b> del <?= data_it($doc['data']) ?> · <?= $doc['stato'] === 'pagata' ? 'pagata il ' . data_it($doc['pagata_il']) . ($doc['metodo'] ? ' (' . e($doc['metodo']) . ')' : '') : 'da pagare entro il ' . data_it($doc['scadenza']) ?></div>
  <h2>Intestatario</h2>
  <table>
    <thead><tr><th>Descrizione</th><?php if ($multiQta): ?><th class="n">Q.tà</th><th class="n">Prezzo</th><?php endif; ?><?php if ($conIva): ?><th class="n">IVA</th><?php endif; ?><th class="n">Importo</th></tr></thead>
    <tbody>
      <?php $colspan = 1 + ($multiQta ? 2 : 0) + ($conIva ? 1 : 0) + 1; ?>
      <?php foreach ($righe as $r): ?>
        <?php if (($r['tipo'] ?? 'riga') === 'descrizione'): ?>
          <tr><td colspan="<?= $colspan ?>" style="color:#5A5F73;font-style:italic"><?= e($r['descrizione']) ?></td></tr>
        <?php else: ?>
          <tr>
            <td><?= e($r['descrizione']) ?></td>
            <?php if ($multiQta): ?><td class="n"><?= $fmtQ($r['quantita'] ?? 1) ?></td><td class="n"><?= euro($r['prezzo'] ?? $r['importo']) ?></td><?php endif; ?>
            <?php if ($conIva): ?><td class="n"><?= (float) ($r['aliquota'] ?? 0) > 0 ? $fmtA($r['aliquota']) : 'esente' ?></td><?php endif; ?>
            <td class="n"><?= euro($r['importo']) ?></td>
          </tr>
        <?php endif; ?>
      <?php endforeach; ?>
      <tr class="tot"><td colspan="<?= $colspan - 1 ?>">Imponibile</td><td class="n"><?= euro($doc['importo']) ?></td></tr>
      <?php if ((float) ($doc['contributi'] ?? 0) > 0): ?><tr><td colspan="<?= $colspan - 1 ?>"><?= e($doc['contributi_desc'] ?: 'Contributo previdenziale') ?></td><td class="n"><?= euro($doc['contributi']) ?></td></tr><?php endif; ?>
      <?php foreach ($perAli as $a => $base): if ((float) $a <= 0) continue; ?>
        <tr><td colspan="<?= $colspan - 1 ?>">IVA <?= $fmtA($a) ?> su <?= euro($base) ?></td><td class="n"><?= euro(round($base * (float) $a / 100, 2)) ?></td></tr>
      <?php endforeach; ?>
      <?php if ($doc['bollo'] > 0): ?><tr><td colspan="<?= $colspan - 1 ?>">Imposta di bollo assolta in modo virtuale</td><td class="n"><?= euro($doc['bollo']) ?></td></tr><?php endif; ?>
      <tr class="tot grande"><td colspan="<?= $colspan - 1 ?>">Totale</td><td class="n"><?= euro($doc['totale']) ?></td></tr>
    </tbody>
  </table>
  <?php if (isset($perAli['0']) && $conIva): ?><p class="small" style="color:#5A5F73;margin-top:8px">Quota esente IVA: <?= euro($perAli['0']) ?> · <?= e($notaEsente) ?></p><?php endif; ?>
  <?php if ($doc['note']): ?><h2>Note</h2><p><?= e($doc['note']) ?></p><?php endif; ?>
  <?php ob_start(); ?><?= $tuttoEsente ? e($notaEsente) . '. ' : '' ?><?= !empty($doc['opposizione']) ? 'Il paziente si è opposto alla trasmissione dei dati al Sistema Tessera Sanitaria (art. 3 DM 31/07/2015).' : 'Dati trasmessi al Sistema Tessera Sanitaria ai fini della dichiarazione precompilata, salvo opposizione del paziente.' ?><?php $piede_extra = '<div class="riga-studio">' . trim(ob_get_clean()) . '</div>'; include __DIR__ . '/_piede.php'; ?>
</div>
<?php if ($auto_print): ?><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),300))</script><?php endif; ?>
</body></html>
