<?php
return [
    'title' => __('Nuova diagnosi'), 'title_edit' => __('Modifica diagnosi'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Aggiungi'),
    'table' => 'diagnosi',
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'diagnosi'],
        ['name' => 'codice', 'label' => __('Codice ICD-9-CM'), 'type' => 'text', 'placeholder' => __('facoltativo')],
        ['name' => 'descrizione', 'label' => __('Descrizione'), 'type' => 'text', 'required' => true],
    ],
];
