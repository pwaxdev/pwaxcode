<?php
/**
 * STORE DI DRFACILE: il repository dei pacchetti (estensioni e moduli), il download, la verifica,
 * l'installazione dei file, gli aggiornamenti e i voti.
 *
 * REPOSITORY = una cartella (locale o pubblicata via HTTP) con:
 *   catalogo.json                   l'elenco dei pacchetti (manifest + file, sha256, stato di approvazione, voti)
 *   pacchetti/<codice>-<versione>.zip
 * Si crea con `php strumenti/pacchetto.php <codice>` (il singolo ZIP) e `php strumenti/repository.php <cartella>` (il catalogo).
 * In config.php: 'store' => ['repository' => 'https://store.drfacile.it' | '/percorso/locale', 'revisore' => false, 'cache' => 3600].
 *
 * PACCHETTO = ZIP con alla radice manifest.json (obbligatorio) + estensione.php, js/, css/, ajax.php, modules/<key>/, assets/…
 * Viene estratto in estensioni/<codice>/. Il codice è immutabile: è la chiave ovunque.
 *
 * APPROVAZIONE: ogni voce del catalogo ha 'stato' = approvato | in_revisione | respinto. Gli studi vedono solo gli approvati;
 * un'installazione con store.revisore = true vede anche quelli in revisione (e può installarli per provarli).
 *
 * I voti (1-5 stelle, e in futuro la recensione) si salvano nel database comune (store_voti, uno per studio e pacchetto)
 * e, se il repository lo prevede (store.voti_url), vengono inviati anche lì.
 */
final class Store
{
    public const STATI = ['approvato' => 'Approvato', 'in_revisione' => 'In revisione', 'respinto' => 'Respinto'];
    public const CATEGORIE = ['Clinica', 'Documenti', 'Amministrazione', 'Accoglienza', 'Comunicazione', 'Produttività', 'Gestione', 'Integrazioni', 'Svago'];

    /* ------------------------------------------------------------------ configurazione */

    /** Il repository configurato: URL http(s) oppure cartella (relativa = rispetto alla root di DRFacile, non alla cartella dello script) */
    public static function repository(): string
    {
        $r = rtrim(trim((string) (Config::get('store.repository') ?? '')), '/');
        if ($r === '' || preg_match('~^https?://~i', $r) || str_starts_with($r, '/') || preg_match('~^[A-Za-z]:[\\/]~', $r)) return $r;
        return DRF_ROOT . '/' . ltrim($r, './');
    }
    public static function revisore(): bool { return (bool) Config::get('store.revisore', false); }
    public static function attivo(): bool { return self::repository() !== ''; }
    private static function remoto(): bool { return (bool) preg_match('~^https?://~i', self::repository()); }
    private static function cacheFile(): string { return DRF_ROOT . '/data/store/catalogo.json'; }

    /* ------------------------------------------------------------------ catalogo */

    /**
     * Scarica il catalogo del repository (con cache di store.cache secondi) e lo riversa nella tabella comune store_moduli.
     * Ritorna ['ok' => bool, 'quando' => datetime|null, 'errore' => string|null, 'pacchetti' => n].
     */
    public static function sincronizza(bool $forza = false): array
    {
        if (!self::attivo()) return ['ok' => false, 'quando' => null, 'errore' => 'Nessun repository configurato (store.repository in config.php)', 'pacchetti' => 0];
        $cache = self::cacheFile(); $ttl = (int) Config::get('store.cache', 3600);
        $quando = is_file($cache) ? date('Y-m-d H:i:s', filemtime($cache)) : null;
        if (!$forza && is_file($cache) && time() - filemtime($cache) < $ttl) {
            return ['ok' => true, 'quando' => $quando, 'errore' => null, 'pacchetti' => count(self::catalogoRemoto()), 'cache' => true];
        }
        try {
            $raw = self::leggi('catalogo.json');
            $cat = json_decode($raw, true);
            if (!is_array($cat) || !isset($cat['pacchetti']) || !is_array($cat['pacchetti'])) throw new RuntimeException('catalogo.json non valido');
            if (!is_dir(dirname($cache))) @mkdir(dirname($cache), 0775, true);
            file_put_contents($cache, $raw);
            self::importa($cat['pacchetti']);
            return ['ok' => true, 'quando' => date('Y-m-d H:i:s'), 'errore' => null, 'pacchetti' => count($cat['pacchetti'])];
        } catch (Throwable $e) {
            error_log('Store: ' . $e->getMessage());
            return ['ok' => false, 'quando' => $quando, 'errore' => $e->getMessage(), 'pacchetti' => 0];
        }
    }

    /** Il catalogo remoto dalla cache (array di manifest arricchiti), per codice */
    public static function catalogoRemoto(): array
    {
        $cache = self::cacheFile();
        if (!is_file($cache)) return [];
        $cat = json_decode((string) file_get_contents($cache), true);
        $out = [];
        foreach ((array) ($cat['pacchetti'] ?? []) as $p) if (!empty($p['codice'])) $out[$p['codice']] = $p;
        return $out;
    }

    /** Riversa i pacchetti del repository nella tabella comune (origine = repository; i respinti spariscono) */
    private static function importa(array $pacchetti): void
    {
        $t = Database::comune('store_moduli');
        $presenti = [];
        foreach (Database::all("SELECT id, codice, versione FROM $t") as $r) $presenti[$r['codice']] = $r;
        $visti = [];
        foreach ($pacchetti as $p) {
            $m = self::normalizza($p);
            if (!$m) continue;
            $visti[] = $m['codice'];
            $riga = ['nome' => $m['nome'], 'sottotitolo' => $m['sottotitolo'], 'descrizione' => $m['descrizione'], 'categoria' => $m['categoria'],
                'prezzo_tipo' => $m['prezzo_tipo'], 'prezzo' => $m['prezzo'], 'fi' => $m['fi'], 'fa' => $m['fa'], 'tinta' => $m['tinta'],
                'schermate' => json_encode($m['schermate'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 'disponibile' => $m['disponibile'], 'versione' => $m['versione'],
                'ordine' => $m['ordine'], 'autore' => $m['autore'], 'autore_url' => $m['autore_url'], 'novita' => $m['novita'], 'stato' => $m['stato'],
                'richiede' => json_encode($m['richiede'], JSON_UNESCAPED_SLASHES), 'dipendenze' => json_encode($m['dipendenze']), 'capabilities' => json_encode($m['capabilities']), 'conflitti' => json_encode($m['conflitti']), 'lingue' => json_encode($m['languages']),
                'file' => $m['file'], 'sha256' => $m['sha256'], 'dimensione' => $m['dimensione'], 'voti_media' => $m['voti_media'], 'voti_n' => $m['voti_n'],
                'origine' => 'repository', 'aggiornato_il' => date('Y-m-d H:i:s'), 'attivo' => 1];
            if (isset($presenti[$m['codice']])) Database::update($t, $riga, 'id = :id', ['id' => (int) $presenti[$m['codice']]['id']]);
            else Database::insert($t, $riga + ['codice' => $m['codice']]);
        }
        // pacchetti spariti dal repository: restano se installati (l'utente li ha), altrimenti si nascondono
        foreach ($presenti as $cod => $r) {
            if (in_array($cod, $visti, true)) continue;
            $orig = Database::value("SELECT origine FROM $t WHERE id = ?", [(int) $r['id']]);
            if ($orig === 'repository') Database::update($t, ['attivo' => self::installato($cod) ? 1 : 0], 'id = :id', ['id' => (int) $r['id']]);
        }
    }

    /** Un manifest (dal catalogo o da un pacchetto) in forma completa e pulita, o null se inutilizzabile */
    public static function normalizza(array $p): ?array
    {
        $cod = strtolower(trim((string) ($p['codice'] ?? '')));
        if (!preg_match('/^[a-z][a-z0-9_]{1,39}$/', $cod) || empty($p['nome']) || empty($p['versione'])) return null;
        $tipo = in_array($p['prezzo_tipo'] ?? '', ['gratis', 'pagamento', 'abbonamento'], true) ? $p['prezzo_tipo'] : 'gratis';
        $stato = isset(self::STATI[$p['stato'] ?? '']) ? $p['stato'] : 'in_revisione';
        if (!empty($p['text_domain']) && strtolower((string) $p['text_domain']) !== $cod) return null;   // regola dello Store: il dominio delle traduzioni È il codice
        $voti = (array) ($p['voti'] ?? []);
        return [
            'codice' => $cod, 'nome' => (string) $p['nome'], 'sottotitolo' => (string) ($p['sottotitolo'] ?? ''), 'descrizione' => (string) ($p['descrizione'] ?? ''),
            'categoria' => (string) ($p['categoria'] ?? 'Clinica'), 'prezzo_tipo' => $tipo, 'prezzo' => (float) ($p['prezzo'] ?? 0),
            'fi' => (string) ($p['fi'] ?? 'puzzle-piece'), 'fa' => (string) ($p['fa'] ?? 'fa-solid fa-puzzle-piece'), 'tinta' => (string) ($p['tinta'] ?? '#6B6FE6'),
            'schermate' => array_map(fn($s) => self::schermata($cod, (array) $s), array_values((array) ($p['schermate'] ?? []))), 'disponibile' => (int) ($p['disponibile'] ?? 1), 'versione' => (string) $p['versione'],
            'ordine' => (int) ($p['ordine'] ?? 100), 'autore' => (string) ($p['autore'] ?? 'Autore'), 'autore_url' => (string) ($p['autore_url'] ?? ''), 'novita' => (int) ($p['novita'] ?? 0),
            'stato' => $stato, 'richiede' => (array) ($p['richiede'] ?? []), 'dipendenze' => array_values((array) ($p['dipendenze'] ?? [])),
            'capabilities' => array_values((array) ($p['capabilities'] ?? [])), 'conflitti' => array_values((array) ($p['conflitti'] ?? [])), 'file' => (string) ($p['file'] ?? ''), 'sha256' => strtolower((string) ($p['sha256'] ?? '')),
            'dimensione' => (int) ($p['dimensione'] ?? 0), 'voti_media' => (float) ($voti['media'] ?? 0), 'voti_n' => (int) ($voti['n'] ?? 0),
            'text_domain' => $cod, 'languages' => array_values(array_map('strval', (array) ($p['languages'] ?? ['it_IT']))),
        ];
    }

    /** Le immagini di un pacchetto stanno nella sua cartella: 'assets/shot.svg' nel manifest → estensioni/<codice>/assets/shot.svg */
    private static function schermata(string $cod, array $s): array
    {
        $img = (string) ($s['img'] ?? '');
        if ($img !== '' && !preg_match('~^(https?:|/|assets/images/)~', $img)) $s['img'] = "estensioni/$cod/" . ltrim($img, '/');
        return $s;
    }

    /* ------------------------------------------------------------------ file installati */

    /** Il manifest dell'estensione presente su disco (estensioni/<codice>/manifest.json), o null se non c'è la cartella */
    public static function manifestInstallato(string $codice): ?array
    {
        $dir = self::dir($codice);
        if (!is_dir($dir)) return null;
        $f = "$dir/manifest.json";
        $m = is_file($f) ? (json_decode((string) file_get_contents($f), true) ?: []) : [];
        return ['codice' => $codice, 'versione' => (string) ($m['versione'] ?? ''), 'nome' => (string) ($m['nome'] ?? $codice)] + $m;
    }

    public static function installato(string $codice): bool { return is_dir(self::dir($codice)) || self::soloCatalogo($codice); }
    public static function dir(string $codice): string { return DRF_ROOT . '/estensioni/' . preg_replace('/[^a-z0-9_]/', '', $codice); }

    /** Estensioni che vivono nel core senza cartella propria (commercialista, firma, salaattesa, ritmo): si attivano e basta */
    private static function soloCatalogo(string $codice): bool
    {
        return in_array($codice, ['commercialista', 'firma', 'salaattesa', 'ritmo', 'sms', 'sms_500', 'sms_2000', 'senza_marchio', 'spazio'], true);   // servizi e opzioni: nessun file
    }

    /* ------------------------------------------------------------------ requisiti */

    /** Problemi che impediscono l'installazione (vuoto = tutto ok) */
    public static function problemi(array $m): array
    {
        $out = [];
        $r = (array) ($m['richiede'] ?? []);
        if (!empty($r['drfacile']) && version_compare(Installer::VERSIONE, (string) $r['drfacile'], '<')) $out[] = "Richiede DRFacile {$r['drfacile']} o superiore (hai " . Installer::VERSIONE . ')';
        if (!empty($r['drfacile_max']) && version_compare(Installer::VERSIONE, (string) $r['drfacile_max'], '>')) $out[] = "Testata fino a DRFacile {$r['drfacile_max']}: su " . Installer::VERSIONE . ' potrebbe non funzionare';
        if (!empty($r['php']) && version_compare(PHP_VERSION, (string) $r['php'], '<')) $out[] = "Richiede PHP {$r['php']} o superiore (hai " . PHP_VERSION . ')';
        foreach ((array) ($r['estensioni_php'] ?? []) as $ext) if (!extension_loaded($ext)) $out[] = "Richiede l'estensione PHP $ext";
        foreach ((array) ($m['conflitti'] ?? []) as $c) if (Estensioni::attiva((string) $c)) $out[] = "In conflitto con l'estensione $c (attiva)";
        return $out;
    }

    /** Dipendenze mancanti (codici non installati): vanno installate prima */
    public static function dipendenzeMancanti(array $m): array
    {
        return array_values(array_filter((array) ($m['dipendenze'] ?? []), fn($d) => !Estensioni::attiva((string) $d)));
    }

    /* ------------------------------------------------------------------ installazione dei file */

    /**
     * Scarica il pacchetto dal repository, verifica sha256 e requisiti, installa le dipendenze mancanti, estrae i file.
     * Ritorna il manifest installato. Non attiva: ci pensa Estensioni::installa().
     */
    public static function scarica(string $codice, int $profondita = 0): array
    {
        if ($profondita > 5) throw new ApiException(__('Catena di dipendenze troppo lunga'));
        $m = self::catalogoRemoto()[$codice] ?? null;
        if (!$m) { self::sincronizza(true); $m = self::catalogoRemoto()[$codice] ?? null; }
        if (!$m) throw new ApiException(__('Pacchetto non presente nel repository'));
        $m = self::normalizza($m) ?? throw new ApiException(__('Manifest non valido nel repository'));
        if ($m['stato'] === 'respinto') throw new ApiException(__('Pacchetto respinto in revisione: non installabile'));
        if ($m['stato'] !== 'approvato' && !self::revisore()) throw new ApiException('Pacchetto in revisione: sarà installabile dopo l\'approvazione');
        if ($m['file'] === '') throw new ApiException(__('Il catalogo non indica il file del pacchetto'));
        if ($p = self::problemi($m)) throw new ApiException(implode(' · ', $p));
        foreach (self::dipendenzeMancanti($m) as $d) {   // prima le dipendenze
            self::scarica((string) $d, $profondita + 1);
            Estensioni::installa((string) $d);
        }
        if (!class_exists('ZipArchive')) throw new ApiException('Serve l\'estensione PHP zip per installare i pacchetti');

        $zip = self::leggi('pacchetti/' . basename($m['file']));
        if ($m['sha256'] !== '' && !hash_equals($m['sha256'], hash('sha256', $zip))) throw new ApiException('Il pacchetto scaricato non corrisponde all\'impronta del catalogo (sha256): installazione annullata');

        $tmpZip = tempnam(sys_get_temp_dir(), 'drfx'); file_put_contents($tmpZip, $zip);
        $tmpDir = sys_get_temp_dir() . '/drfx-' . $codice . '-' . bin2hex(random_bytes(4));
        try {
            $za = new ZipArchive();
            if ($za->open($tmpZip) !== true) throw new ApiException(__('ZIP non leggibile'));
            $manifest = null;
            for ($i = 0; $i < $za->numFiles; $i++) {
                $n = $za->getNameIndex($i);
                if (str_contains($n, '..') || str_starts_with($n, '/') || str_contains($n, '\\')) throw new ApiException("Percorso non ammesso nel pacchetto: $n");   // path traversal
                if ($n === 'manifest.json') $manifest = json_decode((string) $za->getFromIndex($i), true);
            }
            if (!is_array($manifest) || strtolower((string) ($manifest['codice'] ?? '')) !== $codice) throw new ApiException(__('manifest.json mancante o con codice diverso dal catalogo'));
            if ((string) ($manifest['versione'] ?? '') !== $m['versione']) throw new ApiException("Versione nel pacchetto ({$manifest['versione']}) diversa dal catalogo ({$m['versione']})");
            mkdir($tmpDir, 0775, true);
            $za->extractTo($tmpDir); $za->close();
            // sostituzione atomica: la vecchia cartella diventa .bak (una sola generazione), la nuova prende il posto
            $dest = self::dir($codice); $bak = $dest . '.bak';
            if (is_dir($bak)) self::rmdir($bak);
            if (is_dir($dest)) rename($dest, $bak);
            if (!rename($tmpDir, $dest)) { self::copia($tmpDir, $dest); self::rmdir($tmpDir); }   // rename fra filesystem diversi
            if (is_dir($bak)) self::rmdir($bak);
        } finally {
            @unlink($tmpZip); if (is_dir($tmpDir)) self::rmdir($tmpDir);
        }
        return self::manifestInstallato($codice) ?? ['codice' => $codice, 'versione' => $m['versione']];
    }

    /** Elimina i file dell'estensione (i dati nel database restano: DISINSTALLAZIONE ≠ CANCELLAZIONE DATI) */
    public static function rimuoviFile(string $codice): void
    {
        $dir = self::dir($codice);
        if (is_dir($dir)) self::rmdir($dir);
    }

    /** Le estensioni installate da repository per cui il catalogo ha una versione più nuova: [codice => versione nuova] */
    public static function aggiornamentiDisponibili(): array
    {
        $out = [];
        foreach (self::catalogoRemoto() as $cod => $p) {
            $inst = self::manifestInstallato($cod);
            if ($inst && $inst['versione'] !== '' && version_compare((string) $p['versione'], $inst['versione'], '>')) $out[$cod] = (string) $p['versione'];
        }
        return $out;
    }

    /* ------------------------------------------------------------------ voti */

    public static function tabelle(): void
    {
        $id = Database::driver() === 'mysql' ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
        Database::run('CREATE TABLE IF NOT EXISTS ' . Database::comune('store_voti') . " (
            id $id, studio_id INTEGER NOT NULL, codice VARCHAR(40) NOT NULL, voto INTEGER NOT NULL, recensione TEXT,
            inviato INTEGER DEFAULT 0, creato_il VARCHAR(19), aggiornato_il VARCHAR(19))");
    }

    /** Salva (o aggiorna) il voto dello studio: 1-5 stelle, recensione facoltativa (predisposta) */
    public static function vota(string $codice, int $voto, string $recensione = ''): array
    {
        if ($voto < 1 || $voto > 5) throw new ApiException(__('Il voto va da 1 a 5 stelle'));
        $sid = Auth::studioId();
        $t = Database::comune('store_voti'); $ora = date('Y-m-d H:i:s');
        $ex = Database::one("SELECT id FROM $t WHERE studio_id = ? AND codice = ?", [$sid, $codice]);
        if ($ex) Database::update($t, ['voto' => $voto, 'recensione' => $recensione, 'inviato' => 0, 'aggiornato_il' => $ora], 'id = :id', ['id' => (int) $ex['id']]);
        else Database::insert($t, ['studio_id' => $sid, 'codice' => $codice, 'voto' => $voto, 'recensione' => $recensione, 'inviato' => 0, 'creato_il' => $ora, 'aggiornato_il' => $ora]);
        // se il repository raccoglie i voti, glielo mandiamo (senza dati dello studio oltre a un identificativo anonimo)
        $url = trim((string) (Config::get('store.voti_url') ?? ''));
        if ($url !== '' && self::remoto()) {
            try {
                self::http($url, json_encode(['codice' => $codice, 'voto' => $voto, 'recensione' => $recensione, 'installazione' => substr(hash('sha256', DRF_ROOT . $sid), 0, 16), 'versione_app' => Installer::VERSIONE]));
                Database::run("UPDATE $t SET inviato = 1 WHERE studio_id = ? AND codice = ?", [$sid, $codice]);
            } catch (Throwable $e) { error_log('Store voto: ' . $e->getMessage()); }
        }
        return self::voti($codice);
    }

    /** Il voto dello studio e la media: quella del catalogo se c'è, altrimenti quella locale */
    public static function voti(string $codice): array
    {
        $t = Database::comune('store_voti');
        $mio = Database::one("SELECT voto, recensione FROM $t WHERE studio_id = ? AND codice = ?", [Auth::studioId(), $codice]);
        $loc = Database::one("SELECT AVG(voto) m, COUNT(*) n FROM $t WHERE codice = ?", [$codice]);
        $cat = self::catalogoRemoto()[$codice]['voti'] ?? null;
        $media = $cat && !empty($cat['n']) ? (float) $cat['media'] : (float) ($loc['m'] ?? 0);
        $n = $cat && !empty($cat['n']) ? (int) $cat['n'] : (int) ($loc['n'] ?? 0);
        return ['mio' => $mio ? (int) $mio['voto'] : 0, 'recensione' => (string) ($mio['recensione'] ?? ''), 'media' => round($media, 1), 'n' => $n];
    }

    /* ------------------------------------------------------------------ I/O */

    /** Legge un file del repository (HTTP o cartella locale) */
    private static function leggi(string $rel): string
    {
        $repo = self::repository();
        if (self::remoto()) return self::http($repo . '/' . $rel);
        $f = $repo . '/' . $rel;
        if (!is_dir($repo)) throw new RuntimeException("Cartella del repository non trovata: $repo");
        if (!is_file($f)) throw new RuntimeException("File non trovato nel repository: $f");
        if (!is_readable($f)) throw new RuntimeException("File non leggibile dall'utente del web server: $f (permessi)");
        return (string) file_get_contents($f);
    }

    /** GET (o POST se $body) con curl se c'è, altrimenti stream; 20 secondi di timeout */
    private static function http(string $url, ?string $body = null): string
    {
        if (function_exists('curl_init')) {
            $c = curl_init($url);
            curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3, CURLOPT_TIMEOUT => 20, CURLOPT_USERAGENT => 'DRFacile/' . Installer::VERSIONE]);
            if ($body !== null) curl_setopt_array($c, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => $body, CURLOPT_HTTPHEADER => ['Content-Type: application/json']]);
            $r = curl_exec($c); $code = (int) curl_getinfo($c, CURLINFO_RESPONSE_CODE); $err = curl_error($c); curl_close($c);
            if ($r === false) throw new RuntimeException("Repository non raggiungibile: $err");
            if ($code >= 400) throw new RuntimeException("Repository: risposta HTTP $code per $url");
            return (string) $r;
        }
        $ctx = stream_context_create(['http' => ['method' => $body === null ? 'GET' : 'POST', 'timeout' => 20, 'header' => "User-Agent: DRFacile/" . Installer::VERSIONE . ($body === null ? '' : "\r\nContent-Type: application/json"), 'content' => $body ?? '', 'ignore_errors' => true]]);
        $r = @file_get_contents($url, false, $ctx);
        if ($r === false) throw new RuntimeException("Repository non raggiungibile: $url");
        if (preg_match('/ (\d{3}) /', (string) ($http_response_header[0] ?? ''), $m) && (int) $m[1] >= 400) throw new RuntimeException("Repository: risposta HTTP {$m[1]}");
        return (string) $r;
    }

    private static function rmdir(string $dir): void
    {
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $f) {
            $f->isDir() ? rmdir($f->getPathname()) : unlink($f->getPathname());
        }
        rmdir($dir);
    }

    private static function copia(string $da, string $a): void
    {
        mkdir($a, 0775, true);
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($da, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST) as $f) {
            $dest = $a . '/' . substr($f->getPathname(), strlen($da) + 1);
            $f->isDir() ? mkdir($dest, 0775, true) : copy($f->getPathname(), $dest);
        }
    }
}
