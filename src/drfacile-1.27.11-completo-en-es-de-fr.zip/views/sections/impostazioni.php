<div class="settings stagger">
  <?php $pieno = Auth::can('impostazioni.modifica'); ?>
  <div class="card" data-form="miei"><h3><i class="ico" data-fi="id-badge" data-fa="fa-regular fa-id-badge"></i><?= __('I miei dati') ?></h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('Il tuo account: nome, recapiti (servono anche al recupero della password) e password. Il ruolo lo assegna l\'amministratore.') ?></p>
    <div class="grid2"><div class="field"><label><?= __('Nome') ?></label><input class="input" id="mieiNome"></div><div class="field"><label><?= __('Cognome') ?></label><input class="input" id="mieiCognome"></div>
    <div class="field"><label>Email</label><input class="input" id="mieiEmail" type="email"></div><div class="field"><label><?= __('Cellulare') ?></label><input class="input" id="mieiTelefono"></div>
    <div class="field"><label><?= __('Nuova password') ?></label><input class="input" id="mieiPwd" type="password" autocomplete="new-password" placeholder="<?= __('Lascia vuoto per non cambiarla') ?>"></div><div class="field"><label><?= __('Password attuale') ?></label><input class="input" id="mieiPwdAttuale" type="password" autocomplete="current-password" placeholder="<?= __('Per confermare le modifiche') ?>"></div></div>
    <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn primary" type="button" id="mieiSalva"><?= __('Salva i miei dati') ?></button></div>
  </div>
  <?php if ($pieno): ?>
  <div class="card" data-form="profilo"><h3><i class="ico" data-fi="user" data-fa="fa-solid fa-user"></i><?= __('Profilo') ?></h3>
    <div class="ava-row">
      <div class="ava-cur" id="avaCur"></div>
      <div class="ava-drop" id="avaDrop" title="<?= __('Clicca o trascina un\'immagine') ?>">
        <i class="ico" data-fi="picture" data-fa="fa-regular fa-image"></i>
        <div><b><?= __('Foto del profilo') ?></b><span><?= __('Clicca o trascina qui un\'immagine: la ritagli in un attimo') ?></span></div>
      </div>
      <button class="icon-btn sm" id="avaDel" type="button" title="<?= __('Rimuovi la foto') ?>" hidden><i class="ico" data-fi="trash" data-fa="fa-solid fa-trash"></i></button>
      <input type="file" id="avaFile" accept="image/*" hidden>
    </div>
    <div class="grid2"><div class="field"><label><?= __('Nome e cognome') ?></label><input class="input" name="profilo_nome"></div><div class="field"><label><?= __('Titolo') ?></label><input class="input" name="profilo_titolo"></div></div>
    <div class="grid2"><div class="field"><label><?= __('Specializzazione') ?></label><input class="input" name="profilo_specializzazione"></div>
      <div class="field"><label><?= __('Sesso') ?></label><select class="select" name="profilo_sesso"><option value="F"><?= __('Dottoressa') ?></option><option value="M"><?= __('Dottore') ?></option></select><span class="small muted" style="display:block;margin-top:6px"><?= __('Usato nei saluti del programma (es. "Bentornato" all\'accesso)') ?></span></div></div>
    <div class="grid2"><div class="field"><label>Email</label><input class="input" name="profilo_email" type="email"></div><div class="field"><label><?= __('Telefono') ?></label><input class="input" name="profilo_telefono"></div></div>
    <div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn primary" data-save><?= __('Salva profilo') ?></button></div>
  </div>
  <?php endif; ?>
  <?php if (Auth::can('utenti.gestisci')): ?>
  <div class="card"><h3><i class="ico" data-fi="users" data-fa="fa-solid fa-user-group"></i><?= __('Utenti dello studio') ?></h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('Chi può accedere a DRFacile: ognuno con le sue credenziali e la sua foto. Gli account vivono nell\'anagrafica comune, l\'abbonamento è dello studio.') ?></p>
    <div id="utList" class="ut-list"></div>
    <button class="btn ghost sm" id="utNuovo" type="button" style="margin-top:10px"><i class="ico" data-fi="user-add" data-fa="fa-solid fa-user-plus"></i><?= __('Aggiungi utente') ?></button>
  </div>
  <?php endif; ?>
  <?php if ($pieno): ?>
  <div class="card" data-form="studio"><h3><i class="ico" data-fi="building" data-fa="fa-solid fa-hospital"></i><?= __('Studio') ?></h3>
    <div class="field"><label><?= __('Nome dello studio') ?></label><input class="input" name="studio_nome"></div>
    <div class="field"><label><?= __('Indirizzo') ?></label><input class="input" name="studio_indirizzo"></div>
    <div class="grid2"><div class="field"><label><?= __('Partita IVA') ?></label><input class="input mono" name="studio_piva"></div><div class="field"><label><?= __('Codice ordine') ?></label><input class="input mono" name="studio_ordine"></div></div>
    <div class="field"><label><?= __('Riga aggiuntiva sui documenti') ?></label><input class="input" name="studio_riga_documenti" placeholder="Es. Tel. 02 1234567 · studio@esempio.it · www.studio.it"><p class="help"><?= __('Se compilata, viene stampata in fondo a referti, fatture e documenti') ?></p></div>
    <div class="row" style="margin-top:16px;justify-content:flex-end"><button class="btn primary" data-save><?= __('Salva studio') ?></button></div>
  </div>
  <div class="card" data-form="fatturazione"><h3><i class="ico" data-fi="receipt" data-fa="fa-solid fa-file-invoice"></i><?= __('Fatturazione') ?></h3>
    <div class="pref"><div><b><?= __('Spese di studio') ?></b><span><?= __('Proposte come riga aggiuntiva in ogni nuova fattura') ?></span></div><button class="switch" data-name="fattura_spese_attive" type="button" aria-label="<?= __('Spese di studio') ?>"></button><input type="hidden" name="fattura_spese_attive" value="0"></div>
    <div class="grid2" style="margin-top:12px"><div class="field"><label><?= __('Importo spese di studio') ?></label><input class="input num" name="fattura_spese_importo" data-mask="euros"></div><div class="field"><label><?= __('Descrizione in fattura') ?></label><input class="input" name="fattura_spese_desc" placeholder="<?= __('Spese di studio') ?>"></div></div>
    <div class="grid2"><div class="field"><label><?= __('Contributo previdenziale (%)') ?></label><input class="input num" name="fattura_contributi_perc" data-mask="decimale" placeholder="<?= __('Es. 4') ?>"></div><div class="field"><label><?= __('Descrizione del contributo') ?></label><input class="input" name="fattura_contributi_desc" placeholder="<?= __('Es. Contributo integrativo Cassa/INPS 4%') ?>"></div></div>
    <p class="small muted" style="margin-top:4px;line-height:1.6"><?= __('Il contributo (es. 4% della cassa medici o INPS) viene calcolato sull\'imponibile e proposto in ogni nuova fattura; spese e contributo si possono togliere fattura per fattura. Le aliquote IVA delle prestazioni si gestiscono in') ?> <b><?= __('Archivi → Aliquote IVA') ?></b>, i metodi di pagamento (giorni di incasso, conto, codice SDI) in <b><?= __('Archivi → Metodi di pagamento') ?></b>.</p>
    <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn primary" data-save><?= __('Salva fatturazione') ?></button></div>
  </div>
  <div class="card" data-form="preferenze"><h3><i class="ico" data-fi="settings-sliders" data-fa="fa-solid fa-sliders"></i><?= __('Preferenze') ?></h3>
    <div class="pref"><div><b><?= __('Assistente (percorsi guidati)') ?></b><span><?= __('La lista "anti sbadati" che compare al nuovo paziente e con F2: passi automatici e manuali') ?></span></div><button class="switch" data-name="assistente_attivo" type="button"></button><input type="hidden" name="assistente_attivo" value="1"></div>
    <div class="pref"><div><b><?= __('Tema scuro') ?></b><span><?= __('Interfaccia a bassa luminosità') ?></span></div><button class="switch" id="prefTheme" type="button" aria-label="<?= __('Tema scuro') ?>"></button></div>
    <div class="pref"><div><b><?= __('Suoni di sistema') ?></b><span><?= __('Conferme e avvisi') ?></span></div><button class="switch" data-pref="pref_suoni" type="button" aria-label="<?= __('Suoni') ?>"></button></div>
    <div class="pref"><div><b><?= __('Promemoria SMS ai pazienti') ?></b><span><?= __('24 ore prima dell\'appuntamento') ?></span></div><button class="switch" data-pref="pref_sms" type="button" aria-label="<?= __('Promemoria SMS') ?>"></button></div>
    <div class="pref"><div><b><?= __('Firma automatica dei referti') ?></b><span><?= __('Alla chiusura della visita') ?></span></div><button class="switch" data-pref="pref_firma_auto" type="button" aria-label="<?= __('Firma automatica') ?>"></button></div>
    <div class="pref"><div><b><?= __('Prezzi delle prestazioni in visita') ?></b><span><?= __('Mostra i prezzi nella tendina "Prestazioni eseguite" (in fattura si vedono sempre)') ?></span></div><button class="switch" data-pref="pref_prezzi_visita" type="button" aria-label="<?= __('Prezzi in visita') ?>"></button></div>
    <div class="pref"><div><b><?= __('Durata visita predefinita') ?></b><span><?= __('Proposta nelle nuove prenotazioni') ?></span></div><select class="select" data-pref="pref_durata"><option value="15"><?= __('15 min') ?></option><option value="30"><?= __('30 min') ?></option><option value="45"><?= __('45 min') ?></option><option value="60"><?= __('60 min') ?></option></select></div>
  </div>
  <div class="card" data-form="parametri"><h3><i class="ico" data-fi="settings-sliders" data-fa="fa-solid fa-sliders"></i><?= __('Parametri') ?></h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('La numerazione delle fatture: formato del numero e progressivo di partenza.') ?></p>
    <div class="grid2">
      <div class="field"><label><?= __('Formato del numero') ?></label><input class="input mono" name="fattura_formato" list="fmtList" placeholder="{aaaa}/{nnn}" autocomplete="off">
        <datalist id="fmtList"><option value="{aaaa}/{nnn}"></option><option value="{n}/{aa}"></option><option value="{n}-{aaaa}"></option><option value="{nnn}-{aaaa}"></option><option value="{n}DR"></option></datalist>
        <span class="small muted" style="display:block;margin-top:6px"><span class="mono">{n}</span> progressivo · <span class="mono">{nnn}</span> a tre cifre · <span class="mono">{aaaa}</span>/<span class="mono">{aa}</span> anno — prossima: <b class="mono" id="fmtAnteprima">—</b></span>
      </div>
      <div class="field"><label><?= __('Prossimo numero progressivo') ?></label>
        <div class="row" style="gap:8px"><input class="input num" name="fattura_prossimo" data-mask="intero" disabled style="flex:1"><button class="btn soft" type="button" id="numSblocca" title="<?= __('Sblocca la modifica della numerazione') ?>"><i class="ico" data-fi="lock" data-fa="fa-solid fa-lock"></i><?= __('Sblocca') ?></button></div>
        <span class="small muted" style="display:block;margin-top:6px"><?= __('Da usare quando si adotta DRFacile a numerazione già avviata (es. partire dalla fattura 120). Vale se maggiore del progressivo già raggiunto nell\'anno.') ?></span>
      </div>
    </div>
    <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn primary" data-save><?= __('Salva parametri') ?></button></div>
  </div>
  <?php endif; ?>
  <?php $vistaExt = Hooks::filter('views.override', '', 'impostazioni/pannelli'); if ($vistaExt && is_file($vistaExt)) include $vistaExt; ?>
  <?php foreach (Impostazione::pannelli() as $pan): /* pannelli delle estensioni (hook impostazioni.pannelli, docs/sviluppo-estensioni.md) */ ?>
  <div class="card" data-form="ext-<?= e($pan['key']) ?>" data-ext="<?= e($pan['key']) ?>"><h3><i class="ico" data-fi="<?= e($pan['fi']) ?>" data-fa="<?= e($pan['fa']) ?>"></i><?= e($pan['titolo']) ?></h3>
    <?= $pan['html'] ?>
    <?php if ($pan['chiavi']): ?><div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn primary" data-save><?= e($pan['salva']) ?></button></div><?php endif; ?>
  </div>
  <?php endforeach; ?>
  <?php if ($pieno): ?>
  <div class="card" id="cardStampa"><h3><i class="ico" data-fi="print" data-fa="fa-solid fa-print"></i><?= __('Stampa dei documenti') ?></h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('Formato e margini della pagina, carattere, logo e intestazione (studio o professionista), piè di pagina. Valgono per referti, ricette, fatture e documenti.') ?></p>
    <div class="stampa-riass" id="stampaRiass"></div>
    <div class="row" style="margin-top:12px;gap:8px"><button class="btn primary" type="button" id="btnStampaCfg"><i class="ico" data-fi="settings-sliders" data-fa="fa-solid fa-sliders"></i><span><?= __('Configura') ?></span></button><button class="btn ghost" type="button" data-doc="prova" data-id="0"><i class="ico" data-fi="eye" data-fa="fa-regular fa-eye"></i><span><?= __('Prova di stampa') ?></span></button></div>
  </div>
  <?php endif; ?>
  <div class="card"><h3><i class="ico" data-fi="globe" data-fa="fa-solid fa-globe"></i><?= __('Lingua') ?></h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('La lingua è personale (ogni utente la sua). Le traduzioni sono file gettext in') ?> <code>locale/</code><?= __('; le estensioni portano le loro.') ?></p>
    <div class="field" style="max-width:320px"><select class="select" id="setLingua"></select></div>
  </div>
  <?php if ($pieno): ?>
  <div class="card" data-form="email"><h3><i class="ico" data-fi="envelope" data-fa="fa-regular fa-envelope"></i><?= __('Email') ?></h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('Server e credenziali stanno in') ?> <code>config/config.php</code> (<?= e((string) Config::get('comunicazioni.email.driver', 'log')) ?><?= Config::get('comunicazioni.email.driver') === 'smtp' ? ' · ' . e((string) Config::get('comunicazioni.email.smtp.host')) : '' ?>). Qui ciò che vede chi riceve. I testi si personalizzano in <b><?= __('Archivi → Modelli di messaggio') ?></b>.</p>
    <div class="grid2"><div class="field"><label><?= __('Nome del mittente') ?></label><input class="input" name="email_da_nome" placeholder="<?= __('Es. Studio Rossi') ?>"></div><div class="field"><label><?= __('Rispondi a') ?></label><input class="input" name="email_rispondi_a" type="email" placeholder="Es. segreteria@studiorossi.it"></div></div>
    <div class="row" style="margin-top:14px;justify-content:flex-end"><button class="btn primary" data-save><?= __('Salva email') ?></button></div>
  </div>
  <div class="card" id="cardSms"><h3><i class="ico" data-fi="comment-sms" data-fa="fa-solid fa-comment-sms"></i>SMS</h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('Servizio a consumo: si attiva dallo Store e si ricarica a pacchetti. Le credenziali del provider stanno in') ?> <code>config/config.php</code>.</p>
    <div id="smsStato"></div>
  </div>
  <div class="card" id="cardSpazio"><h3><i class="ico" data-fi="disk" data-fa="fa-solid fa-hard-drive"></i><?= __('Spazio dello studio') ?></h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('Documenti generati, archiviati e caricati, più il database. La quota si amplia dallo Store.') ?></p>
    <div class="spazio-bar"><i></i></div>
    <div class="row" style="justify-content:space-between;margin-top:8px;font-size:12px"><b id="spazioUso">—</b><span class="muted" id="spazioQuota"></span></div>
  </div>
  <div class="card"><h3><i class="ico" data-fi="paper-plane" data-fa="fa-regular fa-paper-plane"></i><?= __('Comunicazioni') ?></h3>
    <p class="small muted" style="margin-bottom:10px"><?= __('Da qui passano tutte le email, gli SMS e i WhatsApp dello studio: promemoria, codici di accesso, richieste. Ogni invio resta nel registro qui sotto, così sai sempre cosa è partito e quando. L\'attivazione dei canali (email dello studio, SMS, WhatsApp) si concorda con l\'assistenza in fase di avvio.') ?></p>
    <dl class="dl-mini"><dt>Email</dt><dd class="mono" data-drv="email">—</dd><dt>SMS</dt><dd class="mono" data-drv="sms">—</dd><dt>WhatsApp</dt><dd class="mono" data-drv="whatsapp">—</dd></dl>
    <button class="btn ghost sm" id="setRegistroCom" style="margin-top:8px"><i class="ico" data-fi="list" data-fa="fa-solid fa-list"></i><?= __('Vedi il registro') ?></button>
  </div>
  <div class="card"><h3><i class="ico" data-fi="hourglass-end" data-fa="fa-solid fa-hourglass-half"></i><?= __('Abbonamento') ?></h3>
    <?php $abb = Auth::abbonamento(); ?>
    <?php if ($abb['stato'] === 'non_gestito'): ?><p class="small muted"><?= __('Abbonamento non gestito:') ?> <?= Config::get('abbonamento.attivo') ? __('lo studio non ha una scadenza') . ' (' . __('impostala con') . ' <code>php strumenti/abbonamento.php +30</code>)' : __('attivalo in') . ' <code>config/config.php</code> (<code>abbonamento.attivo = true</code>) ' . __('e dai una scadenza allo studio con') . ' <code>php strumenti/abbonamento.php +30</code>' ?>.</p>
    <?php else: ?>
    <dl class="dl-mini"><dt><?= __('Piano') ?></dt><dd><?= e($abb['periodo'] === 'mensile' ? __('Mensile') : ($abb['periodo'] === 'annuale' ? __('Annuale') : ucfirst($abb['periodo']))) ?></dd><dt><?= __('Scadenza') ?></dt><dd><b><?= data_it($abb['scadenza']) ?></b><?= $abb['giorni'] !== null && $abb['giorni'] >= 0 ? ' <span class="muted small">(' . __('fra') . ' ' . $abb['giorni'] . ' ' . __('gg') . ')</span>' : '' ?></dd><dt><?= __('Stato') ?></dt><dd><?php if ($abb['stato'] === 'attivo'): ?><span class="badge mint"><?= __('Attivo') ?></span><?php elseif ($abb['stato'] === 'in_scadenza'): ?><span class="badge amber"><?= __('In scadenza') ?></span><?php else: ?><span class="badge rose"><?= __('Scaduto') ?></span><?php endif; ?></dd></dl>
    <p class="small muted" style="margin:8px 0 10px"><?= __('Il rinnovo si fa dal portale: alla conferma del pagamento la scadenza si aggiorna da sola. Alla scadenza l\'accesso viene sospeso, i dati restano al sicuro.') ?></p>
    <a class="btn primary sm" href="<?= e($abb['url']) ?>" target="_blank" rel="noopener"><?= __("Rinnova l'abbonamento") ?></a>
    <?php endif; ?>
  </div>
  <div class="card"><h3><i class="ico" data-fi="database" data-fa="fa-solid fa-database"></i><?= __('Dati e backup') ?></h3>
    <p class="small muted" style="line-height:1.6" id="backupInfo">—</p>
    <div class="row" style="margin-top:14px;gap:8px;flex-wrap:wrap">
      <button class="btn soft" id="btnBackup"><i class="ico" data-fi="cloud-upload" data-fa="fa-solid fa-cloud-arrow-up"></i><?= __('Esegui backup ora') ?></button>
      <a class="btn ghost" id="btnExport" href="ajax/impostazioni.php?action=export"><?= __('Esporta archivio (JSON)') ?></a>
      <button class="btn ghost" id="btnImportIgea"><?= __('Importa da Igea') ?></button>
      <button class="btn ghost" id="btnResetDemo" style="color:var(--red-ink)"><?= __('Ripristina dati demo') ?></button>
    </div>
    <h3 style="margin-top:22px;font-size:13px"><?= __('Archivio documentale') ?></h3>
    <div class="archivio" id="archivio"></div>
  </div>
<?php endif; ?>
</div>
