<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'me'     => fn() => ['utente' => Auth::user()['username'] ?? null, 'medico' => Impostazione::profilo()],
    'logout' => function () { Auth::logout(); return ['redirect' => 'login.php']; },
]);
