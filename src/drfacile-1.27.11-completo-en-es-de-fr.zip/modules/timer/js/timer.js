/* Modulo Scrivania: Timer della visita. Parte da solo con 'visita:avviata' (evento del bus), si ferma con 'visita:chiusa'.
   Anello che si riempie sui 30 minuti (durata obiettivo), poi diventa ambra. */
DRF.desk.register('timer', {
  init($win) {
    const K = 'drf_timer', OB = 30 * 60;
    let start = +localStorage.getItem(K) || 0, tick = null;
    const $t = $win.find('.timer-time'), $fg = $win.find('.fg'), $root = $win.find('.timer');
    const draw = () => { const s = start ? Math.floor((Date.now() - start) / 1000) : 0; $t.text(`${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`); $fg.css('stroke-dashoffset', 327 - 327 * Math.min(1, s / OB)); $root.toggleClass('over', s > OB).toggleClass('running', !!start); $win.find('[data-t=start]').text(start ? DRF.__('Ferma') : DRF.__('Avvia')); };
    const go = () => { start = Date.now(); localStorage.setItem(K, start); clearInterval(tick); tick = setInterval(draw, 1000); draw(); };
    const stop = () => { start = 0; localStorage.removeItem(K); clearInterval(tick); draw(); };
    $win.on('click', '[data-t=start]', () => start ? stop() : go()).on('click', '[data-t=reset]', stop);
    DRF.on('visita:avviata', p => { $win.find('.timer-who').text(p && p.nome_completo ? p.nome_completo : DRF.__('Visita in corso')); go(); });
    DRF.on('visita:chiusa', () => { $win.find('.timer-who').text(DRF.__('Nessuna visita in corso')); stop(); });
    if (start) { tick = setInterval(draw, 1000); }
    DRF.api.get('visita', 'stato').then(r => { if (r.aperta) $win.find('.timer-who').text(r.paziente || DRF.__('Visita in corso')); });
    draw();
  }
});
