<?php
require __DIR__ . '/../core/bootstrap.php';
$voci = require DRF_ROOT . '/core/procedure.php';
$voce = function (array $in) use ($voci): array { $k = Api::str($in, 'voce'); if (!isset($voci[$k])) throw new ApiException(__('Voce non trovata'), 404); return $voci[$k] + ['key' => $k]; };
Api::run([
    'elenco' => function () use ($voci) { $out = []; foreach ($voci as $k => $v) $out[] = ['key' => $k] + $v; return $out; },
    'voce'   => function (array $in) use ($voce) {
        $v = $voce($in);
        if ($v['tipo'] === 'procedura') { $p = Procedura::carica($v['procedura']); $v['form'] = ['title' => $p->label(), 'desc' => $p->descrizione(), 'html' => FormBuilder::html($p->campi()), 'pulsante' => $p->pulsante()]; }
        return $v;
    },
    'vista'  => function (array $in) use ($voce) {   // HTML di una pagina libera (views/procedure/<vista>.php)
        $v = $voce($in); if ($v['tipo'] !== 'vista') throw new ApiException(__('La voce non è una pagina'));
        $file = (string) Hooks::filter('views.override', DRF_ROOT . '/views/procedure/' . preg_replace('/[^a-z0-9_]/i', '', $v['vista']) . '.php', 'procedure/' . $v['vista']);   // un'estensione può sostituire la pagina
        if (!is_file($file)) throw new ApiException(__('Pagina non trovata'), 404);
        ob_start(); include $file; return ['html' => ob_get_clean(), 'vista' => $v['vista']];
    },
    'esegui' => function (array $in) use ($voce) { $v = $voce($in); if ($v['tipo'] !== 'procedura') throw new ApiException(__('La voce non è una procedura')); return Procedura::carica($v['procedura'])->esegui($in); },
], ['*' => 'procedure.leggi', 'esegui' => 'procedure.esegui']);
