<?php
/**
 * TRADUZIONI (gettext) senza dipendere da xgettext/msgfmt: estrae le stringhe in un .pot, compila i .po in .mo.
 *
 *   php strumenti/i18n.php estrai                     → locale/drfacile.pot dal core (PHP + JS: __, _p, _n, _np, DRF.__, DRF.t, DRF._p, DRF._n)
 *   php strumenti/i18n.php estrai ginecologia         → estensioni/ginecologia/locale/ginecologia.pot (dominio = codice)
 *   php strumenti/i18n.php compila                    → locale/<lingua>.po → locale/<lingua>/LC_MESSAGES/drfacile.mo (tutte le lingue trovate)
 *   php strumenti/i18n.php compila ginecologia        → idem per l'estensione
 *   php strumenti/i18n.php nuova en_US [ginecologia]  → crea <lingua>.po dal .pot (poi si traduce con Poedit o a mano)
 *
 * Convenzione: i .po stanno in locale/<lingua>.po (comodo per Poedit), i .mo compilati in locale/<lingua>/LC_MESSAGES/<dominio>.mo.
 * Poedit può fare tutto questo da solo: lo strumento serve a chi non ce l'ha e agli script di build.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
define('DRF_ROOT', dirname(__DIR__));

$cmd = $argv[1] ?? 'aiuto';
$arg2 = $argv[2] ?? null; $arg3 = $argv[3] ?? null;
$dominio = in_array($cmd, ['estrai', 'compila'], true) ? ($arg2 ?: 'drfacile') : ($cmd === 'nuova' ? ($arg3 ?: 'drfacile') : 'drfacile');
$base = $dominio === 'drfacile' ? DRF_ROOT : DRF_ROOT . "/estensioni/$dominio";
if (!is_dir($base)) exit("Cartella non trovata: $base\n");
$locale = "$base/locale";
if (!is_dir($locale)) mkdir($locale, 0775, true);

/* ---------------- estrazione */
function estrai(string $base, string $dominio): array
{
    $stringhe = [];   // chiave => ['msgid', 'ctx', 'plural', 'refs' => []]
    $escludi = ['/vendor/', '/data/', '/temp/', '/docs/archivio/', '/docs/backup/', '/node_modules/', '/assets/vendor/', '/estensioni/', '/docs/esempi/'];
    if ($dominio !== 'drfacile') $escludi = ['/vendor/', '/node_modules/'];
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS));
    $ARG = '\s*(?:"((?:[^"\\\\]|\\\\.)*)"|\'((?:[^\'\\\\]|\\\\.)*)\')\s*';
    $dec = fn($a, $b) => stripcslashes($a !== '' && $a !== null ? $a : (string) $b);
    foreach ($it as $f) {
        $p = str_replace('\\', '/', $f->getPathname()); $rel = substr($p, strlen($base) + 1);
        if (!preg_match('/\.(php|js)$/', $p)) continue;
        // I filtri vanno applicati SOLO al percorso relativo: il path assoluto può contenere parole come /data/ (es. /mnt/data/build) e non deve escludere l'intero progetto.
        $salta = false; foreach ($escludi as $e) if (str_contains('/' . $rel . '/', $e)) { $salta = true; break; }
        if ($salta) continue;
        $src = (string) file_get_contents($p);
        $righe = fn(int $off) => substr_count(substr($src, 0, $off), "\n") + 1;
        $add = function (string $id, ?string $ctx, ?string $pl, int $off) use (&$stringhe, $rel, $righe) {
            if ($id === '') return; $k = ($ctx ?? '') . "\x04" . $id;
            $stringhe[$k] ??= ['msgid' => $id, 'ctx' => $ctx, 'plural' => $pl, 'refs' => []];
            if ($pl && !$stringhe[$k]['plural']) $stringhe[$k]['plural'] = $pl;
            $stringhe[$k]['refs'][] = "$rel:" . $righe($off);
        };
        // __('id'[, 'dominio'])  'id'  DRF.t('id')
        if (preg_match_all('/(?<![\w.$])(?:DRF\.)?(?:__|t)\(' . $ARG . '(?:,|\))/', $src, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) foreach ($m as $x) $add($dec($x[1][0] ?? '', $x[2][0] ?? ''), null, null, $x[0][1]);
        // _p('ctx', 'id')  DRF._p('ctx', 'id')
        if (preg_match_all('/(?<![\w.$])(?:DRF\.)?_p\(' . $ARG . ',' . $ARG . '(?:,|\))/', $src, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) foreach ($m as $x) $add($dec($x[3][0] ?? '', $x[4][0] ?? ''), $dec($x[1][0] ?? '', $x[2][0] ?? ''), null, $x[0][1]);
        // _n('sing', 'plur', n)  DRF._n(...)
        if (preg_match_all('/(?<![\w.$])(?:DRF\.)?_n\(' . $ARG . ',' . $ARG . ',/', $src, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) foreach ($m as $x) $add($dec($x[1][0] ?? '', $x[2][0] ?? ''), null, $dec($x[3][0] ?? '', $x[4][0] ?? ''), $x[0][1]);
        // _np('ctx', 'sing', 'plur', n)
        if (preg_match_all('/(?<![\w.$])(?:DRF\.)?_np\(' . $ARG . ',' . $ARG . ',' . $ARG . ',/', $src, $m, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) foreach ($m as $x) $add($dec($x[3][0] ?? '', $x[4][0] ?? ''), $dec($x[1][0] ?? '', $x[2][0] ?? ''), $dec($x[5][0] ?? '', $x[6][0] ?? ''), $x[0][1]);
    }
    ksort($stringhe, SORT_STRING);
    return $stringhe;
}
function poQuote(string $s): string { return '"' . addcslashes($s, "\0..\37\"\\") . '"'; }
function scriviPot(array $s, string $file, string $dominio, bool $pot = true, string $lingua = ''): void
{
    $out = "# " . ($pot ? "Template delle traduzioni di $dominio" : "Traduzione $lingua di $dominio") . "\nmsgid \"\"\nmsgstr \"\"\n\"Project-Id-Version: $dominio\\n\"\n\"POT-Creation-Date: " . date('Y-m-d H:iO') . "\\n\"\n\"MIME-Version: 1.0\\n\"\n\"Content-Type: text/plain; charset=UTF-8\\n\"\n\"Content-Transfer-Encoding: 8bit\\n\"\n\"Language: " . ($pot ? '' : $lingua) . "\\n\"\n\"Plural-Forms: nplurals=2; plural=(n != 1);\\n\"\n\"X-Generator: DRFacile strumenti/i18n.php\\n\"\n\n";
    foreach ($s as $x) {
        $out .= '#: ' . implode(' ', array_slice(array_unique($x['refs']), 0, 6)) . "\n";
        if ($x['ctx'] !== null) $out .= 'msgctxt ' . poQuote($x['ctx']) . "\n";
        $out .= 'msgid ' . poQuote($x['msgid']) . "\n";
        if ($x['plural']) $out .= 'msgid_plural ' . poQuote($x['plural']) . "\nmsgstr[0] \"\"\nmsgstr[1] \"\"\n\n";
        else $out .= "msgstr \"\"\n\n";
    }
    file_put_contents($file, $out);
}

/* ---------------- lettura .po e scrittura .mo */
function leggiPo(string $file): array
{
    $voci = []; $cur = null; $campo = null; $testa = '';
    $push = function () use (&$voci, &$cur, &$testa) { if ($cur === null) return; if ($cur['msgid'] === '' && $cur['ctx'] === null) { $testa = $cur['str'][0] ?? ''; } else $voci[] = $cur; $cur = null; };
    foreach (file($file, FILE_IGNORE_NEW_LINES) as $l) {
        $l = trim($l);
        if ($l === '' || $l[0] === '#') { if ($l === '') $push(); continue; }
        if (preg_match('/^(msgctxt|msgid|msgid_plural|msgstr(?:\[(\d+)\])?)\s+"(.*)"$/', $l, $m)) {
            $val = stripcslashes($m[3]);
            if ($m[1] === 'msgctxt') { $push(); $cur = ['ctx' => $val, 'msgid' => '', 'plural' => null, 'str' => []]; $campo = ['ctx']; }
            elseif ($m[1] === 'msgid') { if ($cur === null || isset($cur['msgid_set'])) { $push(); $cur = ['ctx' => null, 'msgid' => '', 'plural' => null, 'str' => []]; } $cur['msgid'] = $val; $cur['msgid_set'] = true; $campo = ['msgid']; }
            elseif ($m[1] === 'msgid_plural') { $cur['plural'] = $val; $campo = ['plural']; }
            else { $i = (int) ($m[2] ?? 0); $cur['str'][$i] = $val; $campo = ['str', $i]; }
        } elseif ($l[0] === '"' && $cur !== null && $campo) {
            $val = stripcslashes(substr($l, 1, -1));
            if ($campo[0] === 'str') $cur['str'][$campo[1]] .= $val; else $cur[$campo[0]] .= $val;
        }
    }
    $push();
    return ['testa' => $testa, 'voci' => $voci];
}
function scriviMo(array $po, string $file): int
{
    $coppie = [['', $po['testa']]];
    foreach ($po['voci'] as $v) {
        $str = implode("\0", array_map(fn($i) => $v['str'][$i] ?? '', array_keys($v['plural'] ? ($v['str'] ?: [0 => '', 1 => '']) : [0 => ''])));
        if (trim(str_replace("\0", '', $str)) === '') continue;   // non tradotta: si salta (gettext torna la sorgente)
        $id = ($v['ctx'] !== null ? $v['ctx'] . "\x04" : '') . $v['msgid'] . ($v['plural'] ? "\0" . $v['plural'] : '');
        $coppie[] = [$id, $str];
    }
    usort($coppie, fn($a, $b) => strcmp($a[0], $b[0]));
    $n = count($coppie); $ids = ''; $strs = ''; $oIds = []; $oStrs = [];
    foreach ($coppie as [$id, $str]) { $oIds[] = [strlen($id), strlen($ids)]; $ids .= $id . "\0"; $oStrs[] = [strlen($str), strlen($strs)]; $strs .= $str . "\0"; }
    $baseIds = 28 + 16 * $n; $baseStrs = $baseIds + strlen($ids);
    $out = pack('V7', 0x950412de, 0, $n, 28, 28 + 8 * $n, 0, 0);
    foreach ($oIds as [$l, $o]) $out .= pack('V2', $l, $baseIds + $o);
    foreach ($oStrs as [$l, $o]) $out .= pack('V2', $l, $baseStrs + $o);
    $out .= $ids . $strs;
    if (!is_dir(dirname($file))) mkdir(dirname($file), 0775, true);
    file_put_contents($file, $out);
    return $n - 1;
}

switch ($cmd) {
    case 'estrai':
        $s = estrai($base, $dominio);
        scriviPot($s, "$locale/$dominio.pot", $dominio);
        echo "$locale/$dominio.pot: " . count($s) . " stringhe\n";
        // aggiorna i .po esistenti: nuove voci aggiunte, traduzioni conservate
        foreach (glob("$locale/*.po") ?: [] as $po) {
            $vecchio = leggiPo($po); $mappa = [];
            foreach ($vecchio['voci'] as $v) $mappa[($v['ctx'] ?? '') . "\x04" . $v['msgid']] = $v['str'];
            $lingua = basename($po, '.po');
            $out = "# Traduzione $lingua di $dominio\nmsgid \"\"\nmsgstr \"\"\n" . ($vecchio['testa'] !== '' ? implode("\n", array_map(fn($r) => poQuote($r . "\n"), explode("\n", trim($vecchio['testa'])))) : "\"Content-Type: text/plain; charset=UTF-8\\n\"\n\"Language: $lingua\\n\"\n\"Plural-Forms: nplurals=2; plural=(n != 1);\\n\"") . "\n\n";
            foreach ($s as $k => $x) {
                $out .= '#: ' . implode(' ', array_slice(array_unique($x['refs']), 0, 6)) . "\n";
                if ($x['ctx'] !== null) $out .= 'msgctxt ' . poQuote($x['ctx']) . "\n";
                $out .= 'msgid ' . poQuote($x['msgid']) . "\n";
                $str = $mappa[$k] ?? [];
                if ($x['plural']) $out .= 'msgid_plural ' . poQuote($x['plural']) . "\nmsgstr[0] " . poQuote($str[0] ?? '') . "\nmsgstr[1] " . poQuote($str[1] ?? '') . "\n\n";
                else $out .= 'msgstr ' . poQuote($str[0] ?? '') . "\n\n";
            }
            file_put_contents($po, $out); echo "  aggiornato $po\n";
        }
        break;
    case 'nuova':
        $lingua = (string) ($arg2 ?? '');
        if (!preg_match('/^[a-z]{2}_[A-Z]{2}$/', $lingua)) exit("Uso: nuova en_US [dominio]\n");
        if (!is_file("$locale/$dominio.pot")) { $s = estrai($base, $dominio); scriviPot($s, "$locale/$dominio.pot", $dominio); }
        if (is_file("$locale/$lingua.po")) exit("$locale/$lingua.po esiste già\n");
        $s = estrai($base, $dominio); scriviPot($s, "$locale/$lingua.po", $dominio, false, $lingua);
        echo "$locale/$lingua.po creato: traducilo (Poedit) e poi: php strumenti/i18n.php compila" . ($dominio !== 'drfacile' ? " $dominio" : '') . "\n";
        break;
    case 'compila':
        $n = 0;
        foreach (glob("$locale/*.po") ?: [] as $po) {
            $lingua = basename($po, '.po');
            $k = scriviMo(leggiPo($po), "$locale/$lingua/LC_MESSAGES/$dominio.mo");
            echo "$lingua: $k stringhe tradotte → $locale/$lingua/LC_MESSAGES/$dominio.mo\n"; $n++;
        }
        if (!$n) echo "Nessun .po in $locale\n";
        // cache JS invalidata: i cataloghi si generano dai .mo alla richiesta
        break;
    default:
        echo "Uso: php strumenti/i18n.php estrai|compila [dominio]  ·  nuova <lingua> [dominio]\n";
}
