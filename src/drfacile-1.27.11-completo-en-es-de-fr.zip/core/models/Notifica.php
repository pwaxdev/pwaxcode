<?php
/**
 * Notifiche di sistema. Ogni modulo può crearne una: Notifica::aggiungi('success', __('Titolo'), __('Testo'), ['modulo' => 'referti', 'opts' => ['select' => 12]])
 * tipo: info | success | warn | error
 */
final class Notifica extends Model
{
    /** Elimina le notifiche il cui link punta a un certo modulo/opzione (es. la "Visita da fatturare" appena evasa) */
    public static function eliminaPerLink(string $modulo, string $chiave, int $valore): void
    {
        Database::run('DELETE FROM notifiche WHERE link LIKE ? AND link LIKE ?', ['%"modulo":"' . $modulo . '"%', '%"' . $chiave . '":' . $valore . '%']);
    }

    protected static string $table = 'notifiche';
    protected static array $fillable = ['tipo', 'titolo', 'testo', 'link', 'letta'];
    protected static array $json = ['link'];

    public const TIPI = ['info', 'success', 'warn', 'error'];

    public static function aggiungi(string $tipo, string $titolo, string $testo = '', ?array $link = null): int
    {
        Capabilities::richiedi('notifiche.crea');
        $tipo = Hooks::filter('notifiche.tipo', $tipo, $titolo, $testo, $link);   // le estensioni possono ridefinire il tipo (icona/colore) di una notifica
        $tipi = Hooks::filter('notifiche.tipi', self::TIPI);   // tipi aggiuntivi delle estensioni (con icona/colore lato client: hook JS notifiche.tipi)
        return self::save(['tipo' => in_array($tipo, $tipi, true) ? $tipo : 'info', 'titolo' => mb_substr($titolo, 0, 160), 'testo' => mb_substr($testo, 0, 400), 'link' => $link ?: [], 'letta' => 0]);
    }

    public static function recenti(int $n = 8): array { return self::all('1=1', [], 'id DESC', $n); }
    public static function nonLette(): int { return self::count('letta = 0'); }
    public static function tutte(int $limit = 500): array { return self::all('1=1', [], 'id DESC', $limit); }

    public static function segna(int $id, bool $letta): void { Database::update('notifiche', ['letta' => (int) $letta], 'id = :id', ['id' => $id]); }
    public static function segnaTutte(): int { return Database::update('notifiche', ['letta' => 1], 'letta = 0'); }
    public static function eliminaLette(): int { return Database::delete('notifiche', 'letta = 1'); }
    public static function eliminaTutte(): int { return Database::delete('notifiche', '1=1'); }
}
