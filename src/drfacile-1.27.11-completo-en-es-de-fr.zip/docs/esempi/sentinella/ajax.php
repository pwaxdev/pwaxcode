<?php
/** Sentinella · endpoint (ajax/ext.php?ext=sentinella) */
return [
    'azioni' => [
        'aperte' => fn() => ['segnalazioni' => Sentinella::aperte(), 'tipi' => Sentinella::TIPI, 'ultima' => Impostazione::get('sentinella_ultima')],
        'scansione' => function () { $n = Sentinella::scansione(); return ['nuove' => $n, 'totale' => array_sum($n), 'messaggio' => array_sum($n) ? array_sum($n) . ' nuove segnalazioni' : 'Nessuna novità: tutto sotto controllo']; },
        'chiudi' => function (array $in) { Database::update(Sentinella::T, ['stato' => 'chiusa', 'chiuso_il' => date('Y-m-d H:i:s')], 'id = :id', ['id' => Api::int($in, 'id')]); return ['ok' => true]; },
        'paziente' => function (array $in) { $p = Paziente::find(Api::int($in, 'id')) ?? throw new ApiException('Paziente non trovato', 404); return ['semafori' => Sentinella::semafori($p), 'aperte' => Database::all('SELECT id, tipo, gravita, titolo FROM ' . Sentinella::T . " WHERE paziente_id = ? AND stato = 'aperta'", [(int) $p['id']])]; },
        'oggi' => function () {
            $eta = Sentinella::eta();
            $app = Database::all("SELECT a.ora, a.tipo, p.id pid, p.nome, p.cognome, p.nascita, p.allergie FROM appuntamenti a JOIN pazienti p ON p.id = a.paziente_id WHERE a.data = ? AND a.stato = 'prenotato' ORDER BY a.ora", [oggi()]);
            $out = [];
            foreach ($app as $a) {
                $e = eta($a['nascita']); $all = json_arr($a['allergie']);
                $note = array_filter([$e !== null && $e >= $eta ? "$e anni" : null, $all ? count($all) . ' allergie' : null]);
                $out[] = ['ora' => substr((string) $a['ora'], 0, 5), 'paziente' => nome_completo($a), 'pid' => (int) $a['pid'], 'note' => array_values($note)];
            }
            return ['oggi' => $out, 'aperte' => (int) Database::value('SELECT COUNT(*) FROM ' . Sentinella::T . " WHERE stato = 'aperta'"), 'gravi' => (int) Database::value('SELECT COUNT(*) FROM ' . Sentinella::T . " WHERE stato = 'aperta' AND gravita >= 2")];
        },
    ],
    'permessi' => ['*' => 'pazienti.leggi', 'chiudi' => 'pazienti.modifica', 'scansione' => 'pazienti.modifica'],
];
