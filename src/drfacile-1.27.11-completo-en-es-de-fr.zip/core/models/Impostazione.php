<?php
final class Impostazione
{
    private static ?array $cache = null;

    public static function tutte(): array
    {
        if (self::$cache === null) {
            self::$cache = [];
            foreach (Database::all('SELECT chiave, valore FROM impostazioni') as $r) self::$cache[$r['chiave']] = $r['valore'];
        }
        return self::$cache;
    }

    /** Svuota la cache (cambio di database: Tenant) */
    public static function reset(): void { self::$cache = null; }

    public static function get(string $k, string $default = ''): string { return self::tutte()[$k] ?? $default; }

    public static function set(string $k, ?string $v): void
    {
        $ext = Capabilities::corrente();
        if ($ext !== null && !str_starts_with($k, $ext . '_')) Capabilities::richiedi('impostazioni.scrivi');   // le proprie chiavi (prefisso codice_) sono libere
        self::tutte();
        if (array_key_exists($k, self::$cache)) Database::update('impostazioni', ['valore' => $v], 'chiave = :k', ['k' => $k]);
        else Database::insert('impostazioni', ['chiave' => $k, 'valore' => $v]);
        self::$cache[$k] = $v;
    }

    /**
     * I PANNELLI delle estensioni in Impostazioni (hook `impostazioni.pannelli`): ognuno è una card con i suoi campi.
     *   Hooks::add('impostazioni.pannelli', function (array $p) {
     *       $p['dieta'] = ['titolo' => 'Piani alimentari', 'fi' => 'salad', 'fa' => 'fa-solid fa-bowl-food',
     *           'html' => '<div class="field"><label>Kcal predefinite</label><input class="input" name="dieta_kcal"></div>',
     *           'chiavi' => ['dieta_kcal'], 'permesso' => 'impostazioni.modifica', 'salva' => 'Salva dieta'];
     *       return $p;
     *   });
     * I campi con name = chiave vengono caricati e salvati dal core come quelli standard (le chiavi vanno dichiarate in 'chiavi').
     */
    public static function pannelli(): array
    {
        $p = class_exists('Hooks') ? (array) Hooks::filter('impostazioni.pannelli', []) : [];
        $out = [];
        foreach ($p as $key => $d) {
            if (!preg_match('/^[a-z0-9_]+$/', (string) $key) || empty($d['html'])) continue;
            if (class_exists('Auth') && array_key_exists('permesso', $d) && $d['permesso'] === null) { /* pannello personale: tutti */ }
            elseif (class_exists('Auth') && !Auth::can($d['permesso'] ?? 'impostazioni.leggi')) continue;
            $out[$key] = ['key' => $key, 'titolo' => (string) ($d['titolo'] ?? $key), 'fi' => (string) ($d['fi'] ?? 'puzzle-piece'), 'fa' => (string) ($d['fa'] ?? 'fa-solid fa-puzzle-piece'),
                'html' => (string) $d['html'], 'chiavi' => array_values(array_filter((array) ($d['chiavi'] ?? []), 'is_string')), 'salva' => (string) ($d['salva'] ?? 'Salva')];
        }
        return $out;
    }

    /** Le chiavi che le estensioni possono salvare via ajax/impostazioni.php: quelle dei pannelli + hook `impostazioni.chiavi` */
    public static function chiaviEstensioni(): array
    {
        $k = [];
        foreach (self::pannelli() as $p) $k = array_merge($k, $p['chiavi']);
        if (class_exists('Hooks')) $k = (array) Hooks::filter('impostazioni.chiavi', $k);
        return array_values(array_unique(array_filter($k, 'is_string')));
    }

    /** Dati del medico e dello studio, usati da intestazioni e documenti */
    public static function profilo(): array
    {
        $s = self::tutte();
        $nome = $s['profilo_nome'] ?? 'Medico';
        return [
            'titolo' => $s['profilo_titolo'] ?? '', 'nome' => $nome, 'nome_completo' => trim(($s['profilo_titolo'] ?? '') . ' ' . $nome), 'iniziali' => iniziali($nome),
            'sesso' => ($s['profilo_sesso'] ?? 'F') === 'M' ? 'M' : 'F',
            'specializzazione' => $s['profilo_specializzazione'] ?? '', 'email' => $s['profilo_email'] ?? '', 'telefono' => $s['profilo_telefono'] ?? '',
            'studio' => $s['studio_nome'] ?? '', 'indirizzo' => $s['studio_indirizzo'] ?? '', 'piva' => $s['studio_piva'] ?? '', 'ordine' => $s['studio_ordine'] ?? '',
            'riga_documenti' => $s['studio_riga_documenti'] ?? '',
        ];
    }
}
