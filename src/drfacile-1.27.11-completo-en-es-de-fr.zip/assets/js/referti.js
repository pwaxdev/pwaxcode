/* Modulo Referti: elenco per stato, anteprima del documento, firma, invio, modifica bozza, stampa */
DRF.register('referti', (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;
  const st = { filtro: 'tutti', sel: null, list: [], bozze: 0, totale: 0 };
  const STATO = { bozza: 'amber', firmato: 'mint', inviato: 'sky' };

  function load() {
    return DRF.api.get('referti', 'list', { stato: st.filtro }).then(d => {
      st.list = d.referti; st.bozze = d.bozze; st.totale = d.totale;
      if (!st.list.find(r => +r.id === st.sel)) st.sel = st.list[0] ? +st.list[0].id : null;
      renderList(); loadDoc(); DRF.nav.refreshSub(); DRF.postit.refresh();
    });
  }
  function renderList() {
    $('#rlist').html(st.list.map(r => `<div class="rrow ${+r.id === st.sel ? 'on' : ''}" data-id="${r.id}"><span class="ib">${I('document', 'fa-regular fa-file-lines')}</span><div><b>${DRF.esc(r.paziente)}</b><span>${DRF.esc(r.tipo)} · ${U.fmtIso(r.data)}</span></div>${DRF.ui.badge(STATO[r.stato], r.stato_label)}</div>`).join('') || DRF.ui.empty(DRF.__('Nessun referto in questa categoria.')));
    DRF.icons.apply($('#rlist')[0]);
  }
  function loadDoc() {
    if (!st.sel) { $('#doc').html(DRF.ui.empty(DRF.__('Seleziona un referto per vederne l\'anteprima.'))); $('#docActions').html(''); return; }
    DRF.api.get('referti', 'get', { id: st.sel }).then(d => renderDoc(d.referto, d.paziente, d.medico));
  }
  function renderDoc(r, p, m) {
    const bozza = r.stato === 'bozza';
    $('#docActions').html(`${bozza ? `<button class="btn primary" id="rSign">${I('document-signed', 'fa-solid fa-file-signature')}<span>${DRF.__('Firma digitalmente')}</span></button>` : ''}${!bozza ? `<button class="btn ${r.stato === 'inviato' ? 'ghost' : 'primary'}" id="rSend" title="${r.stato === 'inviato' ? DRF.__('Già inviato il ') + U.fmtDateTime(r.inviato_il) + ': ' + DRF.__('invia di nuovo o a un altro indirizzo') : DRF.__('Invia via email (l\'indirizzo si può cambiare)')}">${I('paper-plane', 'fa-regular fa-paper-plane')}<span>${r.stato === 'inviato' ? DRF.__('Invia di nuovo') : DRF.__('Invia via email')}</span></button>` : ''}
      <button class="btn ghost" type="button" data-doc="referto" data-id="${r.id}">${I('download', 'fa-solid fa-download')}<span>PDF</span></button><button class="btn ghost" type="button" data-doc="referto" data-id="${r.id}" data-opts="html,stampa">${I('print', 'fa-solid fa-print')}<span>${DRF.__('Stampa')}</span></a>
      ${bozza ? `<button class="btn ghost" id="rEdit">${I('pencil', 'fa-solid fa-pen')}<span>${DRF.__('Modifica')}</span></button><button class="btn ghost" id="rDel" style="margin-left:auto;color:var(--red-ink)" title="${DRF.__('Elimina bozza')}">${I('trash', 'fa-solid fa-trash')}</button>` : ''}`);
    $('#doc').html(`<div class="paper" id="paper"><header><div><b style="font-size:15px">${DRF.esc(m.nome_completo)}</b><div class="muted small">${DRF.esc(m.specializzazione)} · ${DRF.esc(m.studio)}<br>${DRF.esc(m.indirizzo)} · ${DRF.esc(m.telefono)}</div></div><div style="text-align:right" class="small"><b>${DRF.esc(r.tipo)}</b><br><span class="muted">${U.fmtIso(r.data)}</span></div></header>
      <h2>${DRF.esc(p.nome_completo)}</h2><div class="muted small">${p.eta != null ? DRF._n('%d anno', '%d anni', p.eta) + ' · ' : ''}CF <span class="mono">${DRF.esc(p.cf || '')}</span></div>
      ${Object.entries(r.sezioni).map(([k, v]) => String(v).includes('<') ? `<h4>${DRF.esc(k)}</h4><div class="rich-out" data-sez="${DRF.esc(k)}" data-rich="1">${v}</div>` : `<h4>${DRF.esc(k)}</h4><p data-sez="${DRF.esc(k)}">${DRF.esc(v)}</p>`).join('')}
      <div class="sig"><div>${bozza ? DRF.ui.badge('amber', DRF.__('Bozza, non ancora firmato')) : `<b>${DRF.esc(m.nome)}</b>${DRF.__('Firmato digitalmente il')} ${U.fmtDateTime(r.firmato_il || r.data)}`}</div></div></div>`);
    DRF.icons.apply($('#docActions')[0]);
    // slot per le estensioni: pulsanti (ctx.azione) e contenuti nel referto aperto (ctx.$paper)
    DRF.hooks.run('referto.editor', { $root: $('#doc'), $paper: $('#paper'), $azioni: $('#docActions'), referto: r, paziente: p, medico: m, bozza,
      azione: (label, run, opz) => { const $btn = $(`<button class="btn ghost" type="button">${DRF.icons.html((opz || {}).fi || 'puzzle-piece', (opz || {}).fa || 'fa-solid fa-puzzle-piece')}<span>${DRF.esc(label)}</span></button>`).on('click', run); $('#docActions').append($btn); DRF.icons.apply($btn[0]); return $btn; } });
    $('#rSign').on('click', () => DRF.api.post('referti', 'firma', { id: r.id }).then(d => { DRF.ui.toast(d.messaggio); DRF.app.aggiornaBadge(); load(); }));
    $('#rSend').on('click', () => DRF.doc.invia({ tipo: 'referto', id: r.id, email: p.email || '' }).then(x => { if (x) load(); }));   // finestra: indirizzo modificabile, modello, testo; anche i reinvii
    $('#rDel').on('click', () => DRF.ui.confirm(DRF.__('Eliminare la bozza?'), DRF.__('Il referto verrà rimosso definitivamente.'), DRF.__('Elimina')).then(ok => { if (ok) DRF.api.post('referti', 'delete', { id: r.id }).then(d => { DRF.ui.toast(d.messaggio); st.sel = null; DRF.app.aggiornaBadge(); load(); }); }));
    $('#rEdit').on('click', () => {
      $('#paper [data-sez]').each(function () {
        const rich = this.dataset.rich === '1';
        $(this).replaceWith(rich ? `<textarea class="rich" data-sez="${DRF.esc(this.dataset.sez)}" data-height="120" hidden>${DRF.esc($(this).html())}</textarea>` : `<textarea class="textarea" data-sez="${DRF.esc(this.dataset.sez)}">${DRF.esc($(this).text())}</textarea>`);
      });
      DRF.ui.wire($('#paper')[0]);
      $('#docActions').html(`<button class="btn primary" id="rSave">${I('check', 'fa-solid fa-check')}<span>${DRF.__('Salva modifiche')}</span></button><button class="btn ghost" id="rCancel">${DRF.__('Annulla')}</button>`);
      DRF.icons.apply($('#docActions')[0]);
      $('#rCancel').on('click', loadDoc);
      $('#rSave').on('click', () => { const sez = {}; $('#paper textarea[data-sez]').each(function () { sez[this.dataset.sez] = this.value; }); DRF.api.post('referti', 'salva', { id: r.id, sezioni: sez }).then(d => { DRF.ui.toast(d.messaggio); loadDoc(); }); });
    });
  }

  return {
    title: DRF.__('Referti'),
    record() { return st.sel ? { sezione: 'referto', record: st.sel } : null; },
    sub() { return `${DRF._n('%d bozza', '%d bozze', st.bozze)} ${DRF.__('da firmare ·')} ${DRF._n('%d referto', '%d referti', st.totale)} ${DRF.__('in archivio')}`; },
    action: null,
    init() {
      $('#refFilter').on('click', 'button', function () { st.filtro = this.dataset.f; load(); });
      $('#rlist').on('click', '.rrow', function () { st.sel = +this.dataset.id; $('#rlist .rrow').removeClass('on'); $(this).addClass('on'); loadDoc(); DRF.postit.refresh(); });
    },
    show(opts) { if (opts && opts.select) { st.sel = +opts.select; st.filtro = 'tutti'; $('#refFilter button').removeClass('on').first().addClass('on'); } load(); }
  };
})(jQuery));
