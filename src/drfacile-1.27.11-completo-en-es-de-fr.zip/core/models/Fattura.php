<?php
final class Fattura extends Model
{
    protected static string $table = 'fatture';
    protected static array $fillable = ['numero', 'anno', 'progressivo', 'data', 'paziente_id', 'visita_id', 'prestazione', 'righe', 'importo', 'iva', 'contributi', 'contributi_desc', 'opposizione', 'bollo', 'totale', 'metodo', 'stato', 'scadenza', 'pagata_il', 'note'];
    protected static array $json = ['righe'];

    public const STATI = ['pagata' => 'Pagata', 'attesa' => 'In attesa', 'scaduta' => 'Scaduta'];

    public static function lista(string $stato = 'tutte', int $limit = 5000): array
    {
        self::aggiornaScadute();
        $where = isset(self::STATI[$stato]) ? 'f.stato = ?' : '1=1';
        $U = Database::comune('utenti');
        $rows = Database::all("SELECT f.*, p.nome, p.cognome, v.utente_id, u.nome unome, u.cognome ucognome, u.sesso usesso FROM fatture f JOIN pazienti p ON p.id = f.paziente_id LEFT JOIN visite v ON v.id = f.visita_id LEFT JOIN $U u ON u.id = v.utente_id WHERE $where ORDER BY f.data DESC, f.progressivo DESC LIMIT $limit", $where === '1=1' ? [] : [$stato]);
        return array_map(function ($r) {
            $r['paziente'] = nome_completo($r); $r['stato_label'] = self::STATI[$r['stato']] ?? $r['stato'];
            $r['visitata_da'] = $r['visita_id'] ? Visita::professionista($r) : '';   // il professionista della visita fatturata (multiutente)
            unset($r['nome'], $r['cognome'], $r['unome'], $r['ucognome'], $r['usesso'], $r['utente_id']);
            return $r;
        }, $rows);
    }

    /** Le fatture in attesa oltre la scadenza diventano "scadute" */
    public static function aggiornaScadute(): void
    {
        $nuove = Database::all("SELECT f.id, f.numero, f.totale, p.nome, p.cognome FROM fatture f JOIN pazienti p ON p.id = f.paziente_id WHERE f.stato = 'attesa' AND f.scadenza IS NOT NULL AND f.scadenza < ?", [oggi()]);
        if (!$nuove) return;
        Database::run("UPDATE fatture SET stato = 'scaduta' WHERE stato = 'attesa' AND scadenza IS NOT NULL AND scadenza < ?", [oggi()]);
        foreach ($nuove as $f) Notifica::aggiungi('error', "Fattura {$f['numero']} scaduta", nome_completo($f) . ' · ' . euro($f['totale']) . ' non incassati', ['modulo' => 'fatture', 'opts' => ['select' => (int) $f['id']]]);
    }

    public static function kpi(): array
    {
        $m = date('Y-m'); $mPrec = date('Y-m', strtotime('first day of last month'));
        $inc = (float) Database::value("SELECT COALESCE(SUM(totale),0) FROM fatture WHERE stato = 'pagata' AND substr(data,1,7) = ?", [$m]);
        $incPrec = (float) Database::value("SELECT COALESCE(SUM(totale),0) FROM fatture WHERE stato = 'pagata' AND substr(data,1,7) = ?", [$mPrec]);
        $aperte = Database::one("SELECT COUNT(*) n, COALESCE(SUM(totale),0) t, SUM(CASE WHEN stato='scaduta' THEN 1 ELSE 0 END) s FROM fatture WHERE stato <> 'pagata'");
        return [
            'incassato_mese' => $inc, 'variazione' => $incPrec > 0 ? round(($inc - $incPrec) / $incPrec * 100) : null,
            'da_incassare' => (float) $aperte['t'], 'aperte' => (int) $aperte['n'], 'scadute' => (int) $aperte['s'],
            'emesse_mese' => self::count('substr(data,1,7) = ?', [$m]),
            'ultimo_numero' => Database::value('SELECT numero FROM fatture ORDER BY anno DESC, progressivo DESC LIMIT 1'),
        ];
    }

    /** Metodi di pagamento attivi con giorni di incasso e predefinito (per l'editor) */
    public static function metodi(): array
    {
        $rows = Database::all('SELECT nome, giorni, predefinito FROM metodi_pagamento WHERE attivo = 1 ORDER BY predefinito DESC, id');
        if (!$rows) $rows = [['nome' => 'Contanti', 'giorni' => 0, 'predefinito' => 1]];
        return array_map(fn($r) => ['nome' => $r['nome'], 'giorni' => (int) $r['giorni'], 'predefinito' => (int) $r['predefinito']], $rows);
    }

    /** [nome => etichetta] per le form generiche (retrocompatibilità) */
    public static function metodiMap(): array
    {
        $m = [];
        foreach (self::metodi() as $r) $m[$r['nome']] = $r['nome'] . ($r['giorni'] > 0 ? " · incasso {$r['giorni']} gg" : '');
        return $m;
    }

    /** Giorni di incasso del metodo (0 = incasso immediato); 'attesa' resta per compatibilità */
    private static function giorniMetodo(string $metodo): int
    {
        if ($metodo === 'attesa') return 30;
        $g = Database::value('SELECT giorni FROM metodi_pagamento WHERE nome = ?', [$metodo]);
        return (int) ($g ?? 0);
    }

    /** Numero secondo il formato in Impostazioni: {n} progressivo, {nnn} a tre cifre, {aaaa} anno, {aa} anno breve */
    public static function formatta(int $progressivo, int $anno): string
    {
        $fmt = trim(Impostazione::get('fattura_formato', '')) ?: '{aaaa}/{nnn}';
        if (!str_contains($fmt, '{n}') && !str_contains($fmt, '{nnn}')) $fmt = '{aaaa}/{nnn}';
        $n = strtr($fmt, ['{nnn}' => sprintf('%03d', $progressivo), '{n}' => (string) $progressivo, '{aaaa}' => (string) $anno, '{aa}' => substr((string) $anno, -2)]);
        return mb_substr($n, 0, 20);
    }

    public static function prossimoNumero(): array
    {
        $anno = (int) date('Y');
        $prog = (int) Database::value('SELECT COALESCE(MAX(progressivo),0) FROM fatture WHERE anno = ?', [$anno]) + 1;
        $forzato = (int) numero(Impostazione::get('fattura_prossimo', '0'));
        if ($forzato > $prog) $prog = $forzato;
        return ['anno' => $anno, 'progressivo' => $prog, 'numero' => self::formatta($prog, $anno)];
    }

    /** Sanifica le righe in ingresso: prestazioni/righe libere (quantità × prezzo, aliquota IVA) e righe descrittive */
    public static function righe(array $in): array
    {
        $iva = Iva::mappa();
        $out = [];
        foreach ((array) ($in['righe'] ?? []) as $r) {
            if (!is_array($r)) continue;
            $desc = trim((string) ($r['descrizione'] ?? ''));
            if ($desc === '') continue;
            if (($r['tipo'] ?? '') === 'descrizione') { $out[] = ['tipo' => 'descrizione', 'descrizione' => mb_substr($desc, 0, 300)]; continue; }
            $q = max(0.0, is_numeric($r['quantita'] ?? null) ? (float) $r['quantita'] : numero((string) ($r['quantita'] ?? '1')));
            $prezzo = is_numeric($r['prezzo'] ?? null) ? (float) $r['prezzo'] : numero((string) ($r['prezzo'] ?? '0'));
            $ivaId = (int) ($r['iva_id'] ?? 0);
            $ali = isset($iva[$ivaId]) ? (float) $iva[$ivaId]['aliquota'] : 0.0;
            $out[] = ['tipo' => 'riga', 'descrizione' => mb_substr($desc, 0, 300), 'quantita' => $q ?: 1, 'prezzo' => round($prezzo, 2), 'iva_id' => $ivaId ?: null, 'aliquota' => $ali, 'importo' => round(($q ?: 1) * $prezzo, 2)];
        }
        return $out;
    }

    /** Totali a partire dalle righe: imponibile, contributo (percentuale della cassa), IVA per aliquota, bollo sulla parte esente */
    public static function totali(array $righe, bool $contributi): array
    {
        $imp = 0.0; $perAliquota = [];
        foreach ($righe as $r) {
            if ($r['tipo'] !== 'riga') continue;
            $imp += $r['importo'];
            $perAliquota[(string) $r['aliquota']] = ($perAliquota[(string) $r['aliquota']] ?? 0) + $r['importo'];
        }
        $perc = $contributi ? (float) numero((string) Impostazione::get('fattura_contributi_perc', '0')) : 0.0;
        $contr = $perc > 0 ? round($imp * $perc / 100, 2) : 0.0;
        $ivaTot = 0.0; $dettaglio = [];
        foreach ($perAliquota as $ali => $base) {
            $v = round($base * (float) $ali / 100, 2);
            $ivaTot += $v;
            $dettaglio[] = ['aliquota' => (float) $ali, 'imponibile' => round($base, 2), 'iva' => $v];
        }
        // il contributo integrativo segue il regime delle prestazioni sanitarie (esente): concorre alla base del bollo
        $esente = ($perAliquota['0'] ?? 0) + $contr;
        $bollo = $esente > (float) Config::get('fattura.bollo_soglia') ? (float) Config::get('fattura.bollo_importo') : 0;
        return ['imponibile' => round($imp, 2), 'contributi' => $contr, 'contributi_perc' => $perc, 'iva' => round($ivaTot, 2), 'dettaglio_iva' => $dettaglio, 'bollo' => $bollo, 'totale' => round($imp + $contr + $ivaTot + $bollo, 2)];
    }

    public static function emetti(array $in): array
    {
        $in = Hooks::filter('fattura.emetti', $in);   // righe, note, metodo… prima dell'emissione (ApiException per rifiutare)
        Api::require($in, ['paziente_id'], ['paziente_id' => 'Paziente']);
        if (!Paziente::find((int) $in['paziente_id'])) throw new ApiException(__('Paziente non trovato'));
        if (!empty($in['visita_id'])) {
            $gia = Database::one('SELECT numero FROM fatture WHERE visita_id = ?', [(int) $in['visita_id']]);
            if ($gia) throw new ApiException("Questa visita è già stata fatturata (fattura {$gia['numero']}): modificala dal tasto destro invece di emetterne una nuova");
        }
        // retrocompatibilità: la vecchia form inviava una sola prestazione con importo
        if (empty($in['righe']) && !empty($in['prestazione'])) $in['righe'] = [['tipo' => 'riga', 'descrizione' => $in['prestazione'], 'quantita' => 1, 'prezzo' => Api::float($in, 'importo')]];
        $righe = self::righe($in);
        if (!array_filter($righe, fn($r) => $r['tipo'] === 'riga')) throw new ApiException(__('Aggiungi almeno una prestazione alla fattura'));
        $t = self::totali($righe, !empty($in['contributi']));
        if ($t['totale'] <= 0) throw new ApiException(__('Il totale della fattura deve essere maggiore di zero'));
        $metodo = trim((string) ($in['metodo'] ?? 'Contanti'));
        $giorni = self::giorniMetodo($metodo);
        $attesa = $giorni > 0;
        $descr = array_column(array_values(array_filter($righe, fn($r) => $r['tipo'] === 'riga')), 'descrizione');
        $n = self::prossimoNumero();
        $data = $in['data'] ?? oggi();
        $id = self::save($n + ['data' => $data, 'paziente_id' => (int) $in['paziente_id'], 'visita_id' => Api::int($in, 'visita_id') ?: null,
            'prestazione' => mb_substr($descr[0] . (count($descr) > 1 ? ' +' . (count($descr) - 1) : ''), 0, 200), 'righe' => $righe,
            'importo' => $t['imponibile'], 'iva' => $t['iva'], 'contributi' => $t['contributi'], 'contributi_desc' => $t['contributi'] > 0 ? (trim((string) Impostazione::get('fattura_contributi_desc', '')) ?: 'Contributo previdenziale ' . rtrim(rtrim(number_format($t['contributi_perc'], 2, ',', ''), '0'), ',') . '%') : null,
            'bollo' => $t['bollo'], 'totale' => $t['totale'], 'opposizione' => (int) !empty($in['opposizione']),
            'metodo' => $metodo === 'attesa' ? null : $metodo, 'stato' => $attesa ? 'attesa' : 'pagata', 'scadenza' => date('Y-m-d', strtotime($data . ' +' . ($giorni > 0 ? $giorni : 30) . ' days')), 'pagata_il' => $attesa ? null : oggi(), 'note' => trim((string) ($in['note'] ?? '')) ?: null]);
        Documenti::archivia('fattura', $id);
        if (!empty($in['visita_id'])) Notifica::eliminaPerLink('fatture', 'da_visita', (int) $in['visita_id']);
        if ($attesa) Scadenzario::aggiungi('pagamento', date('Y-m-d', strtotime($data . ' +' . ($giorni > 0 ? $giorni : 30) . ' days')), 'Pagamento in scadenza: fattura ' . $n['numero'], nome_completo(Paziente::find((int) $in['paziente_id']) ?? []) . ' · ' . euro($t['totale']) . ($metodo !== 'attesa' ? ' · ' . $metodo : ''), ['modulo' => 'fatture', 'opts' => ['select' => $id]], 'fatture', $id);
        Attivita::registra('fattura.emessa', 'fatture', $id, $n['numero'] . ' · ' . nome_completo(Paziente::find((int) $in['paziente_id']) ?? []) . ' · ' . euro($t['totale']));
        Hooks::run('fattura.emessa', $id, self::find($id));   // evento: fatturazione elettronica, contabilità esterna…
        return self::find($id);
    }

    public static function incassa(int $id, string $metodo = ''): array
    {
        $f = self::find($id); if (!$f) throw new ApiException(__('Fattura non trovata'));
        $metodo = $metodo ?: (($f['metodo'] && $f['metodo'] !== 'Da incassare') ? $f['metodo'] : 'Contanti');
        self::save(['id' => $id, 'stato' => 'pagata', 'pagata_il' => oggi(), 'metodo' => $metodo]);
        Scadenzario::chiudi('fatture', $id, 'pagamento');
        Attivita::registra('fattura.incassata', 'fatture', $id, $f['numero'] . ' · ' . euro($f['totale']));
        Hooks::run('fattura.incassata', $id, self::find($id));
        return self::find($id);
    }

    /** Modifica una fattura non ancora stampata: numero invariato, righe e totali ricalcolati, documento riarchiviato */
    public static function modifica(int $id, array $in): array
    {
        $f = self::find($id); if (!$f) throw new ApiException(__('Fattura non trovata'), 404);
        if ($f['stampata_il']) throw new ApiException(__('La fattura è già stata stampata e non può essere modificata'));
        Api::require($in, ['paziente_id'], ['paziente_id' => 'Paziente']);
        if (!Paziente::find((int) $in['paziente_id'])) throw new ApiException(__('Paziente non trovato'));
        $righe = self::righe($in);
        if (!array_filter($righe, fn($r) => $r['tipo'] === 'riga')) throw new ApiException(__('Aggiungi almeno una prestazione alla fattura'));
        $t = self::totali($righe, !empty($in['contributi']));
        if ($t['totale'] <= 0) throw new ApiException(__('Il totale della fattura deve essere maggiore di zero'));
        $metodo = trim((string) ($in['metodo'] ?? ($f['metodo'] ?: 'Contanti')));
        $giorni = self::giorniMetodo($metodo);
        $attesa = $giorni > 0;
        $descr = array_column(array_values(array_filter($righe, fn($r) => $r['tipo'] === 'riga')), 'descrizione');
        $data = $in['data'] ?? $f['data'];
        self::save(['id' => $id, 'data' => $data, 'paziente_id' => (int) $in['paziente_id'],
            'prestazione' => mb_substr($descr[0] . (count($descr) > 1 ? ' +' . (count($descr) - 1) : ''), 0, 200), 'righe' => $righe,
            'importo' => $t['imponibile'], 'iva' => $t['iva'], 'contributi' => $t['contributi'], 'contributi_desc' => $t['contributi'] > 0 ? (trim((string) Impostazione::get('fattura_contributi_desc', '')) ?: 'Contributo previdenziale ' . rtrim(rtrim(number_format($t['contributi_perc'], 2, ',', ''), '0'), ',') . '%') : null,
            'bollo' => $t['bollo'], 'totale' => $t['totale'], 'opposizione' => (int) !empty($in['opposizione']),
            'metodo' => $metodo === 'attesa' ? null : $metodo, 'stato' => $attesa ? 'attesa' : 'pagata', 'scadenza' => date('Y-m-d', strtotime($data . ' +' . ($giorni > 0 ? $giorni : 30) . ' days')), 'pagata_il' => $attesa ? null : ($f['pagata_il'] ?: oggi()),
            'note' => trim((string) ($in['note'] ?? '')) ?: null]);
        self::eliminaArchiviati($id);
        Documenti::archivia('fattura', $id);
        if ($attesa) Scadenzario::aggiungi('pagamento', date('Y-m-d', strtotime($data . ' +' . ($giorni > 0 ? $giorni : 30) . ' days')), 'Pagamento in scadenza: fattura ' . $f['numero'], nome_completo(Paziente::find((int) $in['paziente_id']) ?? []) . ' · ' . euro($t['totale']), ['modulo' => 'fatture', 'opts' => ['select' => $id]], 'fatture', $id);
        else Scadenzario::chiudi('fatture', $id, 'pagamento');
        Attivita::registra('fattura.modificata', 'fatture', $id, $f['numero'] . ' · ' . nome_completo(Paziente::find((int) $in['paziente_id']) ?? []) . ' · ' . euro($t['totale']));
        return self::find($id);
    }

    /** Elimina una fattura non ancora stampata (con la copia archiviata). Se era collegata a una visita, la visita torna tra quelle da fatturare. */
    public static function elimina(int $id): array
    {
        $f = self::find($id); if (!$f) throw new ApiException(__('Fattura non trovata'), 404);
        if ($f['stampata_il']) throw new ApiException(__('La fattura è già stata stampata e non può essere eliminata'));
        self::eliminaArchiviati($id);
        self::delete($id);
        Scadenzario::chiudi('fatture', $id);
        Attivita::registra('fattura.eliminata', 'fatture', $id, $f['numero'] . ' · ' . euro($f['totale']));
        return $f;
    }

    /** Rimuove le copie HTML archiviate della fattura */
    private static function eliminaArchiviati(int $id): void
    {
        foreach (glob(Spazio::base() . '/fattura/*/' . sprintf('fattura-%05d-', $id) . '*.*') ?: [] as $file) @unlink($file);
    }

    /** Prima stampa: da qui in poi la fattura non è più modificabile né eliminabile */
    public static function segnaStampata(int $id): void
    {
        Database::run('UPDATE fatture SET stampata_il = ? WHERE id = ? AND stampata_il IS NULL', [date('Y-m-d H:i:s'), $id]);
    }
}
