<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'list'        => fn(array $in) => ['fatture' => Fattura::lista(Api::str($in, 'stato', 'tutte')), 'kpi' => Fattura::kpi(), 'prossimo' => Fattura::prossimoNumero()],
    'prestazioni' => fn() => Prestazione::attive(),
    // tutto ciò che serve all'editor: pazienti, listino con IVA, aliquote, metodi, impostazioni di fatturazione, prossimo numero
    'editor'      => function (array $in) {
        $visita = Api::int($in, 'visita') ? Visita::find(Api::int($in, 'visita')) : null;
        $gia = $visita ? Database::one('SELECT id, numero FROM fatture WHERE visita_id = ?', [(int) $visita['id']]) : null;
        return [
            'pazienti' => Paziente::options(), 'listino' => Prestazione::listino(), 'iva' => Iva::attive(), 'iva_predefinita' => Iva::predefinita()['id'] ?? null,
            'metodi' => Fattura::metodi(), 'prossimo' => Fattura::prossimoNumero(),
            'bollo' => ['soglia' => (float) Config::get('fattura.bollo_soglia'), 'importo' => (float) Config::get('fattura.bollo_importo')],
            'spese' => ['attive' => Impostazione::get('fattura_spese_attive') === '1', 'importo' => numero(Impostazione::get('fattura_spese_importo', '0')), 'descrizione' => Impostazione::get('fattura_spese_desc', 'Spese di studio') ?: 'Spese di studio'],
            'contributi' => ['perc' => numero(Impostazione::get('fattura_contributi_perc', '0')), 'descrizione' => Impostazione::get('fattura_contributi_desc', '')],
            'visita' => $visita && !$gia ? ['id' => (int) $visita['id'], 'data' => $visita['data'], 'paziente_id' => (int) $visita['paziente_id'], 'prestazioni' => $visita['prestazioni'] ?: []] : null,
            'gia_fatturata' => $gia ? ['id' => (int) $gia['id'], 'numero' => $gia['numero']] : null,
        ];
    },
    // visite chiuse con prestazioni non ancora fatturate: la fattura si compila da qui
    'da_visita'   => fn() => ['visite' => Visita::daFatturare()],
    'save'        => function (array $in) { $f = Fattura::emetti($in); return ['fattura' => $f, 'messaggio' => "Fattura {$f['numero']} emessa"]; },
    'modifica'    => function (array $in) { $f = Fattura::modifica(Api::int($in, 'id'), $in); return ['fattura' => $f, 'messaggio' => "Fattura {$f['numero']} aggiornata"]; },
    'elimina'     => function (array $in) { $f = Fattura::elimina(Api::int($in, 'id')); return ['messaggio' => "Fattura {$f['numero']} eliminata" . ($f['visita_id'] ? ' · la visita è tornata tra quelle da fatturare' : '')]; },
    'paga'        => function (array $in) { $f = Fattura::incassa(Api::int($in, 'id'), Api::str($in, 'metodo', 'Contanti')); return ['fattura' => $f, 'messaggio' => "Fattura {$f['numero']} incassata"]; },
    'get'         => fn(array $in) => Fattura::find(Api::int($in, 'id')) ?? throw new ApiException(__('Fattura non trovata'), 404),
], ['*' => 'fatture.leggi', 'save' => 'fatture.emetti', 'modifica' => 'fatture.modifica', 'elimina' => 'fatture.modifica', 'paga' => 'fatture.incassa']);
