<?php
final class Ricetta extends Model
{
    protected static string $table = 'ricette';
    protected static array $fillable = ['paziente_id', 'data', 'tipo', 'esenzione', 'note', 'righe', 'nre', 'stato'];
    protected static array $json = ['righe'];

    public static function generaNre(): string
    {
        return Config::get('ricetta.prefisso_nre', '050A') . ' ' . implode(' ', [random_int(1000, 9999), random_int(1000, 9999), random_int(1000, 9999)]);
    }

    public static function recenti(int $n = 8): array
    {
        $rows = Database::all('SELECT r.*, p.nome, p.cognome FROM ricette r JOIN pazienti p ON p.id = r.paziente_id ORDER BY r.data DESC, r.id DESC LIMIT ' . $n);
        return array_map(function ($r) { $r = self::decode($r); $r['paziente'] = nome_completo($r); unset($r['nome'], $r['cognome']); return $r; }, $rows);
    }

    /** Crea la ricetta: qui si innesta l'invio reale al Sistema TS (DEMA). */
    public static function emetti(array $in): array
    {
        Api::require($in, ['paziente_id'], ['paziente_id' => 'Paziente']);
        $righe = [];
        foreach ((array) ($in['righe'] ?? []) as $r) {
            $f = isset($r['farmaco_id']) ? Farmaco::find((int) $r['farmaco_id']) : null;
            $nome = $f['nome'] ?? trim((string) ($r['farmaco'] ?? ''));
            if ($nome === '') continue;
            $righe[] = ['farmaco' => $nome, 'principio' => $f['principio'] ?? ($r['principio'] ?? ''), 'quantita' => max(1, min(3, (int) ($r['quantita'] ?? 1))), 'posologia' => $r['posologia'] ?? ($f['posologia'] ?? '')];
        }
        if (!$righe) throw new ApiException(__('Aggiungi almeno un farmaco'));
        if (!Paziente::find((int) $in['paziente_id'])) throw new ApiException(__('Paziente non trovato'));
        $id = self::save(['paziente_id' => (int) $in['paziente_id'], 'data' => oggi(), 'tipo' => ($in['tipo'] ?? 'bianca') === 'ssn' ? 'ssn' : 'bianca', 'esenzione' => trim((string) ($in['esenzione'] ?? '')) ?: null, 'note' => trim((string) ($in['note'] ?? '')) ?: null, 'righe' => $righe, 'nre' => self::generaNre(), 'stato' => 'inviata']);
        Storico::aggiungi((int) $in['paziente_id'], oggi(), 'Ricetta', implode(', ', array_column($righe, 'farmaco')), 'ricette', $id);
        Documenti::archivia('ricetta', $id);
        $r = self::find($id); $p = Paziente::find((int) $in['paziente_id']);
        Hooks::run('ricetta.emessa', $id, $r);   // evento: invio al Sistema TS (DEMA) da un'estensione
        Attivita::registra('ricetta.inviata', 'ricette', $id, $p['nome_completo'] . ' · NRE ' . $r['nre']);
        Notifica::aggiungi('success', 'Ricetta inviata al Sistema TS', $p['nome_completo'] . ' · NRE ' . $r['nre'], ['modulo' => 'ricette']);
        return $r;
    }
}
