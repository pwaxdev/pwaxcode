<?php
/**
 * ESTENSIONE DI ESEMPIO "Consigli di fine visita" (codice: consigli) — v1.0
 * Mostra le tre cose che un'estensione completa fa senza toccare il core:
 *   1. un PANNELLO in Impostazioni (hook impostazioni.pannelli): testo predefinito, frasi rapide, un interruttore;
 *   2. una CARD in visita (js/consigli.js, hook visita.pannello) che salva i consigli nei dati della visita (dati.consigli);
 *   3. una SEZIONE nel referto (hook referto.sezioni) alla chiusura.
 * Endpoint proprio: estensioni/consigli/ajax.php (via ajax/ext.php) (legge le impostazioni per la card in visita).
 */

// 1) Pannello in Impostazioni: i campi con name = chiave vengono riempiti e salvati dal core
Hooks::add('impostazioni.pannelli', function (array $p) {
    $p['consigli'] = [
        'titolo' => __('Consigli di fine visita', 'consigli'), 'fi' => 'comment-heart', 'fa' => 'fa-regular fa-comment-dots',
        'html' => '<p class="small muted" style="margin-bottom:10px">Il testo che il medico trova già pronto nella card "Consigli" della visita, e le frasi rapide da aggiungere con un click. Ogni studio ha i suoi.</p>
            <div class="field"><label>Testo predefinito</label><textarea class="input" name="consigli_testo" rows="2" placeholder="Es. Si consiglia riposo e idratazione adeguata."></textarea></div>
            <div class="field"><label>Frasi rapide <span class="small muted">(una per riga)</span></label><textarea class="input" name="consigli_frasi" rows="4" placeholder="Controllo fra 30 giorni&#10;Dieta iposodica&#10;Evitare sforzi per 7 giorni"></textarea></div>
            <div class="pref"><div><b>Sempre nel referto</b><span>Se in visita non scrivi nulla, nel referto va comunque il testo predefinito</span></div><button class="switch" type="button" data-name="consigli_auto" aria-label="Sempre nel referto"></button><input type="hidden" name="consigli_auto"></div>',
        'chiavi' => ['consigli_testo', 'consigli_frasi', 'consigli_auto'],
        'salva' => 'Salva consigli',
    ];
    return $p;
});

// 3) Sezione "Consigli" nel referto, dopo le sezioni standard
Hooks::add('referto.sezioni', function (array $sezioni, array $v): array {
    $testo = trim((string) ($v['dati']['consigli']['testo'] ?? ''));
    if ($testo === '' && Impostazione::get('consigli_auto') === '1') $testo = trim(Impostazione::get('consigli_testo'));
    if ($testo !== '') $sezioni[__('Consigli', 'consigli')] = $testo;
    return $sezioni;
});
