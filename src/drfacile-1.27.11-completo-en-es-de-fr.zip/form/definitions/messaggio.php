<?php
return [
    'title' => __('Nuovo modello di messaggio'), 'title_edit' => __('Modifica modello di messaggio'),
    'endpoint' => 'archivi', 'action' => 'save', 'submit' => __('Salva modello'),
    'table' => 'messaggi', 'wide' => true,
    'fields' => [
        ['name' => 'archivio', 'type' => 'hidden', 'default' => 'messaggi'],
        ['name' => 'codice', 'label' => __('Codice'), 'type' => 'text', 'required' => true, 'class' => 'mono', 'row' => 1, 'placeholder' => __('Es. REF-EMAIL')],
        ['name' => 'canale', 'label' => __('Canale'), 'type' => 'select', 'row' => 1, 'options' => ['email' => __('Email'), 'sms' => 'SMS', 'whatsapp' => __('WhatsApp')]],
        ['name' => 'per_tipo', 'label' => __('Usato per'), 'type' => 'select', 'row' => 1, 'options' => ['generico' => __('Comunicazione generica'), 'referto' => __('Invio referto'), 'fattura' => __('Invio fattura'), 'ricetta' => __('Invio ricetta'), 'documento' => __('Invio documento'), 'file' => __('Invio file dalla documentale'), 'promemoria' => __('Promemoria appuntamento'), 'recupero' => __('Recupero password')]],
        ['name' => 'descrizione', 'label' => __('Descrizione'), 'type' => 'text', 'required' => true, 'placeholder' => __('Es. Referto in allegato, tono formale')],
        ['name' => 'oggetto', 'label' => __('Oggetto (email)'), 'type' => 'text', 'placeholder' => __('Es. Referto della visita del {data} · {studio}')],
        ['name' => 'contenuto', 'label' => __('Testo'), 'type' => 'rich', 'height' => 220,
            'campi' => ['paziente', 'nome', 'cognome', 'medico', 'studio', 'studio_telefono', 'studio_email', 'data', 'documento', 'numero', 'importo', 'appuntamento'],
            'placeholder' => __('Gentile {paziente}, in allegato trova {documento}… Per SMS e WhatsApp resta solo il testo.')],
        ['name' => 'predefinito', 'label' => __('Predefinito per questo uso'), 'type' => 'switch', 'default' => 0, 'row' => 2, 'help' => __('Proposto per primo nella finestra di invio')],
        ['name' => 'abilitato', 'label' => __('Abilitato'), 'type' => 'switch', 'default' => 1, 'row' => 2],
    ],
];
