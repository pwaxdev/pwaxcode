<?php
/**
 * ESTENSIONI del programma (dal Negozio della Scrivania).
 * Il CATALOGO è nel database COMUNE (Database::comune('store_moduli')) — lo stesso negozio per tutti;
 * le INSTALLAZIONI sono dello studio (tabella dedicata `estensioni`).
 * Ovunque nel codice: `if (Estensioni::attiva('commercialista')) …` sblocca la funzionalità.
 */
final class Estensioni
{
    private static ?array $cache = null;

    public static function attiva(string $codice): bool
    {
        if (self::$cache === null) {
            self::$cache = [];
            try {
                foreach (Database::all("SELECT codice, scadenza FROM estensioni WHERE attiva = 1") as $r) {
                    if ($r['scadenza'] && $r['scadenza'] < oggi()) continue;   // abbonamento scaduto: la funzione si spegne da sola
                    self::$cache[$r['codice']] = true;
                }
            } catch (Throwable $e) { /* tabella non ancora creata */ }
        }
        return isset(self::$cache[$codice]);
    }

    /** Carica le estensioni attive: hook server (estensioni/<codice>/estensione.php) — chiamata dal bootstrap */
    public static function carica(): void
    {
        // estensioni "solo catalogo" del core (senza cartella): i loro agganci di ciclo di vita stanno qui
        Hooks::add('estensione.installata', function (string $codice) {
            if ($codice === 'salaattesa' && !Impostazione::get('salaattesa_token')) Impostazione::set('salaattesa_token', bin2hex(random_bytes(16)));
        });
        // migrazioni delle estensioni (estensioni/<codice>/migrations/): all'installazione, alla riattivazione e all'aggiornamento
        foreach (['estensione.installata', 'estensione.attivata', 'estensione.aggiornata'] as $punto) Hooks::add($punto, fn(string $codice) => Migrazioni::esegui($codice), 1);
        foreach (array_keys(self::tutteAttive()) as $codice) {
            if (is_dir(DRF_ROOT . "/estensioni/$codice/locale")) I18n::lega($codice, DRF_ROOT . "/estensioni/$codice/locale");   // traduzioni dell'estensione: dominio = codice
            $f = DRF_ROOT . '/estensioni/' . $codice . '/estensione.php';
            if (is_file($f)) {
                try { OutputGuard::run("estensione $codice/estensione.php", fn() => Capabilities::come($codice, fn() => require_once $f)); }
                catch (Throwable $e) { error_log("Estensione $codice: " . $e->getMessage()); }
            }
        }
    }

    /** Svuota la cache (cambio di database: Tenant) */
    public static function reset(): void { self::$cache = null; }

    public static function tutteAttive(): array
    {
        self::attiva('');   // riempie la cache
        return self::$cache ?? [];
    }

    /** Le risorse client (js/css) delle estensioni attive, da includere nella pagina */
    public static function assets(): array
    {
        $out = ['js' => [], 'css' => []];
        foreach (array_keys(self::tutteAttive()) as $codice) {
            foreach (glob(DRF_ROOT . "/estensioni/$codice/js/*.js") ?: [] as $f) $out['js'][] = "estensioni/$codice/js/" . basename($f);
            foreach (glob(DRF_ROOT . "/estensioni/$codice/css/*.css") ?: [] as $f) $out['css'][] = "estensioni/$codice/css/" . basename($f);
        }
        return $out;
    }

    /** Allinea le versioni attivate ai file presenti (aggiornamento arrivato con l'app o scaricato dallo Store): hook estensione.aggiornata */
    /** Estensione attiva ma senza file (aggiornamento del programma che ha sovrascritto estensioni/): la riscarica dal repository */
    public static function ripara(): void
    {
        if (!Store::attivo() || PHP_SAPI === 'cli' && !getenv('DRF_STUDIO')) return;
        foreach (array_keys(self::tutteAttive()) as $codice) {
            if (Store::installato($codice)) continue;
            try {
                if (!isset(Store::catalogoRemoto()[$codice])) { Store::sincronizza(true); if (!isset(Store::catalogoRemoto()[$codice])) continue; }
                Capabilities::comeCore(fn() => Store::scarica($codice));
                error_log("Estensione $codice: file mancanti dopo un aggiornamento, riscaricata dal repository");
                Attivita::registra('estensione.riparata', 'negozio', 0, $codice);
            } catch (Throwable $e) { error_log("Estensione $codice: impossibile riscaricarla (" . $e->getMessage() . ')'); }
        }
    }

    public static function aggiornamenti(): void
    {
        try {
            $cat = [];
            foreach (Database::all('SELECT codice, versione FROM ' . Database::comune('store_moduli')) as $r) $cat[$r['codice']] = $r['versione'];
            foreach (Database::all('SELECT id, codice, versione FROM estensioni WHERE attiva = 1') as $e) {
                // la versione vera è quella dei file sul disco (manifest.json); il catalogo vale solo per le estensioni senza cartella
                $inst = Store::manifestInstallato($e['codice']);
                $nuova = $inst ? (($inst['versione'] ?? '') ?: null) : ($cat[$e['codice']] ?? null);
                if ($nuova && $nuova !== $e['versione']) {
                    Database::update('estensioni', ['versione' => $nuova], 'id = :id', ['id' => (int) $e['id']]);
                    Hooks::run('estensione.aggiornata', $e['codice'], $e['versione'], $nuova);
                }
            }
        } catch (Throwable $e) { /* comune non pronto */ }
    }

    /** Attiva l'estensione nello studio (i file devono già esserci: distribuiti con l'app o scaricati da Store::scarica) */
    public static function installa(string $codice): void
    {
        if (self::attiva($codice)) return;
        $inst = Store::manifestInstallato($codice);
        $ver = (string) (($inst['versione'] ?? '') ?: (Database::value('SELECT versione FROM ' . Database::comune('store_moduli') . ' WHERE codice = ?', [$codice]) ?: '1.0'));
        $ex = Database::one('SELECT id FROM estensioni WHERE codice = ?', [$codice]);
        if ($ex) Database::update('estensioni', ['attiva' => 1, 'versione' => $ver], 'id = :id', ['id' => (int) $ex['id']]);
        else Database::insert('estensioni', ['codice' => $codice, 'attiva' => 1, 'versione' => $ver, 'installata_il' => date('Y-m-d H:i:s')]);
        self::$cache = null;
        // il codice dell'estensione entra ora (prima non era attiva, quindi non era stato incluso) e riceve il suo hook di ciclo di vita
        $f = Store::dir($codice) . '/estensione.php';
        if (is_file($f)) {
            try { OutputGuard::run("estensione $codice/estensione.php (installazione)", fn() => Capabilities::come($codice, fn() => require_once $f)); }
            catch (Throwable $e) { error_log("Estensione $codice: " . $e->getMessage()); }
        }
        Hooks::run($ex ? 'estensione.attivata' : 'estensione.installata', $codice, $ver);
    }

    /** Disattiva: UI e hook spariscono, i dati restano (riattivando torna tutto) */
    public static function disinstalla(string $codice): void
    {
        Database::run('UPDATE estensioni SET attiva = 0 WHERE codice = ?', [$codice]);
        self::$cache = null;
        Hooks::run('estensione.disattivata', $codice);
    }
    public static function disattiva(string $codice): void { self::disinstalla($codice); }

    /** Rimuove i file dal disco (dopo aver disattivato); le tabelle e i dati dell'estensione restano nel database */
    public static function rimuovi(string $codice): void
    {
        if (self::attiva($codice)) self::disinstalla($codice);
        Store::rimuoviFile($codice);
        Hooks::run('estensione.rimossa', $codice);
    }

    /** Aggiorna i file dal repository e allinea la versione (hook estensione.aggiornata) */
    public static function aggiorna(string $codice): array
    {
        $prima = (string) (Database::value('SELECT versione FROM estensioni WHERE codice = ?', [$codice]) ?: '');
        $m = Store::scarica($codice);
        $dopo = (string) ($m['versione'] ?? $prima);
        if (self::attiva($codice) && $prima !== $dopo) {
            Database::run('UPDATE estensioni SET versione = ? WHERE codice = ?', [$dopo, $codice]);
            Hooks::run('estensione.aggiornata', $codice, $prima, $dopo);
        }
        return ['da' => $prima, 'a' => $dopo];
    }

    /** Il catalogo del Negozio (tabella comune), con lo stato di installazione dello studio */
    /**
     * Il catalogo dello Store con lo stato nello studio. $dettagli = true aggiunge voti, requisiti, aggiornamenti (per l'interfaccia).
     * Gli studi vedono i pacchetti approvati (o già attivi); un'installazione revisore (store.revisore) anche quelli in revisione.
     */
    public static function catalogo(bool $dettagli = false): array
    {
        $t = Database::comune('store_moduli');
        $rows = Database::all("SELECT * FROM $t WHERE attivo = 1 ORDER BY ordine, nome");
        $agg = $dettagli ? Store::aggiornamentiDisponibili() : [];
        $out = [];
        foreach ($rows as $r) {
            $r['stato'] = $r['stato'] ?: 'approvato';
            $r['installata'] = self::attiva($r['codice']);
            if ($r['stato'] === 'respinto' && !$r['installata']) continue;
            if ($r['stato'] === 'in_revisione' && !$r['installata'] && !Store::revisore()) continue;
            $r['schermate'] = json_decode((string) ($r['schermate'] ?? '[]'), true) ?: [];
            foreach (['richiede', 'dipendenze', 'capabilities', 'conflitti'] as $k) $r[$k] = json_decode((string) ($r[$k] ?? ''), true) ?: [];
            $r['presente'] = Store::installato($r['codice']);   // i file ci sono (distribuiti con l'app o scaricati)
            if ($dettagli) {
                $inst = Store::manifestInstallato($r['codice']);
                $r['versione_installata'] = $inst['versione'] ?? ($r['installata'] ? (string) Database::value('SELECT versione FROM estensioni WHERE codice = ?', [$r['codice']]) : null);
                $r['aggiornamento'] = $agg[$r['codice']] ?? null;
                $r['voti'] = Store::voti($r['codice']);
                $r['problemi'] = Store::problemi($r);
                $r['capabilities_desc'] = Capabilities::descrivi($r['capabilities']);
                $r['migrazioni'] = $r['presente'] ? count(Migrazioni::disponibili($r['codice'])) : 0;
                $r['lingue'] = (array) (($inst['languages'] ?? null) ?: (json_decode((string) ($r['lingue'] ?? ''), true) ?: ['it_IT']));
                $r['dipendenze_mancanti'] = Store::dipendenzeMancanti($r);
            }
            $out[] = $r;
        }
        return $out;
    }

    /** Crea la tabella del catalogo nel comune e la popola/aggiorna (idempotente, per codice e versione) */
    public static function tabelle(): void
    {
        $t = Database::comune('store_moduli');
        $id = Database::driver() === 'mysql' ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
        Database::run("CREATE TABLE IF NOT EXISTS $t (
            id $id, codice VARCHAR(40) NOT NULL, nome VARCHAR(120) NOT NULL, sottotitolo VARCHAR(200),
            descrizione TEXT, categoria VARCHAR(40), prezzo_tipo VARCHAR(20) DEFAULT 'gratis', prezzo REAL DEFAULT 0,
            fi VARCHAR(60), fa VARCHAR(80), tinta VARCHAR(20), schermate TEXT, disponibile INTEGER DEFAULT 1,
            versione VARCHAR(20) DEFAULT '1.0', ordine INTEGER DEFAULT 100, attivo INTEGER DEFAULT 1,
            autore VARCHAR(80) DEFAULT 'NASTech', novita INTEGER DEFAULT 0,
            autore_url VARCHAR(200), stato VARCHAR(20) DEFAULT 'approvato', richiede TEXT, dipendenze TEXT, capabilities TEXT, conflitti TEXT, lingue TEXT,
            file VARCHAR(160), sha256 VARCHAR(64), dimensione INTEGER DEFAULT 0, voti_media REAL DEFAULT 0, voti_n INTEGER DEFAULT 0,
            origine VARCHAR(20) DEFAULT 'app', aggiornato_il VARCHAR(19))");
        foreach (['autore' => "VARCHAR(80) DEFAULT 'NASTech'", 'novita' => 'INTEGER DEFAULT 0',
            // Store 3.0 (repository): approvazione, requisiti, pacchetto, voti
            'autore_url' => 'VARCHAR(200)', 'stato' => "VARCHAR(20) DEFAULT 'approvato'", 'richiede' => 'TEXT', 'dipendenze' => 'TEXT', 'capabilities' => 'TEXT',
            'conflitti' => 'TEXT', 'lingue' => 'TEXT', 'file' => 'VARCHAR(160)', 'sha256' => 'VARCHAR(64)', 'dimensione' => 'INTEGER DEFAULT 0', 'voti_media' => 'REAL DEFAULT 0', 'voti_n' => 'INTEGER DEFAULT 0',
            'origine' => "VARCHAR(20) DEFAULT 'app'", 'aggiornato_il' => 'VARCHAR(19)'] as $col => $tipo) {
            try { Database::run("ALTER TABLE $t ADD COLUMN $col $tipo"); } catch (Throwable $e) { /* già presente */ }
        }
        Store::tabelle();
        Pagamenti::tabelle();
        $presenti = [];
        foreach (Database::all("SELECT codice, versione FROM $t") as $r) $presenti[$r['codice']] = $r['versione'];
        foreach (self::catalogoSeed() as $m) {
            $sch = json_encode($m['schermate'], JSON_UNESCAPED_UNICODE);
            if (!isset($presenti[$m['codice']])) {
                Database::run("INSERT INTO $t (codice, nome, sottotitolo, descrizione, categoria, prezzo_tipo, prezzo, fi, fa, tinta, schermate, disponibile, versione, ordine, autore, novita) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [$m['codice'], $m['nome'], $m['sottotitolo'], $m['descrizione'], $m['categoria'], $m['prezzo_tipo'], $m['prezzo'], $m['fi'], $m['fa'], $m['tinta'], $sch, $m['disponibile'], $m['versione'], $m['ordine'], $m['autore'], $m['novita']]);
            } elseif ($presenti[$m['codice']] !== $m['versione'] && Database::value("SELECT origine FROM $t WHERE codice = ?", [$m['codice']]) !== 'repository') {
                // nuova versione del modulo distribuita col programma: la scheda dello store si aggiorna da sola (se il repository non l'ha presa in carico)
                Database::run("UPDATE $t SET nome = ?, sottotitolo = ?, descrizione = ?, categoria = ?, prezzo_tipo = ?, prezzo = ?, fi = ?, fa = ?, tinta = ?, schermate = ?, disponibile = ?, versione = ?, ordine = ?, autore = ?, novita = ? WHERE codice = ?",
                    [$m['nome'], $m['sottotitolo'], $m['descrizione'], $m['categoria'], $m['prezzo_tipo'], $m['prezzo'], $m['fi'], $m['fa'], $m['tinta'], $sch, $m['disponibile'], $m['versione'], $m['ordine'], $m['autore'], $m['novita'], $m['codice']]);
            }
        }
    }

    /** Il catalogo distribuito con il programma (in produzione lo alimenta il portale sul database comune) */
    private static function catalogoSeed(): array
    {
        $M = fn(string $cod, string $nome, string $sotto, string $desc, string $cat, string $tipo, float $prezzo, string $fi, string $fa, string $tinta, array $sch, int $disp, string $ver, int $ord, int $novita = 0) =>
            ['codice' => $cod, 'nome' => $nome, 'sottotitolo' => $sotto, 'descrizione' => $desc, 'categoria' => $cat, 'prezzo_tipo' => $tipo, 'prezzo' => $prezzo, 'fi' => $fi, 'fa' => $fa, 'tinta' => $tinta, 'schermate' => $sch, 'disponibile' => $disp, 'versione' => $ver, 'ordine' => $ord, 'autore' => 'NASTech', 'novita' => $novita];
        return [
            $M('commercialista', 'Commercialista', 'La contabilità in mano al tuo commercialista, senza scambi di carta',
                '<p>Aggiunge il ruolo <b>Commercialista</b> fra gli utenti dello studio: un accesso dedicato per chi ti segue la contabilità.</p><p>In <b>Procedure → Contabilità</b> trovi il riepilogo del periodo (con lo spaccato per aliquota IVA) e l\'esportazione: <b>XML in formato elettronico</b> per ogni fattura più il riepilogo CSV, in un archivio ZIP.</p>',
                'Amministrazione', 'gratis', 0, 'calculator', 'fa-solid fa-calculator', '#4FC3A1',
                [['img' => 'assets/images/store/commercialista-1.svg', 't' => 'Riepilogo del periodo'], ['img' => 'assets/images/store/commercialista-2.svg', 't' => 'Esportazione XML + CSV']], 1, '1.1', 10),
            $M('firma', 'Firma sul tablet', 'Privacy e consensi firmati sullo schermo, archiviati con la firma dentro',
                '<p>Porgi il tablet al paziente: <b>firma con il dito</b> direttamente sullo schermo, e il documento viene generato e archiviato <b>con la firma incorporata</b> — niente stampa, niente scanner.</p><p>Funziona con tutti i modelli dell\'archivio Documenti: dal menu del paziente → Stampa documento trovi il pulsante <b>Firma sul tablet</b>; il consenso viene registrato con la nota della firma e la scadenza del modello.</p>',
                'Accoglienza', 'gratis', 0, 'signature', 'fa-solid fa-signature', '#E79A9D',
                [['img' => 'assets/images/store/firma-1.svg', 't' => 'Il pad di firma'], ['img' => 'assets/images/store/firma-2.svg', 't' => 'La firma nel documento']], 1, '1.1', 15, 1),
            $M('salaattesa', 'Sala d\'attesa', 'Lo schermo per la TV dello studio: chi è in visita e chi è il prossimo',
                '<p>Una pagina pubblica, protetta da un collegamento segreto, da aprire sulla <b>TV o sul tablet della sala d\'attesa</b>: la coda di oggi con le sole iniziali (privacy garantita), chi è <b>in visita</b>, chi è il prossimo, e si aggiorna da sola ogni 30 secondi.</p>',
                'Accoglienza', 'gratis', 0, 'screen', 'fa-solid fa-tv', '#5AA9E6',
                [['img' => 'assets/images/store/salaattesa-1.svg', 't' => 'Lo schermo di sala'], ['t' => 'Collegamento segreto', 's' => 'Un link con token, revocabile']], 1, '1.1', 20),
            $M('ritmo', 'Ritmo', 'Il gioco della Scrivania: trenta secondi di pausa fra un paziente e l\'altro',
                '<p>Il piccolo gioco di memoria musicale di DRFacile: guarda la sequenza, ripetila, e prova a battere il tuo record. Installandolo compare la sua <b>icona sulla Scrivania</b>, come ogni app del Negozio.</p>',
                'Svago', 'gratis', 0, 'gamepad', 'fa-solid fa-gamepad', '#9B7EDE',
                [['img' => 'assets/images/store/ritmo-1.svg', 't' => 'Icona sulla Scrivania']], 1, '1.1', 25, 1),
            $M('bmi', 'BMI in visita', 'Peso, altezza e indice di massa corporea direttamente in anamnesi',
                '<p>L\'estensione di esempio del sistema modulare, utile davvero: durante la visita compare il <b>calcolatore BMI</b> — inserisci peso e altezza, vedi indice e categoria, e con un click il dato finisce <b>nell\'anamnesi</b>.</p><p>È anche l\'esempio guida del manuale <i>Creare estensioni</i>: il suo codice sorgente (una cartella, due file) mostra come agganciarsi alla visita con gli hook.</p>',
                'Clinica', 'gratis', 0, 'chart-line-up', 'fa-solid fa-weight-scale', '#F0B64A',
                [['img' => 'assets/images/store/bmi-1.svg', 't' => 'Il calcolatore in visita']], 1, '1.0', 28, 1),
            $M('gineco', 'Visita ginecologica', 'La visita SOSTITUITA: niente quadro soggettivo/oggettivo, il percorso è tutto ginecologico',
                '<p>La dimostrazione più radicale del sistema modulare: installandola, il corpo della visita standard <b>viene sostituito</b> dal percorso ginecologico — <b>anamnesi ginecologica</b> (motivo, menarca, UM, ciclo, G·P·A, contraccezione), <b>esame ginecologico</b> (esterni, speculum, collo, annessi), <b>accertamenti</b> (pap test, tamponi, ecografia TV) e <b>conclusioni</b>.</p><p>Tutto si salva con la bozza; la conclusione diagnostica diventa la diagnosi della visita, e alla chiusura il referto è ricostruito da zero con le sezioni specialistiche. Testata paziente, storico e chiusura restano del programma. Codice sorgente = esempio guida del manuale.</p>',
                'Clinica', 'gratis', 0, 'venus', 'fa-solid fa-venus', '#D66BA0',
                [['img' => 'assets/images/store/gineco-1.svg', 't' => 'La visita ginecologica al posto di quella standard']], 1, '1.8', 27, 1),
            $M('consigli', 'Consigli di fine visita', 'Il testo per il paziente, pronto in visita e nel referto',
                '<p>L\'estensione di esempio <b>completa</b>: aggiunge un <b>pannello in Impostazioni</b> (testo predefinito, frasi rapide, un interruttore), una <b>card in visita</b> con le frasi rapide da aggiungere con un click, e la sezione <b>Consigli</b> nel referto alla chiusura.</p><p>È l\'esempio guida del manuale <i>Creare estensioni</i> per chi vuole delle impostazioni proprie: tre file più un endpoint AJAX.</p>',
                'Clinica', 'gratis', 0, 'comment-heart', 'fa-regular fa-comment-dots', '#63C7C9',
                [['img' => 'assets/images/store/consigli-1.svg', 't' => 'Card in visita e pannello in Impostazioni']], 1, '1.0', 29, 1),
            $M('sms', 'Servizio SMS', 'Promemoria e comunicazioni via SMS ai pazienti, con il tuo nome come mittente',
                '<p>Attiva l\'invio di SMS dal programma: promemoria degli appuntamenti, codici, comunicazioni. Il servizio si paga in abbonamento e i messaggi si comprano a <b>pacchetti</b> (500, 2.000) dallo Store: il credito residuo è sempre visibile in Impostazioni.</p><p>Le credenziali del provider stanno nella configurazione del server: il cliente non deve fare nulla.</p>',
                'Comunicazione', 'abbonamento', 9, 'comment-sms', 'fa-solid fa-comment-sms', '#3FB68B',
                [['t' => 'Credito SMS', 's' => 'In Impostazioni, con l\'avviso quando sta per finire']], 1, '1.0', 60, 1),
            $M('sms_500', 'Pacchetto 500 SMS', 'Cinquecento messaggi, senza scadenza',
                '<p>500 SMS aggiunti al credito dello studio. Serve il <b>Servizio SMS</b> attivo. L\'acquisto passa dal portale: alla conferma il credito cresce subito.</p>',
                'Comunicazione', 'pagamento', 39, 'comment-sms', 'fa-solid fa-comment-sms', '#3FB68B', [], 1, '1.0', 61, 0),
            $M('sms_2000', 'Pacchetto 2.000 SMS', 'Duemila messaggi, senza scadenza',
                '<p>2.000 SMS aggiunti al credito dello studio, al prezzo migliore. Serve il <b>Servizio SMS</b> attivo.</p>',
                'Comunicazione', 'pagamento', 129, 'comment-sms', 'fa-solid fa-comment-sms', '#3FB68B', [], 1, '1.0', 62, 0),
            $M('senza_marchio', 'Documenti senza firma DRFacile', 'Toglie "Documento generato con DRFacile" dal piè di pagina',
                '<p>Referti, fatture, ricette e documenti riportano in fondo la firma del programma. Con questa opzione l\'interruttore in <b>Impostazioni → Stampa</b> si sblocca e puoi toglierla.</p>',
                'Gestione', 'abbonamento', 3, 'badge-check', 'fa-solid fa-certificate', '#9B7EDE', [], 1, '1.0', 91, 0),
            $M('spazio', 'Spazio aggiuntivo +5 GB', 'Più posto per documenti, immagini ed esami: 5 GB in più per lo studio',
                '<p>Ogni studio ha uno spazio per i documenti generati, quelli caricati nella gestione documentale e il database. Quando si avvicina al limite, con questo pacchetto lo amplii di <b>5 GB</b>, cumulabile.</p><p>L\'acquisto passa dal portale DRFacile: alla conferma la quota dello studio cresce subito (senza nulla da installare).</p>',
                'Gestione', 'pagamento', 29, 'disk', 'fa-solid fa-hard-drive', '#5B8DEF',
                [['t' => 'Spazio dello studio', 's' => 'Usato, disponibile, percentuale']], 1, '1.0', 90, 0),
            $M('magazzino', 'Magazzino e scorte', 'Farmaci e materiali sotto controllo, con le scorte minime',
                '<p>Carichi, scarichi e scorte minime per farmaci e materiali di consumo, con avvisi nello scadenzario quando qualcosa sta per finire o per scadere.</p>',
                'Gestione', 'pagamento', 49, 'boxes', 'fa-solid fa-boxes-stacked', '#F0B64A', [['t' => 'Scorte minime', 's' => 'Avvisi automatici nello scadenzario']], 0, '1.0', 30),
            $M('vocale', 'Refertazione vocale', 'Detti il referto, lui scrive',
                '<p>Dettatura vocale nei campi della visita e del referto, con il vocabolario medico italiano.</p>',
                'Produttività', 'abbonamento', 9, 'microphone', 'fa-solid fa-microphone', '#9B7EDE', [['t' => 'Vocabolario medico', 's' => 'Termini clinici riconosciuti']], 0, '1.0', 40),
            $M('whatsapp', 'Promemoria WhatsApp', 'Pre-visita e promemoria sul canale che i pazienti leggono davvero',
                '<p>Collega WhatsApp Business all\'endpoint Comunicazioni: istruzioni pre-visita, promemoria e conferme partono da sole.</p>',
                'Comunicazione', 'abbonamento', 15, 'paper-plane', 'fa-regular fa-paper-plane', '#63C7C9', [['t' => 'Invii automatici', 's' => 'Alla prenotazione, 24 o 48 ore prima']], 0, '1.0', 50),
        ];
    }

}
