<?php
/** Rende una form definita in form/definitions/<nome>.php (vuota o precompilata con id) */
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'render' => fn(array $in) => FormBuilder::render(Api::str($in, 'name'), Api::int($in, 'id') ?: null, (array) ($in['values'] ?? [])),
]);
