/* Modulo Agenda: settimana, timeline giornaliera, prossimo appuntamento, prenotazioni */
DRF.register('agenda', (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;
  const st = { date: U.todayIso(), sel: null, data: null, view: 'giorno', mese: null };
  const H0 = () => (DRF.config.agenda && DRF.config.agenda.ora_inizio) || 8;
  const H1 = () => (DRF.config.agenda && DRF.config.agenda.ora_fine) || 18;
  const HH = 72;
  const col = t => (st.data && st.data.tipi[t] && st.data.tipi[t].colore) || 'var(--amber)';

  function load() {
    if (st.view === 'mese') return DRF.api.get('agenda', 'mese', { data: st.date }).then(d => { st.mese = d; st.data = st.data || d; st.data.tipi = d.tipi; st.data.prossimo = d.prossimo; st.data.n_oggi = d.n_oggi; renderMonth(); renderNext(); DRF.nav.refreshSub(); });
    return DRF.api.get('agenda', 'giorno', { data: st.date }).then(d => { st.data = d; render(); DRF.nav.refreshSub(); });
  }
  function render() { renderWeek(); renderTimeline(); renderNext(); renderLegend(); }
  function setView(v) {
    st.view = v; $('#agView button').removeClass('on').filter(`[data-v="${v}"]`).addClass('on');
    $('#week, #timeline').prop('hidden', v === 'mese'); $('#month').prop('hidden', v !== 'mese');
    $('#wkPrev').attr('title', v === 'mese' ? DRF.__('Mese precedente') : DRF.__('Settimana precedente')); $('#wkNext').attr('title', v === 'mese' ? DRF.__('Mese successivo') : DRF.__('Settimana successiva'));
    load();
  }
  function renderMonth() {
    const m = st.mese, first = new Date(m.anno, m.mese - 1, 1), start = U.addDays(first, -((first.getDay() + 6) % 7));
    $('#wkLabel').text(m.label);
    let html = U.giorniBrevi().map(d => `<div class="dow">${d}</div>`).join('');
    for (let i = 0; i < 42; i++) {
      const d = U.addDays(start, i), k = U.iso(d), list = m.giorni[k] || [];
      if (i >= 35 && d.getMonth() !== m.mese - 1) break;
      html += `<div class="mday ${d.getMonth() !== m.mese - 1 ? 'out' : ''} ${k === U.todayIso() ? 'today' : ''}" data-d="${k}"><b>${d.getDate()}</b>${list.slice(0, 3).map(a => `<span class="ch" style="--c:${col(a.tipo)}" title="${DRF.esc(a.paziente)} · ${a.ora} · ${DRF.esc(a.tipo_label)}">${a.ora} ${DRF.esc(a.paziente.split(' ').slice(-1)[0])}</span>`).join('')}${list.length > 3 ? `<span class="more">+${list.length - 3} ${DRF.__('altri')}</span>` : ''}${list.length && list.length <= 3 ? '' : ''}</div>`;
    }
    $('#month').html(html);
  }

  function renderWeek() {
    const days = Object.keys(st.data.settimana), mon = U.pd(days[0]), sun = U.pd(days[6]);
    $('#wkLabel').text(`${mon.toLocaleDateString(U.loc(), { day: 'numeric', month: 'short' })} – ${sun.toLocaleDateString(U.loc(), { day: 'numeric', month: 'short', year: 'numeric' })}`);
    $('#week').html(days.map(k => { const d = U.pd(k), n = st.data.settimana[k];
      return `<button class="day ${k === st.date ? 'on' : ''} ${k === U.todayIso() ? 'today' : ''}" data-d="${k}"><span>${d.toLocaleDateString(U.loc(), { weekday: 'short' })}</span><b>${d.getDate()}</b><i>${'<em></em>'.repeat(Math.min(n, 4))}</i></button>`; }).join(''));
  }

  function renderTimeline() {
    const list = st.data.appuntamenti, h0 = H0(), h1 = H1(), isToday = st.date === U.todayIso(), nm = U.nowMin();
    const hours = [...Array(h1 - h0 + 1)].map((_, i) => `<div class="hour"><span>${String(h0 + i).padStart(2, '0')}:00</span></div>`).join('');
    const lanes = [];
    const blocks = list.map(a => {
      const start = U.mins(a.ora), end = start + +a.durata;
      let lane = lanes.findIndex(e => e <= start); if (lane < 0) lane = lanes.length; lanes[lane] = end;
      const top = (start - h0 * 60) / 60 * HH, h = a.durata / 60 * HH - 6;
      const done = a.stato === 'completato' || (isToday && end < nm);
      return `<div class="appt ${a.durata >= 45 ? 'tall' : ''} ${+a.id === st.sel ? 'on' : ''} ${done ? 'done' : ''} ${+a.urgente ? 'urgent' : ''} ${a.stato === 'assente' ? 'noshow' : ''}" style="top:${top}px;height:${h}px;left:${lane * 28}px;z-index:${lane + 1};--c:${col(a.tipo)}" data-id="${a.id}"><b>${+a.urgente ? `<i class="appt-urg" title="${DRF.__('Urgente')}">${I('exclamation', 'fa-solid fa-triangle-exclamation')}</i>` : ''}${DRF.esc(a.paziente)}${a.stato === 'assente' ? ' <em class="appt-ns">' + DRF.__('non presentato') + '</em>' : ''}</b><span>${a.ora} · ${DRF.esc(a.tipo_label)}${a.note ? ' · ' + DRF.esc(a.note) : ''}</span></div>`;
    }).join('');
    const now = isToday && nm >= h0 * 60 && nm <= h1 * 60 ? `<div class="now" style="top:${(nm - h0 * 60) / 60 * HH + 14}px"></div>` : '';
    const empty = DRF.ui.empty(DRF.__('Nessun appuntamento in questa giornata.') + '<br>' + DRF.__('Usa') + ' <b>' + DRF.__('Nuova prenotazione') + '</b> ' + DRF.__('per aggiungerne uno.'));
    $('#timeline').html(hours + `<div class="slots">${blocks || empty}</div>` + now);
  }

  function renderNext() {
    const $el = $('#nextCard');
    let a = st.sel ? st.data.appuntamenti.find(x => +x.id === st.sel) : null, eyebrow = DRF.__('Appuntamento selezionato');
    if (!a) { a = st.data.prossimo; eyebrow = DRF.__('Prossimo appuntamento'); }
    if (!a) {
      $el.html(`<div class="eyebrow">${DRF.__('Oggi')}</div><h2>${DRF.__('Giornata conclusa')}</h2><p>${DRF.__('Nessun altro appuntamento in agenda.')}</p><div class="row"><button class="btn white" id="ncBook">${I('calendar-plus', 'fa-regular fa-calendar-plus')}<span>${DRF.__('Prenota')}</span></button></div>`);
      DRF.icons.apply($el[0]); return;
    }
    const when = a.data === U.todayIso() ? DRF.__('oggi') : U.fmtIso(a.data);
    $el.html(`<div class="eyebrow">${eyebrow}</div><h2>${DRF.esc(a.paziente)}</h2><p>${DRF.esc(a.tipo_label)}${a.note ? ' · ' + DRF.esc(a.note) : ''}</p><div class="time">${I('clock', 'fa-regular fa-clock')} ${when} · ${a.ora} · ${a.durata} min</div>
      <div class="row"><button class="btn white" id="ncStart" data-pid="${a.paziente_id}" data-aid="${a.id}">${I('play', 'fa-solid fa-play')}<span>${DRF.__('Inizia visita')}</span></button><button class="btn glass" id="ncPat" data-pid="${a.paziente_id}">${DRF.__('Scheda')}</button><button class="btn glass" id="ncEdit" data-aid="${a.id}" title="${DRF.__('Modifica')}">${I('pencil', 'fa-solid fa-pen')}</button><button class="btn glass" id="ncDel" data-aid="${a.id}" title="${DRF.__('Elimina')}">${I('trash', 'fa-solid fa-trash')}</button></div>`);
    DRF.icons.apply($el[0]);
  }

  function renderLegend() {
    const list = st.data.appuntamenti, tipi = st.data.tipi;
    const h = Math.round(list.reduce((s, a) => s + +a.durata, 0) / 60 * 10) / 10;
    $('#legend').html(Object.keys(tipi).map(k => `<div><i style="background:${tipi[k].colore}"></i>${DRF.esc(tipi[k].nome)}<b>${list.filter(a => a.tipo === k).length}</b></div>`).join('') +
      `<div style="border-top:1px solid var(--line);padding-top:10px"><i style="background:var(--ink-3)"></i>${DRF.__('Tempo in studio')}<b>${String(h).replace('.', ',')} h</b></div>`);
  }

  /** Elimina con possibilità di annullare dal toast (l'appuntamento viene ricreato con gli stessi dati) */
  function elimina(id) {
    const a = st.data.appuntamenti.find(x => +x.id === +id); if (!a) return;
    DRF.api.post('agenda', 'delete', { id }).then(() => {
      st.sel = null; load();
      DRF.ui.toast(`${DRF.__('Prenotazione eliminata:')} ${a.paziente} · ${a.ora}`, 'info', { undo: () => DRF.api.post('agenda', 'save', { paziente_id: a.paziente_id, data: a.date || a.data, ora: a.ora, durata: a.durata, tipo: a.tipo, note: a.note, stato: a.stato }).then(r => { st.sel = r.id; load(); DRF.ui.toast(DRF.__('Prenotazione ripristinata')); }) });
    });
  }
  function prenota(values) {
    DRF.form.open('appuntamento', { values: Object.assign({ data: st.date }, values || {}), onOpen($b) {
      // scelta della prestazione → propone la sua durata dal listino
      $b.find('[name=tipo]').on('change', function () { const t = (st.data && st.data.tipi || {})[this.value]; if (t && t.durata) DRF.ui.setVal($b.find('[name=durata]'), String(t.durata)); });
      // slot per le estensioni: campi e logica in più nella prenotazione (ctx.campo aggiunge un campo che viene inviato con la form)
      DRF.hooks.run('agenda.appuntamento', { $root: $b, valori: Object.assign({ data: st.date }, values || {}), tipi: (st.data && st.data.tipi) || {},
        campo: (html) => { const $f = $(html); $b.find('.field').last().after($f); DRF.ui.wire($f[0]); return $f; }, val: n => DRF.ui.val($b.find(`[name="${n}"]`)), setVal: (n, v) => DRF.ui.setVal($b.find(`[name="${n}"]`), v) });
    }, onSaved: r => {
      st.date = $('#sheetBody [name=data]').val() || st.date; st.sel = r.id;
      if (r.sovrapposizione) DRF.ui.toast(`${DRF.__('Prenotato, ma si sovrappone a')} ${r.sovrapposizione.paziente} (${r.sovrapposizione.ora})`, 'warn');
      else DRF.ui.toast(DRF.__('Prenotazione salvata'));
      if (r.paziente_creato) DRF.ui.toast(`${r.paziente_creato} ${DRF.__('aggiunto all\'archivio: completa l\'anagrafica prima della visita')}`, { fi: 'user-add', fa: 'fa-solid fa-user-plus' });
      if (r.previsita) DRF.ui.toast(`${r.previsita.titolo}${DRF.__(': invio previsto')} ${r.previsita.quando_label}`, { fi: 'paper-plane', fa: 'fa-regular fa-paper-plane' });
      DRF.nav.go('agenda'); load();
    } });
  }

  return {
    title: DRF.__('Agenda'),
    sub() { const n = st.data ? st.data.n_oggi : 0; const m = DRF.config.medico || {}; return `${U.saluto()}, ${m.nome ? m.nome.split(' ')[0] : ''} · ${U.cap(U.fmtLong(U.today()))} · ${DRF._n('%d appuntamento', '%d appuntamenti', n)} ${DRF.__('oggi')}`; },
    action: { label: DRF.__('Nuova prenotazione'), fi: 'calendar-plus', fa: 'fa-regular fa-calendar-plus', run: () => prenota() },
    prenota,

    init() {
      $('#week').on('click', '.day', function () { st.date = this.dataset.d; st.sel = null; load(); });
      $('#timeline').on('click', '.appt', function () { st.sel = +this.dataset.id; $('#timeline .appt').removeClass('on'); $(this).addClass('on'); renderNext(); })
        .on('dblclick', '.appt', function () { const a = st.data.appuntamenti.find(x => +x.id === +this.dataset.id); if (a && a.stato !== 'completato') DRF.module('visita').avvia(+a.paziente_id, +a.id); });
      const shift = n => { const d = U.pd(st.date); if (st.view === 'mese') d.setMonth(d.getMonth() + n); else d.setDate(d.getDate() + n * 7); st.date = U.iso(d); st.sel = null; load(); };
      $('#wkPrev').on('click', () => shift(-1));
      $('#wkNext').on('click', () => shift(1));
      $('#wkToday').on('click', () => { st.date = U.todayIso(); st.sel = null; load(); });
      $('#agView').on('click', 'button', function () { setView(this.dataset.v); });
      $('#month').on('click', '.mday', function () { st.date = this.dataset.d; st.sel = null; setView('giorno'); });
      $('#nextCard').on('click', '#ncBook', () => prenota())
        .on('click', '#ncStart', function () { DRF.module('visita').avvia(+this.dataset.pid, +this.dataset.aid); })
        .on('click', '#ncPat', function () { DRF.nav.go('pazienti', { select: +this.dataset.pid }); })
        .on('click', '#ncEdit', function () { DRF.form.open('appuntamento', { id: +this.dataset.aid, onSaved: () => { DRF.ui.toast(DRF.__('Prenotazione aggiornata')); load(); } }); })
        .on('click', '#ncDel', function () { elimina(+this.dataset.aid); });
      // tasto destro sugli appuntamenti
      DRF.menu.bind($('#timeline'), '.appt', el => {
        const a = st.data.appuntamenti.find(x => +x.id === +el.dataset.id); if (!a) return null;
        st.sel = +a.id; $('#timeline .appt').removeClass('on'); $(el).addClass('on'); renderNext();
        return [
          { label: DRF.__('Inizia visita'), fi: 'play', fa: 'fa-solid fa-play', run: () => DRF.module('visita').avvia(+a.paziente_id, +a.id), disabled: a.stato === 'completato' },
          { label: DRF.__('Scheda paziente'), fi: 'user', fa: 'fa-solid fa-user', run: () => DRF.nav.go('pazienti', { select: +a.paziente_id }) },
          { label: DRF.__('Nuova ricetta'), fi: 'prescription', fa: 'fa-solid fa-prescription', run: () => DRF.nav.go('ricette', { paziente: +a.paziente_id }) },
          { sep: true },
          { label: DRF.__('Modifica prenotazione'), fi: 'pencil', fa: 'fa-solid fa-pen', kbd: 'E', run: () => DRF.form.open('appuntamento', { id: +a.id, onSaved: () => { DRF.ui.toast(DRF.__('Prenotazione aggiornata')); load(); } }) },
          { label: a.stato === 'completato' ? DRF.__('Riporta a prenotato') : DRF.__('Segna come completato'), fi: 'check', fa: 'fa-solid fa-check', run: () => DRF.api.post('agenda', 'stato', { id: a.id, stato: a.stato === 'completato' ? 'prenotato' : 'completato' }).then(() => load()) },
          { label: a.stato === 'assente' ? DRF.__('Riporta a prenotato') : DRF.__('Non presentato'), fi: 'user-slash', fa: 'fa-solid fa-user-slash', run: () => DRF.api.post('agenda', 'stato', { id: a.id, stato: a.stato === 'assente' ? 'prenotato' : 'assente' }).then(() => { if (a.stato !== 'assente') DRF.ui.toast(`${a.paziente}${DRF.__(': segnato come non presentato')}`, 'warn'); load(); }) },
          { sep: true },
          { label: DRF.__('Elimina prenotazione'), fi: 'trash', fa: 'fa-solid fa-trash', danger: true, kbd: 'Canc', run: () => elimina(+a.id) },
        ];
      }, el => ({ title: (st.data.appuntamenti.find(x => +x.id === +el.dataset.id) || {}).paziente }));
      // tasto destro su uno spazio libero della giornata: prenota a quell'ora
      $('#timeline').on('contextmenu', '.slots', function (e) {
        if ($(e.target).closest('.appt').length) return; e.preventDefault();
        const y = e.clientY - this.getBoundingClientRect().top, min = H0() * 60 + Math.floor(y / HH * 60 / 15) * 15, ora = `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;
        DRF.menu.show(e.clientX, e.clientY, [
          { label: `${DRF.__('Nuova prenotazione alle')} ${ora}`, fi: 'calendar-plus', fa: 'fa-regular fa-calendar-plus', run: () => prenota({ ora }) },
          { label: DRF.__('Nuovo paziente'), fi: 'user-add', fa: 'fa-solid fa-user-plus', run: () => DRF.module('pazienti').nuovo() },
          { sep: true }, { label: DRF.__('Vai a oggi'), fi: 'calendar', fa: 'fa-regular fa-calendar', run: () => { st.date = U.todayIso(); st.sel = null; load(); } },
        ], { title: U.cap(U.fmtLong(U.pd(st.date))) });
      });
      DRF.menu.bind($('#month'), '.mday', el => { const k = el.dataset.d, n = (st.mese.giorni[k] || []).length; return [
        { label: DRF.__('Apri la giornata'), fi: 'eye', fa: 'fa-regular fa-eye', run: () => { st.date = k; st.sel = null; setView('giorno'); } },
        { label: DRF.__('Nuova prenotazione'), fi: 'calendar-plus', fa: 'fa-regular fa-calendar-plus', run: () => { st.date = k; prenota(); } },
        n ? { sep: true } : null, n ? { label: `${DRF._n('%d appuntamento', '%d appuntamenti', n)}`, fi: 'info', fa: 'fa-solid fa-circle-info', disabled: true } : null,
      ]; }, el => ({ title: U.cap(U.fmtLong(U.pd(el.dataset.d))) }));
      // scorciatoie sull'appuntamento selezionato
      $(document).on('keydown', e => { if (DRF.state.current !== 'agenda' || !st.sel || /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) || $('#sheet').hasClass('open')) return; if (e.key === 'e' || e.key === 'E') $('#ncEdit').trigger('click'); if (e.key === 'Delete') $('#ncDel').trigger('click'); });
      $('#qBook').on('click', () => prenota());
      $('#qPat').on('click', () => DRF.module('pazienti').nuovo());
      $('#qInv').on('click', () => DRF.module('fatture').nuova());
      setInterval(() => { if (DRF.state.current === 'agenda' && st.data && st.view === 'giorno') { renderTimeline(); if (!st.sel) load(); } }, 60000);
    },
    show(opts) {
      if (opts && opts.date) st.date = opts.date;
      if (opts && opts.select) { st.sel = opts.select; if (st.view !== 'giorno') return setView('giorno'); }
      load();
    }
  };
})(jQuery));
