/* Modulo Ricette: composizione della ricetta dematerializzata, invio, storico */
DRF.register('ricette', (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;
  const st = { farmaci: [], pazienti: [], righe: [], recenti: [], totale: 0, pazientePreselezionato: null };

  function load() {
    return DRF.api.get('ricette', 'dati').then(d => {
      st.farmaci = d.farmaci; st.pazienti = d.pazienti; st.recenti = d.recenti; st.totale = d.totale;
      const cur = st.pazientePreselezionato || $('#rxPat').val();
      $('#rxPat').html(`<option value="">${DRF.__('Seleziona paziente…')}</option>` + st.pazienti.map(p => `<option value="${p.id}">${DRF.esc(p.nome_completo)}</option>`).join('')).val(cur || '').trigger('change');
      st.pazientePreselezionato = null;
      $('#rxList').html(st.farmaci.map(f => `<option value="${DRF.esc(f.nome)}">${DRF.esc(f.principio || '')}</option>`).join(''));
      const es = $('#rxEs').val();
      $('#rxEs').html('<option value="">' + DRF.__('Nessuna') + '</option>' + (d.esenzioni || []).map(e => `<option value="${DRF.esc(e.codice)}">${DRF.esc(e.codice)}${e.descrizione ? ' · ' + DRF.esc(e.descrizione) : ''}</option>`).join('')).val(es || '').trigger('change');
      $('#rxSuggest').html(st.farmaci.filter(f => +f.preferito).slice(0, 6).map(f => `<button class="chip" data-id="${f.id}">${DRF.esc(f.nome.split(' ')[0])}</button>`).join(''));
      renderRighe(); renderHist(); DRF.nav.refreshSub();
    });
  }
  function renderRighe() {
    $('#rxLines').html(st.righe.map((l, i) => `<div class="rxline"><span class="ib">${I('capsules', 'fa-solid fa-pills')}</span><div><b>${DRF.esc(l.f.nome)}</b><span>${DRF.esc(l.f.principio || '')}${l.f.confezione ? ' · ' + DRF.esc(l.f.confezione) : ''}${l.f.posologia ? ' · ' + DRF.esc(l.f.posologia) : ''}</span></div><div class="qty"><button type="button" data-q="-1" data-i="${i}">−</button><span class="num">${l.q}</span><button type="button" data-q="1" data-i="${i}">+</button></div><button type="button" class="del" data-del="${i}" title="${DRF.__('Rimuovi')}">${I('trash', 'fa-solid fa-trash')}</button></div>`).join('')
      || `<div class="empty" style="padding:22px">${DRF.__('Nessun farmaco in ricetta.')}<br>${DRF.__('Cerca un farmaco qui sopra o scegli tra i più usati.')}</div>`);
    DRF.icons.apply($('#rxLines')[0]);
    slot();
  }
  function slot() { DRF.hooks.run('ricetta.editor', { $root: $('[data-panel="ricette"]'), righe: st.righe, farmaci: st.farmaci || [], aggiungi: add, rendi: renderRighe, paziente: () => DRF.ui.val($('#rxPat')) }); }
  function renderHist() {
    $('#rxHist').html(st.recenti.map(r => `<div><div><b>${DRF.esc(r.paziente)}</b><span>${U.fmtIso(r.data)} · ${r.righe.map(x => DRF.esc(x.farmaco) + ' ×' + x.quantita).join(', ')} · <span class="nre">${DRF.esc(r.nre)}</span> · <a href="#" data-doc="ricetta" data-id="${r.id}">promemoria</a></span></div>${DRF.ui.badge(r.tipo === 'ssn' ? 'sky' : 'violet', r.tipo === 'ssn' ? 'SSN' : DRF.__('Bianca'))}</div>`).join('') || '<span class="muted small">' + DRF.__('Nessuna ricetta emessa.') + '</span>');
  }
  function add(f) { const ex = st.righe.find(l => l.f.id === f.id); if (ex) ex.q = Math.min(3, ex.q + 1); else st.righe.push({ f, q: 1 }); renderRighe(); }
  function addFromInput() {
    const q = $('#rxSearch').val().trim().toLowerCase(); if (!q) return;
    const f = st.farmaci.find(x => x.nome.toLowerCase() === q) || st.farmaci.find(x => x.nome.toLowerCase().includes(q) || (x.principio || '').toLowerCase().includes(q));
    if (!f) return DRF.ui.toast(`${DRF.__('Nessun farmaco trovato per “')}${$('#rxSearch').val()}${DRF.__('”. Puoi aggiungerlo al prontuario con il pulsante accanto.')}`, 'warn');
    add(f); $('#rxSearch').val('');
  }

  return {
    title: DRF.__('Ricette'),
    sub() { return `${DRF.__('Ricetta dematerializzata ·')} ${DRF._n('%d inviata', '%d inviate', st.totale)} ${DRF.__('al Sistema TS')}`; },
    action: null,

    init() {
      $('#rxSuggest').on('click', '.chip', function () { const f = st.farmaci.find(x => +x.id === +this.dataset.id); if (f) add(f); });
      $('#rxAddBtn').on('click', addFromInput);
      $('#rxSearch').on('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addFromInput(); } })
        .on('change', function () { const f = st.farmaci.find(x => x.nome === this.value); if (f) { add(f); this.value = ''; } });
      $('#rxLines').on('click', '[data-q]', function () { const l = st.righe[+this.dataset.i]; l.q = Math.max(1, Math.min(3, l.q + +this.dataset.q)); renderRighe(); })
        .on('click', '[data-del]', function () { st.righe.splice(+this.dataset.del, 1); renderRighe(); });
      $('#rxNewDrug').on('click', () => DRF.form.open('farmaco', { values: { nome: $('#rxSearch').val() }, onSaved: r => { $('#rxSearch').val(''); load().then(() => { const f = st.farmaci.find(x => +x.id === +r.id); if (f) add(f); }); } }));
      $('#rxSend').on('click', () => {
        const pid = +$('#rxPat').val();
        if (!pid) return DRF.ui.toast(DRF.__('Seleziona il paziente della ricetta'), 'warn');
        if (!st.righe.length) return DRF.ui.toast(DRF.__('Aggiungi almeno un farmaco'), 'warn');
        // modale con la barra dei passi: firma → invio al Sistema TS → NRE → promemoria
        let steps, esito = null;
        DRF.ui.modal({ title: DRF.__('Invio della ricetta'), ok: DRF.__('Apri promemoria'), cancel: DRF.__('Chiudi'), html: '<div id="rxSteps"></div><div id="rxStepLog" class="small muted" style="margin-top:16px;text-align:center">' + DRF.__('Firma digitale in corso…') + '</div>',
          onOpen($b) { steps = DRF.ui.steps($b.find('#rxSteps'), { current: 0, steps: [{ label: DRF.__('Firma'), fi: 'document-signed', fa: 'fa-solid fa-file-signature' }, { label: DRF.__('Invio al Sistema TS'), fi: 'paper-plane', fa: 'fa-regular fa-paper-plane' }, { label: DRF.__('Ricezione NRE'), fi: 'barcode', fa: 'fa-solid fa-barcode' }, { label: DRF.__('Promemoria'), fi: 'print', fa: 'fa-solid fa-print' }] }); $('#modalOk').prop('disabled', true); },
          onOk() { if (esito) DRF.doc.apri('ricetta', esito.ricetta.id); } });
        const log = t => $('#rxStepLog').text(t);
        setTimeout(() => { steps.set(1); log(DRF.__('Invio al Sistema Tessera Sanitaria…')); }, 600);
        DRF.api.post('ricette', 'invia', { paziente_id: pid, tipo: DRF.ui.segValue($('#rxType')), esenzione: $('#rxEs').val(), note: $('#rxNote').val(), righe: st.righe.map(l => ({ farmaco_id: l.f.id, quantita: l.q })) }).then(r => {
          esito = r; st.righe = []; $('#rxNote').val(''); DRF.ui.setSelect($('#rxEs'), ''); st.recenti = r.recenti; st.totale = r.totale; renderRighe(); renderHist(); DRF.nav.refreshSub();
          setTimeout(() => { steps.set(2); log('NRE ricevuto: ' + r.ricetta.nre); }, 1100);
          setTimeout(() => { steps.done(); log(DRF.__('Ricetta inviata · NRE ') + r.ricetta.nre + ' · il promemoria è pronto'); $('#modalOk').prop('disabled', false); DRF.ui.toast(`${DRF.__('Ricetta inviata · NRE')} ${r.ricetta.nre}`, { fi: 'paper-plane', fa: 'fa-regular fa-paper-plane' }); }, 1800);
        }, () => { if (steps) steps.error(1, DRF.__('Invio non riuscito')); log(DRF.__('Invio non riuscito: controlla i dati e riprova.')); $('#modalOk').prop('disabled', true); });
      });
    },
    show(opts) { if (opts && opts.paziente) st.pazientePreselezionato = opts.paziente; load(); }
  };
})(jQuery));
