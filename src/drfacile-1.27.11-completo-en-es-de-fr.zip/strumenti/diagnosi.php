<?php
/**
 * Diagnosi dell'installazione: php strumenti/diagnosi.php
 * Progettata per parlare SEMPRE: prima la parte senza database (versioni e impronte
 * dei file, per scovare file vecchi sul disco), poi il database — e se la connessione
 * fallisce lo dice chiaramente invece di restare muta.
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
ini_set('display_errors', '1');
error_reporting(E_ALL);

$root = dirname(__DIR__);
echo "DRFacile — diagnosi (PHP " . PHP_VERSION . ")\n";
echo "  cartella: $root\n";

/* ---- Parte 1: solo filesystem, nessun database ---- */
$src = @file_get_contents("$root/core/Installer.php") ?: '';
preg_match("/VERSIONE = '([^']+)'/", $src, $mv);
preg_match("/SCHEMA = '([^']+)'/", $src, $ms);
echo "  versione file:   " . ($mv[1] ?? 'irriconoscibile') . " · schema atteso: " . ($ms[1] ?? '?') . "\n";
$attese = is_file("$root/docs/impronte.json") ? (json_decode((string) file_get_contents("$root/docs/impronte.json"), true) ?: []) : [];
if (!$attese) {
    echo "  docs/impronte.json ASSENTE: pacchetto applicato a metà ← problema!\n";
} else {
    $marci = [];
    foreach ($attese as $f => $md5) {
        $mio = is_file("$root/$f") ? substr(md5_file("$root/$f"), 0, 10) : 'MANCANTE';
        if ($mio !== $md5) $marci[$f] = $mio;
    }
    echo "  controllo INTEGRALE dei file: " . count($attese) . " nel manifest · " . (count($attese) - count($marci)) . " aggiornati\n";
    if ($marci) {
        echo "  FILE VECCHI O MANCANTI (← ecco il problema):\n";
        foreach (array_slice($marci, 0, 40, true) as $f => $mio) printf("    ✘ %-46s %s\n", $f, $mio);
        echo "  → riapplica il pacchetto sovrascrivendo TUTTI questi file.\n";
    } else {
        echo "  → TUTTI i file sul disco sono quelli giusti.\n";
    }
}

/* ---- Parte 2: il database (se fallisce, dice perché) ---- */
try {
    require "$root/core/bootstrap.php";
    echo "  database:        " . Database::driver() . " · schema nel db: " . (Impostazione::get('schema_versione') ?: '—') . "\n";
    if (Database::driver() === 'sqlite') {
        $f = Config::get('database.sqlite', DRF_ROOT . '/data/drfacile.sqlite');
        echo "  file sqlite:     $f (" . (is_file($f) ? round(filesize($f) / 1024) . ' KB' : 'assente') . ")\n";
        echo "  ATTENZIONE: se ti aspettavi MySQL, il config e' stato sovrascritto: sistemalo in config/config.php\n";
    } else {
        echo "  mysql:           " . (string) Config::get('db.mysql.dsn') . "\n";
    }
    $c = Database::colonneTipi('visite');
    echo "  visite.dati:     " . (isset($c['dati']) ? "presente ({$c['dati']})" : 'ASSENTE ← problema!') . "\n";
    echo "  estensioni attive:\n";
    foreach (Database::all('SELECT codice, versione, scadenza FROM estensioni WHERE attiva = 1') as $e) {
        echo "    - {$e['codice']} v{$e['versione']}" . ($e['scadenza'] ? " (scade {$e['scadenza']})" : '') . "\n";
    }
    $v = Database::one('SELECT id, stato, dati FROM visite ORDER BY id DESC LIMIT 1');
    if ($v) {
        $dati = json_decode((string) $v['dati'], true) ?: [];
        echo "  ultima visita:   #{$v['id']} ({$v['stato']}) · dati estensioni: " . ($dati ? implode(', ', array_keys($dati)) : 'vuoti') . "\n";
    }
} catch (Throwable $e) {
    echo "  DATABASE NON RAGGIUNGIBILE da questo PHP: " . $e->getMessage() . "\n";
    echo "  (capita col PHP di sistema su macOS: usa il PHP di MAMP, es.\n";
    echo "   /Applications/MAMP/bin/php/php8.*/bin/php strumenti/diagnosi.php\n";
    echo "   — la parte sopra, con le impronte, resta comunque valida.)\n";
}
echo "Incolla nella chat tutto questo output.\n";
