<?php
final class Referto extends Model
{
    protected static string $table = 'referti';
    protected static array $fillable = ['paziente_id', 'visita_id', 'tipo', 'data', 'stato', 'sezioni', 'file', 'firmato_il', 'inviato_il'];
    protected static array $json = ['sezioni'];

    public const STATI = ['bozza' => 'Bozza', 'firmato' => 'Firmato', 'inviato' => 'Inviato'];

    public static function lista(string $stato = 'tutti'): array
    {
        $where = $stato !== 'tutti' && isset(self::STATI[$stato]) ? 'r.stato = ?' : '1=1';
        $rows = Database::all("SELECT r.id, r.tipo, r.data, r.stato, r.paziente_id, p.nome, p.cognome FROM referti r JOIN pazienti p ON p.id = r.paziente_id WHERE $where ORDER BY r.data DESC, r.id DESC", $where === '1=1' ? [] : [$stato]);
        return array_map(fn($r) => ['id' => (int) $r['id'], 'tipo' => $r['tipo'], 'data' => $r['data'], 'stato' => $r['stato'], 'stato_label' => self::STATI[$r['stato']], 'paziente_id' => (int) $r['paziente_id'], 'paziente' => nome_completo($r)], $rows);
    }

    public static function contaBozze(): int { return self::count("stato = 'bozza'"); }

    public static function firma(int $id): array
    {
        $r = self::find($id); if (!$r) throw new ApiException(__('Referto non trovato'));
        if ($r['stato'] !== 'bozza') throw new ApiException(__('Il referto è già firmato'));
        self::save(['id' => $id, 'stato' => 'firmato', 'firmato_il' => date('Y-m-d H:i:s')]);
        Documenti::archivia('referto', $id);
        Attivita::registra('referto.firmato', 'referti', $id, nome_completo(Paziente::find((int) $r['paziente_id']) ?? []) . ' · ' . $r['tipo']);
        Hooks::run('referto.firmato', $id, self::find($id));
        return self::find($id);
    }

    public static function invia(int $id): array
    {
        $r = self::find($id); if (!$r) throw new ApiException(__('Referto non trovato'));
        if ($r['stato'] === 'bozza') throw new ApiException(__('Firma il referto prima di inviarlo'));
        // L'invio reale (email/PEC/FSE) lo fa un'estensione con l'hook referto.invia (filter: ritorna false per bloccare); il core registra lo stato.
        if (Hooks::filter('referto.invia', true, $id, $r) === false) throw new ApiException(__('Invio non riuscito'));
        // invio standard del core: email al paziente con il PDF allegato (driver in config comunicazioni.email; 'log' registra e basta)
        $p = Paziente::find((int) $r['paziente_id']) ?? [];
        if (!empty($p['email']) && !Hooks::has('referto.invia')) {
            $medico = Impostazione::profilo();
            $cid = Comunicazioni::invia('email', (string) $p['email'], 'Referto del ' . data_it($r['data']) . ' · ' . $medico['studio'],
                '<p>Gentile ' . e($p['nome_completo']) . ',</p><p>in allegato il referto della visita del ' . e(data_it($r['data'])) . '.</p><p>Cordiali saluti,<br>' . e($medico['nome_completo']) . ($medico['studio'] ? '<br>' . e($medico['studio']) : '') . '</p>',
                ['rif' => "referto-$id", 'allegati' => [['nome' => 'referto-' . data_it($r['data']) . '.pdf', 'contenuto' => Documenti::pdf('referto', $id), 'mime' => 'application/pdf']]]);
            $c = Database::one('SELECT stato, errore FROM comunicazioni WHERE id = ?', [$cid]);
            if ($c && $c['stato'] === 'errore') throw new ApiException('Invio email non riuscito: ' . $c['errore']);
        } elseif (empty($p['email']) && !Hooks::has('referto.invia')) throw new ApiException(__('Il paziente non ha un indirizzo email: aggiungilo nella scheda'));
        self::save(['id' => $id, 'stato' => 'inviato', 'inviato_il' => date('Y-m-d H:i:s')]);
        Hooks::run('referto.inviato', $id);
        Attivita::registra('referto.inviato', 'referti', $id, nome_completo(Paziente::find((int) $r['paziente_id']) ?? []) . ' · ' . $r['tipo']);
        return self::find($id);
    }
}
