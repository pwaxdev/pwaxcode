<?php
/** Recupero password (multi-utente): si indica il nome utente, il codice arriva ai SUOI recapiti
    (email o SMS via endpoint Comunicazioni) e la nuova password viene salvata sul suo account.
    Le richieste vivono nella tabella comune `password_reset` (una riga ciascuna: più utenti in contemporanea,
    anche di studi diversi, senza sovrascriversi); codice in hash, 15 minuti, 5 tentativi, 3 codici ogni 15 minuti. */
require __DIR__ . '/core/bootstrap.php';
if (Auth::check()) { header('Location: index.php'); exit; }
$passo = 'utente'; $errore = ''; $avviso = ''; $canale = $_POST['canale'] ?? ''; $username = strtolower(trim((string) ($_POST['username'] ?? '')));
$maschera = fn(string $s, int $vis = 2) => $s === '' ? '—' : mb_substr($s, 0, $vis) . str_repeat('•', max(3, mb_strlen($s) - $vis - 4)) . mb_substr($s, -4);
$demoLog = (Config::get('comunicazioni.email.driver') ?? 'log') === 'log' && (Config::get('comunicazioni.sms.driver') ?? 'log') === 'log';

$PR = Database::comune('password_reset');
$adesso = date('Y-m-d H:i:s');
$chiavi = RateLimit::chiavi('recupero', $username);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['passo'] ?? '') === 'invia') {
    if ($attesa = RateLimit::bloccato($chiavi)) { $errore = RateLimit::messaggio($attesa); $u = null; }
    else $u = $username !== '' ? Utente::perUsername($username) : null;
    if (!$errore) RateLimit::fallito($chiavi);   // ogni richiesta di codice conta come tentativo: frena chi enumera i nomi utente
    $canale = in_array($canale, ['email', 'sms'], true) ? $canale : 'email';
    // risposta identica con utente inesistente: non riveliamo quali nomi utente esistono
    if ($u) {
        $dest = $canale === 'email' ? (string) $u['email'] : (string) $u['telefono'];
        $recenti = (int) Database::value("SELECT COUNT(*) FROM $PR WHERE utente_id = ? AND creato_il > ?", [(int) $u['id'], date('Y-m-d H:i:s', time() - 900)]);
        if ($dest !== '' && $recenti < 3) {   // al massimo 3 codici ogni 15 minuti per utente
            $codice = (string) random_int(100000, 999999);
            Database::run("UPDATE $PR SET usato = 1 WHERE utente_id = ? AND usato = 0", [(int) $u['id']]);   // vale solo l'ultimo codice
            Database::run("INSERT INTO $PR (utente_id, codice_hash, canale, scadenza, tentativi, usato, ip, creato_il) VALUES (?, ?, ?, ?, 0, 0, ?, ?)",
                [(int) $u['id'], password_hash($codice, PASSWORD_DEFAULT), $canale, date('Y-m-d H:i:s', time() + 15 * 60), (string) ($_SERVER['REMOTE_ADDR'] ?? ''), $adesso]);
            Database::run("DELETE FROM $PR WHERE scadenza < ?", [date('Y-m-d H:i:s', time() - 86400)]);   // pulizia: righe più vecchie di un giorno
            $testo = $canale === 'email'
                ? '<p>Il codice per reimpostare la password di DRFacile è <b style="font-size:18px">' . $codice . '</b>.</p><p>Vale 15 minuti. Se non l\'hai richiesto, ignora questo messaggio.</p>'
                : "DRFacile: il codice per reimpostare la password e' $codice (vale 15 minuti).";
            Comunicazioni::invia($canale, $dest, 'DRFacile · codice di recupero password', $testo, ['rif' => 'recupero-password']);
            if ($demoLog) $avviso = "Canale dimostrativo ('log' in config): il codice è $codice";
        }
    }
    $passo = $errore ? 'utente' : 'codice';
    if (!$errore) $avviso = trim('Se il nome utente esiste e ha un recapito ' . ($canale === 'email' ? 'email' : 'telefonico') . ', il codice è in arrivo. ' . $avviso);
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['passo'] ?? '') === 'reimposta') {
    $passo = 'codice';
    if ($attesa = RateLimit::bloccato($chiavi)) { $errore = RateLimit::messaggio($attesa); }
    $u = !$errore && $username !== '' ? Utente::perUsername($username) : null;
    $r = $u ? Database::one("SELECT * FROM $PR WHERE utente_id = ? AND usato = 0 ORDER BY id DESC LIMIT 1", [(int) $u['id']]) : null;
    $nuova = (string) ($_POST['nuova'] ?? ''); $conferma = (string) ($_POST['conferma'] ?? '');
    if ($errore) { /* bloccato */ }
    elseif (!$r || $r['scadenza'] < $adesso) $errore = 'Codice scaduto: richiedine uno nuovo.';
    elseif ((int) $r['tentativi'] >= 5) $errore = 'Troppi tentativi: richiedi un nuovo codice.';
    elseif (!password_verify((string) ($_POST['codice'] ?? ''), $r['codice_hash'])) { Database::run("UPDATE $PR SET tentativi = tentativi + 1 WHERE id = ?", [(int) $r['id']]); RateLimit::fallito($chiavi); $errore = 'Codice non corretto.'; }
    elseif (strlen($nuova) < 8) $errore = 'La nuova password deve avere almeno 8 caratteri.';
    elseif ($nuova !== $conferma) $errore = 'Le due password non coincidono.';
    else {
        Database::run('UPDATE ' . Database::comune('utenti') . ' SET password_hash = ? WHERE id = ?', [password_hash($nuova, PASSWORD_DEFAULT), (int) $u['id']]);
        Database::run("UPDATE $PR SET usato = 1 WHERE utente_id = ?", [(int) $u['id']]);
        RateLimit::azzera($chiavi);
        try {   // il registro attività è dello studio dell'utente (se il suo database è già pronto)
            Tenant::attiva((int) $u['studio_id']);
            if (Database::tableExists('attivita')) Attivita::registra('password.reimpostata', 'impostazioni', (int) $u['id'], 'Recupero via ' . ($canale ?: 'email'));
        } catch (Throwable $e) { error_log('Recupero password: ' . $e->getMessage()); }
        header('Location: login.php?reimpostata=1'); exit;
    }
}
?>
<!DOCTYPE html>
<html lang="it" data-theme="light">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Recupero password · <?= e(Config::get('app.name')) ?></title>
<link rel="icon" href="assets/images/favicon.svg">
<link rel="stylesheet" href="assets/vendor/fonts/fonts.css">
<link rel="stylesheet" href="assets/css/app.css">
<link rel="stylesheet" href="assets/css/login.css">
</head>
<body class="login-body">
<main class="login">
  <img class="login-logo" src="assets/images/logo.svg" alt="<?= e(Config::get('app.name')) ?>">
  <h1><?= __('Recupero password') ?></h1>
  <?php if ($passo === 'utente'): ?>
  <p class="muted"><?= __('Indica il tuo nome utente e dove ricevere il codice di verifica.') ?></p>
  <form method="post">
    <?php if ($errore): ?><div class="login-errore"><?= e($errore) ?></div><?php endif; ?>
    <input type="hidden" name="passo" value="invia">
    <div class="field"><label for="u"><?= __('Nome utente') ?></label><input class="input" id="u" name="username" autocomplete="username" autofocus required></div>
    <label class="login-scelta"><input type="radio" name="canale" value="email" checked><span><b>Email</b><small><?= __('all\'indirizzo del tuo account') ?></small></span></label>
    <label class="login-scelta"><input type="radio" name="canale" value="sms"><span><b>SMS</b><small><?= __('al numero del tuo account') ?></small></span></label>
    <button class="btn primary block" type="submit"><?= __('Invia il codice') ?></button>
  </form>
  <?php else: ?>
  <p class="muted"><?= __('Inserisci il codice ricevuto e la nuova password.') ?></p>
  <form method="post">
    <?php if ($errore): ?><div class="login-errore"><?= e($errore) ?></div><?php endif; ?>
    <?php if ($avviso): ?><div class="login-avviso"><?= e($avviso) ?></div><?php endif; ?>
    <input type="hidden" name="passo" value="reimposta"><input type="hidden" name="canale" value="<?= e($canale) ?>"><input type="hidden" name="username" value="<?= e($username) ?>">
    <div class="field"><label for="c"><?= __('Codice di verifica') ?></label><input class="input mono" id="c" name="codice" inputmode="numeric" maxlength="6" autofocus required></div>
    <div class="field"><label for="n"><?= __('Nuova password') ?></label><input class="input" id="n" type="password" name="nuova" minlength="8" required></div>
    <div class="field"><label for="k"><?= __('Ripeti la nuova password') ?></label><input class="input" id="k" type="password" name="conferma" required></div>
    <button class="btn primary block" type="submit"><?= __('Reimposta la password') ?></button>
  </form>
  <?php endif; ?>
  <p class="small muted login-hint"><a href="login.php"><?= __('← Torna all\'accesso') ?></a></p>
</main>
</body>
</html>
