/* Sentinella · gli SLOT dell'interfaccia (Extension API 2.0): scheda paziente, Scrivania, barra del titolo, ricerca, notifiche, referto, scorciatoia */
(function ($) {
  'use strict';
  const I = DRF.icons.html;

  // semafori e segnalazioni nella scheda del paziente + pulsante "Richiamo"
  DRF.hooks.add('paziente.scheda', ctx => {
    DRF.api.ext('sentinella', 'paziente', { id: ctx.paziente.id }).then(d => {
      ctx.aggiungi(`<div class="sent-card">${d.semafori.map(([c, t]) => DRF.ui.badge(c, t)).join(' ')}${d.aperte.length ? `<ul>${d.aperte.map(s => `<li>${I('eye', 'fa-regular fa-eye')} ${DRF.esc(s.titolo)}</li>`).join('')}</ul>` : ''}</div>`, 'prima');
      if (d.aperte.some(s => s.tipo === 'assente' || s.tipo === 'controllo')) ctx.azione('Richiamo', () => ctx.prenota(), { fi: 'phone-call', fa: 'fa-solid fa-phone' });
    });
  });

  // riquadro in Scrivania: il quadro di oggi
  DRF.hooks.add('dashboard.widget', ctx => {
    DRF.api.ext('sentinella', 'oggi').then(d => {
      const righe = d.oggi.filter(a => a.note.length).slice(0, 5);
      ctx.aggiungi(`<div class="sent-w">${d.aperte ? `<a href="#" data-sent-go class="sent-w-n"><b>${d.aperte}</b> ${d.aperte === 1 ? 'segnalazione aperta' : 'segnalazioni aperte'}${d.gravi ? ` · <span style="color:var(--rose)">${d.gravi} urgenti</span>` : ''}</a>` : '<span class="muted">Nessuna segnalazione aperta</span>'}
        ${righe.length ? `<div class="small muted" style="margin-top:6px">Oggi, un occhio in più a:</div>${righe.map(a => `<div class="sent-w-row"><span class="mono">${a.ora}</span> <b>${DRF.esc(a.paziente)}</b> <span class="muted">${a.note.join(' · ')}</span></div>`).join('')}` : ''}</div>`, 'Sentinella')
        .on('click', '[data-sent-go]', e => { e.preventDefault(); DRF.desk.close(); ctx.vai('sentinella'); });
    });
  });

  // pulsante nella barra del titolo dell'agenda: il quadro del giorno in un modale
  DRF.hooks.add('topbar.azioni', (az, modulo) => modulo !== 'agenda' ? az : [...az, { label: 'Chi vedo oggi', fi: 'eye', fa: 'fa-regular fa-eye', run: () =>
    DRF.api.ext('sentinella', 'oggi').then(d => DRF.ui.modal({ title: 'Sentinella · chi vedo oggi', ok: false, cancel: 'Chiudi',
      html: d.oggi.length ? `<div class="sent-modal">${d.oggi.map(a => `<div class="sent-w-row"><span class="mono">${a.ora}</span> <b>${DRF.esc(a.paziente)}</b> ${a.note.length ? a.note.map(n => DRF.ui.badge('amber', n)).join(' ') : DRF.ui.badge('mint', 'ok')}</div>`).join('')}</div>` : '<div class="empty">Nessun appuntamento oggi.</div>' })) }]);

  // ricerca ⌘K, notifiche, scorciatoia
  DRF.hooks.add('search.comandi', ctx => { ctx.comando({ label: 'Sentinella: segnalazioni aperte', fi: 'eye', fa: 'fa-regular fa-eye', kw: 'sentinella vigilanza richiami controlli scaduti', run: () => DRF.nav.go('sentinella') }); ctx.comando({ label: 'Sentinella: scansiona ora', fi: 'refresh', fa: 'fa-solid fa-rotate', kw: 'sentinella scansione', run: () => DRF.module('sentinella').action.run() }); });
  DRF.hooks.add('notifiche.tipi', t => Object.assign({}, t, { sentinella: ['eye', 'fa-regular fa-eye'] }));
  DRF.tasti.add('ctrl+shift+s', () => DRF.nav.go('sentinella'), 'Sentinella: apri le segnalazioni');

  // sul referto firmato: pulsante che prenota il controllo
  DRF.hooks.add('referto.editor', ctx => { if (!ctx.bozza) ctx.azione('Prenota il controllo', () => DRF.module('agenda').prenota({ paziente_id: ctx.paziente.id }), { fi: 'calendar', fa: 'fa-regular fa-calendar' }); });
})(jQuery);
