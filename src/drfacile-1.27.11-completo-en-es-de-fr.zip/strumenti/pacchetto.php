<?php
/**
 * PACCHETTO: crea lo ZIP di un'estensione per lo Store a partire da estensioni/<codice>/ (con manifest.json).
 *
 *   php strumenti/pacchetto.php consigli                       → ./consigli-1.0.zip nella cartella corrente
 *   php strumenti/pacchetto.php consigli /percorso/repository  → in <repository>/pacchetti/consigli-1.0.zip (poi: php strumenti/repository.php <repository>)
 *
 * Controlli: manifest valido (codice = cartella, versione, nome), niente config o file nascosti nel pacchetto.
 * Lo ZIP contiene i file alla RADICE (manifest.json, estensione.php, js/, css/, ajax.php, modules/, assets/…).
 */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Solo da riga di comando'); }
require __DIR__ . '/../core/bootstrap.php';
if (!class_exists('ZipArchive')) exit("Serve l'estensione PHP zip\n");

$codice = preg_replace('/[^a-z0-9_]/', '', strtolower((string) ($argv[1] ?? '')));
$dest = rtrim((string) ($argv[2] ?? getcwd()), '/');
if ($codice === '') exit("Uso: php strumenti/pacchetto.php <codice> [cartella repository]\n");
$dir = Store::dir($codice);
if (!is_dir($dir)) exit("Cartella non trovata: estensioni/$codice\n");
$m = json_decode((string) @file_get_contents("$dir/manifest.json"), true);
if (!is_array($m)) exit("manifest.json mancante o non valido in estensioni/$codice\n");
$n = Store::normalizza($m) ?? exit("manifest.json incompleto (servono almeno codice, nome, versione; codice = lettere/numeri/_)\n");
if ($n['codice'] !== $codice) exit("Il codice nel manifest ({$n['codice']}) non coincide con la cartella ($codice)\n");
if ($argv[2] ?? null) $dest .= '/pacchetti';   // dentro un repository i pacchetti stanno in pacchetti/
if (!is_dir($dest)) mkdir($dest, 0775, true);
$file = "$dest/$codice-{$n['versione']}.zip";

$zip = new ZipArchive();
if ($zip->open($file, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) exit("Impossibile creare $file\n");
$n_file = 0;
foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST) as $f) {
    $rel = str_replace('\\', '/', substr($f->getPathname(), strlen($dir) + 1));
    if (str_starts_with(basename($rel), '.') || preg_match('~(^|/)(node_modules|\.git)(/|$)~', $rel)) continue;
    if ($f->isDir()) { $zip->addEmptyDir($rel); continue; }
    $zip->addFile($f->getPathname(), $rel); $n_file++;
}
$zip->close();
printf("%s · %s v%s · %d file · %d KB · sha256 %s\n", basename($file), $n['nome'], $n['versione'], $n_file, round(filesize($file) / 1024), hash_file('sha256', $file));
if (is_file(dirname($dest) . '/catalogo.json')) echo "Ora aggiorna il catalogo: php strumenti/repository.php " . dirname($dest) . "\n";
