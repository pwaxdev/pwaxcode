<?php
return [
    'title' => __('Nuovo paziente'), 'title_edit' => __('Modifica scheda paziente'),
    'endpoint' => 'pazienti', 'action' => 'save', 'submit' => __('Crea paziente'), 'submit_edit' => __('Salva scheda'),
    'model' => 'Paziente', 'wide' => true,
    'fields' => [
        ['name' => 'cognome', 'label' => __('Cognome'), 'type' => 'text', 'required' => true, 'row' => 1, 'w' => 6],
        ['name' => 'nome', 'label' => __('Nome'), 'type' => 'text', 'required' => true, 'row' => 1, 'w' => 6],

        ['name' => 'indirizzo', 'label' => __('Indirizzo'), 'type' => 'text', 'row' => 2, 'w' => 5],
        ['name' => 'citta', 'label' => __('Città'), 'type' => 'comune', 'fill' => ['cap' => 'cap', 'provincia' => 'provincia'], 'row' => 2, 'w' => 4],
        ['name' => 'cap', 'label' => 'CAP', 'type' => 'text', 'mask' => 'cap', 'row' => 2, 'w' => 2],
        ['name' => 'provincia', 'label' => 'PV', 'type' => 'text', 'attrs' => ['maxlength' => 2, 'style' => 'text-transform:uppercase'], 'row' => 2, 'w' => 1],

        ['name' => 'cf', 'label' => __('Codice fiscale'), 'type' => 'cf', 'row' => 3, 'w' => 4],
        ['name' => 'piva', 'label' => __('Partita IVA'), 'type' => 'text', 'class' => 'mono', 'attrs' => ['maxlength' => 16], 'row' => 3, 'w' => 3],
        ['name' => 'rappresentato', 'label' => __('Rappresentato legalmente'), 'type' => 'switch', 'inline' => true, 'default' => 0, 'row' => 3, 'w' => 5],

        ['name' => 'sesso', 'label' => __('Sesso'), 'type' => 'seg', 'options' => ['M' => 'M', 'F' => 'F'], 'default' => 'F', 'row' => 4, 'w' => 2],
        ['name' => 'nascita', 'label' => __('Data di nascita'), 'type' => 'date', 'row' => 4, 'w' => 3],
        ['name' => 'comune_nascita', 'label' => __('Comune di nascita'), 'type' => 'comune', 'fill' => ['cod' => 'cod_nascita'], 'row' => 4, 'w' => 7],
        ['name' => 'cod_nascita', 'type' => 'hidden'],

        ['name' => 'rapp_sezione', 'type' => 'section', 'label' => __('Rappresentante legale'), 'hint' => 'genitore, tutore o amministratore di sostegno', 'show_if' => 'rappresentato'],
        ['name' => 'rapp_nome', 'label' => __('Nome e cognome'), 'type' => 'text', 'row' => 5, 'w' => 5, 'show_if' => 'rappresentato'],
        ['name' => 'rapp_cf', 'label' => __('Codice fiscale'), 'type' => 'text', 'class' => 'mono', 'attrs' => ['maxlength' => 16, 'style' => 'text-transform:uppercase'], 'row' => 5, 'w' => 4, 'show_if' => 'rappresentato'],
        ['name' => 'rapp_telefono', 'label' => __('Telefono'), 'type' => 'tel', 'row' => 5, 'w' => 3, 'show_if' => 'rappresentato'],

        ['name' => 'contatti', 'type' => 'section', 'label' => __('Contatti e provenienza')],
        ['name' => 'professione', 'label' => __('Professione'), 'type' => 'text', 'row' => 6, 'w' => 4],
        ['name' => 'inviato_da', 'label' => __('Inviato da'), 'type' => 'text', 'placeholder' => __('medico, collega, struttura…'), 'row' => 6, 'w' => 4],
        ['name' => 'provenienza', 'label' => __('Provenienza'), 'type' => 'select', 'empty' => __('Seleziona…'), 'options' => ['Passaparola' => __('Passaparola'), 'Medico curante' => __('Medico curante'), 'Internet' => __('Internet'), 'Pubblicità' => __('Pubblicità'), 'Convenzione' => __('Convenzione'), 'Altro' => __('Altro')], 'row' => 6, 'w' => 4],
        ['name' => 'cellulare', 'label' => __('Cellulare'), 'type' => 'tel', 'row' => 7, 'w' => 3],
        ['name' => 'telefono', 'label' => __('Telefono'), 'type' => 'tel', 'row' => 7, 'w' => 3],
        ['name' => 'email', 'label' => 'Email', 'type' => 'email', 'row' => 7, 'w' => 3],
        ['name' => 'pec', 'label' => 'PEC', 'type' => 'email', 'row' => 7, 'w' => 3],

        ['name' => 'clinica', 'type' => 'section', 'label' => __('Note cliniche')],
        ['name' => 'allergie', 'label' => __('Allergie (separate da virgola)'), 'type' => 'text', 'placeholder' => __('Es. penicillina, lattice')],
        ['name' => 'note', 'label' => __('Note'), 'type' => 'textarea'],
    ],
];
