<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    // moduli disponibili + HTML già renderizzato + layout salvato
    'moduli' => function () {
        $moduli = Scrivania::moduli();
        foreach ($moduli as $k => &$m) { $m['html'] = Scrivania::render($k); unset($m['dir']); }
        return ['moduli' => array_values($moduli), 'layout' => (object) Scrivania::layout(), 'layout_chiave' => Scrivania::chiaveLayout(), 'prossimo' => Appuntamento::prossimo(), 'n_oggi' => Appuntamento::contaGiorno(oggi())];
    },
    'salva'  => function (array $in) { Scrivania::salvaLayout(is_array($in['layout'] ?? null) ? $in['layout'] : []); return ['ok' => true]; },
]);
