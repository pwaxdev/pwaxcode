<?php
/**
 * Acquisti: Stripe Checkout (ritorno e webhook) e attivazione manuale. Le azioni API passano da Api::run (login, CSRF, permessi).
 *   ?action=ritorno&ordine=ID&sessione=…   ← il browser torna da Stripe: verifica e applica, poi riapre lo Store
 *   ?action=annullato&ordine=ID            ← pagamento annullato
 *   ?action=webhook                        ← Stripe (POST, firma verificata): senza sessione utente
 */
$azione = $_GET['action'] ?? '';
if ($azione === 'webhook') {
    require __DIR__ . '/../core/bootstrap.php';
    header('Content-Type: text/plain');
    try { echo Pagamenti::webhook((string) file_get_contents('php://input'), (string) ($_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '')); }
    catch (Throwable $e) { http_response_code(400); error_log('Stripe webhook: ' . $e->getMessage()); echo $e->getMessage(); }
    exit;
}
require __DIR__ . '/../core/bootstrap.php';
if ($azione === 'ritorno' || $azione === 'annullato') {
    Auth::requirePage();
    $oid = (int) ($_GET['ordine'] ?? 0);
    if ($azione === 'annullato') { Database::update(Database::comune('ordini'), ['stato' => 'annullato'], 'id = :id AND studio_id = :s AND stato = :c', ['id' => $oid, 's' => Auth::studioId(), 'c' => 'creato']); header('Location: ../index.php?acquisto=annullato'); exit; }
    try { $o = Pagamenti::ritorno($oid, (string) ($_GET['sessione'] ?? '')); header('Location: ../index.php?acquisto=ok&codice=' . rawurlencode($o['codice'])); }
    catch (Throwable $e) { header('Location: ../index.php?acquisto=errore&msg=' . rawurlencode($e->getMessage())); }
    exit;
}
Api::run([
    'acquista' => fn(array $in) => ['url' => Pagamenti::checkout(Api::str($in, 'codice'))],
    'manuale' => function (array $in) { $o = Pagamenti::manuale(Api::str($in, 'codice'), Api::str($in, 'metodo') ?: 'bonifico', Api::str($in, 'note')); return ['ordine' => $o, 'messaggio' => $o['nome'] . ' attivato (' . $o['metodo'] . ')']; },
    'ordini' => fn() => ['ordini' => Pagamenti::ordini(), 'stati' => Pagamenti::STATI, 'stripe' => Pagamenti::stripeAttivo(), 'amministratore' => Pagamenti::amministratore()],
], ['*' => 'store.gestisci', 'ordini' => 'store.leggi']);
