/* Lo Store di DRFacile (3.0): catalogo distribuito con il programma + repository dei pacchetti (core/Store.php).
   Ricerca, categorie, filtro Tutte/Installate/Aggiornamenti, voti a stelle, requisiti e permessi dichiarati,
   installazione con download e verifica, aggiornamento, disattivazione (i dati restano), rimozione dei file.
   Con store.revisore = true si vedono anche i pacchetti in revisione (badge), per provarli prima dell'approvazione. */
DRF.desk.register('negozio', {
  init($win) {
    const st = { moduli: [], categorie: [], vista: 'elenco', sel: null, filtro: 'tutte', cat: '', q: '', repo: {}, gestisci: false, zip: true };
    const APP_DESK = { ritmo: 'ritmo' };   // estensioni "solo catalogo" che aprono un'app della Scrivania
    const I = (fi, fa) => DRF.icons.html(fi, fa);
    const PREZZO = m => m.prezzo_tipo === 'gratis' ? '<span class="store-prezzo gratis">' + DRF.__('Gratis') + '</span>'
      : m.prezzo_tipo === 'pagamento' ? `<span class="store-prezzo pagamento">${DRF.util.eur(m.prezzo)} ${DRF.__('una tantum')}</span>`
      : `<span class="store-prezzo abbonamento">${DRF.util.eur(m.prezzo)}${DRF.__('/mese')}</span>`;
    const STATO = m => m.stato === 'in_revisione' ? '<span class="store-stato rev">' + DRF.__('In revisione') + '</span>' : m.stato === 'respinto' ? '<span class="store-stato no">' + DRF.__('Respinto') + '</span>' : '';
    const STELLE = (v, opts) => {   // v = media (0-5); opts.mio = voto dello studio; opts.n = numero voti; opts.vota = cliccabile
      opts = opts || {};
      const piene = Math.round((+v || 0) * 2) / 2;
      let s = '';
      for (let i = 1; i <= 5; i++) s += `<i class="star ${i <= piene ? 'on' : (i - 0.5 === piene ? 'half' : '')} ${opts.mio && i <= opts.mio ? 'mio' : ''}" data-star="${i}">★</i>`;
      v = +v || 0;
      return `<span class="store-stelle ${opts.vota ? 'vota' : ''}" title="${opts.vota ? DRF.__('Vota da 1 a 5 stelle') : ''}">${s}${opts.n != null ? `<small>${v ? v.toFixed(1) : '—'} · ${DRF._n('%d voto', '%d voti', opts.n)}</small>` : ''}</span>`;
    };
    const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const cerca = m => { const q = norm(st.q).trim(); if (!q) return true; return [m.nome, m.sottotitolo, m.descrizione, m.autore, m.categoria, m.codice].some(x => norm(x).includes(q)); };
    const nAgg = () => st.moduli.filter(m => m.installata && m.aggiornamento).length;

    // Elenco: la testata (titolo, ricerca, filtri, categorie) si costruisce una volta; la griglia si ridisegna a ogni filtro
    const acquisti = () => DRF.api.get('pagamenti', 'ordini').then(d => {
      $win.find('.store-lista').html(d.ordini.length ? `<div class="store-ordini">${d.ordini.map(o => `<div class="store-ord"><span class="store-ord-ico">${I(o.stato === 'pagato' || o.stato === 'manuale' ? 'check' : o.stato === 'creato' ? 'time-past' : 'cross', o.stato === 'pagato' || o.stato === 'manuale' ? 'fa-solid fa-check' : o.stato === 'creato' ? 'fa-regular fa-clock' : 'fa-solid fa-xmark')}</span><div><b>${DRF.esc(o.nome)}</b><span>${DRF.util.fmtDateTime(o.creato_il)} · ${DRF.util.eur(+o.importo)}${o.tipo === 'abbonamento' ? '/mese' : ''} · ${DRF.esc(o.metodo || '')}${o.note ? ' · ' + DRF.esc(o.note) : ''}</span></div>${DRF.ui.badge(o.stato === 'pagato' || o.stato === 'manuale' ? 'mint' : o.stato === 'creato' ? 'amber' : 'gray', d.stati[o.stato] || o.stato)}</div>`).join('')}</div>` : '<div class="empty" style="margin-top:30px">' + DRF.__('Nessun acquisto. Le estensioni gratuite non passano di qui.') + '</div>');
      DRF.icons.apply($win.find('.store-lista')[0]);
    });
    const griglia = () => {
      if (st.filtro === 'acquisti') { $win.find('.store-filtro button').each(function () { $(this).toggleClass('on', this.dataset.f === st.filtro); }); return acquisti(); }
      const lista = st.moduli.filter(m => (st.filtro === 'tutte' || (st.filtro === 'installate' && m.installata) || (st.filtro === 'aggiornamenti' && m.installata && m.aggiornamento)) && (!st.cat || m.categoria === st.cat) && cerca(m));
      $win.find('.store-filtro button').each(function () { $(this).toggleClass('on', this.dataset.f === st.filtro); });
      $win.find('.store-filtro [data-f="aggiornamenti"] .store-n').remove();
      if (nAgg()) $win.find('.store-filtro [data-f="aggiornamenti"]').append(` <b class="store-n">${nAgg()}</b>`);
      $win.find('.store-lista').html(lista.length ? `<div class="store-grid">${lista.map(m => `
          <div class="store-it" data-cod="${m.codice}">
            <span class="store-ico" style="--tinta:${m.tinta}">${I(m.fi, m.fa)}</span>
            <div class="store-mid"><b>${DRF.esc(m.nome)}${+m.novita ? ' <span class="store-new">' + DRF.__('NUOVO') + '</span>' : ''}${STATO(m)}</b><span>${DRF.esc(m.sottotitolo || '')}</span>
              <div class="store-riga">${STELLE(m.voti.media, { n: m.voti.n })}</div>
              <div class="store-badges">${PREZZO(m)}${m.installata ? `<span class="store-inst">${I('check', 'fa-solid fa-check')} ${DRF.__('Installata')}</span>` : ''}${m.installata && m.aggiornamento ? `<span class="store-agg">${I('arrow-up', 'fa-solid fa-arrow-up')} v${DRF.esc(m.aggiornamento)}</span>` : ''}${!+m.disponibile ? '<span class="store-soon">' + DRF.__('In arrivo') + '</span>' : ''}<span class="store-autore">${DRF.esc(m.autore || 'NASTech')} · v${DRF.esc(m.versione)}</span></div>
            </div>
          </div>`).join('')}</div>` : `<div class="empty" style="margin-top:30px">${st.q ? DRF.__('Nessun risultato per "') + DRF.esc(st.q) + '".' : st.filtro === 'aggiornamenti' ? DRF.__('Tutto aggiornato.') : st.filtro === 'installate' ? DRF.__('Nessuna estensione installata: sfoglia lo store con il filtro "Tutte".') : DRF.__('Nessuna estensione in questa categoria.')}</div>`);
      DRF.icons.apply($win.find('.store-lista')[0]);
    };
    const elenco = () => {
      st.vista = 'elenco';
      const cats = st.categorie;   // tutte quelle previste (anche vuote: Documenti arriverà), più quelle presenti nel catalogo
      const sync = st.repo.sync || null;
      const errore = st.repo.attivo && sync && !sync.ok ? `<span class="store-err" title="${DRF.esc(sync.errore || '')}">${I('triangle-warning', 'fa-solid fa-triangle-exclamation')} ${DRF.__('Repository non raggiungibile')}</span>` : '';
      $win.find('.store-body').html(`
        <div class="store-top">
          <div class="store-titolo"><h2>${I('shop', 'fa-solid fa-store')} ${DRF.__('Lo store di DRFacile')}</h2>
            <p>${DRF.__('Estendi il tuo programma: estensioni cliniche, moduli, documenti e integrazioni per lo studio.')}${st.repo.revisore ? ' <b class="store-rev">' + DRF.__('Modalità revisore') + '</b>' : ''} ${errore}</p></div>
          <div class="store-cerca"><input class="input" type="search" placeholder="${DRF.__('Cerca nello store…')}" value="${DRF.esc(st.q)}" autocomplete="off"><span>${I('search', 'fa-solid fa-magnifying-glass')}</span></div>
          ${st.gestisci && st.repo.attivo ? `<button class="icon-btn sm" data-store="sync" title="${DRF.__('Aggiorna il catalogo dal repository')}">${I('refresh', 'fa-solid fa-rotate')}</button>` : ''}
        </div>
        <div class="store-filtri">
          <div class="seg store-filtro"><button type="button" data-f="tutte">${DRF.__('Tutte')}</button><button type="button" data-f="installate">${DRF.__('Installate')}</button><button type="button" data-f="aggiornamenti">${DRF.__('Aggiornamenti')}</button><button type="button" data-f="acquisti">${DRF.__('Acquisti')}</button></div>
          <div class="store-cat"><select class="select store-cat-sel"><option value="*" ${!st.cat ? 'selected' : ''}>${DRF.__('Tutte le categorie')}</option>${cats.map(c => `<option value="${DRF.esc(c)}" ${st.cat === c ? 'selected' : ''}>${DRF.esc(c)}${st.moduli.some(m => m.categoria === c) ? '' : ' (' + DRF.__('in arrivo') + ')'}</option>`).join('')}</select></div>
        </div>
        ${st.spazio ? `<div class="store-spazio ${st.spazio.percentuale >= 90 ? 'pieno' : ''}"><span>${I('disk', 'fa-solid fa-hard-drive')}</span><div><b>${DRF.__('Spazio dello studio:')} ${DRF.esc(st.spazio.uso_umano)}${st.spazio.quota_mb ? ` ${DRF.__('su')} ${DRF.esc(st.spazio.quota_umano)} · ${st.spazio.percentuale}%` : ' · ' + DRF.__('illimitato')}</b><div class="spazio-bar"><i style="width:${st.spazio.percentuale}%"></i></div></div>${st.moduli.some(m => m.codice === 'spazio') ? `<button class="btn ${st.spazio.percentuale >= 90 ? 'primary' : 'ghost'} sm" data-store="spazio">${I('plus', 'fa-solid fa-plus')}${DRF.__('Più spazio')}</button>` : ''}</div>` : ''}
        <div class="store-lista"></div>`);
      DRF.ui.select($win.find('.store-cat-sel'), { dropdownParent: $win, minimumResultsForSearch: Infinity });
      DRF.icons.apply($win[0]);
      griglia();
    };

    const scheda = cod => {
      const m = st.moduli.find(x => x.codice === cod); if (!m) return;
      st.vista = 'scheda'; st.sel = cod;
      const G = st.gestisci;
      const btn = [];
      if (m.installata) {
        if (cod === 'salaattesa') btn.push(`<button class="btn soft sm" data-store="apri-sala">${I('screen', 'fa-solid fa-tv')}${DRF.__('Apri lo schermo di sala')}</button>`);
        if (APP_DESK[cod]) btn.push(`<button class="btn soft sm" data-store="apri-app">${I('expand', 'fa-solid fa-up-right-from-square')}${DRF.__('Apri')}</button>`);
        if (G && m.aggiornamento) btn.push(`<button class="btn primary sm" data-store="aggiorna">${I('arrow-up', 'fa-solid fa-arrow-up')}${DRF.__('Aggiorna alla v')}${DRF.esc(m.aggiornamento)}</button>`);
        if (G) btn.push('<button class="btn ghost sm" data-store="disinstalla">' + DRF.__('Disattiva') + '</button>');
      } else if (m.presente && m.origine === 'repository') {
        if (G) btn.push(`<button class="btn primary sm" data-store="attiva">${I('play', 'fa-solid fa-play')}${DRF.__('Attiva')}</button><button class="btn ghost sm danger" data-store="rimuovi">${DRF.__('Rimuovi i file')}</button>`);
      } else if (!+m.disponibile) btn.push('<span class="store-soon">' + DRF.__('In arrivo: sarà attivabile dal portale') + '</span>');
      else if (m.prezzo_tipo !== 'gratis') btn.push(G && (st.pag.stripe || st.pag.amministratore) ? `<button class="btn primary sm" data-store="acquista">${I('credit-card', 'fa-regular fa-credit-card')}${DRF.__('Acquista')}${m.prezzo_tipo === 'abbonamento' ? ' · ' + DRF.util.eur(m.prezzo) + '/mese' : ' · ' + DRF.util.eur(m.prezzo)}</button>` : `<button class="btn primary sm" data-store="portale">${I('shop', 'fa-solid fa-store')}${DRF.__('Attiva dal portale')}</button>`);
      else if (!G) btn.push('<span class="small muted">' + DRF.__('Chiedi all\'amministratore dello studio') + '</span>');
      else if (m.problemi.length) btn.push(`<span class="store-err">${I('triangle-warning', 'fa-solid fa-triangle-exclamation')} ${DRF.esc(m.problemi[0])}</span>`);
      else if (!m.presente && !st.zip) btn.push('<span class="store-err">' + DRF.__('Serve l\'estensione PHP zip per installare i pacchetti') + '</span>');
      else btn.push(`<button class="btn primary sm" data-store="installa">${I('download', 'fa-solid fa-download')}${m.presente ? DRF.__('Installa gratis') : DRF.__('Scarica e installa')}${m.dimensione ? ` <small>(${Math.round(m.dimensione / 1024)} KB)</small>` : ''}</button>`);
      if (m.installata && m.origine === 'repository' && G) btn.push('<button class="btn ghost sm danger" data-store="rimuovi" title="' + DRF.__('Disattiva e cancella i file (i dati restano)') + '">' + DRF.__('Rimuovi') + '</button>');

      const shots = (m.schermate || []).map(s => s.img
        ? `<figure class="store-fig"><img src="${DRF.esc(s.img)}" alt="" loading="lazy">${s.t ? `<figcaption>${DRF.esc(s.t)}</figcaption>` : ''}</figure>`
        : `<div class="store-shot" style="--tinta:${m.tinta}"><b>${DRF.esc(s.t)}</b><span>${DRF.esc(s.s || '')}</span></div>`).join('');
      const req = [];
      if (m.richiede.drfacile) req.push(`${DRF.__('DRFacile ≥')} ${DRF.esc(m.richiede.drfacile)}`);
      if (m.richiede.php) req.push(`${DRF.__('PHP ≥')} ${DRF.esc(m.richiede.php)}`);
      if ((m.dipendenze || []).length) req.push(`${DRF.__('Richiede:')} ${m.dipendenze.map(d => `<code>${DRF.esc(d)}</code>`).join(' ')}${m.dipendenze_mancanti.length ? ' <span class="muted">' + DRF.__('(si installano insieme)') + '</span>' : ''}`);
      if ((m.lingue || []).length) req.push(`${DRF.__('Lingue:')} ${m.lingue.map(l => DRF.esc(l.slice(0, 2))).join(', ')}`);
      const caps = (m.capabilities || []).length ? `<div class="store-caps"><b>${I('shield-check', 'fa-solid fa-shield-halved')} ${DRF.__('Cosa usa')}</b>${m.capabilities.map(c => `<code>${DRF.esc(c)}</code>`).join('')}</div>` : '';
      $win.find('.store-body').html(`
        <button class="store-back" data-store="indietro">${I('angle-left', 'fa-solid fa-chevron-left')} ${DRF.__('Store')}</button>
        <div class="store-head"><span class="store-ico" style="--tinta:${m.tinta}">${I(m.fi, m.fa)}</span>
          <div><h2>${DRF.esc(m.nome)}${+m.novita ? ' <span class="store-new">' + DRF.__('NUOVO') + '</span>' : ''}${STATO(m)}</h2><p>${DRF.esc(m.sottotitolo || '')}</p>
            <p class="store-firma">${m.autore_url ? `<a href="${DRF.esc(m.autore_url)}" target="_blank" rel="noopener">${DRF.esc(m.autore || 'NASTech')}</a>` : DRF.esc(m.autore || 'NASTech')} · ${DRF.esc(m.categoria || '')} ${DRF.__('· versione')} ${DRF.esc(m.versione)}${m.versione_installata && m.versione_installata !== m.versione ? ` <span class="muted">${DRF.__('(installata')} ${DRF.esc(m.versione_installata)})</span>` : ''}${m.origine === 'repository' ? ' · ' + DRF.__('dal repository') : ' · ' + DRF.__('con il programma')}</p>
            <div class="store-riga">${STELLE(m.voti.media, { n: m.voti.n, mio: m.voti.mio, vota: m.installata })}${m.installata ? `<small class="muted store-miovoto">${m.voti.mio ? DRF.__('Il tuo voto: ') + m.voti.mio + '/5 · ' + DRF.__('clicca per cambiarlo') : DRF.__('Clicca una stella per votare')}</small>` : ''}</div></div></div>
        <div class="store-cta">${PREZZO(m)}${btn.join('')}</div>
        ${m.problemi.length && m.installata ? `<div class="store-avviso">${m.problemi.map(p => DRF.esc(p)).join('<br>')}</div>` : ''}
        ${req.length || caps ? `<div class="store-req">${req.length ? `<div><b>${I('list-check', 'fa-solid fa-list-check')} ${DRF.__('Requisiti')}</b>${req.join(' · ')}</div>` : ''}${caps}</div>` : ''}
        ${shots ? `<div class="store-shots ${((m.schermate || [])[0] || {}).img ? 'con-img' : ''}">${shots}</div>` : ''}
        <div class="store-desc">${m.descrizione}</div>
        <div class="store-meta">${m.origine === 'repository' ? DRF.__('Pacchetto del repository: viene scaricato, verificato (impronta sha256, requisiti, dipendenze) e installato nella cartella delle estensioni; gli aggiornamenti compaiono qui.') : DRF.__('Distribuita con il programma: gli aggiornamenti arrivano con gli aggiornamenti di DRFacile.')} ${DRF.__('Disattivare non cancella nulla: riattivando ritrovi i tuoi dati.')}${m.stato === 'in_revisione' ? ' <b>' + DRF.__('In revisione') + '</b>: ' + DRF.__('visibile solo ai revisori, non ancora pubblicata.') : ''}</div>`);
      DRF.icons.apply($win[0]);
    };

    const load = () => DRF.api.get('store', 'catalogo').then(d => { st.moduli = d.moduli; st.categorie = d.categorie; st.url = d.salaattesa_url; st.repo = d.repository || {}; st.gestisci = !!d.gestisci; st.zip = d.zip !== false; st.spazio = d.spazio || null; st.pag = d.pagamenti || {}; st.vista === 'scheda' ? scheda(st.sel) : elenco(); });
    const dopo = r => {
      DRF.ui.toast(r.messaggio, 'success');
      if (r.salaattesa_url) st.url = r.salaattesa_url;
      if (r.icona) DRF.ui.toast(DRF.__('Icona aggiunta alla Scrivania'), { fi: 'apps', fa: 'fa-solid fa-table-cells' });
      if (st.sel === 'commercialista') DRF.ui.toast(DRF.__('Nuovo ruolo "Commercialista" fra gli utenti e voce Contabilità nelle Procedure'), { fi: 'calculator', fa: 'fa-solid fa-calculator' });
      DRF.desk.reloadModuli();
      if (r.ricarica) { DRF.ui.toast(DRF.__('Attivo i componenti dell\'estensione…'), { fi: 'refresh', fa: 'fa-solid fa-rotate' }); setTimeout(() => location.reload(), 900); return; }   // js/css dell'estensione entrano con la pagina: la ricarichiamo noi
      load();
    };
    const occupato = (on) => $win.find('[data-store]').prop('disabled', on);

    $win.on('click', '.store-filtro button', function () { st.filtro = this.dataset.f; griglia(); });
    $win.on('change', '.store-cat-sel', function () { st.cat = this.value === '*' ? '' : this.value; griglia(); });   // '*' e non '': con '' select2 la tratterebbe come placeholder e non si potrebbe più riselezionare
    $win.on('input', '.store-cerca input', DRF.util.debounce(function () { st.q = this.value; griglia(); }, 150));   // la testata non si ridisegna: il cursore resta dov'è
    $win.on('click', '.store-it', function () { scheda(this.dataset.cod); });
    $win.on('click', '[data-store="spazio"]', () => scheda('spazio'));
    $win.on('click', '[data-store="indietro"]', elenco);
    $win.on('click', '[data-store="sync"]', () => DRF.api.post('store', 'sincronizza').then(r => { DRF.ui.toast(r.sync.ok ? `${DRF.__('Catalogo aggiornato:')} ${r.sync.pacchetti} ${DRF.__('pacchetti')}` : r.sync.errore, r.sync.ok ? 'success' : 'error'); load(); }));
    $win.on('click', '[data-store="installa"]', () => { occupato(true); DRF.ui.toast(DRF.__('Installazione in corso…'), { fi: 'download', fa: 'fa-solid fa-download' }); DRF.api.post('store', 'installa', { codice: st.sel }).then(dopo).always(() => occupato(false)); });
    $win.on('click', '[data-store="aggiorna"]', () => { occupato(true); DRF.api.post('store', 'aggiorna', { codice: st.sel }).then(dopo).always(() => occupato(false)); });
    $win.on('click', '[data-store="attiva"]', () => DRF.api.post('store', 'attiva', { codice: st.sel }).then(dopo));
    $win.on('click', '[data-store="disinstalla"]', () => DRF.ui.confirm(DRF.__('Disattivare questa estensione?'), DRF.__('I dati restano: riattivandola ritrovi tutto.'), DRF.__('Disattiva')).then(ok => { if (ok) DRF.api.post('store', 'disinstalla', { codice: st.sel }).then(dopo); }));
    $win.on('click', '[data-store="rimuovi"]', () => DRF.ui.confirm(DRF.__('Rimuovere i file di questa estensione?'), DRF.__('Viene disattivata e la sua cartella cancellata. I dati nel database restano: reinstallandola li ritrovi.'), DRF.__('Rimuovi')).then(ok => { if (ok) DRF.api.post('store', 'rimuovi', { codice: st.sel }).then(dopo); }));
    $win.on('click', '.store-stelle.vota .star', function () { const v = +this.dataset.star; DRF.api.post('store', 'vota', { codice: st.sel, voto: v }).then(r => { const m = st.moduli.find(x => x.codice === st.sel); if (m) m.voti = r.voti; DRF.ui.toast(`${DRF.__('Grazie:')} ${DRF._n('%d stella', '%d stelle', v)}`, 'success'); scheda(st.sel); }); });
    $win.on('click', '[data-store="apri-sala"]', () => { if (st.url) window.open(st.url, '_blank'); });
    $win.on('click', '[data-store="apri-app"]', () => { const k = APP_DESK[st.sel]; if (k) DRF.desk.apri(k); });
    $win.on('click', '[data-store="acquista"]', () => {
      const m = st.moduli.find(x => x.codice === st.sel); if (!m) return;
      const abb = m.prezzo_tipo === 'abbonamento';
      DRF.ui.modal({ title: DRF.__('Acquista · ') + m.nome, ok: false, cancel: DRF.__('Annulla'), html: `
        <div class="store-acq"><div class="store-acq-prezzo"><b>${DRF.util.eur(m.prezzo)}</b><span>${abb ? DRF.__('al mese, disdici quando vuoi') : DRF.__('una tantum')}</span></div><p class="small muted">${DRF.esc(m.sottotitolo || '')}</p>
        ${st.pag.stripe ? `<button class="btn primary" type="button" data-acq="stripe">${I('credit-card', 'fa-regular fa-credit-card')}<span>${DRF.__('Paga con carta')}</span></button><div class="small muted" style="margin-top:6px">${DRF.__('Pagamento sicuro su Stripe; al ritorno l\'acquisto è già attivo.')}</div>` : '<div class="small muted">' + DRF.__('Pagamento con carta non configurato su questa installazione.') + '</div>'}
        ${st.pag.amministratore ? `<div class="store-acq-man"><b>${DRF.__('Attivazione manuale')}</b><span class="small muted">${DRF.__('Amministratore di sistema: bonifico ricevuto, omaggio, periodo di prova.')}</span>
          <div class="grid2" style="margin-top:8px"><div class="field"><label>${DRF.__('Metodo')}</label><select class="select" id="acqMetodo"><option value="bonifico">${DRF.__('Bonifico')}</option><option value="contanti">${DRF.__('Contanti')}</option><option value="omaggio">${DRF.__('Omaggio')}</option><option value="prova">${DRF.__('Prova / simulazione')}</option><option value="altro">${DRF.__('Altro')}</option></select></div><div class="field"><label>${DRF.__('Nota')}</label><input class="input" id="acqNote" placeholder="${DRF.__('Es. CRO 1234 del 3/9')}"></div></div>
          <button class="btn soft" type="button" data-acq="manuale" style="margin-top:8px">${I('check', 'fa-solid fa-check')}<span>${DRF.__('Attiva ora')}</span></button></div>` : ''}</div>`,
        onOpen($b) {
          DRF.ui.select($b.find('#acqMetodo'), { minimumResultsForSearch: Infinity });
          $b.on('click', '[data-acq="stripe"]', function () { $(this).prop('disabled', true); DRF.api.post('pagamenti', 'acquista', { codice: m.codice }).then(r => { location.href = r.url; }).always(() => $(this).prop('disabled', false)); });
          $b.on('click', '[data-acq="manuale"]', function () { $(this).prop('disabled', true); DRF.api.post('pagamenti', 'manuale', { codice: m.codice, metodo: $b.find('#acqMetodo').val(), note: $b.find('#acqNote').val() }).then(r => { DRF.ui.closeModal(); dopo({ messaggio: r.messaggio, ricarica: !!(m.presente || m.origine === 'repository') && !['sms', 'sms_500', 'sms_2000', 'senza_marchio', 'spazio'].includes(m.codice) }); }).always(() => $(this).prop('disabled', false)); });
        } });
    });
    $win.on('click', '[data-store="portale"]', () => DRF.ui.alert(DRF.__('Attivazione dal portale'), DRF.__('Le estensioni a pagamento e in abbonamento si acquistano dal portale DRFacile: alla conferma compaiono qui già attive.'), 'info'));

    $win.data('reload', load); load();
  },
  open($win) { const r = $win.data('reload'); if (r) r(); }
});
