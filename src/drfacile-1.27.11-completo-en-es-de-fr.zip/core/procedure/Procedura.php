<?php
/**
 * Classe base delle procedure. Per crearne una nuova: core/procedure/MiaProcedura.php che estende Procedura,
 * poi una voce in core/procedure.php con 'tipo' => 'procedura', 'procedura' => 'MiaProcedura'.
 *
 *   campi()   → elenco dei parametri nel formato del FormBuilder (form/definitions)
 *   esegui()  → riceve i parametri e restituisce ['titolo' => ..., 'html' => ...] (HTML già pronto, con e() sui dati)
 */
abstract class Procedura
{
    abstract public function label(): string;
    abstract public function descrizione(): string;
    public function pulsante(): string { return 'Esegui'; }
    public function campi(): array { return []; }
    abstract public function esegui(array $in): array;

    public static function carica(string $nome): self
    {
        $nome = preg_replace('/[^A-Za-z0-9_]/', '', $nome);
        $file = DRF_ROOT . "/core/procedure/$nome.php";
        if (!is_file($file)) throw new ApiException("Procedura non trovata: $nome", 404);
        require_once $file;
        if (!class_exists($nome) || !is_subclass_of($nome, self::class)) throw new ApiException("Classe $nome non valida");
        return new $nome();
    }

    /** Tabella HTML rapida per i risultati: colonne [campo => etichetta], righe già escapate con e() */
    protected function tabella(array $colonne, array $righe): string
    {
        if (!$righe) return '<div class="empty">Nessun risultato.</div>';
        $h = '<div class="tbl"><table><thead><tr>' . implode('', array_map(fn($l) => '<th>' . e($l) . '</th>', $colonne)) . '</tr></thead><tbody>';
        foreach ($righe as $r) { $h .= '<tr>'; foreach (array_keys($colonne) as $k) $h .= '<td>' . ($r[$k] ?? '') . '</td>'; $h .= '</tr>'; }
        return $h . '</tbody></table></div>';
    }
}
