<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'list'    => fn(array $in) => Paziente::cerca(Api::str($in, 'q'), Api::str($in, 'filtro', 'tutti')),
    'get'     => function (array $in) {
        $p = Paziente::find(Api::int($in, 'id')) ?? throw new ApiException(__('Paziente non trovato'), 404);
        return ['paziente' => $p, 'storico' => Storico::diPaziente((int) $p['id'])];
    },
    'options' => fn() => Paziente::options(),
    'save'    => function (array $in) { $id = Paziente::salvaDaForm($in); return ['id' => $id, 'paziente' => Paziente::find($id), 'messaggio' => empty($in['id']) ? 'Paziente aggiunto all\'archivio' : 'Scheda paziente aggiornata']; },
    'delete'  => function (array $in) {
        $id = Api::int($in, 'id');
        if (Fattura::count('paziente_id = ?', [$id]) > 0) throw new ApiException(__('Il paziente ha fatture emesse e non può essere eliminato'));
        if (Visita::count("paziente_id = ? AND stato = 'chiusa'", [$id]) > 0) throw new ApiException(__('Il paziente ha visite chiuse in cartella: non può essere eliminato (in arrivo la procedura di oblio GDPR)'));
        if (Visita::count("paziente_id = ? AND stato = 'bozza'", [$id]) > 0) throw new ApiException(__('Il paziente ha una visita in corso: chiudila o annullala prima di eliminarlo'));
        $ok = Paziente::delete($id); Hooks::run('paziente.eliminato', $id);
        return ['eliminato' => $ok];
    },
], ['*' => 'pazienti.leggi', 'save' => 'pazienti.modifica', 'delete' => 'pazienti.elimina']);
