<?php
require __DIR__ . '/../core/bootstrap.php';
Api::run([
    'list'   => fn(array $in) => ['referti' => Referto::lista(Api::str($in, 'stato', 'tutti')), 'bozze' => Referto::contaBozze(), 'totale' => Referto::count()],
    'get'    => function (array $in) {
        $r = Referto::find(Api::int($in, 'id')) ?? throw new ApiException(__('Referto non trovato'), 404);
        return ['referto' => $r, 'paziente' => Paziente::find((int) $r['paziente_id']), 'medico' => Impostazione::profilo()];
    },
    'firma'  => fn(array $in) => ['referto' => Referto::firma(Api::int($in, 'id')), 'messaggio' => __('Referto firmato digitalmente')],
    'invia'  => function (array $in) { $r = Referto::invia(Api::int($in, 'id')); $p = Paziente::find((int) $r['paziente_id']); return ['referto' => $r, 'messaggio' => 'Referto inviato a ' . ($p['email'] ?: $p['nome_completo'])]; },
    'salva'  => function (array $in) {
        $r = Referto::find(Api::int($in, 'id')) ?? throw new ApiException(__('Referto non trovato'), 404);
        if ($r['stato'] !== 'bozza') throw new ApiException(__('Solo le bozze possono essere modificate'));
        $sezioni = array_map(fn($v) => str_contains((string) $v, '<') ? rich_txt((string) $v) : trim((string) $v), (array) ($in['sezioni'] ?? $r['sezioni']));
        Referto::save(['id' => $r['id'], 'sezioni' => $sezioni]);
        return ['referto' => Referto::find((int) $r['id']), 'messaggio' => __('Bozza aggiornata')];
    },
    'delete' => function (array $in) {
        $r = Referto::find(Api::int($in, 'id')) ?? throw new ApiException(__('Referto non trovato'), 404);
        if ($r['stato'] !== 'bozza') throw new ApiException(__('Solo le bozze possono essere eliminate'));
        return ['eliminato' => Referto::delete((int) $r['id']), 'messaggio' => __('Bozza eliminata')];
    },
], ['*' => 'referti.leggi', 'firma' => 'referti.modifica', 'salva' => 'referti.modifica', 'delete' => 'referti.modifica', 'invia' => 'referti.invia']);
