<?php
/** Catalogo COMUNE dei documenti richiedibili all'assistenza (pulsante "Richiedi" in Archivi → Documenti).
    È lo stesso per tutte le installazioni: la richiesta parte via email (config → assistenza.email_richieste)
    e il modello, una volta preparato, viene inserito da remoto nell'archivio Documenti dello studio. */
return [
    'privacy'        => 'Informativa privacy e consenso al trattamento (GDPR)',
    'cons_operazione' => 'Consenso informato all\'operazione / intervento',
    'cons_anestesia' => 'Consenso all\'anestesia',
    'cons_estetica'  => 'Consenso a trattamento di medicina estetica',
    'cons_minori'    => 'Consenso per pazienti minorenni (esercenti la potestà)',
    'cert_generico'  => 'Certificato medico generico',
    'cert_sport'     => 'Certificato di idoneità sportiva non agonistica',
    'lettera_collega' => 'Lettera di accompagnamento per il collega specialista',
    'promemoria_email' => 'Promemoria appuntamento (email)',
    'istruzioni_post' => 'Istruzioni post-trattamento',
    'altro'          => 'Altro documento (descrivilo nelle note)',
];
