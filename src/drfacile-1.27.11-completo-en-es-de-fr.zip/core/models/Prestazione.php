<?php
final class Prestazione extends Model
{
    protected static string $table = 'prestazioni';
    protected static array $fillable = ['nome', 'prezzo', 'durata', 'colore', 'iva_id', 'prenotabile', 'previsita', 'previsita_titolo', 'previsita_testo', 'previsita_quando', 'attiva'];

    public static function attive(): array { return self::all('attiva = 1', [], 'id'); }

    /** Prestazioni attive con l'aliquota IVA risolta (per il listino delle fatture e la scheda visita) */
    public static function listino(): array
    {
        return Database::all('SELECT p.id, p.nome, p.prezzo, p.durata, p.colore, p.iva_id, p.prenotabile, p.previsita, p.previsita_quando, i.aliquota, i.nome iva_nome FROM prestazioni p LEFT JOIN iva i ON i.id = p.iva_id WHERE p.attiva = 1 ORDER BY p.nome');
    }

    public static function optionsMap(): array
    {
        $m = [];
        foreach (self::attive() as $p) $m[$p['nome']] = $p['nome'] . ' · ' . euro($p['prezzo']);
        return $m;
    }
}
