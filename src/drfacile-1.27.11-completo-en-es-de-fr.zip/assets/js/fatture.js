/* Modulo Fatturazione: KPI, elenco in DataTable con filtro per stato, incasso,
   editor a righe multiple (prestazioni con IVA, righe libere e descrittive, spese di studio, contributo cassa)
   e compilazione automatica dalla visita chiusa ("Da visita"). */
DRF.register('fatture', (function ($) {
  'use strict';
  const U = DRF.util, I = DRF.icons.html;
  const st = { filtro: 'tutte', list: [], kpi: null, hl: null, dt: null, ed: null };
  const STATO = { pagata: 'mint', attesa: 'amber', scaduta: 'red' };
  const num = v => { let s = String(v == null ? '' : v).trim(); if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.'); const n = parseFloat(s); return isFinite(n) ? n : 0; };
  const n2 = v => (Math.round(v * 100) / 100);
  const pcent = a => (+a || 0).toLocaleString(DRF.util.loc(), { maximumFractionDigits: 2 }) + '%';

  function load() {
    return DRF.api.get('fatture', 'list', { stato: st.filtro }).then(d => { st.list = d.fatture; st.kpi = d.kpi; render(); DRF.nav.refreshSub(); });
  }
  function render() {
    const k = st.kpi;
    const varTxt = k.variazione == null ? DRF.__('primo mese di attività') : `${k.variazione >= 0 ? '+' : ''}${k.variazione}${DRF.__('% rispetto al mese scorso')}`;
    $('#fKpis').html(`<div class="kpi">${I('euro', 'fa-solid fa-euro-sign', 'violet')}<div><span>${DRF.__('Incassato nel mese')}</span><b class="num">${U.eur(k.incassato_mese)}</b><small class="${k.variazione == null ? '' : k.variazione >= 0 ? 'up' : 'down'}">${varTxt}</small></div></div>
      <div class="kpi">${I('hourglass-end', 'fa-solid fa-hourglass-half', 'amber')}<div><span>${DRF.__('Da incassare')}</span><b class="num">${U.eur(k.da_incassare)}</b><small>${DRF._n('%d fattura aperta', '%d fatture aperte', k.aperte)}${k.scadute ? ` · ${DRF._n('%d scaduta', '%d scadute', k.scadute)}` : ''}</small></div></div>
      <div class="kpi">${I('receipt', 'fa-solid fa-file-invoice', 'mint')}<div><span>${DRF.__('Fatture emesse nel mese')}</span><b class="num">${k.emesse_mese}</b><small>${DRF.__('ultimo numero')} <span class="mono">${DRF.esc(k.ultimo_numero || '—')}</span></small></div></div>`);
    DRF.icons.apply($('#fKpis')[0]);
    if (!st.dt) st.dt = DRF.ui.datatable($('#fTable'), { order: [[1, 'desc']], rowId: r => 'f' + r.id, createdRow: (row, f) => { if (+f.id === st.hl) row.classList.add('hl'); }, columns: [
      { data: null, orderable: false, searchable: false, className: 'dt-actions', render: f => `<button class="icon-btn sm" type="button" data-doc="fattura" data-id="${f.id}" title="${DRF.__('Apri / stampa')}">${I('print', 'fa-solid fa-print')}</button><button class="icon-btn sm ${f.inviata_il ? 'sent' : ''}" type="button" data-mail="${f.id}" title="${f.inviata_il ? DRF.__('Inviata via email il ') + U.fmtDateTime(f.inviata_il) + ' · ' + DRF.__('invia di nuovo') : DRF.__('Invia via email')}">${I('paper-plane', 'fa-regular fa-paper-plane')}</button>${f.stato !== 'pagata' ? `<button class="icon-btn sm accent" data-pay="${f.id}" type="button" title="${DRF.__('Segna come pagata')}">${I('euro', 'fa-solid fa-euro-sign')}</button>` : ''}` },
      { data: 'numero', render: d => `<b class="mono">${DRF.esc(d)}</b>` },
      { data: 'data', render: (d, t) => t === 'display' ? `<span class="num">${U.fmtIso(d)}</span>` : d },
      { data: 'paziente', render: (d, t, f) => t === 'display' ? `<div class="row" style="gap:10px">${DRF.ui.avatar(d, ';width:30px;height:30px;border-radius:9px;font-size:11px')}<div class="fat-paz"><span>${DRF.esc(d)}</span>${f.visitata_da ? `<small>${DRF.__('visitata da')} ${DRF.esc(f.visitata_da)}</small>` : ''}</div></div>` : d },
      { data: 'prestazione', render: (d, t, f) => `<span class="muted">${DRF.esc(d)}</span><div class="small muted">${+f.visita_id ? `${I('stethoscope', 'fa-solid fa-stethoscope')} ${DRF.__('da visita')} ` : ''}${+f.opposizione ? '<span class="badge amber" style="font-size:10px">' + DRF.__('Opposizione TS') + '</span>' : ''}</div>` },
      { data: 'totale', render: (d, t, f) => t === 'display' ? `<b class="num">${U.eur(d)}</b>${+f.iva || +f.bollo ? `<div class="small muted">${[+f.iva ? 'IVA ' + U.eur(f.iva) : '', +f.bollo ? 'bollo ' + U.eur(f.bollo) : ''].filter(Boolean).join(' · ')}</div>` : ''}` : +d },
      { data: 'stato', render: (d, t, f) => t === 'display' ? DRF.ui.badge(STATO[d], f.stato_label) : f.stato_label },
    ] });
    st.dt.clear().rows.add(st.list).draw();
    if (st.hl) { const idx = st.dt.row('#f' + st.hl).index(); if (idx != null && idx >= 0) { st.dt.page(Math.floor(st.dt.rows({ order: 'applied' }).indexes().indexOf(idx) / st.dt.page.len())).draw(false); } st.hl = null; }
  }

  /* ------------------------------ EDITOR ------------------------------ */

  /** Apre l'editor della fattura: nuova, precompilata da una visita, o in modifica di una fattura non stampata */
  function nuova(pazienteId, visitaId, fatturaId) {
    const chiamate = [DRF.api.get('fatture', 'editor', visitaId ? { visita: visitaId } : {})];
    if (fatturaId) chiamate.push(DRF.api.get('fatture', 'get', { id: fatturaId }));
    Promise.all(chiamate).then(([d, fx]) => {
      if (!fx && visitaId && d.gia_fatturata) { DRF.ui.toast(`${DRF.__('Visita già fatturata (fattura')} ${d.gia_fatturata.numero}${DRF.__('): la apro in modifica')}`, 'warn'); return nuova(null, null, d.gia_fatturata.id); }
      const E = st.ed = { d, rows: [], contributi: fx ? +fx.contributi > 0 : d.contributi.perc > 0, opposizione: fx ? +fx.opposizione === 1 : false, visita: fx ? fx.visita_id : (d.visita ? d.visita.id : null), id: fx ? +fx.id : null, fx };
      const listino = {}; d.listino.forEach(p => listino[p.id] = p);
      const rigaDa = p => ({ tipo: 'riga', descrizione: p.nome, quantita: 1, prezzo: +p.prezzo, iva_id: p.iva_id ? +p.iva_id : (d.iva_predefinita ? +d.iva_predefinita : null) });
      if (fx) {
        // modifica: righe della fattura così come sono
        E.rows = (fx.righe || []).map(r => r.tipo === 'descrizione' ? { tipo: 'descrizione', descrizione: r.descrizione } : { tipo: 'riga', descrizione: r.descrizione, quantita: +r.quantita || 1, prezzo: +r.prezzo, iva_id: r.iva_id ? +r.iva_id : null });
      } else if (d.visita) {
        // precompilazione dalla visita: le prestazioni segnate in visita diventano righe (prezzi e IVA dal listino attuale)
        (d.visita.prestazioni || []).forEach(x => { const p = listino[x.id]; E.rows.push(p ? rigaDa(p) : { tipo: 'riga', descrizione: x.nome, quantita: 1, prezzo: 0, iva_id: d.iva_predefinita ? +d.iva_predefinita : null }); });
      }
      // spese di studio: proposte se configurate in Impostazioni (solo per le nuove fatture)
      if (!fx && d.spese.attive && d.spese.importo > 0) E.rows.push({ tipo: 'riga', descrizione: d.spese.descrizione, quantita: 1, prezzo: d.spese.importo, iva_id: d.iva_predefinita ? +d.iva_predefinita : null, spese: true });

      $('#sheet').addClass('wide');
      DRF.ui.openSheet(fx ? `${DRF.__('Modifica fattura')} ${fx.numero}` : `${DRF.__('Nuova fattura')} ${d.prossimo.numero}`, `
        <div class="fat-ed">
          <div class="grid2">
            <div class="field"><label>${DRF.__('Paziente *')}</label><select class="select" id="fePat"><option value="">${DRF.__('Seleziona…')}</option>${d.pazienti.map(p => `<option value="${p.id}">${DRF.esc(p.nome_completo)}</option>`).join('')}</select></div>
            <div class="field"><label>${DRF.__('Data')}</label><input class="input" type="date" id="feData" value="${fx ? fx.data : U.todayIso()}"></div>
          </div>
          ${d.visita ? `<div class="fat-visita">${I('stethoscope', 'fa-solid fa-stethoscope')}<span>${DRF.__('Compilata dalla visita del')} <b>${U.fmtIso(d.visita.data)}</b>${DRF.__(': le prestazioni arrivano dalla scheda, prezzi e IVA dal listino. Puoi modificare tutto.')}</span></div>` : ''}
          <div class="field"><label>${DRF.__('Righe della fattura')}</label>
            <div class="fat-rt-wrap"><table class="fat-rt"><thead><tr><th>${DRF.__('Descrizione')}</th><th class="c-q">${DRF.__('Q.tà')}</th><th class="c-p">${DRF.__('Prezzo')}</th><th class="c-i">IVA</th><th class="c-t">${DRF.__('Importo')}</th><th class="c-x"></th></tr></thead><tbody id="feRows"></tbody></table></div>
            <div class="row fat-add">
              <select class="select" id="feAddPrest"><option value="">${DRF.__('Aggiungi prestazione dal listino…')}</option>${d.listino.map(p => `<option value="${p.id}">${DRF.esc(p.nome)} · ${U.eur(p.prezzo)}${+p.aliquota ? ' +IVA ' + pcent(p.aliquota) : ''}</option>`).join('')}</select>
              <button class="btn ghost sm" type="button" id="feAddLibera">${I('plus', 'fa-solid fa-plus')}${DRF.__('Riga libera')}</button>
              <button class="btn ghost sm" type="button" id="feAddDesc">${I('align-left', 'fa-solid fa-align-left')}${DRF.__('Riga descrittiva')}</button>
            </div>
          </div>
          <div class="fat-opts">
            ${d.spese.importo > 0 ? `<div class="pref"><div><b>${DRF.__('Spese di studio')}</b><span>${U.eur(d.spese.importo)} ${DRF.__('· si aggiungono come riga (modificabile)')}</span></div><button class="switch ${d.spese.attive ? 'on' : ''}" type="button" id="feSpese" aria-label="${DRF.__('Spese di studio')}"></button></div>` : ''}
            ${d.contributi.perc > 0 ? `<div class="pref"><div><b>${DRF.__('Contributo previdenziale')} ${pcent(d.contributi.perc)}</b><span>${DRF.esc(d.contributi.descrizione || "Calcolato sull'imponibile")}</span></div><button class="switch ${E.contributi ? 'on' : ''}" type="button" id="feContr" aria-label="${DRF.__('Contributo')}"></button></div>` : ''}
            <div class="pref"><div><b>${DRF.__('Opposizione al Sistema TS')}</b><span>${DRF.__('Il paziente si oppone alla trasmissione della spesa sanitaria: la fattura non andrà al Sistema TS e in stampa lo dichiara')}</span></div><button class="switch ${E.opposizione ? 'on' : ''}" type="button" id="feOppo" aria-label="${DRF.__('Opposizione')}"></button></div>
          </div>
          <div class="grid2">
            <div class="field"><label>${DRF.__('Incasso')}</label><select class="select" id="feMetodo">${d.metodi.map(m => `<option value="${DRF.esc(m.nome)}">${DRF.esc(m.nome)}${m.giorni > 0 ? ` ${DRF.__('· incasso')} ${m.giorni} gg` : ''}</option>`).join('')}</select></div>
            <div class="field"><label>${DRF.__('Note in fattura')}</label><input class="input" id="feNote" placeholder="${DRF.__('Facoltative')}" value="${fx ? DRF.esc(fx.note || '') : ''}"></div>
          </div>
          <div class="card white fat-riep" id="feRiep"></div>
        </div>`, salva, fx ? DRF.__('Salva modifiche') : DRF.__('Emetti fattura'));

      if (fx) DRF.ui.setSelect($('#fePat'), fx.paziente_id);
      else if (d.visita) DRF.ui.setSelect($('#fePat'), d.visita.paziente_id);
      else if (pazienteId) DRF.ui.setSelect($('#fePat'), pazienteId);
      const predef = (d.metodi.find(m => m.predefinito) || d.metodi[0] || {}).nome;
      DRF.ui.setSelect($('#feMetodo'), fx ? (fx.metodo && d.metodi.some(m => m.nome === fx.metodo) ? fx.metodo : (fx.stato === 'attesa' ? ((d.metodi.find(m => m.giorni > 0) || {}).nome || predef) : predef)) : predef);
      righe(); totali();
      // slot per le estensioni: righe, sconti, campi aggiuntivi nell'editor della fattura
      DRF.hooks.run('fattura.editor', { $root: $('#sheetBody'), editor: E, dati: d, fattura: fx || null, righe: () => E.rows,
        aggiungiRiga: r => { E.rows.push(Object.assign({ tipo: 'riga', descrizione: '', quantita: 1, prezzo: 0, iva_id: d.iva_predefinita ? +d.iva_predefinita : null }, r || {})); righe(); totali(); },
        ricalcola: () => { righe(); totali(); }, campo: html => { const $f = $(html); $('#feNote').closest('.grid2').after($f); DRF.ui.wire($f[0]); return $f; } });

      $('#feAddPrest').on('change', function () { if (!this.value) return; const p = listino[+this.value]; if (p) { E.rows.push(rigaDa(p)); righe(); totali(); } DRF.ui.setSelect($(this), ''); });
      $('#feAddLibera').on('click', () => { E.rows.push({ tipo: 'riga', descrizione: '', quantita: 1, prezzo: 0, iva_id: d.iva_predefinita ? +d.iva_predefinita : null }); righe(); totali(); $('#feRows tr:last [data-f=descrizione]').trigger('focus'); });
      $('#feAddDesc').on('click', () => { E.rows.push({ tipo: 'descrizione', descrizione: '' }); righe(); totali(); $('#feRows tr:last [data-f=descrizione]').trigger('focus'); });
      $('#feRows').on('input', '[data-f]', function () { const r = E.rows[+this.closest('tr').dataset.i]; r[this.dataset.f] = this.dataset.f === 'descrizione' ? this.value : this.value; if (this.dataset.f !== 'descrizione') { aggiornaRiga(this.closest('tr'), r); } totali(); })
        .on('change', 'select[data-f=iva_id]', function () { const r = E.rows[+this.closest('tr').dataset.i]; r.iva_id = +this.value || null; totali(); })
        .on('click', '[data-del]', function () { const i = +this.closest('tr').dataset.i; if (E.rows[i].spese) $('#feSpese').removeClass('on'); E.rows.splice(i, 1); righe(); totali(); });
      $('#feSpese').on('click', function () {
        $(this).toggleClass('on');
        const i = E.rows.findIndex(r => r.spese);
        if ($(this).hasClass('on') && i < 0) E.rows.push({ tipo: 'riga', descrizione: d.spese.descrizione, quantita: 1, prezzo: d.spese.importo, iva_id: d.iva_predefinita ? +d.iva_predefinita : null, spese: true });
        if (!$(this).hasClass('on') && i >= 0) E.rows.splice(i, 1);
        righe(); totali();
      });
      $('#feContr').on('click', function () { $(this).toggleClass('on'); E.contributi = $(this).hasClass('on'); totali(); });
      $('#feOppo').on('click', function () { $(this).toggleClass('on'); E.opposizione = $(this).hasClass('on'); });
    });
  }

  function ivaSelect(r) {
    return `<select data-f="iva_id">${st.ed.d.iva.map(i => `<option value="${i.id}" ${+r.iva_id === +i.id ? 'selected' : ''}>${pcent(i.aliquota)}</option>`).join('')}</select>`;
  }
  function righe() {
    const E = st.ed;
    $('#feRows').html(E.rows.map((r, i) => r.tipo === 'descrizione'
      ? `<tr data-i="${i}" class="r-desc"><td colspan="4"><input data-f="descrizione" value="${DRF.esc(r.descrizione)}" placeholder="${DRF.__('Testo descrittivo (senza importo)…')}"></td><td class="c-t muted">—</td><td class="c-x"><button type="button" class="icon-btn sm danger" data-del title="${DRF.__('Rimuovi')}">${I('trash', 'fa-solid fa-trash')}</button></td></tr>`
      : `<tr data-i="${i}"><td><input data-f="descrizione" value="${DRF.esc(r.descrizione)}" placeholder="${DRF.__('Prestazione…')}"></td><td class="c-q"><input data-f="quantita" value="${DRF.esc(String(r.quantita).replace('.', ','))}" inputmode="decimal"></td><td class="c-p"><input data-f="prezzo" value="${DRF.esc(num(r.prezzo).toLocaleString(DRF.util.loc(), { minimumFractionDigits: 2, maximumFractionDigits: 2 }))}" inputmode="decimal"></td><td class="c-i">${ivaSelect(r)}</td><td class="c-t num" data-tot>${U.eur(n2(num(r.quantita) * num(r.prezzo)))}</td><td class="c-x"><button type="button" class="icon-btn sm danger" data-del title="${DRF.__('Rimuovi')}">${I('trash', 'fa-solid fa-trash')}</button></td></tr>`
    ).join('') || '<tr class="r-empty"><td colspan="6">' + DRF.__('Nessuna riga: aggiungi una prestazione dal listino qui sotto.') + '</td></tr>');
    DRF.icons.apply($('#feRows')[0]);
  }
  function aggiornaRiga(tr, r) { $(tr).find('[data-tot]').text(U.eur(n2(num(r.quantita) * num(r.prezzo)))); }

  /** Totali come sul server: imponibile, contributo, IVA per aliquota, bollo sulla parte esente */
  function calcola() {
    const E = st.ed, ali = {}; let imp = 0;
    const aliDi = r => { const i = E.d.iva.find(x => +x.id === +r.iva_id); return i ? +i.aliquota : 0; };
    E.rows.forEach(r => { if (r.tipo !== 'riga') return; const t = n2(num(r.quantita) * num(r.prezzo)); imp += t; const a = aliDi(r); ali[a] = (ali[a] || 0) + t; });
    const contr = E.contributi && E.d.contributi.perc > 0 ? n2(imp * E.d.contributi.perc / 100) : 0;
    let iva = 0; const det = Object.entries(ali).map(([a, base]) => { const v = n2(base * a / 100); iva += v; return { aliquota: +a, imponibile: n2(base), iva: v }; });
    const esente = (ali[0] || 0) + contr;
    const bollo = esente > E.d.bollo.soglia ? E.d.bollo.importo : 0;
    return { imp: n2(imp), contr, iva: n2(iva), det, bollo, tot: n2(imp + contr + iva + bollo) };
  }
  function totali() {
    const E = st.ed, t = calcola();
    $('#feRiep').html(`
      <div class="row"><span class="muted">${DRF.__('Imponibile')}</span><b class="num">${U.eur(t.imp)}</b></div>
      ${t.contr ? `<div class="row"><span class="muted">${DRF.esc(E.d.contributi.descrizione || DRF.__('Contributo previdenziale'))} (${pcent(E.d.contributi.perc)})</span><b class="num">${U.eur(t.contr)}</b></div>` : ''}
      ${t.det.filter(x => x.aliquota > 0).map(x => `<div class="row"><span class="muted">IVA ${pcent(x.aliquota)} su ${U.eur(x.imponibile)}</span><b class="num">${U.eur(x.iva)}</b></div>`).join('')}
      ${t.det.some(x => x.aliquota === 0) ? `<div class="row"><span class="muted small">${DRF.__('Quota esente IVA (art. 10)')}</span><span class="num small muted">${U.eur(t.det.find(x => x.aliquota === 0).imponibile)}</span></div>` : ''}
      ${t.bollo ? `<div class="row"><span class="muted">${DRF.__('Marca da bollo (esente oltre')} ${U.eur(E.d.bollo.soglia)})</span><b class="num">${U.eur(t.bollo)}</b></div>` : ''}
      <div class="row tot"><b>${DRF.__('Totale')}</b><b class="num">${U.eur(t.tot)}</b></div>`);
  }
  function salva() {
    const E = st.ed;
    const pid = +$('#fePat').val();
    if (!pid) { DRF.ui.toast(DRF.__('Seleziona il paziente'), 'warn'); return false; }
    const righeOut = E.rows.map(r => r.tipo === 'descrizione' ? { tipo: 'descrizione', descrizione: r.descrizione.trim() } : { tipo: 'riga', descrizione: r.descrizione.trim(), quantita: num(r.quantita) || 1, prezzo: num(r.prezzo), iva_id: r.iva_id }).filter(r => r.descrizione);
    if (!righeOut.some(r => r.tipo === 'riga')) { DRF.ui.toast(DRF.__('Aggiungi almeno una prestazione'), 'warn'); return false; }
    DRF.ui.sheetBusy(true);
    DRF.api.post('fatture', E.id ? 'modifica' : 'save', { id: E.id, paziente_id: pid, data: $('#feData').val() || U.todayIso(), righe: righeOut, contributi: E.contributi ? 1 : 0, opposizione: E.opposizione ? 1 : 0, metodo: $('#feMetodo').val(), note: $('#feNote').val(), visita_id: E.visita })
      .then(r => {
        DRF.ui.closeSheet(); DRF.ui.toast(r.messaggio); st.hl = r.fattura.id; st.filtro = 'tutte'; $('#fFilter button').removeClass('on').first().addClass('on'); load(); DRF.app.aggiornaBadge();
        if (!E.id) DRF.ui.confirm(`${DRF.__('Stampare la fattura')} ${r.fattura.numero}?`, DRF.__('La stampa la segna come emessa in via definitiva: da quel momento non sarà più modificabile né eliminabile.'), DRF.__('Stampa ora'))
          .then(ok => { if (ok) { r.fattura.stampata_il = new Date().toISOString(); const riga = st.dt && st.dt.row('#f' + r.fattura.id); if (riga && riga.data()) riga.data().stampata_il = r.fattura.stampata_il; DRF.doc.apri('fattura', r.fattura.id); } });
      })
      .always(() => DRF.ui.sheetBusy(false));
    return false;
  }

  /* ------------------------------ DA VISITA ------------------------------ */

  /** Visite chiuse con prestazioni non ancora fatturate: un click compila la fattura */
  function daVisita() {
    DRF.api.get('fatture', 'da_visita').then(d => {
      if (!d.visite.length) return DRF.ui.alert(DRF.__('Nessuna visita da fatturare'), DRF.__('Le visite chiuse con prestazioni segnate in scheda compaiono qui finché non vengono fatturate.'), 'info');
      DRF.ui.modal({ title: DRF.__('Fattura da una visita'), size: 'lg', ok: false, cancel: DRF.__('Chiudi'),
        html: `<p class="small muted" style="margin-bottom:12px">${DRF.__('Visite chiuse con prestazioni non ancora fatturate: scegline una e la fattura si compila da sola.')}</p><div class="fat-dv">${d.visite.map(v => `<button type="button" class="fat-dv-it" data-v="${v.id}"><span class="num fat-dv-data">${U.fmtIso(v.data)}</span><span class="fat-dv-who"><b>${DRF.esc(v.paziente)}${v.professionista ? ` <em>· ${DRF.esc(v.professionista)}</em>` : ''}</b><small>${DRF.esc((v.prestazioni || []).map(p => p.nome).join(', '))}</small></span>${I('arrow-small-right', 'fa-solid fa-arrow-right')}</button>`).join('')}</div>`,
        onOpen($b) { $b.on('click', '.fat-dv-it', function () { const id = +this.dataset.v; DRF.ui.closeModal(); nuova(null, id); }); } });
    });
  }

  return {
    title: DRF.__('Fatturazione'),
    sub() { return U.cap(U.today().toLocaleDateString(DRF.util.loc(), { month: 'long', year: 'numeric' })) + (st.kpi ? ` · ${st.kpi.aperte} ${DRF.__('da incassare')}` : ''); },
    action: { label: DRF.__('Nuova fattura'), fi: 'plus', fa: 'fa-solid fa-plus', run: () => nuova() },
    nuova,
    init() {
      $('#fFilter').on('click', 'button', function () { st.filtro = this.dataset.f; load(); });
      $('#fTable').on('click', '[data-mail]', function () { DRF.doc.invia({ tipo: 'fattura', id: +this.dataset.mail }).then(x => { if (x) load(); }); });
      $('#fTable').on('click', '[data-pay]', function () { const id = +this.dataset.pay; DRF.api.post('fatture', 'paga', { id }).then(d => { DRF.ui.toast(d.messaggio); load(); DRF.app.aggiornaBadge(); }); });
      $('#fListino').on('click', () => DRF.nav.go('archivi', { archivio: 'prestazioni' }));
      $('#fDaVisita').on('click', daVisita);
      // la prima apertura del documento marca la fattura come stampata: da lì niente più modifiche
      $('#fTable').on('click', 'a[href*="tipo=fattura"]', function () { const f = st.dt.row($(this).closest('tr')).data(); if (f && !f.stampata_il) f.stampata_il = new Date().toISOString(); });
      DRF.menu.bind($('#fTable'), 'tbody tr', tr => {
        const f = st.dt.row(tr).data(); if (!f) return null;
        const bloccata = !!f.stampata_il;
        return [
          { label: DRF.__('Apri / stampa'), fi: 'print', fa: 'fa-solid fa-print', run: () => { if (!f.stampata_il) f.stampata_il = new Date().toISOString(); DRF.doc.apri('fattura', f.id); } },
          ...(f.stato !== 'pagata' ? [{ label: DRF.__('Segna come pagata'), fi: 'euro', fa: 'fa-solid fa-euro-sign', run: () => DRF.api.post('fatture', 'paga', { id: f.id }).then(d => { DRF.ui.toast(d.messaggio); load(); DRF.app.aggiornaBadge(); }) }] : []),
          { sep: true },
          { label: bloccata ? DRF.__('Modifica (già stampata)') : DRF.__('Modifica fattura'), fi: 'pencil', fa: 'fa-solid fa-pen', disabled: bloccata, run: () => nuova(null, null, f.id) },
          { label: bloccata ? DRF.__('Elimina (già stampata)') : DRF.__('Elimina fattura'), fi: 'trash', fa: 'fa-solid fa-trash', danger: true, disabled: bloccata, run: () => {
            DRF.ui.confirm(DRF.__('Eliminare la fattura ') + f.numero + '?', DRF.__('Verrà rimossa anche la copia archiviata. Il numero resterà libero e verrà riusato') + (+f.visita_id ? '; ' + DRF.__('la visita collegata tornerà tra quelle da fatturare') : '') + '.', DRF.__('Elimina'), 'warn')
              .then(ok => { if (ok) DRF.api.post('fatture', 'elimina', { id: f.id }).then(d => { DRF.ui.toast(d.messaggio); load(); DRF.app.aggiornaBadge(); }); });
          } },
        ];
      });
    },
    show(opts) {
      if (opts && opts.select) { st.hl = +opts.select; st.filtro = 'tutte'; $('#fFilter button').removeClass('on').first().addClass('on'); }
      load();
      if (opts && opts.da_visita) nuova(null, +opts.da_visita);
    }
  };
})(jQuery));
