<?php
/**
 * ARCHIVIO FILE dello studio: la cartella dove stanno documenti generati, archiviati e caricati, con la QUOTA.
 *   studio nel database base   → docs/archivio  (come sempre; upload in docs/archivio/upload)
 *   studio con database dedicato → data/studi/<id>/archivio
 * La quota (MB) è nella riga dello studio nel database comune (studi.quota_mb; 0 = illimitata; predefinita da config
 * archivio.quota_mb) e si compra dallo Store / dal portale: `php strumenti/studio.php quota <id> +5120`.
 * Tutto ciò che scrive un file passa da Spazio::scrivi(): controllo della quota, percorso sicuro, capability per le estensioni.
 */
final class Spazio
{
    public static function base(): string
    {
        $t = Database::tenantId();
        return $t ? DRF_ROOT . "/data/studi/$t/archivio" : rtrim((string) (Config::get('paths.archivio') ?: DRF_ROOT . '/docs/archivio'), '/');
    }

    /** Percorso assoluto di un file relativo all'archivio (null se esce dalla cartella) */
    public static function percorso(string $rel): ?string
    {
        $rel = ltrim(str_replace('\\', '/', $rel), '/');
        if ($rel === '' || str_contains($rel, '..')) return null;
        return self::base() . '/' . $rel;
    }

    /** Scrive un file (crea le cartelle); rifiuta se la quota è esaurita. Ritorna il percorso relativo. */
    public static function scrivi(string $rel, string $bytes): string
    {
        Capabilities::richiedi('spazio.scrivi');
        $p = self::percorso($rel) ?? throw new ApiException(__('Percorso non valido'));
        $q = self::quota();
        if ($q > 0 && self::uso() + strlen($bytes) > $q * 1048576) throw new ApiException('Spazio esaurito: lo studio ha usato ' . self::umano(self::uso()) . ' su ' . self::umano($q * 1048576) . '. Acquista altro spazio dallo Store o elimina documenti.');
        if (!is_dir(dirname($p))) mkdir(dirname($p), 0775, true);
        if (file_put_contents($p, $bytes) === false) throw new ApiException(__('Impossibile scrivere il file'));
        self::azzeraCache();
        return $rel;
    }

    public static function elimina(string $rel): void
    {
        Capabilities::richiedi('spazio.scrivi');
        $p = self::percorso($rel);
        if ($p && is_file($p)) { unlink($p); self::azzeraCache(); }
    }

    /** Byte usati dallo studio (calcolo con cache di 5 minuti nelle impostazioni) */
    public static function uso(bool $forza = false): int
    {
        $il = (int) (Impostazione::get('archivio_uso_il') ?: 0);
        if (!$forza && time() - $il < 300) return (int) Impostazione::get('archivio_uso');
        $tot = 0; $b = self::base();
        if (is_dir($b)) foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($b, FilesystemIterator::SKIP_DOTS)) as $f) $tot += $f->getSize();
        $tot += self::pesoDatabase();
        Capabilities::comeCore(function () use ($tot) { Impostazione::set('archivio_uso', (string) $tot); Impostazione::set('archivio_uso_il', (string) time()); });
        return $tot;
    }

    /** Il database dello studio conta nello spazio (SQLite: il file; MySQL: dimensione delle tabelle) */
    private static function pesoDatabase(): int
    {
        try {
            if (Database::driver() === 'sqlite') { $f = Database::tenantId() ? null : (string) Config::get('db.sqlite'); if (Database::tenantId()) { $s = Tenant::studio(); $c = $s ? Tenant::configDb($s) : null; $f = $c['sqlite'] ?? null; if ($f && !str_starts_with($f, '/')) $f = DRF_ROOT . '/' . $f; } return $f && is_file($f) ? filesize($f) : 0; }
            return (int) Database::value('SELECT COALESCE(SUM(data_length + index_length), 0) FROM information_schema.tables WHERE table_schema = DATABASE()');
        } catch (Throwable $e) { return 0; }
    }

    /** Quota in MB (0 = illimitata) */
    public static function quota(): int
    {
        $sid = Auth::studioId();
        $q = null;
        if ($sid) { try { $q = Database::value('SELECT quota_mb FROM ' . Database::comune('studi') . ' WHERE id = ?', [$sid]); } catch (Throwable $e) { /* colonna assente */ } }
        return (int) ($q !== null && $q !== '' ? $q : Config::get('archivio.quota_mb', 2048));
    }

    /** Il riepilogo per l'interfaccia */
    public static function stato(): array
    {
        $uso = self::uso(); $q = self::quota();
        return ['uso' => $uso, 'uso_umano' => self::umano($uso), 'quota_mb' => $q, 'quota_umano' => $q ? self::umano($q * 1048576) : 'illimitata',
            'percentuale' => $q ? min(100, (int) round($uso / ($q * 1048576) * 100)) : 0, 'esaurito' => $q > 0 && $uso >= $q * 1048576];
    }

    public static function azzeraCache(): void { Capabilities::comeCore(fn() => Impostazione::set('archivio_uso_il', '0')); }

    public static function umano(int $b): string
    {
        if ($b >= 1073741824) return number_format($b / 1073741824, 2, ',', '.') . ' GB';
        if ($b >= 1048576) return number_format($b / 1048576, 1, ',', '.') . ' MB';
        return number_format($b / 1024, 0, ',', '.') . ' KB';
    }
}
