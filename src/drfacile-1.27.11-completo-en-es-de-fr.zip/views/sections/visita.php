<div class="visit stagger">
  <div>
    <div class="vhead" id="vhead"></div>
    <div class="stepper" id="stepper">
      <button class="step on" data-tab="anamnesi"><i class="n">1</i><?= __('Anamnesi') ?></button>
      <button class="step" data-tab="visita"><i class="n">2</i><?= __('Visita') ?></button>
      <button class="step" data-tab="esami"><i class="n">3</i><?= __('Esami') ?></button>
      <button class="step" data-tab="terapia"><i class="n">4</i><?= __('Terapia') ?></button>
      <button class="step" data-tab="complicanze"><i class="n">5</i><?= __('Complicanze') ?></button>
    </div>

    <div class="vtab" data-tab="anamnesi">
      <div class="card">
        <h3><i class="ico" data-fi="notebook" data-fa="fa-regular fa-clipboard"></i><?= __('Motivo e anamnesi') ?></h3>
        <div class="field"><label><?= __('Motivo della visita') ?></label><input class="input" name="motivo" placeholder="<?= __('Es. dolore lombare da 3 giorni') ?>"></div>
        <div class="field"><label><?= __('Prestazioni eseguite') ?></label><select class="select" id="vPrest" multiple data-placeholder="<?= __('Es. visita ginecologica, pap test…') ?>"></select><span class="small muted" style="display:block;margin-top:6px"><?= __('Verranno riportate nella fattura della visita. Il listino si gestisce in') ?> <b><?= __('Archivi → Prestazioni') ?></b>.</span></div>
        <div class="field"><label><?= __('Anamnesi') ?></label><textarea class="rich" id="vNote" name="anamnesi" data-height="150" placeholder="<?= __('Anamnesi patologica remota e prossima, sintomi riferiti, farmaci in uso…') ?>" hidden></textarea></div>
      </div>
      <div class="card" style="margin-top:14px">
        <h3><i class="ico" data-fi="user" data-fa="fa-solid fa-person"></i><?= __('Quadro soggettivo') ?> <span class="muted small" style="font-weight:600"><?= __('· sintomi riferiti dal paziente: tocca una regione del modello') ?></span></h3>
        <div id="bmSintomi"></div>
      </div>
    </div>

    <div class="vtab" data-tab="visita" hidden>
      <div class="vitals" id="vitals">
        <div class="vital"><label><i class="ico" data-fi="heart" data-fa="fa-solid fa-heart-pulse"></i><?= __('Pressione') ?></label><div class="v"><input id="vSys" name="pa_sys" placeholder="120" data-mask="intero" data-min="40" data-max="300" maxlength="3"><em>/</em><input id="vDia" name="pa_dia" placeholder="80" data-mask="intero" data-min="20" data-max="200" maxlength="3"><em>mmHg</em></div></div>
        <div class="vital"><label><i class="ico" data-fi="pulse" data-fa="fa-solid fa-wave-square"></i><?= __('Frequenza') ?></label><div class="v"><input id="vFc" name="fc" placeholder="72" data-mask="intero" data-min="15" data-max="250" maxlength="3"><em>bpm</em></div></div>
        <div class="vital"><label><i class="ico" data-fi="lungs" data-fa="fa-solid fa-lungs"></i>SpO₂</label><div class="v"><input id="vSpo2" name="spo2" placeholder="98" data-mask="intero" data-min="40" data-max="100" maxlength="3"><em>%</em></div></div>
        <div class="vital"><label><i class="ico" data-fi="thermometer-half" data-fa="fa-solid fa-temperature-half"></i><?= __('Temperatura') ?></label><div class="v"><input id="vTemp" name="temp" placeholder="36,5" data-mask="decimale1" data-min="30" data-max="45" maxlength="4"><em>°C</em></div></div>
        <div class="vital"><label><i class="ico" data-fi="scale" data-fa="fa-solid fa-weight-scale"></i><?= __('Peso') ?></label><div class="v"><input id="vPeso" name="peso" placeholder="70" data-mask="decimale1" data-min="1" data-max="350" maxlength="5"><em>kg</em></div></div>
        <div class="vital"><label><i class="ico" data-fi="ruler-vertical" data-fa="fa-solid fa-ruler-vertical"></i><?= __('Altezza') ?></label><div class="v"><input id="vAlt" name="altezza" placeholder="170" data-mask="intero" data-min="30" data-max="250" maxlength="3"><em>cm</em></div></div>
        <div class="vital"><label><i class="ico" data-fi="stats" data-fa="fa-solid fa-chart-simple"></i>BMI</label><div class="v"><span class="big" id="vBmi">—</span><em id="vBmiCat"></em></div></div>
        <div class="vital"><label><i class="ico" data-fi="raindrops" data-fa="fa-solid fa-droplet"></i><?= __('Glicemia') ?></label><div class="v"><input id="vGli" name="glicemia" placeholder="90" data-mask="intero" data-min="20" data-max="900" maxlength="3"><em>mg/dl</em><em id="vGliCat"></em></div></div>
      </div>
      <div class="card" style="margin-bottom:14px">
        <h3><i class="ico" data-fi="stethoscope" data-fa="fa-solid fa-stethoscope"></i><?= __('Quadro oggettivo') ?> <span class="muted small" style="font-weight:600"><?= __('· reperti dell\'esame obiettivo: tocca una regione del modello') ?></span></h3>
        <div id="bmReperti"></div>
      </div>
      <div class="grid2" style="margin-bottom:14px">
        <div class="card"><h3><i class="ico" data-fi="notebook" data-fa="fa-regular fa-clipboard"></i><?= __('Esame obiettivo, note') ?></h3>
          <textarea class="rich" name="esame_obiettivo" data-height="150" placeholder="<?= __('Rilievi dell\'esame obiettivo in testo libero…') ?>" hidden></textarea>
        </div>
        <div class="card"><h3><i class="ico" data-fi="diagnosis" data-fa="fa-solid fa-notes-medical"></i><?= __('Diagnosi') ?></h3>
          <div class="tagbox" id="dxBox"><input id="dxInput" list="dxList" placeholder="<?= __('Scrivi e premi Invio') ?>"></div>
          <datalist id="dxList"></datalist>
          <p class="small muted" style="margin-top:8px"><?= __('Le diagnosi frequenti si gestiscono in') ?> <b><?= __('Archivi → Diagnosi') ?></b>.</p>
        </div>
      </div>
      <div class="card"><h3><i class="ico" data-fi="time-past" data-fa="fa-solid fa-clock-rotate-left"></i><?= __('Storico visite del paziente') ?></h3>
        <table id="vStorico" class="dt" style="width:100%"><thead><tr><th></th><th><?= __('Data') ?></th><th><?= __('Motivo') ?></th><th><?= __('Diagnosi') ?></th><th><?= __('Referto') ?></th></tr></thead><tbody></tbody></table>
      </div>
    </div>

    <div class="vtab" data-tab="esami" hidden>
      <div class="card">
        <h3><i class="ico" data-fi="test-tube" data-fa="fa-solid fa-vial"></i><?= __('Esami richiesti ed eseguiti') ?></h3>
        <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:10px">
          <input class="input" id="exInput" list="exList" placeholder="<?= __('Esame, poi Invio') ?>" style="flex:1;min-width:220px">
          <div class="seg" id="exStato"><button class="on" data-v="richiesto"><?= __('Richiesto') ?></button><button data-v="eseguito"><?= __('Eseguito') ?></button></div>
          <button class="btn soft" id="exAdd" type="button" title="<?= __('Aggiungi') ?>"><i class="ico" data-fi="plus" data-fa="fa-solid fa-plus"></i></button>
        </div>
        <datalist id="exList"></datalist>
        <table id="exTable" class="dt" style="width:100%"><thead><tr><th></th><th><?= __('Esame') ?></th><th><?= __('Stato') ?></th><th><?= __('Data') ?></th><th><?= __('Esito / note') ?></th></tr></thead><tbody></tbody></table>
        <p class="small muted" style="margin-top:10px"><?= __('Il catalogo esami si gestisce in') ?> <b><?= __('Archivi → Esami') ?></b>; <?= __('l\'integrazione con il sistema esami di Igea si innesta qui.') ?></p>
      </div>
    </div>

    <div class="vtab" data-tab="terapia" hidden>
      <div class="grid2">
        <div class="card"><h3><i class="ico" data-fi="capsules" data-fa="fa-solid fa-pills"></i><?= __('Terapia') ?></h3>
          <div class="therapy" id="therapy"></div>
          <div class="row"><input class="input" id="thInput" list="thList" placeholder="<?= __('Farmaco e posologia, poi Invio') ?>"><button class="btn soft" id="thAdd" title="<?= __('Aggiungi') ?>"><i class="ico" data-fi="plus" data-fa="fa-solid fa-plus"></i></button></div>
          <datalist id="thList"></datalist>
        </div>
        <div class="card"><h3><i class="ico" data-fi="calendar-check" data-fa="fa-regular fa-calendar-check"></i><?= __('Indicazioni e controllo') ?></h3>
          <div class="field"><label><?= __('Indicazioni per il paziente') ?></label><textarea class="textarea" name="indicazioni" placeholder="<?= __('Riposo, dieta, esami da eseguire…') ?>"></textarea></div>
          <div class="field"><label><?= __('Prossimo controllo') ?></label><input class="input" type="date" name="controllo"></div>
        </div>
      </div>
    </div>

    <div class="vtab" data-tab="complicanze" hidden>
      <div class="card"><h3><i class="ico" data-fi="exclamation" data-fa="fa-solid fa-triangle-exclamation"></i><?= __('Complicanze') ?></h3>
        <div class="seg" id="vCompSeg" style="margin-bottom:12px"><button class="on" data-v="0"><?= __('Nessuna complicanza') ?></button><button data-v="1"><?= __('Complicanze presenti') ?></button></div>
        <textarea class="textarea" name="complicanze" style="min-height:150px" placeholder="<?= __('Descrivi complicanze, eventi avversi, reazioni…') ?>" hidden></textarea>
      </div>
    </div>

    <div class="row" style="justify-content:space-between;margin-top:14px">
      <button class="btn ghost" id="vPrev"><i class="ico" data-fi="angle-left" data-fa="fa-solid fa-chevron-left"></i><?= __('Indietro') ?></button>
      <button class="btn primary" id="vNext"><?= __('Avanti') ?><i class="ico" data-fi="angle-right" data-fa="fa-solid fa-chevron-right"></i></button>
    </div>
  </div>
  <div class="side">
    <div class="card"><h3><i class="ico" data-fi="exclamation" data-fa="fa-solid fa-triangle-exclamation"></i><?= __('Attenzione') ?></h3><div class="alert-list" id="vAlert"></div></div>
    <div class="card"><h3><i class="ico" data-fi="time-past" data-fa="fa-solid fa-clock-rotate-left"></i><?= __('Storico del paziente') ?></h3><div id="vhist"></div></div>
    <button class="btn primary block" id="closeVisit"><i class="ico" data-fi="check" data-fa="fa-solid fa-check"></i><?= __('Chiudi visita e genera referto') ?></button>
    <button class="btn ghost block" id="draftVisit"><?= __('Salva bozza') ?></button>
    <button class="btn ghost block" id="abortVisit" style="color:var(--red-ink)"><?= __('Annulla visita') ?></button>
    <p class="small muted" id="vSaved" style="text-align:center"></p>
  </div>
</div>
