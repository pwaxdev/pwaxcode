/* Utilità: date, formati italiani, iniziali, colori avatar */
DRF.util = (function () {
  'use strict';
  const pad = n => String(n).padStart(2, '0');
  const U = {
    today() { const d = new Date(); d.setHours(0, 0, 0, 0); return d; },
    iso(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; },
    todayIso() { return U.iso(U.today()); },
    pd(k) { const [y, m, d] = String(k).slice(0, 10).split('-').map(Number); return new Date(y, m - 1, d); },
    addDays(d, n) { const x = new Date(d); x.setDate(x.getDate() + n); return x; },
    fmtLong(d) { return d.toLocaleDateString(U.loc(), { weekday: 'long', day: 'numeric', month: 'long' }); },
    fmtShort(d) { return d.toLocaleDateString(U.loc(), { day: '2-digit', month: '2-digit', year: 'numeric' }); },
    fmtIso(k) { return k ? U.fmtShort(U.pd(k)) : ''; },
    fmtDateTime(s) { if (!s) return ''; const d = new Date(String(s).replace(' ', 'T')); return isNaN(d) ? s : d.toLocaleDateString(U.loc(), { day: '2-digit', month: '2-digit', year: 'numeric' }) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); },
    cap(s) { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); },
    mins(t) { const [h, m] = String(t).split(':').map(Number); return h * 60 + m; },
    nowMin() { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); },
    eur(n) { return Number(n || 0).toLocaleString(DRF.util.loc(), { style: 'currency', currency: 'EUR' }); },
    num(n, dec = 0) { return Number(n || 0).toLocaleString(DRF.util.loc(), { minimumFractionDigits: dec, maximumFractionDigits: dec }); },
    initials(n) { return String(n || '').split(' ').filter(Boolean).map(w => w[0]).join('').slice(0, 2).toUpperCase(); },
    hue(n) { let h = 0; for (const c of String(n || '')) h = (h * 31 + c.charCodeAt(0)) % 360; return h; },
    avStyle(n) { return `background:hsl(${U.hue(n)} 50% 60%)`; },
    plural(n, s, p) { return n === 1 ? s : p; },
    saluto() { const h = new Date().getHours(); return h < 13 ? DRF.__('Buongiorno') : h < 18 ? DRF.__('Buon pomeriggio') : DRF.__('Buonasera'); },
    /** Locale per le date (dalla lingua dell'utente: it-IT, en-US…) */
    loc() { return ((DRF.config.locale || 'it_IT').replace('_', '-')); },
    /** Nomi dei giorni (lun→dom) e dei mesi nella lingua dell'utente, con l'iniziale maiuscola */
    giorniBrevi() { const b = new Date(2024, 0, 1); return [0, 1, 2, 3, 4, 5, 6].map(i => { const s = new Date(b.getFullYear(), b.getMonth(), b.getDate() + i).toLocaleDateString(U.loc(), { weekday: 'short' }).replace('.', ''); return s.charAt(0).toUpperCase() + s.slice(1); }); },
    mesi() { return [...Array(12).keys()].map(m => { const s = new Date(2024, m, 1).toLocaleDateString(U.loc(), { month: 'long' }); return s.charAt(0).toUpperCase() + s.slice(1); }); },
    debounce(fn, ms) { let t; return function () { clearTimeout(t); const a = arguments, c = this; t = setTimeout(() => fn.apply(c, a), ms); }; },
  };
  return U;
})();
