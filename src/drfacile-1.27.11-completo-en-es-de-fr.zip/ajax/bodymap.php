<?php
/** Pool degli SVG dei modelli corporei (uomo, donna, ragazzo, ragazza, neonato · fronte e retro), scaricato una volta dal browser */
require __DIR__ . '/../core/bootstrap.php';
Auth::requireAjax();
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: private, max-age=86400');
readfile(DRF_ROOT . '/views/partials/svgbody.php');
