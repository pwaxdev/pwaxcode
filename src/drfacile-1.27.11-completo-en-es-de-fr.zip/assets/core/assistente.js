/* Assistente "anti sbadati" (F2): pannello flottante con i percorsi guidati.
   I passi automatici si spuntano da soli (ricontrollati a ogni cambio di sezione), quelli manuali con un click.
   Non invasivo: compare ridotto a pillola, si espande/riduce, si chiude quando il percorso è finito.
   Percorsi definiti in core/percorsi.php; si attiva/disattiva in Impostazioni → Preferenze. */
DRF.assistente = (function ($) {
  'use strict';
  const st = { p: null, aperto: false, attivo: true, visto: 0 };
  let $box = null;

  function el() {
    if ($box) return $box;
    $box = $('<div class="todo-float" hidden><button type="button" class="todo-pill"></button><div class="todo-panel" hidden><div class="todo-head"><b></b><span class="todo-prog"></span><button type="button" class="icon-btn sm" data-todo="riduci" title="' + DRF.__('Riduci') + '"><i class="ico" data-fi="angle-small-down" data-fa="fa-solid fa-chevron-down"></i></button><button type="button" class="icon-btn sm" data-todo="chiudi" title="' + DRF.__('Chiudi il percorso') + '"><i class="ico" data-fi="cross-small" data-fa="fa-solid fa-xmark"></i></button></div><div class="todo-list"></div><div class="todo-foot muted small">' + DRF.__('F2 mostra e nasconde assistente') + '</div></div></div>').appendTo('body');
    $box.on('click', '.todo-pill', () => espandi(!st.aperto));
    $box.on('click', '[data-todo="riduci"]', () => espandi(false));
    $box.on('click', '[data-todo="chiudi"]', () => {
      if (!st.p) return;
      DRF.ui.confirm(st.p.completo ? DRF.__('Percorso completato: archiviarlo?') : DRF.__('Chiudere il percorso?'), st.p.completo ? DRF.__('Bel lavoro: tutti i passi sono fatti.') : DRF.__('I passi non completati resteranno così.'), st.p.completo ? DRF.__('Archivia') : DRF.__('Chiudi')).then(ok => {
        if (ok) DRF.api.post('assistente', 'chiudi', { id: st.p.id }).then(() => { st.p = null; render(); A.refresh(); });
      });
    });
    $box.on('click', '.todo-check', function (e) {
      e.stopPropagation();
      const k = this.dataset.k, passo = st.p.passi.find(x => x.chiave === k);
      if (passo.auto) return DRF.ui.toast(DRF.__('Questo passo si spunta da solo appena la condizione è vera'), 'info');
      DRF.api.post('assistente', 'spunta', { id: st.p.id, chiave: k, fatto: passo.fatto ? 0 : 1 }).then(d => { st.p = d.percorso; render(); if (d.percorso.completo) festa(); });
    });
    $box.on('click', '.todo-it', function () {
      const passo = st.p.passi.find(x => x.chiave === this.dataset.k);
      if (passo && passo.link && passo.link.modulo) DRF.nav.go(passo.link.modulo, passo.link.opts || {});
    });
    return $box;
  }

  function festa() { DRF.ui.toast(DRF.__('Percorso completato! 🎉'), 'success'); }

  function render() {
    const $b = el();
    if (!st.attivo || !st.p) { $b.prop('hidden', true); return; }
    const p = st.p;
    $b.prop('hidden', false);
    $b.find('.todo-pill').html(`${DRF.icons.html('list-check', 'fa-solid fa-list-check')}<span>${DRF.esc(p.etichetta || p.titolo)}</span><b class="${p.completo ? 'ok' : ''}">${p.fatti}/${p.totale}</b>`);
    $b.find('.todo-head b').text(p.etichetta || p.titolo);
    $b.find('.todo-prog').html(`<i style="width:${Math.round(p.fatti / p.totale * 100)}%"></i>`);
    $b.find('.todo-list').html(p.passi.map(x => `
      <div class="todo-it ${x.fatto ? 'done' : ''}" data-k="${DRF.esc(x.chiave)}">
        <button type="button" class="todo-check ${x.fatto ? 'on' : ''}" data-k="${DRF.esc(x.chiave)}" title="${x.auto ? DRF.__('Passo automatico') : DRF.__('Segna come fatto')}">${x.fatto ? DRF.icons.html('check', 'fa-solid fa-check') : ''}</button>
        <span class="todo-label">${DRF.esc(x.label)}</span>
        ${x.auto ? `<i class="todo-auto" title="${DRF.__('Si spunta da solo')}">${DRF.icons.html('bolt', 'fa-solid fa-bolt')}</i>` : ''}
      </div>`).join(''));
    $b.find('.todo-panel').prop('hidden', !st.aperto);
    $b.toggleClass('open', st.aperto);
    DRF.icons.apply($b[0]);
  }
  function espandi(b) { st.aperto = b; render(); }

  const A = {
    /** Ricarica il percorso corrente (i passi automatici vengono riverificati sul server) */
    refresh(espandiSeNuovo) {
      if (!DRF.can('assistente.usa')) return $.Deferred().resolve().promise();
      return DRF.api.get('assistente', 'corrente').then(d => {
        st.attivo = d.attivo;
        const nuovo = d.percorso && (!st.p || d.percorso.id !== st.p.id);
        st.p = d.percorso;
        if (nuovo && espandiSeNuovo) st.aperto = true;
        render();
        return d;
      });
    },
    /** Apre un percorso da codice: DRF.assistente.apri('nuovo_paziente', pazienteId, 'etichetta') */
    apri(percorso, rifId, etichetta) {
      return DRF.api.post('assistente', 'apri', { percorso, rif_id: rifId || null, etichetta: etichetta || '' }).then(d => { st.p = d.percorso; st.aperto = true; render(); });
    },
    toggle() {
      if (!st.p) return A.refresh(true).then(d => { if (!d.percorso) DRF.ui.toast(DRF.__('Nessun percorso aperto: si apre da solo (es. nuovo paziente) o da codice con DRF.assistente.apri()'), 'info'); });
      espandi(!st.aperto);
    },
  };

  $(function () {
    A.refresh(false);
    DRF.on('modulo:aperto', () => { if (st.p) A.refresh(false); });
    $(document).on('keydown', e => { if (e.key !== 'F2') return; e.preventDefault(); if (!$('#modal').hasClass('open')) A.toggle(); });
  });
  return A;
})(jQuery);
