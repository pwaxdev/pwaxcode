<?php
/** ZIP minimale senza compressione (metodo "store"): nessuna dipendenza da ext-zip.
    Sufficiente per gli export (XML, CSV): i lettori zip lo aprono tutti. */
final class ZipSemplice
{
    private array $file = [];

    public function aggiungi(string $nome, string $contenuto): void { $this->file[] = [$nome, $contenuto]; }

    public function contenuto(): string
    {
        $locale = ''; $centrale = ''; $offset = 0;
        foreach ($this->file as [$nome, $dati]) {
            $crc = crc32($dati); $len = strlen($dati); $n = strlen($nome);
            $testata = pack('VvvvvvVVVvv', 0x04034b50, 20, 0x0800, 0, 0, 0, $crc, $len, $len, $n, 0);
            $locale .= $testata . $nome . $dati;
            $centrale .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0x0800, 0, 0, 0, $crc, $len, $len, $n, 0, 0, 0, 0, 32, $offset) . $nome;
            $offset += strlen($testata) + $n + $len;
        }
        $fine = pack('VvvvvVVv', 0x06054b50, 0, 0, count($this->file), count($this->file), strlen($centrale), $offset, 0);
        return $locale . $centrale . $fine;
    }
}
