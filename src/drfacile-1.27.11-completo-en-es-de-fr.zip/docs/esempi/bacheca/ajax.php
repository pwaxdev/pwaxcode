<?php
/** Bacheca personale · endpoint: i numeri della giornata dell'utente collegato e le sue note */
$uid = fn() => (int) (Auth::utente()['id'] ?? 0);
return [
    'azioni' => [
        'giornata' => function () use ($uid) {
            $oggi = oggi(); $me = $uid();
            $visite = (int) Database::value("SELECT COUNT(*) FROM visite WHERE stato = 'chiusa' AND data = ?" . ($me ? ' AND utente_id = ?' : ''), $me ? [$oggi, $me] : [$oggi]);
            $aperte = (int) Database::value("SELECT COUNT(*) FROM visite WHERE stato = 'bozza'");
            $fat = Database::one("SELECT COUNT(*) n, COALESCE(SUM(totale), 0) t FROM fatture WHERE data = ?", [$oggi]);
            $inc = (float) Database::value("SELECT COALESCE(SUM(totale), 0) FROM fatture WHERE stato = 'pagata' AND pagata_il = ?", [$oggi]);
            $nuovi = (int) Database::value("SELECT COUNT(*) FROM pazienti WHERE creato_il LIKE ?", [$oggi . '%']);
            $prossimi = (int) Database::value("SELECT COUNT(*) FROM appuntamenti WHERE data = ? AND stato = 'prenotato' AND ora > ?", [$oggi, date('H:i')]);
            return ['visite' => $visite, 'aperte' => $aperte, 'fatture' => (int) $fat['n'], 'fatturato' => (float) $fat['t'], 'incassato' => $inc, 'nuovi' => $nuovi, 'prossimi' => $prossimi, 'utente' => Auth::utente()['nome_completo'] ?? ''];
        },
        'note' => fn() => ['note' => Impostazione::get('bacheca_note_' . $uid())],
        'salva_note' => function (array $in) use ($uid) { Impostazione::set('bacheca_note_' . $uid(), mb_substr(Api::str($in, 'note'), 0, 4000)); return ['ok' => true]; },
    ],
    'permessi' => null,   // basta essere collegati: sono dati propri
];
