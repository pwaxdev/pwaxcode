<?php
/**
 * DRFacile · bootstrap
 * Carica la configurazione (config/config.php), autoload, sessione e database. Va incluso da ogni entry point (index.php, login.php, ajax/*.php).
 */
declare(strict_types=1);

if (!defined('DRF_ROOT')) {
    define('DRF_ROOT', dirname(__DIR__));
}

require_once DRF_ROOT . '/core/Config.php';
if (!is_file(DRF_ROOT . '/config/config.php')) {
    // Prima installazione. L'esempio contiene credenziali NOTE (medico / drfacile): lo copiamo da soli
    // solo su una macchina di sviluppo (CLI, server integrato di PHP, o richiesta dal computer stesso).
    // Su un server raggiungibile dalla rete il file va creato a mano, così la password si cambia PRIMA di andare online.
    $locale = PHP_SAPI === 'cli' || PHP_SAPI === 'cli-server' || in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
    if ($locale && is_file(DRF_ROOT . '/config/config.esempio.php')) {
        copy(DRF_ROOT . '/config/config.esempio.php', DRF_ROOT . '/config/config.php');
    } else {
        http_response_code(503);
        header('Content-Type: text/plain; charset=utf-8');
        exit("DRFacile non è ancora configurato.\n\nCopia config/config.esempio.php in config/config.php, imposta una password diversa da quella predefinita\n(php -r 'echo password_hash(\"nuova-password\", PASSWORD_DEFAULT);') e app.debug = false, poi ricarica la pagina.\n");
    }
}
Config::init(require DRF_ROOT . '/config/config.php');

date_default_timezone_set(Config::get('app.timezone', 'Europe/Rome'));
error_reporting(E_ALL);
ini_set('display_errors', Config::get('app.debug') ? '1' : '0');
ini_set('log_errors', '1');
mb_internal_encoding('UTF-8');

// Autoload: core/, core/models/, core/procedure/, form/
spl_autoload_register(function (string $class): void {
    foreach ([DRF_ROOT . '/core/', DRF_ROOT . '/core/models/', DRF_ROOT . '/core/procedure/', DRF_ROOT . '/form/'] as $dir) {
        $file = $dir . $class . '.php';
        if (is_file($file)) { require_once $file; return; }
    }
});
I18n::init();   // lingua di config (app.locale); dopo il login vince la preferenza dell'utente


require_once DRF_ROOT . '/core/Helpers.php';

// Sessione (mai da riga di comando: gli strumenti CLI non ne hanno bisogno)
if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_NONE) {
    session_name((string) Config::get('auth.session_name', 'DRFSESSID'));
    // sessioni in una cartella nostra: il garbage collector di sistema (spesso 10-24 minuti)
    // non può più cancellarle; la durata la decide auth.lifetime (default 8 ore di inattività)
    $vitaSessione = (int) Config::get('auth.lifetime', 28800);
    $dirSessioni = DRF_ROOT . '/data/sessioni';
    if (!is_dir($dirSessioni)) @mkdir($dirSessioni, 0775, true);
    if (is_writable($dirSessioni)) session_save_path($dirSessioni);
    ini_set('session.gc_maxlifetime', (string) max($vitaSessione, 28800));
    ini_set('session.use_strict_mode', '1');   // rifiuta id di sessione non generati dal server
    // Cookie Secure: dati sanitari, quindi solo HTTPS in produzione.
    //   auth.cookie_secure = 'auto' (default) → Secure quando la richiesta è HTTPS (anche dietro proxy)
    //                      = true            → sempre Secure (l'app è raggiungibile SOLO in HTTPS)
    //                      = false           → mai (solo sviluppo in HTTP)
    $sicuro = Config::get('auth.cookie_secure', 'auto');
    if ($sicuro === 'auto') $sicuro = drf_https();
    session_set_cookie_params(['lifetime' => $vitaSessione, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => (bool) $sicuro]);
    session_start();
}

// Database + installazione automatica alla prima esecuzione.
// Ordine: base (comune) → tenant → studio. Le tabelle comuni (studi, utenti, negozio) vengono create nel database
// base di config.php; poi, se l'utente in sessione appartiene a uno studio con database dedicato (studi.database),
// la connessione passa a quello e TUTTO il resto (installer, estensioni, scadenzario) lavora lì.
Config::override('app.version', Installer::VERSIONE);   // la versione viaggia con il codice, non con config.php
Database::init(Config::get('db'));
$drfBaseNuovo = !Database::tableExists('pazienti');
if ($drfBaseNuovo) {
    Installer::run();                                    // prima esecuzione in assoluto: il base ospita anche lo studio predefinito
} elseif (!Database::tableExists('impostazioni')) {
    // Installazione parziale: la prima esecuzione può essersi interrotta dopo aver creato `pazienti`
    // ma prima di completare lo schema. Non possiamo usare `pazienti` come unico indicatore di installazione
    // completata: Utente::migra() legge subito Impostazione::profilo() e, senza questa riparazione,
    // il secondo tentativo terminerebbe con "Table impostazioni doesn't exist".
    // aggiorna() è idempotente: crea TUTTE le tabelle/colonne mancanti e completa i seed senza perdere dati.
    Installer::aggiorna();
}
// Tabelle comuni (studi, utenti, negozio…): create/allineate una volta per sessione e per versione del programma,
// non a ogni richiesta (da CLI e alla prima installazione sempre)
$drfComune = Installer::VERSIONE . '/' . Installer::SCHEMA_COMUNE;
if ($drfBaseNuovo || PHP_SAPI === 'cli' || ($_SESSION['drf_comune'] ?? '') !== $drfComune) {
    Utente::tabelle();       // database comune: studi, utenti, password_reset e archivi di supporto condivisi
    Estensioni::tabelle();   // negozio delle estensioni: catalogo comune a tutti gli studi
    if (PHP_SAPI !== 'cli') $_SESSION['drf_comune'] = $drfComune;
}
// In modalità demo il dataset deve esistere anche se la prima installazione era stata interrotta
// e successivamente riparata con Installer::aggiorna(). Il marcatore nel seed impedisce duplicazioni.
Seed::demoSeNecessario();
Utente::migra();             // migrazione dal monoutente: primo studio + primo utente dalle vecchie credenziali (solo se non c'è ancora nessun utente)
Tenant::risolvi();           // SaaS: dallo studio in sessione al suo database dedicato (se ne ha uno)
if (!empty($_SESSION['drf_user']) && ($drfLingua = (string) (Auth::utente()['lingua'] ?? '')) !== '') I18n::init($drfLingua);   // lingua dell'utente
if (!Database::tableExists('pazienti')) {
    if (!Tenant::base()) Config::override('app.demo', false);   // i dati dimostrativi sono solo per il base
    Installer::run();        // database dedicato appena creato: schema, impostazioni e archivi di base
} elseif (!Database::tableExists('impostazioni')) {
    // Anche un database dedicato può essere rimasto a metà durante la sua prima creazione.
    // Ripariamo lo schema prima di leggere qualunque impostazione.
    Installer::aggiorna();
} elseif (Impostazione::get('schema_versione') !== Installer::SCHEMA) {
    Installer::aggiorna();   // aggiornamento incrementale dello schema (nuove tabelle/colonne)
}
Estensioni::ripara();        // estensioni attive rimaste senza file (aggiornamento del programma): riscaricate dal repository
Estensioni::carica();        // hook server delle estensioni attive (estensioni/<codice>/estensione.php)
Estensioni::aggiornamenti(); // allinea le versioni installate al catalogo (il codice arriva con l'app)
Scadenzario::controlla();    // scadenzario universale senza cron: gira al primo accesso della giornata
if (!empty($_SESSION['drf_login_da_registrare'])) {   // l'accesso appena avvenuto, nel registro dello studio giusto
    Attivita::registra('accesso.login', null, null, (string) $_SESSION['drf_login_da_registrare']);
    unset($_SESSION['drf_login_da_registrare']);
}
unset($drfBaseNuovo, $drfComune);
