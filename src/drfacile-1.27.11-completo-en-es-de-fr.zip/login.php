<?php
/** DRFacile · accesso */
require __DIR__ . '/core/bootstrap.php';
if (Auth::check()) { header('Location: index.php'); exit; }
$errore = '';
$abb = ['stato' => 'non_gestito'];   // lo stato dell'abbonamento è dello STUDIO: si conosce solo dopo aver riconosciuto l'utente
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string) ($_POST['username'] ?? ''));
    $chiavi = RateLimit::chiavi('login', $username);   // per IP e per nome utente: 5 errori → 30 s, 10 → 5 min, 20 → 30 min
    if ($attesa = RateLimit::bloccato($chiavi)) $errore = RateLimit::messaggio($attesa);
    elseif (Auth::login($username, (string) ($_POST['password'] ?? ''))) {
        RateLimit::azzera($chiavi);
        $abb = Auth::abbonamento();   // ora la sessione sa qual è lo studio
        if ($abb['stato'] !== 'scaduto') { header('Location: index.php'); exit; }
        Auth::logout();   // credenziali giuste ma studio sospeso: nessuna sessione, solo la schermata di rinnovo
    } else { $blocco = RateLimit::fallito($chiavi); $errore = $blocco ? RateLimit::messaggio($blocco) : __('Utente o password non corretti'); }
}
?>
<!DOCTYPE html>
<html lang="<?= e(I18n::lingua()) ?>" data-theme="light">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= __('Accesso') ?> · <?= e(Config::get('app.name')) ?></title>
<link rel="icon" href="assets/images/favicon.svg">
<link rel="stylesheet" href="assets/vendor/fonts/fonts.css">
<link rel="stylesheet" href="assets/css/app.css">
<link rel="stylesheet" href="assets/css/login.css">
</head>
<body class="login-body">
<main class="login">
  <img class="login-logo" src="assets/images/logo.svg" alt="<?= e(Config::get('app.name')) ?>">
  <h1><?= __('Accedi al tuo studio') ?></h1>
  <p class="muted"><?= __('Il gestionale dello studio medico') ?></p>
  <?php if ($abb['stato'] === 'scaduto'): ?>
  <div class="login-blocco">
    <b><?= __('Abbonamento scaduto il') ?> <?= data_it($abb['scadenza']) ?></b>
    <p>L'accesso a DRFacile è sospeso. Rinnova l'abbonamento (<?= e($abb['periodo']) ?>) per riprendere da dove avevi lasciato: i tuoi dati sono al sicuro.</p>
    <a class="btn primary block" href="<?= e($abb['url']) ?>" target="_blank" rel="noopener"><?= __('Rinnova l\'abbonamento') ?></a>
  </div>
  <?php else: ?>
  <form method="post" autocomplete="on">
    <?php if ($errore): ?><div class="login-errore"><?= e($errore) ?></div><?php endif; ?>
    <?php if (isset($_GET['reimpostata'])): ?><div class="login-avviso"><?= __('Password reimpostata: accedi con quella nuova.') ?></div><?php endif; ?>
    <div class="field"><label for="u"><?= __('Utente') ?></label><input class="input" id="u" name="username" value="<?= e($_POST['username'] ?? '') ?>" autofocus required></div>
    <div class="field"><label for="p"><?= __('Password') ?></label><input class="input" id="p" type="password" name="password" required></div>
    <button class="btn primary block" type="submit"><?= __('Accedi') ?></button>
    <p class="login-links"><a href="recupero.php"><?= __('Password dimenticata?') ?></a></p>
  </form>
  <?php endif; ?>
  <p class="small muted login-hint"><a href="https://drfacile.it" target="_blank" rel="noopener">drfacile.it</a> v<?= e(Config::get('app.version')) ?><br>© 2025 <a href="https://nastech.it" target="_blank" rel="noopener">NASTech Srl</a></p>
</main>
</body>
</html>
